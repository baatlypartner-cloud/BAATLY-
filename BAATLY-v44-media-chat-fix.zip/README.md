## Latest patch — v44 media and chat fixes

See `BAATLY_V44_MEDIA_CHAT_FIXES.md` for details. This patch force-refreshes failed photo URLs from canonical storage keys, leaves normal-user message billing to the server (free user-to-user DMs), and restricts calls to approved hosts.

# BAATLY User App — v44

Native Android application built with Kotlin and Jetpack Compose.

## Open and build

1. Open this project root in Android Studio.
2. Use JDK 17 for the Gradle build.
3. Create `.env` from `.env.example` and populate the project's existing Supabase and Agora runtime configuration using your own values.
4. For a signed Release APK, configure the signing variables/secrets in your CI workflow. Do not commit the upload keystore or passwords.
5. Run `./gradlew :app:assembleRelease`.

The project `versionCode` is set to **44** and `versionName` is `1.0.44`.

## v42 social-media fixes

See `BAATLY_V42_SOCIAL_FIXES.md` for profile/Highlights, Followers/Following, private accounts, Story viewers, comments and targeted chat routing. See `BAATLY_V43_RECOMMENDATION_ENGINE.md` for the recommendation engine details. Its SQL migration is in `app/supabase/migrations/20261025_social_recommendation_engine.sql`; the corresponding migration and Edge Function update have already been applied to the connected BAATLY backend in this session.

## Build verification note

The changes are supplied as Android source in this ZIP, not as a verified APK. The Gradle 9.3.1 distribution could not be downloaded in the editing environment because the Gradle host was unreachable. Run the Release APK workflow in a network-enabled build environment and test the flows listed in `BAATLY_V42_SOCIAL_FIXES.md` on a physical device before publishing.

Earlier v40/v41 update notes remain in the repository for reference.


## v42 compile fix

The `SocialProfileScreen.kt` experimental Material3 API compiler diagnostics were addressed with `@OptIn(ExperimentalMaterial3Api::class)`. The source ZIP is not a compiled/verified APK; run the GitHub Actions Release build to validate in a network-enabled environment.
