# BAATLY v44 — Media Rendering and Chat/Call Rules

## Fixed in source

1. **Photo rendering / media URL choice**
   - Feed, search results, profile grid and profile-post dialog now prefer a fresh HTTP(S) media URL provided by the `baatly-r2-media` feed response instead of overriding it with the raw storage key.
   - If a photo fails to load, the UI force-refreshes the canonical `media_path` URL instead of reusing a cached/expired signed URL.
   - Story photos, profile-grid photos, search thumbnails and full-screen post images use the same retry behavior.
   - Post media type parsing is normalized from the declared type and the file extension, so image files are not incorrectly treated as videos.

2. **Free normal-user messaging**
   - Removed the app-side wallet pre-check for text, image and voice messages. The backend determines the actual recipient role and applies the paid host-chat rule, avoiding false balance errors caused by stale `isApprovedHost` conversation metadata.
   - The `send_message` database RPC was inspected: it charges only regular-user → approved-host messages, and returns zero charge for regular-user → regular-user messages and approved-host replies.
   - A balance failure reported by the backend now opens recharge UI only for a real paid-host-chat balance error.
   - `openChatWithHost` marks the conversation as an approved-host conversation so the composer and host-specific UI label are correct.
   - The chat header says "Free messages between users" and the composer says "Message..." for regular-user conversations.

3. **Calls restricted to approved hosts**
   - Direct-chat call button is displayed only for an approved-host conversation.
   - `BaatlyViewModel.startCall` rejects non-host targets before starting a call.
   - Backend `request_call` and `request_video_call` were inspected and already verify approved-host status; they reject regular-user-to-regular-user calls.

4. **Version**
   - `versionCode = 44`
   - `versionName = 1.0.44`

## Verification and limitation

- ZIP integrity is checked after packaging.
- Kotlin source parser check found no syntax/parser diagnostics in the edited files. The ad-hoc `kotlinc` check is not a full Android build because project dependencies are not available in that standalone invocation.
- Full Gradle compilation could not run in this environment: the Gradle wrapper could not resolve `services.gradle.org` (`UnknownHostException`). Build status therefore remains unverified until GitHub Actions runs successfully.
