package com.example

import android.app.Activity
import android.app.Application
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager

/**
 * BaatlyApplication provides a centralized, global application-level privacy protection
 * mechanism that enforces WindowManager.LayoutParams.FLAG_SECURE across every single Activity,
 * Dialog, and Window in the app.
 *
 * This guarantees:
 * 1. Screenshot capture is completely blocked on all screens.
 * 2. Screen recording capture is blocked (renders blank/black content according to Android OS security).
 * 3. Sensitive app previews are shielded in the Recent Apps / Task Switcher overview.
 * 4. Automatic future-proofing for any newly added Activity or component.
 */
class BaatlyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        setupGlobalSecureWindowPolicy()
    }

    /**
     * Registers ActivityLifecycleCallbacks to ensure every Activity launched within the
     * application automatically has FLAG_SECURE applied, without requiring any manual
     * per-screen code.
     */
    private fun setupGlobalSecureWindowPolicy() {
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                applyWindowProtection(activity)
            }

            override fun onActivityStarted(activity: Activity) {
                applyWindowProtection(activity)
            }

            override fun onActivityResumed(activity: Activity) {
                applyWindowProtection(activity)
            }

            override fun onActivityPaused(activity: Activity) {
                // Ensure protection remains active when paused or entering recent-apps overview
                applyWindowProtection(activity)
            }

            override fun onActivityStopped(activity: Activity) {}

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {}
        })
    }

    companion object {
        private const val TAG = "BaatlySecurity"

        /**
         * Applies comprehensive window security to the given Activity:
         * - Sets WindowManager.LayoutParams.FLAG_SECURE on the window.
         * - On Android 14+ (API 34+), explicitly disables screenshots in the recent tasks overview.
         */
        fun applyWindowProtection(activity: Activity) {
            try {
                activity.window.setFlags(
                    WindowManager.LayoutParams.FLAG_SECURE,
                    WindowManager.LayoutParams.FLAG_SECURE
                )

                // On Android 14+ (API 34+), explicitly disable recents screenshot preview
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    activity.setRecentsScreenshotEnabled(false)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to apply secure window flag: ${e.message}")
            }
        }
    }
}
