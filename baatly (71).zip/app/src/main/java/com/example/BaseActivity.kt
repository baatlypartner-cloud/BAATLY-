package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity

/**
 * BaseActivity provides a centralized Activity layer that guarantees
 * WindowManager.LayoutParams.FLAG_SECURE is applied across all Activity lifecycle states.
 * All existing and future Activities in the application can inherit from BaseActivity.
 */
abstract class BaseActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        BaatlyApplication.applyWindowProtection(this)
        super.onCreate(savedInstanceState)
        BaatlyApplication.applyWindowProtection(this)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        BaatlyApplication.applyWindowProtection(this)
    }

    override fun onResume() {
        super.onResume()
        BaatlyApplication.applyWindowProtection(this)
    }
}
