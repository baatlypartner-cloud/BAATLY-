-- ====================================================================
-- BAATLY SOCIAL SYSTEM FIX MIGRATION
-- Project: qewhxsbrnlgunygghpez
-- Version: 2026-10-09
-- ====================================================================

-- 1. User App Feed RPC that excludes the current user's own posts
-- Preserves visibility rules, moderation, blocking, lock/unlock rules, and follow state
CREATE OR REPLACE FUNCTION public.social_get_feed_user(
    p_limit integer DEFAULT 20,
    p_offset integer DEFAULT 0,
    p_feed_mode text DEFAULT 'for_you'
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_uid uuid;
    v_res json;
BEGIN
    v_uid := auth.uid();

    SELECT json_agg(t) INTO v_res FROM (
        SELECT 
            p.id,
            p.owner_id,
            COALESCE(u.raw_user_meta_data->>'display_name', u.email, 'Creator') AS display_name,
            u.raw_user_meta_data->>'avatar_url' AS avatar_url,
            COALESCE((u.raw_user_meta_data->>'is_host')::boolean, false) AS is_owner_host,
            (p.owner_id = v_uid) AS is_owner,
            COALESCE(p.is_locked, false) AS is_locked,
            CASE 
                WHEN p.owner_id = v_uid THEN true
                WHEN NOT COALESCE(p.is_locked, false) THEN true
                WHEN EXISTS (
                    SELECT 1 FROM public.social_unlocked_content uc 
                    WHERE uc.content_type = 'post' AND uc.content_id = p.id AND uc.user_id = v_uid
                ) THEN true
                ELSE false
            END AS is_unlocked,
            COALESCE(p.unlock_price_rupees, 1.0) AS unlock_price_rupees,
            p.media_path,
            COALESCE(p.media_bucket, 'social-media') AS media_bucket,
            p.media_type,
            p.caption,
            p.published_at,
            p.created_at,
            COALESCE(p.likes_count, 0) AS likes_count,
            COALESCE(p.love_notes_count, 0) AS love_notes_count,
            COALESCE(p.views_count, 0) AS views_count,
            EXISTS (
                SELECT 1 FROM public.social_likes l 
                WHERE l.content_type = 'post' AND l.content_id = p.id AND l.user_id = v_uid
            ) AS is_liked,
            EXISTS (
                SELECT 1 FROM public.social_follows f 
                WHERE f.follower_id = v_uid AND f.target_user_id = p.owner_id
            ) AS is_following,
            true AS can_love_note,
            true AS can_voice_call,
            true AS can_video_call
        FROM public.social_posts p
        LEFT JOIN auth.users u ON u.id = p.owner_id
        WHERE 
            -- HIDE CURRENT USER'S OWN POSTS FROM PUBLIC FEED
            (v_uid IS NULL OR p.owner_id <> v_uid)
            -- Follow mode filter
            AND (
                p_feed_mode <> 'following'
                OR EXISTS (
                    SELECT 1 FROM public.social_follows f 
                    WHERE f.follower_id = v_uid AND f.target_user_id = p.owner_id
                )
            )
            -- Exclude blocked users if table exists
            AND NOT EXISTS (
                SELECT 1 FROM public.blocked_users b 
                WHERE (b.blocker_id = v_uid AND b.blocked_id = p.owner_id)
                   OR (b.blocker_id = p.owner_id AND b.blocked_id = v_uid)
            )
        ORDER BY p.created_at DESC
        LIMIT p_limit OFFSET p_offset
    ) t;

    RETURN COALESCE(v_res, '[]'::json);
END;
$$;

GRANT EXECUTE ON FUNCTION public.social_get_feed_user(integer, integer, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.social_get_feed_user(integer, integer, text) TO anon;

-- 2. Secure Story Deletion RPC
CREATE OR REPLACE FUNCTION public.social_delete_story(
    p_story_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_uid uuid;
    v_media_path text;
BEGIN
    v_uid := auth.uid();
    IF v_uid IS NULL THEN
        RAISE EXCEPTION 'Authentication required';
    END IF;

    -- Verify ownership
    SELECT media_path INTO v_media_path
    FROM public.social_stories
    WHERE id = p_story_id AND owner_id = v_uid;

    IF v_media_path IS NULL THEN
        RAISE EXCEPTION 'Story not found or you do not have permission to delete it';
    END IF;

    -- Delete related non-financial records
    DELETE FROM public.social_story_views WHERE story_id = p_story_id;
    DELETE FROM public.social_likes WHERE content_type = 'story' AND content_id = p_story_id;
    
    -- Delete the story itself
    DELETE FROM public.social_stories WHERE id = p_story_id AND owner_id = v_uid;

    RETURN json_build_object(
        'success', true,
        'story_id', p_story_id,
        'media_path', v_media_path
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.social_delete_story(uuid) TO authenticated;

-- 3. Profile Posts Retrieval RPC
CREATE OR REPLACE FUNCTION public.social_get_profile_posts(
    p_target_user_id uuid,
    p_limit integer DEFAULT 30,
    p_offset integer DEFAULT 0
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_uid uuid;
    v_res json;
BEGIN
    v_uid := auth.uid();

    SELECT json_agg(t) INTO v_res FROM (
        SELECT 
            p.id,
            p.owner_id,
            COALESCE(u.raw_user_meta_data->>'display_name', u.email, 'Creator') AS display_name,
            u.raw_user_meta_data->>'avatar_url' AS avatar_url,
            COALESCE((u.raw_user_meta_data->>'is_host')::boolean, false) AS is_owner_host,
            (p.owner_id = v_uid) AS is_owner,
            COALESCE(p.is_locked, false) AS is_locked,
            CASE 
                WHEN p.owner_id = v_uid THEN true
                WHEN NOT COALESCE(p.is_locked, false) THEN true
                WHEN EXISTS (
                    SELECT 1 FROM public.social_unlocked_content uc 
                    WHERE uc.content_type = 'post' AND uc.content_id = p.id AND uc.user_id = v_uid
                ) THEN true
                ELSE false
            END AS is_unlocked,
            COALESCE(p.unlock_price_rupees, 1.0) AS unlock_price_rupees,
            p.media_path,
            COALESCE(p.media_bucket, 'social-media') AS media_bucket,
            p.media_type,
            p.caption,
            p.published_at,
            p.created_at,
            COALESCE(p.likes_count, 0) AS likes_count,
            COALESCE(p.love_notes_count, 0) AS love_notes_count,
            COALESCE(p.views_count, 0) AS views_count,
            EXISTS (
                SELECT 1 FROM public.social_likes l 
                WHERE l.content_type = 'post' AND l.content_id = p.id AND l.user_id = v_uid
            ) AS is_liked,
            EXISTS (
                SELECT 1 FROM public.social_follows f 
                WHERE f.follower_id = v_uid AND f.target_user_id = p.owner_id
            ) AS is_following,
            true AS can_love_note,
            true AS can_voice_call,
            true AS can_video_call
        FROM public.social_posts p
        LEFT JOIN auth.users u ON u.id = p.owner_id
        WHERE p.owner_id = p_target_user_id
        ORDER BY p.created_at DESC
        LIMIT p_limit OFFSET p_offset
    ) t;

    RETURN COALESCE(v_res, '[]'::json);
END;
$$;

GRANT EXECUTE ON FUNCTION public.social_get_profile_posts(uuid, integer, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.social_get_profile_posts(uuid, integer, integer) TO anon;
