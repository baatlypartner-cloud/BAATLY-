package com.example.ui.social

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.SocialPost
import com.example.data.model.SocialStory
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.BaatlyTopBar
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val walletSummary by viewModel.walletSummary.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val posts by viewModel.socialPosts.collectAsState()
    val stories by viewModel.socialStories.collectAsState()
    val isLoading by viewModel.isSocialLoading.collectAsState()
    val feedMode by viewModel.socialFeedMode.collectAsState()

    val effectivePricing by viewModel.effectivePricing.collectAsState()
    val isSocialActionInFlight by viewModel.isSocialActionInFlight.collectAsState()
    val activeLikeOperations by viewModel.activeLikeOperations.collectAsState()
    val activeUnlockOperations by viewModel.activeUnlockOperations.collectAsState()

    var showCreatePostDialog by remember { mutableStateOf(false) }
    var showCreateStoryDialog by remember { mutableStateOf(false) }
    var selectedStoryForViewer by remember { mutableStateOf<SocialStory?>(null) }
    var activeLoveNotePost by remember { mutableStateOf<SocialPost?>(null) }

    // Initial load
    LaunchedEffect(Unit) {
        viewModel.refreshSocialFeed()
    }

    // Photo pickers
    val postImagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val tempFile = File(context.cacheDir, "social_post_${System.currentTimeMillis()}.jpg")
                    tempFile.outputStream().use { output -> inputStream?.copyTo(output) }
                    viewModel.createSocialPost(
                        mediaFile = tempFile,
                        caption = "Shared on Baatly Social",
                        onComplete = { showCreatePostDialog = false }
                    )
                } catch (e: Exception) {
                    viewModel.showUserMessage("Failed to process photo")
                }
            }
        }
    }

    val storyImagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val tempFile = File(context.cacheDir, "social_story_${System.currentTimeMillis()}.jpg")
                    tempFile.outputStream().use { output -> inputStream?.copyTo(output) }
                    viewModel.createSocialStory(
                        mediaFile = tempFile,
                        caption = "My Story",
                        onComplete = { showCreateStoryDialog = false }
                    )
                } catch (e: Exception) {
                    viewModel.showUserMessage("Failed to process story photo")
                }
            }
        }
    }

    Scaffold(
        topBar = {
            BaatlyTopBar(
                walletBalanceRupees = walletSummary.availableBalanceRupees,
                onWalletClick = { viewModel.setScreen(Screen.WALLET) },
                onNotificationClick = { viewModel.setScreen(Screen.NOTIFICATIONS) },
                unreadNotifications = notifications.count { !it.isRead },
                onRefreshClick = { viewModel.refreshSocialFeed() }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreatePostDialog = true },
                containerColor = VibrantPink,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("fab_create_social_post")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Create Post")
            }
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Mode Segment (For You / Following)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = feedMode == "for_you",
                    onClick = { viewModel.setSocialFeedMode("for_you") },
                    label = { Text("For You") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VibrantPink,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("chip_for_you")
                )
                FilterChip(
                    selected = feedMode == "following",
                    onClick = { viewModel.setSocialFeedMode("following") },
                    label = { Text("Following") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VibrantPink,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("chip_following")
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Stories Row
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Stories",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            ),
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                        )
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Add Story item
                            item {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.clickable { storyImagePickerLauncher.launch("image/*") }
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(CircleShape)
                                            .background(DarkSurface)
                                            .border(2.dp, DarkCardBorder, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Add,
                                            contentDescription = "Add Story",
                                            tint = VibrantPink,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Add Story",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextSecondary
                                        )
                                    )
                                    Text(
                                        text = "₹${effectivePricing.socialStoryCreationRateRupees.toInt()}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            color = PrimaryLavender
                                        )
                                    )
                                }
                            }

                            items(stories) { story ->
                                StoryAvatarItem(
                                    story = story,
                                    viewModel = viewModel,
                                    effectivePricing = effectivePricing,
                                    onClick = {
                                        if (story.isLocked && !story.isUnlocked) {
                                            viewModel.unlockSocialStory(story) {
                                                selectedStoryForViewer = story
                                            }
                                        } else {
                                            selectedStoryForViewer = story
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                // Feed Section
                if (isLoading && posts.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = VibrantPink)
                        }
                    }
                } else if (posts.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = if (feedMode == "following") "No posts from followed hosts yet" else "No posts yet",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = TextSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = { viewModel.refreshSocialFeed() },
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text("Refresh", color = VibrantPink)
                                }
                            }
                        }
                    }
                } else {
                    items(posts, key = { it.id }) { post ->
                        SocialPostCard(
                            post = post,
                            viewModel = viewModel,
                            effectivePricing = effectivePricing,
                            isLiking = activeLikeOperations.contains(post.id),
                            isUnlocking = activeUnlockOperations.contains(post.id),
                            onLoveNoteClick = { activeLoveNotePost = post }
                        )
                    }
                }
            }
        }
    }

    // Story Viewer Dialog
    selectedStoryForViewer?.let { story ->
        StoryViewerDialog(
            story = story,
            viewModel = viewModel,
            onDismiss = { selectedStoryForViewer = null }
        )
    }

    // Love Note Sheet for Post
    activeLoveNotePost?.let { post ->
        SocialLoveNoteDialog(
            post = post,
            viewModel = viewModel,
            onDismiss = { activeLoveNotePost = null }
        )
    }

    // Create Post Dialog
    if (showCreatePostDialog) {
        val postCost = effectivePricing.socialPostCreationRateRupees.toInt()
        AlertDialog(
            onDismissRequest = { if (!isSocialActionInFlight) showCreatePostDialog = false },
            title = { Text("Create Social Post", color = TextPrimary) },
            text = {
                Text(
                    "Share a photo on Baatly Social feed. User posts cost ₹$postCost from your wallet balance.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        postImagePickerLauncher.launch("image/*")
                    },
                    enabled = !isSocialActionInFlight,
                    colors = ButtonDefaults.buttonColors(containerColor = VibrantPink)
                ) {
                    Text("Select Photo (₹$postCost)")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCreatePostDialog = false },
                    enabled = !isSocialActionInFlight
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun StoryAvatarItem(
    story: SocialStory,
    viewModel: BaatlyViewModel,
    effectivePricing: com.example.data.model.EffectiveUserPricing,
    onClick: () -> Unit
) {
    var resolvedAvatar by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(story.creatorAvatarUrl) {
        resolvedAvatar = viewModel.dataService.resolveProfileAvatarUrl(story.creatorAvatarUrl)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .border(
                    width = 2.5.dp,
                    color = if (story.isLocked && !story.isUnlocked) SecondaryAmber else VibrantPink,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (!resolvedAvatar.isNullOrBlank()) {
                AsyncImage(
                    model = resolvedAvatar,
                    contentDescription = story.creatorName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(PrimaryLavenderContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = story.creatorName.take(1).uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = PrimaryLavenderDark
                        )
                    )
                }
            }

            if (story.isLocked && !story.isUnlocked) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(SecondaryAmber),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Locked",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = story.creatorName.take(8),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
        )
        if (story.isLocked && !story.isUnlocked) {
            val storyUnlockCost = if (story.unlockPriceRupees > 0.0) story.unlockPriceRupees.toInt() else effectivePricing.socialStoryUnlockRateRupees.toInt()
            Text(
                text = "₹$storyUnlockCost",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    color = SecondaryAmber,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

@Composable
private fun SocialPostCard(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    effectivePricing: com.example.data.model.EffectiveUserPricing,
    isLiking: Boolean,
    isUnlocking: Boolean,
    onLoveNoteClick: () -> Unit
) {
    var resolvedAvatar by remember { mutableStateOf<String?>(null) }
    var resolvedMedia by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(post.creatorAvatarUrl) {
        resolvedAvatar = viewModel.dataService.resolveProfileAvatarUrl(post.creatorAvatarUrl)
    }

    LaunchedEffect(post.mediaPath, post.mediaUrl, post.isUnlocked) {
        if (!post.isLocked || post.isUnlocked) {
            val rawPath = post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
            resolvedMedia = viewModel.dataService.resolveSocialMediaUrl(rawPath, isStory = false, explicitBucket = post.mediaBucket)
        }
    }

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag("post_card_${post.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header: Author Avatar & Name & Follow
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!resolvedAvatar.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAvatar,
                            contentDescription = post.creatorName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(PrimaryLavenderContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = post.creatorName.take(1).uppercase(),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryLavenderDark
                                )
                            )
                        }
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = post.creatorName,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            if (post.isHost) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Verified Host",
                                    tint = PrimaryLavender,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        if (post.createdAt.isNotBlank()) {
                            Text(
                                text = post.createdAt.take(10),
                                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                            )
                        }
                    }
                }

                // Follow button
                TextButton(
                    onClick = { viewModel.toggleSocialFollow(post.userId) },
                    modifier = Modifier.testTag("btn_follow_${post.id}")
                ) {
                    Text(
                        text = if (post.isFollowing) "Following" else "+ Follow",
                        color = if (post.isFollowing) TextSecondary else VibrantPink,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            // Post Media / Paywall
            if (post.isLocked && !post.isUnlocked) {
                val postUnlockCost = if (post.unlockPriceRupees > 0.0) post.unlockPriceRupees.toInt() else effectivePricing.socialPostUnlockRateRupees.toInt()
                // Locked Paywall UI
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(Color(0xFF1F1D24)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = "Locked Post",
                            tint = SecondaryAmber,
                            modifier = Modifier.size(44.dp)
                        )
                        Text(
                            text = "Exclusive Host Content",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "Unlock this post for direct ₹$postUnlockCost to support ${post.creatorName}.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        )
                        Button(
                            onClick = { viewModel.unlockSocialPost(post) },
                            enabled = !isUnlocking,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VibrantPink,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("btn_unlock_post_${post.id}")
                        ) {
                            Text(
                                text = if (isUnlocking) "Unlocking..." else "Unlock for ₹$postUnlockCost",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            } else if (!resolvedMedia.isNullOrBlank()) {
                // Unlocked Image — tap opens Full-Screen Media Viewer
                AsyncImage(
                    model = resolvedMedia,
                    contentDescription = post.caption,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 220.dp, max = 340.dp)
                        .clickable {
                            viewModel.openFullScreenMedia(resolvedMedia!!, type = post.mediaType)
                        }
                )
            }

            // Caption
            if (post.caption.isNotBlank()) {
                Text(
                    text = post.caption,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextPrimary,
                        lineHeight = 20.sp
                    ),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }

            HorizontalDivider(color = DarkBorderSubtle)

            // Actions: Like, Love Note
            val likeCost = effectivePricing.socialLikeRateRupees.toInt()
            val loveNoteCost = effectivePricing.socialLoveNoteRateRupees.toInt()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Like Button (Double-tap guarded)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(enabled = !isLiking) { viewModel.toggleSocialLike(post) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("btn_like_${post.id}")
                ) {
                    Icon(
                        imageVector = if (post.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (post.isLiked) VibrantPink else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (post.likesCount > 0) "${post.likesCount} • ₹$likeCost" else "Like • ₹$likeCost",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = if (post.isLiked) VibrantPink else TextSecondary
                        )
                    )
                }

                // Love Note Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onLoveNoteClick() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("btn_love_note_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Mail,
                        contentDescription = "Love Note",
                        tint = PrimaryLavender,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (post.loveNotesCount > 0) "Love Note (${post.loveNotesCount}) • ₹$loveNoteCost" else "Love Note • ₹$loveNoteCost",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = PrimaryLavender
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun StoryViewerDialog(
    story: SocialStory,
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit
) {
    var resolvedMedia by remember { mutableStateOf<String?>(null) }
    var showStoryLoveNoteDialog by remember { mutableStateOf(false) }

    LaunchedEffect(story.mediaPath, story.mediaUrl) {
        val rawPath = story.mediaPath?.takeIf { it.isNotBlank() } ?: story.mediaUrl
        resolvedMedia = viewModel.dataService.resolveSocialMediaUrl(rawPath, isStory = true, explicitBucket = story.mediaBucket)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.Black,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (!resolvedMedia.isNullOrBlank()) {
                    AsyncImage(
                        model = resolvedMedia,
                        contentDescription = story.caption,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                viewModel.openFullScreenMedia(resolvedMedia!!, type = "image")
                            }
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color.White)
                    }
                }

                // Header with Creator name & Close
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = story.creatorName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                // Bottom Caption & Love Note Action
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (story.caption.isNotBlank()) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = story.caption,
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    Button(
                        onClick = { showStoryLoveNoteDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Mail, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Love Note to ${story.creatorName}", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showStoryLoveNoteDialog) {
        val effectivePricing by viewModel.effectivePricing.collectAsState()
        val isSocialActionInFlight by viewModel.isSocialActionInFlight.collectAsState()
        val loveNoteCost = effectivePricing.socialLoveNoteRateRupees.toInt()
        var text by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { if (!isSocialActionInFlight) showStoryLoveNoteDialog = false },
            title = { Text("Reply to Story with Love Note 💌", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Sending a Love Note on ${story.creatorName}'s story costs direct ₹$loveNoteCost from your wallet.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        placeholder = { Text("Write your reply...") },
                        enabled = !isSocialActionInFlight,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.sendSocialLoveNote(
                            contentType = "story",
                            contentId = story.id,
                            messageText = text,
                            onComplete = {
                                showStoryLoveNoteDialog = false
                            }
                        )
                    },
                    enabled = text.isNotBlank() && !isSocialActionInFlight,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender)
                ) {
                    Text(if (isSocialActionInFlight) "Sending..." else "Send for ₹$loveNoteCost")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showStoryLoveNoteDialog = false },
                    enabled = !isSocialActionInFlight
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun SocialLoveNoteDialog(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit
) {
    val effectivePricing by viewModel.effectivePricing.collectAsState()
    val isSocialActionInFlight by viewModel.isSocialActionInFlight.collectAsState()
    val loveNoteCost = effectivePricing.socialLoveNoteRateRupees.toInt()
    var text by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = { if (!isSocialActionInFlight) onDismiss() },
        title = { Text("Send a Love Note 💌", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Sending a Love Note on ${post.creatorName}'s post costs direct ₹$loveNoteCost from your wallet.",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("Write your Love Note...") },
                    enabled = !isSocialActionInFlight,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.sendSocialLoveNote(
                        contentType = "post",
                        contentId = post.id,
                        messageText = text,
                        onComplete = onDismiss
                    )
                },
                enabled = text.isNotBlank() && !isSocialActionInFlight,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender)
            ) {
                Text(if (isSocialActionInFlight) "Sending..." else "Send for ₹$loveNoteCost")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                enabled = !isSocialActionInFlight
            ) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
