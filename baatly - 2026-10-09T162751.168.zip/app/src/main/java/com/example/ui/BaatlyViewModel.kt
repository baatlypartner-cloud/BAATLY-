package com.example.ui

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AgoraCallManager
import com.example.data.audio.AudioPlayerManager
import com.example.data.audio.AudioRecorderManager
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.network.SupabaseAuthService
import com.example.data.network.SupabaseClient
import com.example.data.network.SupabaseConfig
import com.example.data.network.SupabaseDataService
import com.example.data.notification.NotificationHelper
import com.example.domain.BillingEngine
import com.example.ui.payment.UroPayCheckoutLauncher
import com.example.util.BaatlyAnalytics
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class Screen {
    AUTH,
    HOME,
    HOST_PROFILE,
    ACTIVE_CALL,
    DIRECT_CHAT,
    BAATLY_SYSTEM_CHAT,
    CHAT_LIST,
    WALLET,
    RECENT_CALLS,
    PROFILE,
    NOTIFICATIONS,
    LEGAL_DETAIL,
    ASTROLOGER,
    SOCIAL,
    FULL_SCREEN_MEDIA_VIEWER
}

enum class HomeMode {
    CALL,
    VIDEO,
    CHAT
}

enum class CallState {
    IDLE,
    REQUESTING,
    RINGING,
    CONNECTED,
    ENDED,
    REJECTED
}

class BaatlyViewModel(application: Application) : AndroidViewModel(application) {

    val sessionManager = SessionManager(application)
    private val supabaseClient = SupabaseClient(sessionManager)
    val authService = SupabaseAuthService(supabaseClient, sessionManager)
    val dataService = SupabaseDataService(supabaseClient, sessionManager)

    private val _effectivePricing = MutableStateFlow<EffectiveUserPricing>(EffectiveUserPricing.DEFAULT)
    val effectivePricing: StateFlow<EffectiveUserPricing> = _effectivePricing.asStateFlow()

    private val _previousScreen = MutableStateFlow<Screen>(Screen.HOME)
    val previousScreen: StateFlow<Screen> = _previousScreen.asStateFlow()

    val agoraCallManager = AgoraCallManager(application)
    val audioRecorderManager = AudioRecorderManager(application)
    val audioPlayerManager = AudioPlayerManager(application)
    val realtimeManager = com.example.data.network.SupabaseRealtimeManager(supabaseClient.okHttpClient, sessionManager)

    // User & Auth State
    val isLoggedIn = sessionManager.accessToken
    val currentUser = sessionManager.currentUser
    val wallet = sessionManager.wallet
    val isOnboardingCompleted = sessionManager.isOnboardingCompletedFlow

    fun completeOnboarding() {
        sessionManager.setOnboardingCompleted(true)
    }

    private val _isRestoringSession = MutableStateFlow(sessionManager.isLoggedIn && sessionManager.currentUser.value == null)
    val isRestoringSession: StateFlow<Boolean> = _isRestoringSession.asStateFlow()

    private val _startupError = MutableStateFlow<String?>(null)
    val startupError: StateFlow<String?> = _startupError.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _userIdAvailable = MutableStateFlow<Boolean?>(null)
    val userIdAvailable: StateFlow<Boolean?> = _userIdAvailable.asStateFlow()

    // Navigation & Screen State
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _homeMode = MutableStateFlow(HomeMode.CALL)
    val homeMode: StateFlow<HomeMode> = _homeMode.asStateFlow()

    // Partners State
    private val _availablePartners = MutableStateFlow<List<PartnerProfile>>(emptyList())
    val availablePartners: StateFlow<List<PartnerProfile>> = _availablePartners.asStateFlow()

    private val _isLoadingPartners = MutableStateFlow(false)
    val isLoadingPartners: StateFlow<Boolean> = _isLoadingPartners.asStateFlow()

    private val _selectedPartner = MutableStateFlow<PartnerProfile?>(null)
    val selectedPartner: StateFlow<PartnerProfile?> = _selectedPartner.asStateFlow()

    // Call State
    private val _activeCall = MutableStateFlow<CallRecord?>(null)
    val activeCall: StateFlow<CallRecord?> = _activeCall.asStateFlow()

    private val _activeCallPartner = MutableStateFlow<PartnerProfile?>(null)
    val activeCallPartner: StateFlow<PartnerProfile?> = _activeCallPartner.asStateFlow()

    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _callRemainingSeconds = MutableStateFlow(0)
    val callRemainingSeconds: StateFlow<Int> = _callRemainingSeconds.asStateFlow()

    private val _callElapsedSeconds = MutableStateFlow(0)
    val callElapsedSeconds: StateFlow<Int> = _callElapsedSeconds.asStateFlow()

    private val _pendingVideoPermissionsRequired = MutableStateFlow(false)
    val pendingVideoPermissionsRequired: StateFlow<Boolean> = _pendingVideoPermissionsRequired.asStateFlow()
    private var pendingVideoJoin: (() -> Unit)? = null

    fun onVideoPermissionsGranted() {
        _pendingVideoPermissionsRequired.value = false
        val joinAction = pendingVideoJoin
        pendingVideoJoin = null
        joinAction?.invoke()
    }

    fun onVideoPermissionsDenied() {
        _pendingVideoPermissionsRequired.value = false
        pendingVideoJoin = null
        showUserMessage("Camera permission is required for video calls.")
        endCall()
    }

    private var callTimerJob: Job? = null
    private var callEnforcementJob: Job? = null

    // Chat State
    private val _conversations = MutableStateFlow<List<ConversationSummary>>(emptyList())
    val conversations: StateFlow<List<ConversationSummary>> = _conversations.asStateFlow()

    private val _activeConversation = MutableStateFlow<ConversationSummary?>(null)
    val activeConversation: StateFlow<ConversationSummary?> = _activeConversation.asStateFlow()

    private val _chatPartner = MutableStateFlow<PartnerProfile?>(null)
    val chatPartner: StateFlow<PartnerProfile?> = _chatPartner.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isChatBlocked = MutableStateFlow(false)
    val isChatBlocked: StateFlow<Boolean> = _isChatBlocked.asStateFlow()

    private val _chatBlockStatus = MutableStateFlow<com.example.data.model.UserBlockStatus?>(null)
    val chatBlockStatus: StateFlow<com.example.data.model.UserBlockStatus?> = _chatBlockStatus.asStateFlow()

    // Gifts State
    private val _gifts = MutableStateFlow<List<GiftItem>>(emptyList())
    val gifts: StateFlow<List<GiftItem>> = _gifts.asStateFlow()

    private val _showGiftSheet = MutableStateFlow(false)
    val showGiftSheet: StateFlow<Boolean> = _showGiftSheet.asStateFlow()

    private val _recentGiftAnimation = MutableStateFlow<GiftItem?>(null)
    val recentGiftAnimation: StateFlow<GiftItem?> = _recentGiftAnimation.asStateFlow()

    // Wallet & Payments State
    private val _walletSummary = MutableStateFlow(WalletSummary())
    val walletSummary: StateFlow<WalletSummary> = _walletSummary.asStateFlow()

    private val _isWalletLoading = MutableStateFlow(false)
    val isWalletLoading: StateFlow<Boolean> = _isWalletLoading.asStateFlow()

    private val _walletError = MutableStateFlow<String?>(null)
    val walletError: StateFlow<String?> = _walletError.asStateFlow()

    private val _isWalletInitialized = MutableStateFlow(false)
    val isWalletInitialized: StateFlow<Boolean> = _isWalletInitialized.asStateFlow()

    private val _rechargePackages = MutableStateFlow<List<WalletRechargePackage>>(emptyList())
    val rechargePackages: StateFlow<List<WalletRechargePackage>> = _rechargePackages.asStateFlow()

    private val _uropayPaymentState = MutableStateFlow<UroPayPaymentUiState>(UroPayPaymentUiState.Idle)
    val uropayPaymentState: StateFlow<UroPayPaymentUiState> = _uropayPaymentState.asStateFlow()
    val uroPayPaymentState: StateFlow<UroPayPaymentUiState> = _uropayPaymentState.asStateFlow()

    private val _showRechargePopup = MutableStateFlow(false)
    val showRechargePopup: StateFlow<Boolean> = _showRechargePopup.asStateFlow()

    private val _transactions = MutableStateFlow<List<TransactionItem>>(emptyList())
    val transactions: StateFlow<List<TransactionItem>> = _transactions.asStateFlow()

    private val _walletTransactions = MutableStateFlow<List<WalletTransaction>>(emptyList())
    val walletTransactions: StateFlow<List<WalletTransaction>> = _walletTransactions.asStateFlow()

    private val _recentCalls = MutableStateFlow<List<CallRecord>>(emptyList())
    val recentCalls: StateFlow<List<CallRecord>> = _recentCalls.asStateFlow()

    // Notifications State
    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _unreadNotificationsCount = MutableStateFlow(0)
    val unreadNotificationsCount: StateFlow<Int> = _unreadNotificationsCount.asStateFlow()

    // Ratings & Reviews State
    private val _pendingRatingCall = MutableStateFlow<PendingRatingCall?>(null)
    val pendingRatingCall: StateFlow<PendingRatingCall?> = _pendingRatingCall.asStateFlow()

    private val _isSubmittingRating = MutableStateFlow(false)
    val isSubmittingRating: StateFlow<Boolean> = _isSubmittingRating.asStateFlow()

    private val _hostPublicRatings = MutableStateFlow<Map<String, PublicUserRating>>(emptyMap())
    val hostPublicRatings: StateFlow<Map<String, PublicUserRating>> = _hostPublicRatings.asStateFlow()

    // Report User State
    private val _activeReportTarget = MutableStateFlow<ActiveReportTarget?>(null)
    val activeReportTarget: StateFlow<ActiveReportTarget?> = _activeReportTarget.asStateFlow()

    private val _isSubmittingReport = MutableStateFlow(false)
    val isSubmittingReport: StateFlow<Boolean> = _isSubmittingReport.asStateFlow()

    // Legal Page State
    private val _activeLegalPage = MutableStateFlow<com.example.ui.legal.LegalPage?>(null)
    val activeLegalPage: StateFlow<com.example.ui.legal.LegalPage?> = _activeLegalPage.asStateFlow()

    // User Message / Toast
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        restoreSessionOnStartup()
        initAgoraCallbacks()
    }

    private fun initAgoraCallbacks() {
        agoraCallManager.onCallConnected = {
            handleCallConnectedAuthoritative()
        }
        agoraCallManager.onCallEnded = {
            com.example.service.BaatlyUserCallForegroundService.stopService(getApplication())
            handleCallEndedLocally()
        }
        agoraCallManager.onError = { err ->
            com.example.service.BaatlyUserCallForegroundService.stopService(getApplication())
            showUserMessage("Call Error: $err")
            handleCallEndedLocally()
        }
        agoraCallManager.onTokenRefreshRequired = { channelName ->
            handleTokenRenewal(channelName)
        }
    }

    private fun handleCallConnectedAuthoritative() {
        if (_callState.value == CallState.CONNECTED) {
            Log.i("BaatlyViewModel", "Call already in CONNECTED state, skipping duplicate connected callback")
            return
        }
        _callState.value = CallState.CONNECTED

        val currentCall = _activeCall.value
        val callId = currentCall?.id.orEmpty()
        val partnerName = _activeCallPartner.value?.displayName ?: _activeCallPartner.value?.partnerDisplayName ?: "Host"
        val isVideo = agoraCallManager.isVideoCall.value || currentCall?.callType.equals("video", ignoreCase = true)

        // Start Foreground Service reliably tied to current call
        com.example.service.BaatlyUserCallForegroundService.startService(
            context = getApplication(),
            callId = callId,
            partnerName = partnerName,
            isVideo = isVideo
        )

        // Retrieve fresh call record for accurate duration limit
        if (currentCall != null) {
            viewModelScope.launch {
                dataService.getCallRecord(currentCall.id).onSuccess { freshRecord ->
                    _activeCall.value = freshRecord
                    val initialMax = if (freshRecord.maxDurationSeconds > 0) {
                        freshRecord.maxDurationSeconds
                    } else {
                        val rate = if (isVideo) effectivePricing.value.videoCallRateRupeesPerMinute else effectivePricing.value.callRateRupeesPerMinute
                        BillingEngine.calculateMaxCallDurationSeconds(
                            _walletSummary.value.availableBalanceRupees,
                            rate
                        )
                    }
                    _callRemainingSeconds.value = initialMax
                }
            }
        }

        startCallTimer()
        startCallBalanceEnforcement()
    }

    private fun handleTokenRenewal(channelName: String) {
        viewModelScope.launch {
            try {
                dataService.getAgoraToken(channelName).onSuccess { tokenRes ->
                    val ok = agoraCallManager.renewToken(tokenRes.token)
                    Log.i("BaatlyViewModel", "Automatic Agora token renewal completed: success=$ok")
                }.onFailure { e ->
                    Log.e("BaatlyViewModel", "Automatic Agora token renewal failed: ${e.message}", e)
                    agoraCallManager.onTokenRenewalFailed()
                }
            } catch (e: Exception) {
                Log.e("BaatlyViewModel", "Exception during Agora token renewal: ${e.message}", e)
                agoraCallManager.onTokenRenewalFailed()
            }
        }
    }

    fun onAppResumed() {
        val pendingPayment = sessionManager.getPendingPayment()
        if (pendingPayment != null) {
            val elapsed = System.currentTimeMillis() - pendingPayment.createdAt
            if (elapsed < 15 * 60 * 1000L) {
                // After return from external browser checkout: transition OpeningCheckout to Verifying
                if (_uropayPaymentState.value is UroPayPaymentUiState.OpeningCheckout) {
                    _uropayPaymentState.value = UroPayPaymentUiState.Verifying(pendingPayment.paymentId, 0.0)
                }
                verifyUroPayPayment(pendingPayment.paymentId)
            } else {
                sessionManager.clearPendingPayment()
            }
        }
        if (sessionManager.isLoggedIn) {
            refreshWallet()
            refreshNotifications()
        }
    }

    private fun restoreSessionOnStartup() {
        viewModelScope.launch {
            if (sessionManager.hasPersistedSessionCredentials) {
                _isRestoringSession.value = true
                val restored = authService.restoreOrRefreshSession()
                if (restored) {
                    authService.fetchCurrentUserProfile()
                    val uid = sessionManager.userId.value
                    if (uid != null) {
                        refreshPricing()
                        refreshWallet()
                        refreshRechargePackages()
                        refreshPartners()
                        refreshGifts()
                        refreshNotifications()
                        refreshFcmToken()
                    }
                }
                _isRestoringSession.value = false
            } else {
                _isRestoringSession.value = false
            }
        }
    }

    fun retryStartup() {
        _startupError.value = null
        restoreSessionOnStartup()
    }

    fun refreshPricing() {
        val uid = sessionManager.userId.value ?: return
        viewModelScope.launch {
            dataService.getEffectiveUserPricing(uid).onSuccess { pricing ->
                _effectivePricing.value = pricing
            }
        }
    }

    // ==========================================
    // AUTHENTICATION
    // ==========================================

    fun clearAuthError() {
        _authError.value = null
    }

    fun checkUserIdAvailable(userId: String) {
        if (userId.length < 3) {
            _userIdAvailable.value = null
            return
        }
        viewModelScope.launch {
            val available = authService.checkUserIdAvailable(userId)
            _userIdAvailable.value = available
        }
    }

    fun checkUserIdAvailability(userId: String) {
        checkUserIdAvailable(userId)
    }

    fun signIn(userId: String, pass: String) {
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            authService.signIn(userId, pass)
                .onSuccess {
                    _isAuthLoading.value = false
                    _currentScreen.value = Screen.HOME
                    refreshPricing()
                    refreshWallet()
                    refreshRechargePackages()
                    refreshPartners()
                    refreshGifts()
                    refreshNotifications()
                    refreshFcmToken()
                }
                .onFailure { e ->
                    _isAuthLoading.value = false
                    _authError.value = e.message ?: "Sign in failed"
                }
        }
    }

    fun signUp(
        userId: String,
        pass: String,
        displayName: String,
        mobile: String,
        avatar: File? = null,
        referral: String? = null
    ) {
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            authService.signUp(userId, pass, displayName, mobile, avatar, referral)
                .onSuccess {
                    _isAuthLoading.value = false
                    _currentScreen.value = Screen.HOME
                    refreshPricing()
                    refreshWallet()
                    refreshRechargePackages()
                    refreshPartners()
                    refreshGifts()
                    refreshNotifications()
                    refreshFcmToken()
                }
                .onFailure { e ->
                    _isAuthLoading.value = false
                    _authError.value = e.message ?: "Registration failed"
                }
        }
    }

    fun signUp(
        userId: String,
        password: String,
        displayName: String,
        mobileNumber: String,
        referralCode: String? = null,
        avatarFile: File? = null
    ) {
        signUp(
            userId = userId,
            pass = password,
            displayName = displayName,
            mobile = mobileNumber,
            avatar = avatarFile,
            referral = referralCode
        )
    }

    fun signOut() {
        viewModelScope.launch {
            val token = sessionManager.fcmToken.value
            if (!token.isNullOrBlank()) {
                dataService.unregisterFcmToken(token)
            }
            authService.signOut()
            _currentScreen.value = Screen.AUTH
            _availablePartners.value = emptyList()
            _conversations.value = emptyList()
            _messages.value = emptyList()
            _walletSummary.value = WalletSummary()
        }
    }

    fun updateProfile(displayName: String, bio: String?, avatar: File?) {
        viewModelScope.launch {
            authService.updateProfile(displayName, bio, avatar)
                .onSuccess {
                    showUserMessage("Profile updated successfully")
                }
                .onFailure { e ->
                    showUserMessage("Update failed: ${e.message}")
                }
        }
    }

    fun updateUserProfile(
        displayName: String,
        bio: String?,
        avatarFile: File?,
        onComplete: ((Boolean, String?) -> Unit)? = null
    ) {
        viewModelScope.launch {
            authService.updateProfile(displayName, bio, avatarFile)
                .onSuccess {
                    authService.fetchCurrentUserProfile()
                    showUserMessage("Profile updated successfully")
                    onComplete?.invoke(true, null)
                }
                .onFailure { e ->
                    val err = e.message ?: "Update failed"
                    showUserMessage(err)
                    onComplete?.invoke(false, err)
                }
        }
    }

    fun requestAccountDeletion(onComplete: ((Boolean, String?) -> Unit)? = null) {
        viewModelScope.launch {
            authService.requestAccountDeletion()
                .onSuccess {
                    onComplete?.invoke(true, null)
                    signOut()
                    showUserMessage("Account deletion requested successfully")
                }
                .onFailure { e ->
                    val err = e.message ?: "Could not delete account"
                    onComplete?.invoke(false, err)
                    showUserMessage(err)
                }
        }
    }

    // ==========================================
    // NAVIGATION
    // ==========================================

    fun setScreen(screen: Screen) {
        if (_currentScreen.value != screen) {
            _previousScreen.value = _currentScreen.value
            _currentScreen.value = screen
        }
        if (screen == Screen.WALLET) {
            refreshWallet()
            refreshRechargePackages()
            fetchTransactions()
        }
        if (screen == Screen.RECENT_CALLS) {
            fetchRecentCalls()
        }
    }

    fun setHomeMode(mode: HomeMode) {
        _homeMode.value = mode
    }

    fun goBack() {
        if (_currentScreen.value == Screen.HOST_PROFILE || _currentScreen.value == Screen.RECENT_CALLS ||
            _currentScreen.value == Screen.WALLET || _currentScreen.value == Screen.PROFILE ||
            _currentScreen.value == Screen.NOTIFICATIONS
        ) {
            _currentScreen.value = Screen.HOME
        } else if (_currentScreen.value == Screen.DIRECT_CHAT) {
            closeChatScreen()
        } else if (_currentScreen.value == Screen.BAATLY_SYSTEM_CHAT) {
            _currentScreen.value = Screen.CHAT_LIST
        } else if (_currentScreen.value == Screen.LEGAL_DETAIL) {
            closeLegalPage()
        } else {
            _currentScreen.value = _previousScreen.value
        }
    }

    fun openLegalPage(page: com.example.ui.legal.LegalPage) {
        _activeLegalPage.value = page
        setScreen(Screen.LEGAL_DETAIL)
    }

    fun closeLegalPage() {
        _activeLegalPage.value = null
        setScreen(Screen.PROFILE)
    }

    // ==========================================
    // PARTNERS & PROFILES
    // ==========================================

    fun refreshPartners() {
        _isLoadingPartners.value = true
        viewModelScope.launch {
            dataService.getAvailablePartners()
                .onSuccess { list ->
                    _availablePartners.value = list
                    _isLoadingPartners.value = false
                }
                .onFailure {
                    _isLoadingPartners.value = false
                }
        }
    }

    fun selectPartner(partner: PartnerProfile) {
        _selectedPartner.value = partner
        setScreen(Screen.HOST_PROFILE)
    }

    fun openPartnerProfile(partner: PartnerProfile) {
        selectPartner(partner)
    }

    fun openHostProfile(partner: PartnerProfile) {
        selectPartner(partner)
    }

    fun loadPublicRatingForUser(userId: String) {
        if (userId.isBlank()) return
        viewModelScope.launch {
            dataService.getPublicUserRating(userId).onSuccess { rating ->
                val current = _hostPublicRatings.value.toMutableMap()
                current[userId] = rating
                _hostPublicRatings.value = current
            }
        }
    }

    // ==========================================
    // CALLS
    // ==========================================

    fun requestCall(partner: PartnerProfile) {
        startCall(partner, isVideo = false)
    }

    fun requestVideoCall(partner: PartnerProfile) {
        startCall(partner, isVideo = true)
    }

    fun toggleGiftSheet(show: Boolean? = null) {
        val next = show ?: !_showGiftSheet.value
        _showGiftSheet.value = next
        if (next) refreshGifts()
    }

    fun startCall(partner: PartnerProfile, isVideo: Boolean = false) {
        val minRequired = if (isVideo) effectivePricing.value.videoCallRateRupeesPerMinute else effectivePricing.value.callRateRupeesPerMinute
        if (_walletSummary.value.availableBalanceRupees < minRequired) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance to start call. Minimum ₹${minRequired.toInt()} required.")
            return
        }

        _activeCallPartner.value = partner
        _callState.value = CallState.REQUESTING
        _callElapsedSeconds.value = 0
        setScreen(Screen.ACTIVE_CALL)

        var hasTokenBeenRequested = false

        viewModelScope.launch {
            val callResult = if (isVideo) {
                dataService.requestVideoCall(partner.id)
            } else {
                dataService.requestCall(partner.id)
            }

            callResult.onSuccess { record ->
                _activeCall.value = record
                _callState.value = CallState.RINGING

                // Listen to Realtime updates for call status
                realtimeManager.subscribeToCall(record.id) { updatedRecord ->
                    _activeCall.value = updatedRecord
                    when (updatedRecord.status.lowercase()) {
                        "accepted" -> {
                            if (_callState.value != CallState.ENDED && _callState.value != CallState.IDLE) {
                                if (!hasTokenBeenRequested) {
                                    hasTokenBeenRequested = true
                                    viewModelScope.launch {
                                        dataService.getAgoraToken(updatedRecord.channelName)
                                            .onSuccess { agoraToken ->
                                                if (_callState.value == CallState.ENDED || _callState.value == CallState.IDLE) {
                                                    return@onSuccess
                                                }
                                                agoraCallManager.currentCallId = updatedRecord.id
                                                agoraCallManager.currentChannelName = updatedRecord.channelName

                                                val joinAgoraAction = {
                                                    agoraCallManager.startCall(
                                                        channelName = updatedRecord.channelName,
                                                        token = agoraToken.token,
                                                        uid = agoraToken.uid,
                                                        isVideo = isVideo
                                                    )
                                                }

                                                if (isVideo && (!agoraCallManager.hasCameraPermission() || !agoraCallManager.hasMicPermission())) {
                                                    android.util.Log.i("BaatlyViewModel", "VIDEO_PERMISSIONS_DEFERRED: waiting for CAMERA & RECORD_AUDIO permissions before Agora join")
                                                    pendingVideoJoin = joinAgoraAction
                                                    _pendingVideoPermissionsRequired.value = true
                                                } else {
                                                    joinAgoraAction()
                                                }
                                            }
                                            .onFailure { e ->
                                                showUserMessage("Could not connect call audio/video: ${e.message}")
                                                endCall()
                                            }
                                    }
                                }
                            }
                        }
                        "rejected", "cancelled", "completed", "failed", "missed" -> {
                            handleRemoteCallTerminated(updatedRecord)
                        }
                    }
                }
            }.onFailure { e ->
                showUserMessage("Call request failed: ${e.message}")
                _callState.value = CallState.IDLE
                _activeCall.value = null
                _activeCallPartner.value = null
                setScreen(Screen.HOME)
            }
        }
    }

    fun handleRemoteCallTerminated(call: CallRecord) {
        callTimerJob?.cancel()
        callEnforcementJob?.cancel()
        com.example.data.audio.BaatlyRingtoneManager.stopRingtone()
        com.example.service.BaatlyUserCallForegroundService.stopService(getApplication())
        agoraCallManager.currentCallId = null
        agoraCallManager.currentChannelName = null
        agoraCallManager.endCall()
        realtimeManager.unsubscribe()

        val status = call.status.lowercase()
        val message = when (status) {
            "cancelled" -> "Call was cancelled."
            "rejected" -> "Call was declined."
            "missed" -> "Call was missed."
            "failed" -> "Call failed to connect."
            "completed" -> "Call ended."
            else -> "Call finished."
        }
        showUserMessage(message)

        _callState.value = CallState.ENDED
        _activeCall.value = call

        viewModelScope.launch {
            if (status == "completed" && call.isConnected) {
                checkCallRatingEligibility(call.id, _activeCallPartner.value?.id ?: call.partnerId)
            }
            refreshWallet()
            fetchRecentCalls()

            delay(1000)
            _activeCall.value = null
            _activeCallPartner.value = null
            _callState.value = CallState.IDLE
            setScreen(Screen.HOME)
        }
    }

    fun endCall() {
        val call = _activeCall.value
        val state = _callState.value

        pendingVideoJoin = null
        _pendingVideoPermissionsRequired.value = false

        callTimerJob?.cancel()
        callEnforcementJob?.cancel()
        com.example.data.audio.BaatlyRingtoneManager.stopRingtone()
        com.example.service.BaatlyUserCallForegroundService.stopService(getApplication())
        agoraCallManager.currentCallId = null
        agoraCallManager.currentChannelName = null
        agoraCallManager.endCall()
        realtimeManager.unsubscribe()

        if (call == null) {
            _callState.value = CallState.IDLE
            _activeCall.value = null
            _activeCallPartner.value = null
            setScreen(Screen.HOME)
            return
        }

        val isConnected = state == CallState.CONNECTED && call.isConnected
        val shouldCancel = !isConnected || state == CallState.REQUESTING || state == CallState.RINGING || call.connectedAt.isNullOrBlank()

        _callState.value = CallState.ENDED

        viewModelScope.launch {
            if (shouldCancel) {
                var cancelResult = dataService.updateCallState(call.id, "cancelled")
                if (cancelResult.isFailure) {
                    delay(300)
                    cancelResult = dataService.updateCallState(call.id, "cancelled")
                }

                if (cancelResult.isSuccess) {
                    refreshWallet()
                    fetchRecentCalls()
                } else {
                    val freshRecordResult = dataService.getCallRecord(call.id)
                    val freshRecord = freshRecordResult.getOrNull()
                    val freshStatus = freshRecord?.status?.lowercase() ?: ""
                    if (freshStatus in listOf("cancelled", "rejected", "missed", "failed", "completed")) {
                        handleRemoteCallTerminated(freshRecord ?: call.copy(status = freshStatus))
                        return@launch
                    } else {
                        val err = cancelResult.exceptionOrNull()?.message ?: "Failed to cancel call"
                        showUserMessage("Call cancellation error: $err")
                    }
                }
            } else {
                var completeResult = dataService.updateCallState(call.id, "completed")
                if (completeResult.isFailure) {
                    delay(300)
                    completeResult = dataService.updateCallState(call.id, "completed")
                }

                if (call.isConnected) {
                    dataService.settleCall(call.id)
                    checkCallRatingEligibility(call.id, _activeCallPartner.value?.id ?: call.partnerId)
                }
                refreshWallet()
                fetchRecentCalls()
            }

            delay(1000)
            _activeCall.value = null
            _activeCallPartner.value = null
            _callState.value = CallState.IDLE
            setScreen(Screen.HOME)
        }
    }

    fun acceptIncomingCall(callId: String, partnerId: String, isVideo: Boolean) {
        com.example.data.audio.BaatlyRingtoneManager.stopRingtone()
        _callState.value = CallState.RINGING
        _callElapsedSeconds.value = 0
        setScreen(Screen.ACTIVE_CALL)

        viewModelScope.launch {
            // 1. Resolve partner profile
            dataService.getHostProfile(partnerId).onSuccess { profile ->
                _activeCallPartner.value = profile
            }.onFailure {
                _activeCallPartner.value = PartnerProfile(
                    id = partnerId,
                    userId = partnerId,
                    partnerDisplayName = "Baatly Host",
                    avatarUrl = null,
                    isOnline = true
                )
            }

            // 2. Fetch call record and verify it hasn't been cancelled by caller
            dataService.getCallRecord(callId).onSuccess { callRecord ->
                val recordStatus = callRecord.status.lowercase()
                if (recordStatus in listOf("cancelled", "rejected", "missed", "failed", "completed")) {
                    showUserMessage("Call was already $recordStatus.")
                    handleRemoteCallTerminated(callRecord)
                    return@onSuccess
                }
                _activeCall.value = callRecord

                // 3. Update state to accepted
                dataService.updateCallState(callId, "accepted").onSuccess {
                    // 4. Retrieve Agora Token
                    dataService.getAgoraToken(callRecord.channelName).onSuccess { tokenRes ->
                        agoraCallManager.currentCallId = callId
                        agoraCallManager.currentChannelName = callRecord.channelName

                        // Subscribe to live call updates (e.g. completes/cancellations)
                        realtimeManager.subscribeToCall(callId) { updatedRecord ->
                            _activeCall.value = updatedRecord
                            val status = updatedRecord.status.lowercase()
                            if (status in listOf("rejected", "cancelled", "completed", "failed", "missed")) {
                                handleRemoteCallTerminated(updatedRecord)
                            }
                        }

                        // Start Agora join
                        val joinAgoraAction = {
                            agoraCallManager.startCall(
                                channelName = callRecord.channelName,
                                token = tokenRes.token,
                                uid = tokenRes.uid,
                                isVideo = isVideo
                            )
                        }

                        if (isVideo && (!agoraCallManager.hasCameraPermission() || !agoraCallManager.hasMicPermission())) {
                            android.util.Log.i("BaatlyViewModel", "VIDEO_PERMISSIONS_DEFERRED: waiting for CAMERA & RECORD_AUDIO permissions before Agora join")
                            pendingVideoJoin = joinAgoraAction
                            _pendingVideoPermissionsRequired.value = true
                        } else {
                            joinAgoraAction()
                        }
                    }.onFailure { e ->
                        showUserMessage("Could not connect call audio/video: ${e.message}")
                        endCall()
                    }
                }.onFailure { e ->
                    showUserMessage("Call is no longer available.")
                    dataService.getCallRecord(callId).onSuccess { freshRec ->
                        handleRemoteCallTerminated(freshRec)
                    }.onFailure {
                        endCall()
                    }
                }
            }.onFailure { e ->
                showUserMessage("Call validation failed: ${e.message}")
                endCall()
            }
        }
    }

    private fun handleCallEndedLocally() {
        endCall()
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _callElapsedSeconds.value += 1
                val maxDur = _activeCall.value?.maxDurationSeconds ?: 0
                if (maxDur > 0) {
                    val rem = (maxDur - _callElapsedSeconds.value).coerceAtLeast(0)
                    _callRemainingSeconds.value = rem
                    if (rem <= 0 && _callState.value == CallState.CONNECTED) {
                        showUserMessage("Call duration limit reached.")
                        endCall()
                        break
                    }
                } else if (_callRemainingSeconds.value > 0) {
                    _callRemainingSeconds.value = (_callRemainingSeconds.value - 1).coerceAtLeast(0)
                    if (_callRemainingSeconds.value <= 0 && _callState.value == CallState.CONNECTED) {
                        showUserMessage("Call duration limit reached.")
                        endCall()
                        break
                    }
                }
            }
        }
    }

    private fun startCallBalanceEnforcement() {
        callEnforcementJob?.cancel()
        callEnforcementJob = viewModelScope.launch {
            while (true) {
                delay(15000) // Check every 15 seconds
                val call = _activeCall.value ?: break
                dataService.enforceCallBalanceLimit(call.id).onSuccess { res ->
                    _callRemainingSeconds.value = res.remainingSeconds
                    if (!res.isAllowed || res.remainingSeconds <= 0) {
                        showUserMessage("Call balance depleted.")
                        endCall()
                        break
                    }
                }
            }
        }
    }

    fun fetchRecentCalls() {
        viewModelScope.launch {
            dataService.fetchRecentCalls().onSuccess { list ->
                _recentCalls.value = list
            }
        }
    }

    // ==========================================
    // CHAT & MESSAGING
    // ==========================================

    fun openChatWithHost(partner: PartnerProfile) {
        _chatPartner.value = partner
        _chatBlockStatus.value = null // Set loading
        _isChatBlocked.value = false
        setScreen(Screen.DIRECT_CHAT)
        viewModelScope.launch {
            val partnerId = partner.id
            dataService.isUserBlocked(partnerId).onSuccess { status ->
                _chatBlockStatus.value = status
                _isChatBlocked.value = status.blockedByMe
            }.onFailure {
                _chatBlockStatus.value = com.example.data.model.UserBlockStatus(blocked = false, blockedByMe = false, blockedMe = false)
                _isChatBlocked.value = false
            }

            dataService.startChatWithHost(partnerId).onSuccess { convId ->
                val conv = ConversationSummary(
                    id = convId,
                    partnerId = partnerId,
                    partnerName = partner.displayName,
                    partnerAvatar = partner.avatarUrl,
                    isOnline = partner.isOnline
                )
                _activeConversation.value = conv
                subscribeToActiveConversationRealtime(convId)
                loadMessagesForConversation(convId)
            }
        }
    }

    fun openConversation(conv: ConversationSummary) {
        _activeConversation.value = conv
        _chatBlockStatus.value = null // Set loading
        _isChatBlocked.value = false
        setScreen(Screen.DIRECT_CHAT)
        subscribeToActiveConversationRealtime(conv.id)
        viewModelScope.launch {
            val partnerId = conv.partnerId
            dataService.isUserBlocked(partnerId).onSuccess { status ->
                _chatBlockStatus.value = status
                _isChatBlocked.value = status.blockedByMe
            }.onFailure {
                _chatBlockStatus.value = com.example.data.model.UserBlockStatus(blocked = false, blockedByMe = false, blockedMe = false)
                _isChatBlocked.value = false
            }

            // First try get_conversation_participant_profile RPC
            dataService.getConversationParticipantProfile(conv.id, partnerId).onSuccess { res ->
                val name = res.displayName?.takeIf { it.isNotBlank() } ?: conv.partnerName
                val avatar = res.avatarUrl?.takeIf { it.isNotBlank() } ?: conv.partnerAvatar
                val updatedConv = conv.copy(partnerName = name, partnerAvatar = avatar)
                _activeConversation.value = updatedConv
                _chatPartner.value = PartnerProfile(
                    id = res.userId,
                    userId = res.userId,
                    partnerDisplayName = name,
                    avatarUrl = avatar ?: "",
                    isOnline = conv.isOnline
                )
            }.onFailure {
                // Fallback to getHostProfile
                dataService.getHostProfile(partnerId).onSuccess { profile ->
                    _chatPartner.value = profile
                    _activeConversation.value = conv.copy(
                        partnerName = profile.displayName,
                        partnerAvatar = profile.avatarUrl?.takeIf { it.isNotBlank() } ?: conv.partnerAvatar
                    )
                }.onFailure {
                    // Final fallback to the conv values
                    _chatPartner.value = PartnerProfile(
                        id = partnerId,
                        userId = partnerId,
                        partnerDisplayName = conv.partnerName,
                        avatarUrl = conv.partnerAvatar ?: "",
                        isOnline = conv.isOnline
                    )
                }
            }
            loadMessagesForConversation(conv.id)
        }
    }

    fun closeChatScreen() {
        realtimeManager.unsubscribe()
        _activeConversation.value = null
        _chatPartner.value = null
        _messages.value = emptyList()
        _isChatBlocked.value = false
        _chatBlockStatus.value = null
        setScreen(Screen.CHAT_LIST)
    }

    fun refreshConversations() {
        viewModelScope.launch {
            dataService.fetchConversations().onSuccess { list ->
                _conversations.value = list
            }
        }
    }

    private fun loadMessagesForConversation(convId: String) {
        viewModelScope.launch {
            dataService.fetchMessages(convId).onSuccess { list ->
                val currentUserId = sessionManager.userId.value ?: ""
                _messages.value = list

                // Identify incoming undelivered and unseen messages
                val incomingUndelivered = list.filter { it.receiverId == currentUserId && it.deliveredAt.isNullOrBlank() }.map { it.id }
                val incomingUnseen = list.filter { it.receiverId == currentUserId && it.seenAt.isNullOrBlank() }.map { it.id }

                if (incomingUndelivered.isNotEmpty() || incomingUnseen.isNotEmpty()) {
                    if (incomingUndelivered.isNotEmpty()) {
                        dataService.markMessagesDelivered(convId, incomingUndelivered)
                    }
                    if (incomingUnseen.isNotEmpty()) {
                        dataService.markMessagesSeen(convId, incomingUnseen)
                    }
                    dataService.markConversationRead(convId)
                    
                    // Re-fetch accurate verified timestamps from database
                    dataService.fetchMessages(convId).onSuccess { updatedList ->
                        _messages.value = updatedList
                    }
                } else {
                    dataService.markConversationRead(convId)
                }
                
                refreshConversations()
            }
        }
    }

    private fun subscribeToActiveConversationRealtime(conversationId: String) {
        realtimeManager.subscribeToConversation(
            conversationId = conversationId,
            onNewMessage = { msg ->
                handleIncomingRealtimeMessage(msg)
            },
            onMessageUpdated = { msg ->
                handleUpdatedRealtimeMessage(msg)
            },
            onResync = {
                loadMessagesForConversation(conversationId)
                refreshConversations()
            }
        )
    }

    private fun handleIncomingRealtimeMessage(msg: ChatMessage) {
        val currentUserId = sessionManager.userId.value ?: ""
        val activeConv = _activeConversation.value
        
        // Ignore duplicate message IDs
        if (_messages.value.any { it.id == msg.id }) return

        if (activeConv != null && msg.conversationId == activeConv.id) {
            _messages.value = _messages.value + msg
            if (msg.receiverId == currentUserId) {
                viewModelScope.launch {
                    dataService.markMessagesDelivered(activeConv.id, listOf(msg.id))
                    dataService.markMessagesSeen(activeConv.id, listOf(msg.id))
                    dataService.markConversationRead(activeConv.id)
                    // Load latest with exact backend verification timestamp
                    dataService.fetchMessages(activeConv.id).onSuccess { updatedList ->
                        _messages.value = updatedList
                    }
                }
            }
        } else {
            if (msg.receiverId == currentUserId) {
                viewModelScope.launch {
                    dataService.markMessagesDelivered(msg.conversationId, listOf(msg.id))
                    refreshConversations()
                }
            }
        }
        refreshConversations()
    }

    private fun handleUpdatedRealtimeMessage(msg: ChatMessage) {
        val activeConv = _activeConversation.value
        if (activeConv != null && msg.conversationId == activeConv.id) {
            _messages.value = _messages.value.map { existing ->
                if (existing.id == msg.id) {
                    existing.copy(
                        deliveredAt = msg.deliveredAt,
                        seenAt = msg.seenAt,
                        isRead = msg.isRead,
                        isDelivered = msg.deliveredAt != null,
                        isSeen = msg.seenAt != null
                    )
                } else {
                    existing
                }
            }
        }
        // Update corresponding conversation summary in the exact same state transition
        _conversations.value = _conversations.value.map { conv ->
            if (conv.id == msg.conversationId && conv.lastMessageId == msg.id) {
                conv.copy(
                    lastMessageSeenAt = msg.seenAt,
                    lastMessageDeliveredAt = msg.deliveredAt
                )
            } else {
                conv
            }
        }
        refreshConversations()
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val msgCost = effectivePricing.value.messageRateRupees
        if (_walletSummary.value.availableBalanceRupees < msgCost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance for message. ₹${msgCost.toInt()} required.")
            return
        }

        viewModelScope.launch {
            dataService.sendMessage(
                conversationId = conv.id,
                receiverId = partner.id,
                messageType = "text",
                messageText = text.trim()
            ).onSuccess { msg ->
                // Do not append duplicated message if already received via realtime
                if (!_messages.value.any { it.id == msg.id }) {
                    _messages.value = _messages.value + msg
                }
                refreshWallet()
                refreshConversations()
            }.onFailure { e ->
                showUserMessage("Failed to send: ${e.message}")
            }
        }
    }

    fun sendImageMessage(file: File) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val msgCost = effectivePricing.value.messageRateRupees
        if (_walletSummary.value.availableBalanceRupees < msgCost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance for image message. ₹${msgCost.toInt()} required.")
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = false).onSuccess { mediaPath ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "image",
                    mediaUrl = mediaPath
                ).onSuccess { msg ->
                    _messages.value = _messages.value + msg
                    refreshWallet()
                }.onFailure { e ->
                    showUserMessage("Failed to send image: ${e.message}")
                }
            }.onFailure { e ->
                showUserMessage("Failed to upload image: ${e.message}")
            }
        }
    }

    fun sendVoiceMessage(file: File, durationSeconds: Int) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val msgCost = effectivePricing.value.messageRateRupees
        if (_walletSummary.value.availableBalanceRupees < msgCost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance for voice message. ₹${msgCost.toInt()} required.")
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = true).onSuccess { mediaPath ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "voice",
                    mediaUrl = mediaPath,
                    mediaDurationSeconds = durationSeconds
                ).onSuccess { msg ->
                    _messages.value = _messages.value + msg
                    refreshWallet()
                }.onFailure { e ->
                    showUserMessage("Failed to send voice message: ${e.message}")
                }
            }.onFailure { e ->
                showUserMessage("Failed to upload voice note: ${e.message}")
            }
        }
    }

    fun playVoiceMessage(message: ChatMessage) {
        val messageId = message.id
        val rawMedia = message.mediaUrl
        if (rawMedia.isNullOrBlank()) {
            showUserMessage("Unable to load voice message.")
            return
        }

        if (audioPlayerManager.currentlyPlayingMessageId.value == messageId) {
            if (audioPlayerManager.isPlaying.value) {
                audioPlayerManager.pause()
            } else {
                audioPlayerManager.playVoice(messageId, rawMedia)
            }
            return
        }

        viewModelScope.launch {
            val resolvedUrl = dataService.resolveChatVoiceUrl(rawMedia)
            if (resolvedUrl.isBlank()) {
                showUserMessage("Unable to load voice message.")
                return@launch
            }

            var hasRetried = false
            fun startPlayback(url: String) {
                audioPlayerManager.playVoice(
                    messageId = messageId,
                    resolvedUrlOrLocalPath = url,
                    onError = { errMsg, errorCode ->
                        if (!hasRetried) {
                            hasRetried = true
                            viewModelScope.launch {
                                android.util.Log.w("VoicePlayback", "Playback failed for message $messageId, invalidating signed URL cache and retrying once...")
                                dataService.invalidateSignedMediaUrl(rawMedia, com.example.data.network.SupabaseConfig.BUCKET_CHAT_MEDIA)
                                val freshUrl = dataService.resolveChatVoiceUrl(rawMedia)
                                if (freshUrl.isNotBlank() && freshUrl != url) {
                                    startPlayback(freshUrl)
                                } else {
                                    showUserMessage("Unable to load voice message.")
                                }
                            }
                        } else {
                            showUserMessage("Unable to load voice message.")
                        }
                    }
                )
            }

            startPlayback(resolvedUrl)
        }
    }

    // ==========================================
    // GIFTS
    // ==========================================

    fun openGiftSheet() {
        _showGiftSheet.value = true
        refreshGifts()
    }

    fun closeGiftSheet() {
        _showGiftSheet.value = false
    }

    fun refreshGifts() {
        viewModelScope.launch {
            dataService.fetchGifts().onSuccess { list ->
                _gifts.value = list
            }
        }
    }

    fun sendGift(gift: GiftItem) {
        val receiverId = _activeCallPartner.value?.id ?: _chatPartner.value?.id ?: return
        val convId = _activeConversation.value?.id
        val callId = _activeCall.value?.id

        if (_walletSummary.value.availableBalanceRupees < gift.priceRupees) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance for gift. ₹${gift.priceRupees.toInt()} required.")
            return
        }

        viewModelScope.launch {
            dataService.sendGift(gift.id, receiverId, convId, callId)
                .onSuccess {
                    _recentGiftAnimation.value = gift
                    closeGiftSheet()
                    refreshWallet()
                    delay(3500)
                    _recentGiftAnimation.value = null
                }
                .onFailure { e ->
                    showUserMessage("Gift failed: ${e.message}")
                }
        }
    }

    // ==========================================
    // WALLET & UROPAY RECHARGE
    // ==========================================

    private var walletRefreshJob: Job? = null

    fun refreshWallet() {
        val currentUid = sessionManager.userId.value ?: ""
        walletRefreshJob?.cancel()
        walletRefreshJob = viewModelScope.launch {
            _isWalletLoading.value = true
            _walletError.value = null
            Log.d("WalletRefresh", "UID: $currentUid | Refresh STARTED")
            dataService.fetchWalletSummary().fold(
                onSuccess = { summary ->
                    _walletSummary.value = summary
                    _isWalletInitialized.value = true
                    _isWalletLoading.value = false
                    _walletError.value = null
                    Log.d(
                        "WalletRefresh",
                        "UID: $currentUid | Refresh SUCCESS | balance_rupees: ${summary.balanceRupees} | available_balance_rupees: ${summary.availableBalanceRupees}"
                    )
                },
                onFailure = { e ->
                    _isWalletLoading.value = false
                    val errMsg = e.message ?: "Failed to fetch wallet summary"
                    _walletError.value = errMsg
                    Log.e("WalletRefresh", "UID: $currentUid | Refresh FAILURE | error: $errMsg", e)
                }
            )
        }
    }

    fun refreshRechargePackages() {
        viewModelScope.launch {
            dataService.fetchWalletRechargePackages().onSuccess { list ->
                _rechargePackages.value = list
            }
        }
    }

    fun showRechargeModal() {
        _showRechargePopup.value = true
        refreshRechargePackages()
    }

    fun dismissRechargePopup() {
        _showRechargePopup.value = false
    }

    fun closeRechargePopup() {
        dismissRechargePopup()
    }

    fun startUroPayRecharge(pkg: WalletRechargePackage, targetCallId: String? = null, isCallRecharge: Boolean = false) {
        val effectiveCallId = targetCallId ?: _activeCall.value?.id
        if (isCallRecharge && effectiveCallId.isNullOrBlank()) {
            _uropayPaymentState.value = UroPayPaymentUiState.Failed(null, "No active call found for in-call recharge", true, pkg.amountRupees)
            return
        }

        // Prevent duplicate simultaneous recharge requests
        val currentState = _uropayPaymentState.value
        if (currentState is UroPayPaymentUiState.CreatingOrder ||
            currentState is UroPayPaymentUiState.OpeningCheckout ||
            currentState is UroPayPaymentUiState.Verifying
        ) {
            Log.d("BaatlyViewModel", "Payment already in progress (${currentState.javaClass.simpleName}), ignoring tap")
            return
        }

        // If there is an existing pending payment for this package with a valid openUrl, allow resuming checkout
        val existingPending = sessionManager.getPendingPayment()
        if (existingPending != null &&
            existingPending.packageId == pkg.id &&
            !existingPending.openUrl.isNullOrBlank() &&
            UroPayCheckoutLauncher.isValidCheckoutUrl(existingPending.openUrl) &&
            (System.currentTimeMillis() - existingPending.createdAt) < 5 * 60 * 1000L
        ) {
            Log.d("BaatlyViewModel", "Reusing existing valid pending order: ${existingPending.paymentId}")
            _uropayPaymentState.value = UroPayPaymentUiState.OpeningCheckout(
                paymentId = existingPending.paymentId,
                openUrl = existingPending.openUrl,
                amountRupees = existingPending.amountRupees,
                pkg = pkg
            )
            return
        }

        _uropayPaymentState.value = UroPayPaymentUiState.CreatingOrder(pkg.amountRupees)
        val tenantRef = "BAATLY_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"

        viewModelScope.launch {
            dataService.createUroPayOrder(pkg.id, tenantRef, effectiveCallId)
                .onSuccess { orderRes ->
                    val validUrl = orderRes.openUrl?.trim()
                    val isValidUrl = !validUrl.isNullOrBlank() && UroPayCheckoutLauncher.isValidCheckoutUrl(validUrl)

                    if (isValidUrl && !validUrl.isNullOrBlank()) {
                        val pending = PendingUroPayPayment(
                            paymentId = orderRes.paymentId,
                            orderId = orderRes.orderId,
                            tenantOrderRef = tenantRef,
                            packageId = pkg.id,
                            amountRupees = pkg.amountRupees,
                            openUrl = validUrl,
                            targetCallId = effectiveCallId
                        )
                        sessionManager.savePendingPayment(pending)
                        _uropayPaymentState.value = UroPayPaymentUiState.OpeningCheckout(
                            paymentId = orderRes.paymentId,
                            openUrl = validUrl,
                            amountRupees = pkg.amountRupees,
                            pkg = pkg
                        )
                    } else {
                        val errMsg = if (validUrl.isNullOrBlank()) "No checkout URL returned from payment server" else "Invalid checkout URL returned"
                        _uropayPaymentState.value = UroPayPaymentUiState.Failed(
                            paymentId = orderRes.paymentId,
                            errorMessage = errMsg,
                            canRetry = true,
                            amountRupees = pkg.amountRupees
                        )
                    }
                }
                .onFailure { e ->
                    _uropayPaymentState.value = UroPayPaymentUiState.Failed(null, e.message ?: "Failed to create order", true, pkg.amountRupees)
                }
        }
    }

    fun onCheckoutLaunchFailed(paymentId: String?, errorMessage: String, amountRupees: Double = 0.0) {
        Log.e("BaatlyViewModel", "Checkout launch failed for paymentId=$paymentId: $errorMessage")
        UroPayCheckoutLauncher.resetLaunchTracking()
        _uropayPaymentState.value = UroPayPaymentUiState.Failed(
            paymentId = paymentId,
            errorMessage = errorMessage,
            canRetry = true,
            amountRupees = amountRupees
        )
    }

    fun onCheckoutLaunched(paymentId: String) {
        Log.d("BaatlyViewModel", "Checkout window opened successfully for paymentId=$paymentId")
    }

    fun cancelUroPayPayment() {
        UroPayCheckoutLauncher.resetLaunchTracking()
        sessionManager.clearPendingPayment()
        _uropayPaymentState.value = UroPayPaymentUiState.Cancelled
    }

    fun verifyUroPayPayment(paymentId: String) {
        val pending = sessionManager.getPendingPayment()
        val targetCallIdToRefresh = pending?.targetCallId ?: _activeCall.value?.id

        _uropayPaymentState.value = UroPayPaymentUiState.Verifying(paymentId, 0.0)
        viewModelScope.launch {
            dataService.verifyUroPayPayment(paymentId)
                .onSuccess { res ->
                    if (res.verified && res.status.equals("success", ignoreCase = true) && res.amountRupees > 0.0) {
                        sessionManager.clearPendingPayment()
                        _showRechargePopup.value = false
                        viewModelScope.launch {
                            dataService.fetchWalletSummary().fold(
                                onSuccess = { freshSummary ->
                                    _walletSummary.value = freshSummary
                                    _isWalletInitialized.value = true
                                    _isWalletLoading.value = false
                                    _walletError.value = null
                                    _uropayPaymentState.value = UroPayPaymentUiState.Success(paymentId, res.amountRupees, freshSummary.balanceRupees)
                                },
                                onFailure = {
                                    refreshWallet()
                                    _uropayPaymentState.value = UroPayPaymentUiState.Success(paymentId, res.amountRupees, _walletSummary.value.balanceRupees + res.amountRupees)
                                }
                            )
                        }

                        if (!targetCallIdToRefresh.isNullOrBlank()) {
                            dataService.getCallRecord(targetCallIdToRefresh).onSuccess { freshCall ->
                                val status = freshCall.status.lowercase()
                                if (status == "connected" || status == "accepted" || status == "ringing") {
                                    _activeCall.value = freshCall
                                    val newMax = freshCall.maxDurationSeconds
                                    if (newMax > 0) {
                                        val newRemaining = (newMax - _callElapsedSeconds.value).coerceAtLeast(0)
                                        _callRemainingSeconds.value = newRemaining
                                    }
                                    showUserMessage("Recharge successful! Call duration extended.")
                                }
                            }
                        }
                    } else {
                        sessionManager.clearPendingPayment()
                        val statusLower = res.status.lowercase()
                        when {
                            statusLower.contains("cancel") -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Cancelled
                            }
                            statusLower.contains("fail") -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Failed(
                                    paymentId = paymentId,
                                    errorMessage = "Payment failed.",
                                    canRetry = true,
                                    amountRupees = res.amountRupees
                                )
                            }
                            statusLower.contains("expire") -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Expired(paymentId)
                            }
                            statusLower.contains("pending") || statusLower.contains("process") -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Pending(
                                    paymentId = paymentId,
                                    amountRupees = res.amountRupees,
                                    message = "Payment is still processing."
                                )
                            }
                            else -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Failed(
                                    paymentId = paymentId,
                                    errorMessage = res.message.ifBlank { "Payment was not completed." },
                                    canRetry = true,
                                    amountRupees = res.amountRupees
                                )
                            }
                        }
                    }
                }
                .onFailure { e ->
                    _uropayPaymentState.value = UroPayPaymentUiState.Failed(paymentId, e.message ?: "Verification request failed")
                }
        }
    }

    fun closeInAppCheckout() {
        val pending = sessionManager.getPendingPayment()
        if (pending != null) {
            verifyUroPayPayment(pending.paymentId)
        } else {
            _uropayPaymentState.value = UroPayPaymentUiState.Idle
        }
    }

    fun resetPaymentState() {
        UroPayCheckoutLauncher.resetLaunchTracking()
        _uropayPaymentState.value = UroPayPaymentUiState.Idle
    }

    fun handlePaymentReturnDeepLink(uri: Uri) {
        val paymentId = uri.getQueryParameter("payment_id") ?: sessionManager.getPendingPayment()?.paymentId
        if (!paymentId.isNullOrBlank()) {
            verifyUroPayPayment(paymentId)
        }
    }

    fun fetchTransactions() {
        viewModelScope.launch {
            dataService.fetchTransactions().onSuccess { list ->
                _transactions.value = list
            }
            dataService.fetchWalletTransactions().onSuccess { list ->
                _walletTransactions.value = list
            }
        }
    }

    // ==========================================
    // NOTIFICATIONS & FCM
    // ==========================================

    private fun refreshFcmToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful && task.result != null) {
                val token = task.result
                sessionManager.saveFcmToken(token)
                viewModelScope.launch {
                    dataService.registerFcmToken(token)
                }
            }
        }
    }

    fun refreshNotifications() {
        viewModelScope.launch {
            dataService.fetchNotifications().onSuccess { list ->
                _notifications.value = list
                _unreadNotificationsCount.value = list.count { !it.isRead }
            }
        }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            dataService.markNotificationAsRead(id)
            refreshNotifications()
        }
    }

    fun handleNotificationTap(type: String?, data: Map<String, String?>) {
        when (type) {
            "call", "incoming_call" -> {
                val callId = data["call_id"]
                if (!callId.isNullOrBlank()) {
                    setScreen(Screen.ACTIVE_CALL)
                }
            }
            "chat", "message" -> {
                val convId = data["conversation_id"]
                val partnerId = data["partner_id"]
                if (!convId.isNullOrBlank() || !partnerId.isNullOrBlank()) {
                    setScreen(Screen.CHAT_LIST)
                }
            }
            "recharge", "wallet" -> {
                setScreen(Screen.WALLET)
            }
            else -> {
                setScreen(Screen.NOTIFICATIONS)
            }
        }
    }

    // ==========================================
    // RATINGS & REVIEWS
    // ==========================================

    private fun checkCallRatingEligibility(callId: String, partnerId: String) {
        viewModelScope.launch {
            dataService.getCallRatingEligibility(callId).onSuccess { elig ->
                if (elig.isEligible) {
                    val partnerName = _activeCallPartner.value?.displayName ?: "Host"
                    val partnerAvatar = _activeCallPartner.value?.avatarUrl
                    _pendingRatingCall.value = PendingRatingCall(
                        callId = callId,
                        partnerId = partnerId,
                        partnerName = partnerName,
                        partnerAvatar = partnerAvatar,
                        durationSeconds = _callElapsedSeconds.value
                    )
                }
            }
        }
    }

    fun submitCallRating(rating: Int, reviewText: String?) {
        val pending = _pendingRatingCall.value ?: return
        _isSubmittingRating.value = true
        viewModelScope.launch {
            dataService.submitCallRating(pending.callId, pending.partnerId, rating, reviewText)
                .onSuccess {
                    _isSubmittingRating.value = false
                    _pendingRatingCall.value = null
                    showUserMessage("Thank you for your rating!")
                }
                .onFailure { e ->
                    _isSubmittingRating.value = false
                    showUserMessage("Rating submission failed: ${e.message}")
                }
        }
    }

    fun dismissRatingPopup() {
        _pendingRatingCall.value = null
    }

    // ==========================================
    // BLOCK & REPORT USER
    // ==========================================

    fun blockUser(partnerId: String) {
        viewModelScope.launch {
            dataService.blockUser(partnerId).onSuccess { rpcSuccess ->
                if (rpcSuccess) {
                    dataService.isUserBlocked(partnerId).onSuccess { verifyStatus ->
                        if (verifyStatus.blockedByMe) {
                            _chatBlockStatus.value = verifyStatus
                            _isChatBlocked.value = true
                            showUserMessage("User blocked")
                            refreshPartners()
                        } else {
                            showUserMessage("Block verification failed on backend")
                            dataService.isUserBlocked(partnerId).onSuccess { s ->
                                _chatBlockStatus.value = s
                                _isChatBlocked.value = s.blockedByMe
                            }
                        }
                    }.onFailure { e ->
                        showUserMessage("Block verification error: ${e.message}")
                        dataService.isUserBlocked(partnerId).onSuccess { s ->
                            _chatBlockStatus.value = s
                            _isChatBlocked.value = s.blockedByMe
                        }
                    }
                } else {
                    showUserMessage("Block request was not acknowledged by backend")
                }
            }.onFailure { e ->
                showUserMessage("Could not block user: ${e.message}")
            }
        }
    }

    fun unblockUser(partnerId: String) {
        viewModelScope.launch {
            dataService.unblockUser(partnerId).onSuccess { rpcSuccess ->
                if (rpcSuccess) {
                    dataService.isUserBlocked(partnerId).onSuccess { verifyStatus ->
                        if (!verifyStatus.blockedByMe) {
                            _chatBlockStatus.value = verifyStatus
                            _isChatBlocked.value = false
                            showUserMessage("User unblocked")
                            refreshPartners()
                        } else {
                            showUserMessage("Unblock verification failed on backend")
                            dataService.isUserBlocked(partnerId).onSuccess { s ->
                                _chatBlockStatus.value = s
                                _isChatBlocked.value = s.blockedByMe
                            }
                        }
                    }.onFailure { e ->
                        showUserMessage("Unblock verification error: ${e.message}")
                        dataService.isUserBlocked(partnerId).onSuccess { s ->
                            _chatBlockStatus.value = s
                            _isChatBlocked.value = s.blockedByMe
                        }
                    }
                } else {
                    showUserMessage("Unblock request was not acknowledged by backend")
                }
            }.onFailure { e ->
                showUserMessage("Could not unblock user: ${e.message}")
            }
        }
    }

    fun openReportDialog(targetUserId: String, targetUserName: String, targetAvatarUrl: String? = null) {
        _activeReportTarget.value = ActiveReportTarget(targetUserId, targetUserName, targetAvatarUrl)
    }

    fun openReportDialog(reportedUserId: String, targetDisplayName: String) {
        _activeReportTarget.value = ActiveReportTarget(reportedUserId, targetDisplayName, null)
    }

    fun dismissReportDialog() {
        _activeReportTarget.value = null
    }

    fun closeReportDialog() {
        dismissReportDialog()
    }

    fun submitUserReport(category: String, description: String?, callId: String? = null, messageId: String? = null, priority: String = "normal") {
        val target = _activeReportTarget.value ?: return
        _isSubmittingReport.value = true
        viewModelScope.launch {
            val effectiveCallId = callId ?: _activeCall.value?.id
            dataService.submitUserReport(
                reportedUserId = target.targetUserId,
                category = category,
                description = description ?: "",
                callId = effectiveCallId,
                messageId = messageId,
                priority = priority
            )
                .onSuccess {
                    _isSubmittingReport.value = false
                    _activeReportTarget.value = null
                    showUserMessage("Report submitted. Thank you.")
                }
                .onFailure { e ->
                    _isSubmittingReport.value = false
                    showUserMessage("Report failed: ${e.message}")
                }
        }
    }

    // ==========================================
    // UTILS
    // ==========================================

    fun showUserMessage(msg: String) {
        _userMessage.value = msg
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // ==========================================
    // SOCIAL & FULL SCREEN VIEWER STATE
    // ==========================================

    private val _socialPosts = MutableStateFlow<List<SocialPost>>(emptyList())
    val socialPosts: StateFlow<List<SocialPost>> = _socialPosts.asStateFlow()

    private val _socialStories = MutableStateFlow<List<SocialStory>>(emptyList())
    val socialStories: StateFlow<List<SocialStory>> = _socialStories.asStateFlow()

    private val _isSocialLoading = MutableStateFlow(false)
    val isSocialLoading: StateFlow<Boolean> = _isSocialLoading.asStateFlow()

    private val _socialFeedMode = MutableStateFlow("for_you") // "for_you" or "following"
    val socialFeedMode: StateFlow<String> = _socialFeedMode.asStateFlow()

    // My Social Profile / User Profile Posts State
    private val _mySocialProfile = MutableStateFlow<SocialProfile?>(null)
    val mySocialProfile: StateFlow<SocialProfile?> = _mySocialProfile.asStateFlow()

    private val _mySocialPosts = MutableStateFlow<List<SocialPost>>(emptyList())
    val mySocialPosts: StateFlow<List<SocialPost>> = _mySocialPosts.asStateFlow()

    private val _isMySocialLoading = MutableStateFlow(false)
    val isMySocialLoading: StateFlow<Boolean> = _isMySocialLoading.asStateFlow()

    // Host Social Profile State
    private val _viewedSocialProfile = MutableStateFlow<SocialProfile?>(null)
    val viewedSocialProfile: StateFlow<SocialProfile?> = _viewedSocialProfile.asStateFlow()

    private val _viewedSocialPosts = MutableStateFlow<List<SocialPost>>(emptyList())
    val viewedSocialPosts: StateFlow<List<SocialPost>> = _viewedSocialPosts.asStateFlow()

    private val _isViewedSocialLoading = MutableStateFlow(false)
    val isViewedSocialLoading: StateFlow<Boolean> = _isViewedSocialLoading.asStateFlow()

    // Social Search State
    private val _socialSearchResults = MutableStateFlow<List<SocialProfile>>(emptyList())
    val socialSearchResults: StateFlow<List<SocialProfile>> = _socialSearchResults.asStateFlow()

    private val _isSocialSearching = MutableStateFlow(false)
    val isSocialSearching: StateFlow<Boolean> = _isSocialSearching.asStateFlow()

    private val _socialSearchError = MutableStateFlow<String?>(null)
    val socialSearchError: StateFlow<String?> = _socialSearchError.asStateFlow()

    // Full Screen Media Viewer State
    private val _fullScreenMediaUrl = MutableStateFlow<String?>(null)
    val fullScreenMediaUrl: StateFlow<String?> = _fullScreenMediaUrl.asStateFlow()

    private val _fullScreenMediaType = MutableStateFlow("image")
    val fullScreenMediaType: StateFlow<String> = _fullScreenMediaType.asStateFlow()

    private var previousScreenBeforeMediaViewer: Screen = Screen.HOME

    fun openFullScreenMedia(url: String, type: String = "image") {
        if (url.isBlank()) return
        previousScreenBeforeMediaViewer = _currentScreen.value
        _fullScreenMediaUrl.value = url
        _fullScreenMediaType.value = type
        setScreen(Screen.FULL_SCREEN_MEDIA_VIEWER)
    }

    fun closeFullScreenMedia() {
        _fullScreenMediaUrl.value = null
        setScreen(previousScreenBeforeMediaViewer)
    }

    fun setSocialFeedMode(mode: String) {
        _socialFeedMode.value = mode
        refreshSocialFeed()
    }

    fun refreshSocialFeed() {
        _isSocialLoading.value = true
        viewModelScope.launch {
            dataService.getSocialFeed(mode = _socialFeedMode.value).onSuccess { posts ->
                _socialPosts.value = posts
                _isSocialLoading.value = false
            }.onFailure { e ->
                _isSocialLoading.value = false
                Log.w("BaatlyViewModel", "Failed to load social feed: ${e.message}")
            }
            refreshSocialStories()
        }
    }

    fun refreshSocialStories() {
        viewModelScope.launch {
            dataService.getVisibleStories().onSuccess { stories ->
                _socialStories.value = stories
            }.onFailure { e ->
                Log.w("BaatlyViewModel", "Failed to load social stories: ${e.message}")
            }
        }
    }

    // Social Action In-Flight Guards (Double-tap Protection)
    private val _isSocialActionInFlight = MutableStateFlow(false)
    val isSocialActionInFlight: StateFlow<Boolean> = _isSocialActionInFlight.asStateFlow()

    private val _activeLikeOperations = MutableStateFlow<Set<String>>(emptySet())
    val activeLikeOperations: StateFlow<Set<String>> = _activeLikeOperations.asStateFlow()

    private val _activeUnlockOperations = MutableStateFlow<Set<String>>(emptySet())
    val activeUnlockOperations: StateFlow<Set<String>> = _activeUnlockOperations.asStateFlow()

    fun unlockSocialPost(post: SocialPost) {
        if (_activeUnlockOperations.value.contains(post.id)) return
        val cost = if (post.unlockPriceRupees > 0.0) post.unlockPriceRupees else _effectivePricing.value.socialPostUnlockRateRupees
        if (_walletSummary.value.availableBalanceRupees < cost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance. ₹${cost.toInt()} required to unlock.")
            return
        }

        _activeUnlockOperations.value = _activeUnlockOperations.value + post.id
        viewModelScope.launch {
            try {
                dataService.socialViewContent("post", post.id).onSuccess { res ->
                    showUserMessage("Unlocked post!")
                    _socialPosts.value = _socialPosts.value.map {
                        if (it.id == post.id) it.copy(isUnlocked = true, isLocked = false, visibleUntil = res.visibleUntil) else it
                    }
                    if (res.charged) {
                        refreshWallet()
                    }
                }.onFailure { e ->
                    showUserMessage("Unlock failed: ${e.message}")
                }
            } finally {
                _activeUnlockOperations.value = _activeUnlockOperations.value - post.id
            }
        }
    }

    fun unlockSocialStory(story: SocialStory, onUnlocked: () -> Unit) {
        if (_activeUnlockOperations.value.contains(story.id)) return
        val cost = if (story.unlockPriceRupees > 0.0) story.unlockPriceRupees else _effectivePricing.value.socialStoryUnlockRateRupees
        if (_walletSummary.value.availableBalanceRupees < cost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance. ₹${cost.toInt()} required to unlock story.")
            return
        }

        _activeUnlockOperations.value = _activeUnlockOperations.value + story.id
        viewModelScope.launch {
            try {
                dataService.socialViewContent("story", story.id).onSuccess { res ->
                    showUserMessage("Unlocked story!")
                    _socialStories.value = _socialStories.value.map {
                        if (it.id == story.id) it.copy(isUnlocked = true, isLocked = false, isViewed = true) else it
                    }
                    if (res.charged) {
                        refreshWallet()
                    }
                    onUnlocked()
                }.onFailure { e ->
                    showUserMessage("Unlock failed: ${e.message}")
                }
            } finally {
                _activeUnlockOperations.value = _activeUnlockOperations.value - story.id
            }
        }
    }

    fun toggleSocialLike(post: SocialPost) {
        if (_activeLikeOperations.value.contains(post.id)) return
        val currentLiked = post.isLiked
        val cost = if (!currentLiked) _effectivePricing.value.socialLikeRateRupees else 0.0
        if (!currentLiked && _walletSummary.value.availableBalanceRupees < cost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance. ₹${cost.toInt()} required to like.")
            return
        }

        _activeLikeOperations.value = _activeLikeOperations.value + post.id
        // Optimistic UI update
        val newLiked = !currentLiked
        val newCount = if (newLiked) post.likesCount + 1 else (post.likesCount - 1).coerceAtLeast(0)
        _socialPosts.value = _socialPosts.value.map {
            if (it.id == post.id) it.copy(isLiked = newLiked, likesCount = newCount) else it
        }

        viewModelScope.launch {
            try {
                dataService.socialToggleLike("post", post.id).onSuccess { res ->
                    val finalCount = if (res.isLiked == currentLiked) post.likesCount else newCount
                    _socialPosts.value = _socialPosts.value.map {
                        if (it.id == post.id) it.copy(isLiked = res.isLiked, likesCount = finalCount) else it
                    }
                    if (res.charged) {
                        refreshWallet()
                    }
                }.onFailure { e ->
                    // Revert optimistic update
                    _socialPosts.value = _socialPosts.value.map {
                        if (it.id == post.id) it.copy(isLiked = currentLiked, likesCount = post.likesCount) else it
                    }
                    showUserMessage("Like failed: ${e.message}")
                }
            } finally {
                _activeLikeOperations.value = _activeLikeOperations.value - post.id
            }
        }
    }

    fun sendSocialLoveNote(contentType: String, contentId: String, messageText: String, onComplete: () -> Unit) {
        if (messageText.isBlank()) return
        if (_isSocialActionInFlight.value) return
        val cost = _effectivePricing.value.socialLoveNoteRateRupees
        if (_walletSummary.value.availableBalanceRupees < cost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance. ₹${cost.toInt()} required to send Love Note.")
            return
        }

        _isSocialActionInFlight.value = true
        viewModelScope.launch {
            try {
                dataService.socialSendLoveNote(contentType, contentId, messageText.trim()).onSuccess { res ->
                    showUserMessage("Love Note sent!")
                    refreshWallet()
                    refreshConversations()
                    if (contentType == "post") {
                        _socialPosts.value = _socialPosts.value.map {
                            if (it.id == contentId) it.copy(loveNotesCount = it.loveNotesCount + 1) else it
                        }
                    } else if (contentType == "story") {
                        _socialStories.value = _socialStories.value.map {
                            if (it.id == contentId) it.copy(loveNotesCount = it.loveNotesCount + 1) else it
                        }
                    }
                    onComplete()
                }.onFailure { e ->
                    showUserMessage("Could not send Love Note: ${e.message}")
                }
            } finally {
                _isSocialActionInFlight.value = false
            }
        }
    }

    fun toggleSocialFollow(targetUserId: String) {
        viewModelScope.launch {
            dataService.socialFollowToggle(targetUserId).onSuccess { following ->
                _socialPosts.value = _socialPosts.value.map {
                    if (it.userId == targetUserId) it.copy(isFollowing = following) else it
                }
                showUserMessage(if (following) "Followed!" else "Unfollowed")
            }.onFailure { e ->
                showUserMessage("Follow failed: ${e.message}")
            }
        }
    }

    fun createSocialPost(mediaFile: File, caption: String, onComplete: () -> Unit) {
        if (_isSocialActionInFlight.value) return
        val cost = _effectivePricing.value.socialPostCreationRateRupees
        if (_walletSummary.value.availableBalanceRupees < cost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance. ₹${cost.toInt()} required to create post.")
            return
        }

        _isSocialActionInFlight.value = true
        viewModelScope.launch {
            try {
                showUserMessage("Uploading photo...")
                dataService.uploadSocialMedia(mediaFile, isStory = false).onSuccess { mediaPath ->
                    dataService.socialCreateContent("post", mediaPath, caption).onSuccess { createdId ->
                        Log.i("BaatlyViewModel", "Post created with ID: $createdId")
                        showUserMessage("Post created successfully!")
                        refreshWallet()
                        refreshSocialFeed()
                        onComplete()
                    }.onFailure { e ->
                        // Attempt cleanup of orphaned media upon failure
                        launch(Dispatchers.IO) {
                            dataService.cleanupUploadedMedia(SupabaseConfig.BUCKET_SOCIAL_MEDIA, mediaPath)
                        }
                        showUserMessage("Failed to publish post: ${e.message}")
                    }
                }.onFailure { e ->
                    showUserMessage("Upload failed: ${e.message}")
                }
            } finally {
                _isSocialActionInFlight.value = false
            }
        }
    }

    fun createSocialStory(mediaFile: File, caption: String, onComplete: () -> Unit) {
        if (_isSocialActionInFlight.value) return
        val cost = _effectivePricing.value.socialStoryCreationRateRupees
        if (_walletSummary.value.availableBalanceRupees < cost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance. ₹${cost.toInt()} required to create story.")
            return
        }

        _isSocialActionInFlight.value = true
        viewModelScope.launch {
            try {
                showUserMessage("Uploading story...")
                dataService.uploadSocialMedia(mediaFile, isStory = true).onSuccess { mediaPath ->
                    dataService.socialCreateContent("story", mediaPath, caption).onSuccess { createdId ->
                        Log.i("BaatlyViewModel", "Story created with ID: $createdId")
                        showUserMessage("Story created successfully!")
                        refreshWallet()
                        refreshSocialStories()
                        onComplete()
                    }.onFailure { e ->
                        // Attempt cleanup of orphaned media upon failure
                        launch(Dispatchers.IO) {
                            dataService.cleanupUploadedMedia(SupabaseConfig.BUCKET_STORIES_MEDIA, mediaPath)
                        }
                        showUserMessage("Failed to publish story: ${e.message}")
                    }
                }.onFailure { e ->
                    showUserMessage("Upload failed: ${e.message}")
                }
            } finally {
                _isSocialActionInFlight.value = false
            }
        }
    }

    // ==========================================
    // SOCIAL POST & STORY DELETION
    // ==========================================

    fun deleteSocialPost(postId: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        if (postId.isBlank()) return
        if (_isSocialActionInFlight.value) return
        _isSocialActionInFlight.value = true

        viewModelScope.launch {
            try {
                dataService.socialDeletePost(postId).onSuccess {
                    showUserMessage("Post deleted successfully")
                    // Remove from feed and profile lists immediately
                    _socialPosts.value = _socialPosts.value.filter { it.id != postId }
                    _mySocialPosts.value = _mySocialPosts.value.filter { it.id != postId }
                    // Refresh profile counts & feed
                    _mySocialProfile.value = _mySocialProfile.value?.let { prof ->
                        prof.copy(postsCount = (prof.postsCount - 1).coerceAtLeast(0))
                    }
                    refreshSocialFeed()
                    loadMySocialProfile()
                    onComplete?.invoke(true, null)
                }.onFailure { e ->
                    val err = e.message ?: "Failed to delete post"
                    showUserMessage(err)
                    onComplete?.invoke(false, err)
                }
            } finally {
                _isSocialActionInFlight.value = false
            }
        }
    }

    fun deleteSocialStory(storyId: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        if (storyId.isBlank()) return
        if (_isSocialActionInFlight.value) return
        _isSocialActionInFlight.value = true

        viewModelScope.launch {
            try {
                dataService.socialDeleteStory(storyId).onSuccess {
                    showUserMessage("Story deleted successfully")
                    _socialStories.value = _socialStories.value.filter { it.id != storyId }
                    refreshSocialStories()
                    onComplete?.invoke(true, null)
                }.onFailure { e ->
                    val err = e.message ?: "Failed to delete story"
                    showUserMessage(err)
                    onComplete?.invoke(false, err)
                }
            } finally {
                _isSocialActionInFlight.value = false
            }
        }
    }

    // ==========================================
    // MY SOCIAL PROFILE & POSTS
    // ==========================================

    fun loadMySocialProfile() {
        val uid = sessionManager.userId.value.orEmpty()
        if (uid.isBlank()) return
        _isMySocialLoading.value = true
        viewModelScope.launch {
            // First ensure profile exists
            dataService.socialEnsureProfile()

            dataService.socialPublicProfile(uid).onSuccess { prof ->
                _mySocialProfile.value = prof
            }.onFailure { e ->
                Log.d("BaatlyViewModel", "loadMySocialProfile info fallback: ${e.message}")
                val cur = sessionManager.currentUser.value
                _mySocialProfile.value = SocialProfile(
                    userId = uid,
                    displayName = cur?.displayName ?: "User",
                    username = cur?.username ?: cur?.userId ?: "",
                    avatarUrl = cur?.avatarUrl,
                    bio = cur?.bio
                )
            }

            dataService.socialGetProfilePosts(uid, limit = 50, offset = 0).onSuccess { posts ->
                _mySocialPosts.value = posts
                _mySocialProfile.value = _mySocialProfile.value?.copy(postsCount = posts.size)
                _isMySocialLoading.value = false
            }.onFailure { e ->
                _isMySocialLoading.value = false
                Log.w("BaatlyViewModel", "loadMySocialProfile posts error: ${e.message}")
            }
        }
    }

    // ==========================================
    // VIEWED USER/HOST SOCIAL PROFILE & POSTS
    // ==========================================

    fun openHostSocialProfileFromPost(post: SocialPost) {
        val targetId = post.userId.takeIf { it.isNotBlank() } ?: return
        val currentUserId = sessionManager.userId.value.orEmpty()
        if (targetId == currentUserId) {
            setScreen(Screen.PROFILE)
            loadMySocialProfile()
            return
        }

        // Check if we have matching PartnerProfile in available partners
        val matchedPartner = _availablePartners.value.find { it.userId == targetId || it.id == targetId }
        if (matchedPartner != null) {
            selectPartner(matchedPartner)
            return
        }

        // Otherwise load partner by host ID or fallback
        viewModelScope.launch {
            dataService.getHostProfile(targetId).onSuccess { p ->
                selectPartner(p)
            }.onFailure {
                // Synthesize partner profile from post data
                val synthPartner = PartnerProfile(
                    id = targetId,
                    userId = targetId,
                    partnerDisplayName = post.creatorName,
                    avatarUrl = post.creatorAvatarUrl,
                    isAvailable = true,
                    isOnline = true,
                    audioEnabled = post.canVoiceCall,
                    videoEnabled = post.canVideoCall,
                    videoCallAccess = post.canVideoCall,
                    chatEnabled = post.canLoveNote
                )
                selectPartner(synthPartner)
            }
        }
    }

    fun loadViewedSocialProfile(targetUserId: String) {
        if (targetUserId.isBlank()) return
        _isViewedSocialLoading.value = true
        viewModelScope.launch {
            dataService.socialPublicProfile(targetUserId).onSuccess { prof ->
                _viewedSocialProfile.value = prof
            }.onFailure { e ->
                Log.w("BaatlyViewModel", "loadViewedSocialProfile info error: ${e.message}")
            }

            dataService.socialGetProfilePosts(targetUserId, limit = 50, offset = 0).onSuccess { posts ->
                _viewedSocialPosts.value = posts
                _isViewedSocialLoading.value = false
            }.onFailure { e ->
                _isViewedSocialLoading.value = false
                Log.w("BaatlyViewModel", "loadViewedSocialProfile posts error: ${e.message}")
            }
        }
    }

    // ==========================================
    // SOCIAL SEARCH FOR HOSTS
    // ==========================================

    fun searchSocialHosts(query: String) {
        if (query.isBlank()) {
            _socialSearchResults.value = emptyList()
            _socialSearchError.value = null
            _isSocialSearching.value = false
            return
        }

        _isSocialSearching.value = true
        _socialSearchError.value = null
        viewModelScope.launch {
            dataService.socialSearchProfiles(query.trim(), limit = 20).onSuccess { results ->
                _socialSearchResults.value = results
                _isSocialSearching.value = false
                _socialSearchError.value = null
            }.onFailure { e ->
                _isSocialSearching.value = false
                _socialSearchError.value = e.message ?: "Failed to find hosts"
            }
        }
    }

    fun openHostSocialProfile(profile: SocialProfile) {
        val targetId = profile.userId.takeIf { it.isNotBlank() } ?: return
        val currentUserId = sessionManager.userId.value.orEmpty()
        if (targetId == currentUserId) {
            setScreen(Screen.PROFILE)
            loadMySocialProfile()
            return
        }

        val matchedPartner = _availablePartners.value.find { it.userId == targetId || it.id == targetId }
        if (matchedPartner != null) {
            selectPartner(matchedPartner)
            return
        }

        viewModelScope.launch {
            dataService.getHostProfile(targetId).onSuccess { p ->
                selectPartner(p)
            }.onFailure {
                val synth = PartnerProfile(
                    id = targetId,
                    userId = targetId,
                    partnerDisplayName = profile.displayName,
                    bio = profile.bio,
                    avatarUrl = profile.avatarUrl,
                    isAvailable = true,
                    isOnline = profile.isOnline,
                    audioEnabled = true,
                    chatEnabled = true
                )
                selectPartner(synth)
            }
        }
    }
}
