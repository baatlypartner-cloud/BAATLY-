package com.example.ui.payment

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import androidx.browser.customtabs.CustomTabsCallback
import androidx.browser.customtabs.CustomTabsClient
import androidx.browser.customtabs.CustomTabsIntent
import androidx.browser.customtabs.CustomTabsServiceConnection
import androidx.browser.customtabs.CustomTabsSession

/**
 * UroPayCheckoutLauncher coordinates launching the UroPay checkout URL
 * following this strict fallback order:
 *
 * UroPay open_url
 *         ↓
 * Validate URL
 *         ↓
 * Try Pre-warmed Custom Tabs
 *         ↓
 * If unavailable → ACTION_VIEW (System Browser)
 *         ↓
 * If unavailable → Safe Error State (No infinite spinner)
 */
object UroPayCheckoutLauncher {
    private const val TAG = "UroPayCheckoutLauncher"

    const val USER_FACING_LAUNCH_ERROR =
        "Unable to open payment page. Please install or enable a browser and try again."

    private val ALLOWED_CHECKOUT_HOSTS = setOf(
        "api.uropai.in",
        "uropai.in",
        "checkout.uropai.in",
        "checkout.uropay.me",
        "uropay.me",
        "api.uropay.me",
        "uropay.in",
        "api.uropay.in",
        "checkout.uropay.in",
        "baatly.app",
        "www.baatly.app",
        "baatly.com"
    )

    // Pre-warmed Custom Tabs Client & Session
    @Volatile
    private var customTabsClient: CustomTabsClient? = null
    @Volatile
    private var customTabsSession: CustomTabsSession? = null
    @Volatile
    private var customTabsServiceConnection: CustomTabsServiceConnection? = null
    @Volatile
    private var isBindingCustomTabs = false
    @Volatile
    private var preferredPackageName: String? = null

    // Deduplication tracking to prevent multiple browser windows
    @Volatile
    private var lastLaunchedPaymentId: String? = null
    @Volatile
    private var lastLaunchTimeMs: Long = 0L

    /**
     * Pre-warms the Custom Tabs service on app startup or wallet screen entry.
     * Initializes Chrome's browser process in background to prevent cold-start spinner delays.
     */
    fun prewarm(context: Context) {
        val appContext = context.applicationContext
        try {
            val pkg = CustomTabsClient.getPackageName(appContext, null)
            if (pkg.isNullOrBlank()) {
                Log.d(TAG, "No Custom Tabs provider available for pre-warming")
                return
            }
            preferredPackageName = pkg

            if (customTabsClient != null || isBindingCustomTabs) {
                return
            }

            isBindingCustomTabs = true
            val connection = object : CustomTabsServiceConnection() {
                override fun onCustomTabsServiceConnected(name: ComponentName, client: CustomTabsClient) {
                    Log.d(TAG, "CustomTabsService connected: $name. Warming up browser engine...")
                    customTabsClient = client
                    isBindingCustomTabs = false
                    try {
                        val warmed = client.warmup(0L)
                        Log.d(TAG, "CustomTabsClient warmup result: $warmed")
                        val session = client.newSession(object : CustomTabsCallback() {
                            override fun onNavigationEvent(navigationEvent: Int, extras: android.os.Bundle?) {
                                Log.d(TAG, "CustomTabs navigation event: $navigationEvent")
                            }
                        })
                        customTabsSession = session
                        // Hint connection to UroPay checkout servers for instant DNS/SSL resolution
                        session?.mayLaunchUrl(Uri.parse("https://api.uropai.in"), null, null)
                        session?.mayLaunchUrl(Uri.parse("https://checkout.uropai.in"), null, null)
                        session?.mayLaunchUrl(Uri.parse("https://checkout.uropay.me"), null, null)
                    } catch (e: Exception) {
                        Log.w(TAG, "Custom Tabs session initialization failed: ${e.message}")
                    }
                }

                override fun onServiceDisconnected(name: ComponentName?) {
                    Log.d(TAG, "CustomTabsService disconnected")
                    customTabsClient = null
                    customTabsSession = null
                    isBindingCustomTabs = false
                }
            }

            customTabsServiceConnection = connection
            val bound = CustomTabsClient.bindCustomTabsService(appContext, pkg, connection)
            Log.d(TAG, "CustomTabsClient.bindCustomTabsService result: $bound for pkg: $pkg")
        } catch (e: Exception) {
            isBindingCustomTabs = false
            Log.w(TAG, "Failed to pre-warm Custom Tabs: ${e.message}")
        }
    }

    /**
     * Unbinds Custom Tabs service cleanly if required.
     */
    fun unbind(context: Context) {
        try {
            customTabsServiceConnection?.let {
                context.applicationContext.unbindService(it)
                customTabsServiceConnection = null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error unbinding Custom Tabs service: ${e.message}")
        } finally {
            customTabsClient = null
            customTabsSession = null
            isBindingCustomTabs = false
        }
    }

    /**
     * Resets launch deduplication tracking (e.g. after cancellation or failure).
     */
    fun resetLaunchTracking() {
        lastLaunchedPaymentId = null
        lastLaunchTimeMs = 0L
    }

    /**
     * Validates that the checkout URL is safe and valid for UroPay:
     * - Parseable URI
     * - HTTPS scheme
     * - Host matches expected UroPay domain or allowed payment gateway
     */
    fun isValidCheckoutUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = try {
            Uri.parse(url.trim())
        } catch (_: Exception) {
            return false
        }
        val scheme = uri.scheme?.lowercase() ?: return false
        val host = uri.host?.lowercase() ?: return false
        if (scheme != "https") return false
        if (host.isBlank()) return false

        // Exact allowlist match or specific subdomain suffixes
        val isExpectedHost = ALLOWED_CHECKOUT_HOSTS.contains(host) ||
                host.endsWith(".uropai.in") ||
                host.endsWith(".uropay.me") ||
                host.endsWith(".uropay.in") ||
                host.endsWith(".baatly.app")
        return isExpectedHost
    }

    /**
     * Checks if Android Custom Tabs service is available on this device.
     */
    fun isCustomTabsAvailable(context: Context): Boolean {
        return try {
            val packageName = preferredPackageName ?: CustomTabsClient.getPackageName(context, null)
            if (!packageName.isNullOrBlank()) {
                preferredPackageName = packageName
                return true
            }
            val pm = context.packageManager
            val serviceIntent = Intent("android.support.customtabs.action.CustomTabsService")
            val resolveInfos = pm.queryIntentServices(serviceIntent, 0)
            resolveInfos.isNotEmpty()
        } catch (e: Exception) {
            Log.w(TAG, "Error checking Custom Tabs availability: ${e.message}")
            false
        }
    }

    /**
     * Checks if an Activity exists on the device to handle ACTION_VIEW for the given URI.
     */
    fun isBrowserActivityAvailable(context: Context, uri: Uri): Boolean {
        return try {
            val viewIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                if (context !is Activity) {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            val pm = context.packageManager
            val resolveActivity = viewIntent.resolveActivity(pm)
            if (resolveActivity != null) {
                return true
            }
            val activities = pm.queryIntentActivities(viewIntent, PackageManager.MATCH_DEFAULT_ONLY)
            activities.isNotEmpty()
        } catch (e: Exception) {
            Log.w(TAG, "Error checking browser activity availability: ${e.message}")
            false
        }
    }

    /**
     * Launches the checkout URL following the required fallback chain:
     * 1. Validate URL
     * 2. Deduplicate repeated launches for the same payment attempt
     * 3. Try Pre-warmed Custom Tabs if supported
     * 4. Try ACTION_VIEW if an activity can handle it
     * 5. If everything fails, report user-friendly error message and return false
     *
     * @return true if browser was launched successfully, false otherwise
     */
    @Synchronized
    fun launch(
        context: Context,
        openUrl: String,
        paymentId: String? = null,
        force: Boolean = false,
        onError: (userMessage: String) -> Unit
    ): Boolean {
        val trimmedUrl = openUrl.trim()
        val uri = try {
            Uri.parse(trimmedUrl)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse checkout URL: $trimmedUrl, error: ${e.message}")
            onError(USER_FACING_LAUNCH_ERROR)
            return false
        }

        val host = uri.host?.lowercase() ?: ""
        val scheme = uri.scheme?.lowercase() ?: ""

        Log.d(
            TAG,
            "UroPay checkout launch requested:\n" +
            "open_url=$trimmedUrl\n" +
            "paymentId=$paymentId\n" +
            "host=$host\n" +
            "scheme=$scheme"
        )

        // 1. Validate UroPay checkout URL
        if (!isValidCheckoutUrl(trimmedUrl)) {
            Log.e(TAG, "Invalid or unverified checkout URL rejected: host=$host, scheme=$scheme, url=$trimmedUrl")
            onError(USER_FACING_LAUNCH_ERROR)
            return false
        }

        // 2. Deduplicate rapid duplicate launches (e.g. from Compose recomposition or double clicks)
        val now = System.currentTimeMillis()
        if (!force && !paymentId.isNullOrBlank() && paymentId == lastLaunchedPaymentId && (now - lastLaunchTimeMs) < 3000L) {
            Log.d(TAG, "Checkout already launched for paymentId=$paymentId within 3000ms. Skipping duplicate launch.")
            return true
        }

        // 3. Custom Tabs first (preferred and pre-warmed)
        if (isCustomTabsAvailable(context)) {
            try {
                Log.d(TAG, "Custom Tabs provider available. Launching via CustomTabsIntent for: $trimmedUrl")
                val session = customTabsSession
                val builder = if (session != null) {
                    CustomTabsIntent.Builder(session)
                } else {
                    CustomTabsIntent.Builder()
                }

                val customTabsIntent = builder
                    .setShowTitle(true)
                    .setShareState(CustomTabsIntent.SHARE_STATE_OFF)
                    .build().apply {
                        val pkg = preferredPackageName ?: CustomTabsClient.getPackageName(context, null)
                        if (!pkg.isNullOrBlank()) {
                            intent.setPackage(pkg)
                        }
                        if (context !is Activity) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    }

                customTabsIntent.launchUrl(context, uri)
                lastLaunchedPaymentId = paymentId
                lastLaunchTimeMs = now
                Log.d(TAG, "CustomTabs launched successfully.")
                return true
            } catch (e: Exception) {
                Log.w(TAG, "CustomTabs launchUrl failed: ${e.message}. Proceeding to ACTION_VIEW fallback...", e)
            }
        } else {
            Log.d(TAG, "Custom Tabs not available on this device. Proceeding to ACTION_VIEW check...")
        }

        // 4. ACTION_VIEW Fallback
        val isBrowserAvailable = isBrowserActivityAvailable(context, uri)
        Log.d(TAG, "ACTION_VIEW browser activity resolvable: $isBrowserAvailable")
        if (isBrowserAvailable) {
            try {
                Log.d(TAG, "Browser Activity found for ACTION_VIEW. Launching...")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    if (context !is Activity) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                context.startActivity(intent)
                lastLaunchedPaymentId = paymentId
                lastLaunchTimeMs = now
                Log.d(TAG, "ACTION_VIEW launched successfully.")
                return true
            } catch (e: Exception) {
                Log.w(TAG, "ACTION_VIEW startActivity failed: ${e.message}.", e)
            }
        } else {
            Log.d(TAG, "No browser Activity found for ACTION_VIEW.")
        }

        // 5. Report failure without hanging
        Log.e(TAG, "No valid Custom Tabs or browser available to handle UroPay checkout.")
        onError(USER_FACING_LAUNCH_ERROR)
        return false
    }

    /**
     * Backward-compatible convenience launch method for callers not passing paymentId.
     */
    fun launch(
        context: Context,
        openUrl: String,
        onError: (userMessage: String) -> Unit
    ): Boolean {
        return launch(
            context = context,
            openUrl = openUrl,
            paymentId = null,
            force = false,
            onError = onError
        )
    }
}
