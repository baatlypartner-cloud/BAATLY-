package com.example.ui.astrologer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.BaatlyTopBar
import com.example.ui.theme.*

@Composable
fun AstrologerScreen(viewModel: BaatlyViewModel) {
    val walletSummary by viewModel.walletSummary.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val scrollState = rememberScrollState()

    var selectedZodiac by remember { mutableStateOf("Aries ♈") }
    val zodiacSigns = listOf(
        "Aries ♈", "Taurus ♉", "Gemini ♊", "Cancer ♋",
        "Leo ♌", "Virgo ♍", "Libra ♎", "Scorpio ♏",
        "Sagittarius ♐", "Capricorn ♑", "Aquarius ♒", "Pisces ♓"
    )

    Scaffold(
        topBar = {
            BaatlyTopBar(
                walletBalanceRupees = walletSummary.availableBalanceRupees,
                onWalletClick = { viewModel.setScreen(Screen.WALLET) },
                onNotificationClick = { viewModel.setScreen(Screen.NOTIFICATIONS) },
                unreadNotifications = notifications.count { !it.isRead },
                onRefreshClick = {}
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "AI Astrologer ✨",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
            }

            Text(
                text = "Ancient Vedic wisdom powered by verified astrology calculations.",
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
            )

            // Preparation Notice Card (No fake ephemeris calculations)
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = PrimaryLavenderContainer.copy(alpha = 0.4f),
                border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryLavender.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(PrimaryLavender.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = PrimaryLavender,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Astrology Engine Being Prepared",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "High-precision planetary ephemeris backend integration is underway. Real-time horoscope insights will be available soon.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        )
                    }
                }
            }

            // Zodiac Selector (Shell)
            Text(
                text = "Select Zodiac Sign",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                zodiacSigns.take(4).forEach { sign ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (selectedZodiac == sign) PrimaryLavender else DarkSurface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selectedZodiac == sign) PrimaryLavender else DarkCardBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedZodiac = sign }
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = sign.split(" ").last(),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = if (selectedZodiac == sign) Color.White else TextPrimary
                                )
                            )
                        }
                    }
                }
            }

            // Astrology Service Shell Cards
            Text(
                text = "Astrology Services",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            AstrologyFeatureCard(
                title = "Daily Vedic Horoscope",
                description = "Personalized planetary transit analysis based on your moon sign and nakshatra.",
                icon = Icons.Outlined.WbSunny,
                tag = "Coming Soon",
                onClick = {
                    viewModel.showUserMessage("Daily Horoscope service is being prepared with real ephemeris engine.")
                }
            )

            AstrologyFeatureCard(
                title = "Kundali / Birth Chart (Janam Patri)",
                description = "Comprehensive 12-house chart mapping planetary positions at your exact birth time.",
                icon = Icons.Outlined.AutoGraph,
                tag = "In Architecture",
                onClick = {
                    viewModel.showUserMessage("Birth chart calculations require exact planetary ephemeris data.")
                }
            )

            AstrologyFeatureCard(
                title = "Kundali Milan & Compatibility",
                description = "Ashtakoota 36-guna match analysis for relationship harmony and longevity.",
                icon = Icons.Outlined.FavoriteBorder,
                tag = "Coming Soon",
                onClick = {
                    viewModel.showUserMessage("Compatibility calculation service is being prepared.")
                }
            )

            AstrologyFeatureCard(
                title = "Consult Certified Astrologer",
                description = "Connect 1-to-1 with verified Vedic astrologers over audio and video calls.",
                icon = Icons.Outlined.SupportAgent,
                tag = "Live Soon",
                onClick = {
                    viewModel.showUserMessage("Astrologer hosts are being onboarded to Baatly.")
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun AstrologyFeatureCard(
    title: String,
    description: String,
    icon: ImageVector,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(PrimaryLavender.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = PrimaryLavender,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SecondaryAmber.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = tag,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SecondaryAmber,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                )
            }

            Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = null,
                tint = TextTertiary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
