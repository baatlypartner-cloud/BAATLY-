package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AuthState
import com.example.data.model.PendingUroPayPayment
import com.example.data.model.UserProfile
import com.example.data.model.WalletInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("baatly_session_prefs", Context.MODE_PRIVATE)

    private val _accessToken = MutableStateFlow<String?>(prefs.getString(KEY_TOKEN, null))
    val accessToken: StateFlow<String?> = _accessToken.asStateFlow()

    private val _refreshToken = MutableStateFlow<String?>(prefs.getString(KEY_REFRESH_TOKEN, null))
    val refreshToken: StateFlow<String?> = _refreshToken.asStateFlow()

    private val _userId = MutableStateFlow<String?>(prefs.getString(KEY_USER_ID, null))
    val userId: StateFlow<String?> = _userId.asStateFlow()

    private val _currentUser = MutableStateFlow<UserProfile?>(loadSavedProfile())
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _wallet = MutableStateFlow<WalletInfo?>(loadSavedWallet())
    val wallet: StateFlow<WalletInfo?> = _wallet.asStateFlow()

    private val _fcmToken = MutableStateFlow<String?>(prefs.getString(KEY_FCM_TOKEN, null))
    val fcmToken: StateFlow<String?> = _fcmToken.asStateFlow()

    private val _authState = MutableStateFlow<AuthState>(
        initAuthState(
            token = prefs.getString(KEY_TOKEN, null),
            refreshToken = prefs.getString(KEY_REFRESH_TOKEN, null),
            userId = prefs.getString(KEY_USER_ID, null),
            profile = loadSavedProfile()
        )
    )
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    val lastRegisteredFcmToken: String?
        get() = prefs.getString(KEY_LAST_REG_FCM_TOKEN, null)

    val lastRegisteredUserId: String?
        get() = prefs.getString(KEY_LAST_REG_USER_ID, null)

    fun saveFcmToken(token: String) {
        if (token.isNotBlank()) {
            prefs.edit().putString(KEY_FCM_TOKEN, token).apply()
            _fcmToken.value = token
        }
    }

    fun markFcmTokenRegistered(token: String, userId: String) {
        prefs.edit()
            .putString(KEY_LAST_REG_FCM_TOKEN, token)
            .putString(KEY_LAST_REG_USER_ID, userId)
            .apply()
    }

    fun clearFcmTokenRegistration() {
        prefs.edit()
            .remove(KEY_LAST_REG_FCM_TOKEN)
            .remove(KEY_LAST_REG_USER_ID)
            .apply()
    }

    private val _isOnboardingCompleted = MutableStateFlow(prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false))
    val isOnboardingCompletedFlow: StateFlow<Boolean> = _isOnboardingCompleted.asStateFlow()

    val isOnboardingCompleted: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false)

    fun setOnboardingCompleted(completed: Boolean = true) {
        prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, completed).apply()
        _isOnboardingCompleted.value = completed
    }

    val isLoggedIn: Boolean
        get() = _authState.value is AuthState.Authenticated

    val hasPersistedSessionCredentials: Boolean
        get() = !_refreshToken.value.isNullOrBlank() || !_accessToken.value.isNullOrBlank()

    fun isTokenExpiredOrNearExpiry(token: String? = _accessToken.value, bufferSeconds: Long = 60): Boolean {
        if (token.isNullOrBlank()) return true
        return try {
            val parts = token.split(".")
            if (parts.size < 2) return true
            val payloadBytes = android.util.Base64.decode(
                parts[1],
                android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP
            )
            val json = JSONObject(String(payloadBytes, Charsets.UTF_8))
            val exp = json.optLong("exp", 0L)
            if (exp == 0L) return false
            val currentSec = System.currentTimeMillis() / 1000
            currentSec >= (exp - bufferSeconds)
        } catch (_: Exception) {
            true
        }
    }

    @Synchronized
    fun saveSession(token: String, userId: String, profile: UserProfile? = null, refreshToken: String? = null) {
        val editor = prefs.edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USER_ID, userId)
        
        if (!refreshToken.isNullOrBlank()) {
            editor.putString(KEY_REFRESH_TOKEN, refreshToken)
            _refreshToken.value = refreshToken
        }

        val resolvedProfile = profile ?: _currentUser.value
        if (resolvedProfile != null) {
            val json = serializeProfile(resolvedProfile)
            editor.putString(KEY_PROFILE_JSON, json)
            _currentUser.value = resolvedProfile
        }
        
        editor.apply()
        _accessToken.value = token
        _userId.value = userId
        _authState.value = AuthState.Authenticated(userId, resolvedProfile)
    }

    @Synchronized
    fun setAuthenticated(userId: String, profile: UserProfile? = null) {
        val resolvedProfile = profile ?: _currentUser.value
        _authState.value = AuthState.Authenticated(userId, resolvedProfile)
    }

    @Synchronized
    fun updateProfile(profile: UserProfile) {
        _currentUser.value = profile
        val json = serializeProfile(profile)
        prefs.edit().putString(KEY_PROFILE_JSON, json).apply()
        val currentUserId = _userId.value ?: profile.userId.ifBlank { profile.id }
        if (currentUserId.isNotBlank()) {
            _authState.value = AuthState.Authenticated(currentUserId, profile)
        }
    }

    @Synchronized
    fun updateWallet(wallet: WalletInfo) {
        _wallet.value = wallet
        val json = serializeWallet(wallet)
        prefs.edit().putString(KEY_WALLET_JSON, json).apply()
    }

    @Synchronized
    fun clearSession() {
        val onboardingCompleted = isOnboardingCompleted
        prefs.edit().clear().apply()
        if (onboardingCompleted) {
            prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, true).apply()
            _isOnboardingCompleted.value = true
        }
        _accessToken.value = null
        _refreshToken.value = null
        _userId.value = null
        _currentUser.value = null
        _wallet.value = null
        _authState.value = AuthState.Unauthenticated
    }

    private fun serializeProfile(profile: UserProfile): String {
        return JSONObject().apply {
            put("id", profile.id)
            put("user_id", profile.userId)
            put("username", profile.username)
            put("display_name", profile.displayName)
            put("avatar_url", profile.avatarUrl)
            put("bio", profile.bio)
            put("gender", profile.gender)
            put("language", profile.language)
            put("account_status", profile.accountStatus)
            put("is_online", profile.isOnline)
            put("mobile_number", profile.mobileNumber)
            put("referral_code", profile.referralCode)
            put("referral_code_used", profile.referralCodeUsed)
            put("rating", profile.rating)
            put("reviews_count", profile.reviewsCount)
            put("total_calls", profile.totalCalls)
            put("created_at", profile.createdAt)
        }.toString()
    }

    private fun loadSavedProfile(): UserProfile? {
        val jsonStr = prefs.getString(KEY_PROFILE_JSON, null) ?: return null
        return try {
            val json = JSONObject(jsonStr)
            UserProfile(
                id = json.optString("id"),
                userId = json.optString("user_id"),
                username = json.optString("username"),
                displayName = json.optString("display_name"),
                avatarUrl = json.optString("avatar_url").takeIf { it.isNotBlank() },
                bio = json.optString("bio").takeIf { it.isNotBlank() },
                gender = json.optString("gender"),
                language = json.optString("language"),
                accountStatus = json.optString("account_status", "active"),
                isOnline = json.optBoolean("is_online", false),
                mobileNumber = json.optString("mobile_number"),
                referralCode = json.optString("referral_code"),
                referralCodeUsed = json.optString("referral_code_used"),
                rating = json.optDouble("rating", 5.0),
                reviewsCount = json.optInt("reviews_count", 0),
                totalCalls = json.optInt("total_calls", 0),
                createdAt = json.optString("created_at")
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun serializeWallet(wallet: WalletInfo): String {
        return JSONObject().apply {
            put("user_id", wallet.userId)
            put("balance_rupees", wallet.balanceRupees)
            put("available_balance_rupees", wallet.availableBalanceRupees)
            put("updated_at", wallet.updatedAt)
        }.toString()
    }

    private fun loadSavedWallet(): WalletInfo? {
        val jsonStr = prefs.getString(KEY_WALLET_JSON, null) ?: return null
        return try {
            val json = JSONObject(jsonStr)
            WalletInfo(
                userId = json.optString("user_id"),
                balanceRupees = json.optDouble("balance_rupees", 0.0),
                availableBalanceRupees = json.optDouble("available_balance_rupees", 0.0),
                updatedAt = json.optString("updated_at")
            )
        } catch (_: Exception) {
            null
        }
    }

    fun savePendingPayment(payment: PendingUroPayPayment) {
        val json = JSONObject().apply {
            put("payment_id", payment.paymentId)
            put("order_id", payment.orderId)
            put("tenant_order_ref", payment.tenantOrderRef)
            put("package_id", payment.packageId)
            put("amount_rupees", payment.amountRupees)
            put("open_url", payment.openUrl)
            put("target_call_id", payment.targetCallId)
            put("created_at", payment.createdAt)
        }.toString()
        prefs.edit().putString(KEY_PENDING_PAYMENT, json).apply()
    }

    fun getPendingPayment(): PendingUroPayPayment? {
        val jsonStr = prefs.getString(KEY_PENDING_PAYMENT, null) ?: return null
        return try {
            val json = JSONObject(jsonStr)
            PendingUroPayPayment(
                paymentId = json.getString("payment_id"),
                orderId = json.optString("order_id").takeIf { it.isNotBlank() },
                tenantOrderRef = json.getString("tenant_order_ref"),
                packageId = json.getString("package_id"),
                amountRupees = json.optDouble("amount_rupees", 0.0),
                openUrl = json.optString("open_url").takeIf { it.isNotBlank() },
                targetCallId = json.optString("target_call_id").takeIf { it.isNotBlank() },
                createdAt = json.optLong("created_at", System.currentTimeMillis())
            )
        } catch (_: Exception) {
            null
        }
    }

    fun clearPendingPayment() {
        prefs.edit().remove(KEY_PENDING_PAYMENT).apply()
    }

    companion object {
        private fun initAuthState(token: String?, refreshToken: String?, userId: String?, profile: UserProfile?): AuthState {
            return if (!userId.isNullOrBlank() && (!token.isNullOrBlank() || !refreshToken.isNullOrBlank())) {
                AuthState.Authenticated(userId, profile)
            } else if (!token.isNullOrBlank() || !refreshToken.isNullOrBlank()) {
                AuthState.Restoring
            } else {
                AuthState.Unauthenticated
            }
        }

        private const val KEY_TOKEN = "jwt_access_token"
        private const val KEY_REFRESH_TOKEN = "jwt_refresh_token"
        private const val KEY_USER_ID = "auth_user_id"
        private const val KEY_PROFILE_JSON = "cached_profile_json"
        private const val KEY_WALLET_JSON = "cached_wallet_json"
        private const val KEY_ONBOARDING_COMPLETED = "onboarding_completed"
        private const val KEY_FCM_TOKEN = "fcm_device_token"
        private const val KEY_LAST_REG_FCM_TOKEN = "fcm_last_registered_token"
        private const val KEY_LAST_REG_USER_ID = "fcm_last_registered_user_id"
        private const val KEY_PENDING_PAYMENT = "uropay_pending_payment"
    }
}
