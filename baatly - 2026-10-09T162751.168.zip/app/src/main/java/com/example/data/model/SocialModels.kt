package com.example.data.model

import java.io.Serializable

data class SocialPost(
    val id: String = "",
    val userId: String = "", // owner_id
    val creatorName: String = "Host", // display_name
    val creatorAvatarUrl: String? = null, // avatar_url
    val isHost: Boolean = true, // is_owner_host
    val isOwner: Boolean = false,
    val mediaUrl: String? = null,
    val mediaPath: String? = null,
    val mediaBucket: String? = null,
    val mediaType: String = "image", // "image", "video"
    val caption: String = "",
    val isLocked: Boolean = false,
    val unlockPriceRupees: Double = 1.0,
    val isUnlocked: Boolean = false,
    val isLiked: Boolean = false,
    val likesCount: Int = 0,
    val loveNotesCount: Int = 0,
    val viewsCount: Int = 0,
    val isFollowing: Boolean = false,
    val canLoveNote: Boolean = true,
    val canVoiceCall: Boolean = true,
    val canVideoCall: Boolean = true,
    val visibleUntil: String? = null,
    val createdAt: String = ""
) : Serializable

data class SocialStory(
    val id: String = "",
    val userId: String = "", // owner_id
    val creatorName: String = "Host", // display_name
    val creatorAvatarUrl: String? = null, // avatar_url
    val isHost: Boolean = true, // is_owner_host
    val isOwner: Boolean = false,
    val mediaUrl: String? = null,
    val mediaPath: String? = null,
    val mediaBucket: String? = null,
    val caption: String = "",
    val isLocked: Boolean = false,
    val unlockPriceRupees: Double = 1.0,
    val isUnlocked: Boolean = false,
    val isViewed: Boolean = false,
    val viewsCount: Int = 0,
    val likesCount: Int = 0,
    val loveNotesCount: Int = 0,
    val isLiked: Boolean = false,
    val isFollowing: Boolean = false,
    val canLoveNote: Boolean = true,
    val canVoiceCall: Boolean = true,
    val canVideoCall: Boolean = true,
    val expiresAt: String = "",
    val createdAt: String = ""
) : Serializable

data class SocialProfile(
    val userId: String = "",
    val displayName: String = "",
    val username: String = "",
    val avatarUrl: String? = null,
    val bio: String? = null,
    val isHost: Boolean = false,
    val isOnline: Boolean = false,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val postsCount: Int = 0,
    val isFollowing: Boolean = false,
    val partnerProfile: PartnerProfile? = null
) : Serializable

data class SocialLoveNoteItem(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val senderAvatarUrl: String? = null,
    val messageText: String = "",
    val createdAt: String = ""
) : Serializable
