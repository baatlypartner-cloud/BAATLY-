package com.example.data.model

import java.io.Serializable

data class SocialViewResult(
    val success: Boolean = true,
    val isUnlocked: Boolean = true,
    val charged: Boolean = false,
    val amountRupees: Double = 0.0,
    val hostEarningRupees: Double = 0.0,
    val visibleUntil: String? = null
) : Serializable

data class SocialLikeResult(
    val success: Boolean = true,
    val isLiked: Boolean = true,
    val charged: Boolean = false,
    val amountRupees: Double = 0.0,
    val hostEarningRupees: Double = 0.0
) : Serializable

data class SocialLoveNoteResult(
    val success: Boolean = true,
    val messageId: String = "",
    val conversationId: String = "",
    val contentType: String = "",
    val contentId: String = "",
    val chargeRupees: Double = 0.0,
    val hostEarningRupees: Double = 0.0
) : Serializable
