package com.example.ui.social

import android.Manifest
import android.net.Uri
import android.content.pm.PackageManager
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraEffect
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.media3.effect.Media3Effect
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.util.UnstableApi
import com.example.ui.media.MediaEditorExporter
import java.io.File

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun BaatlyCameraScreen(
    onDismiss: () -> Unit,
    onCaptured: (Uri) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var permissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var permissionAsked by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("Original") }
    var usingFrontCamera by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }
    val filters = listOf("Original", "Warm", "Vivid", "Mono", "Vintage", "Invert")

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
    }
    LaunchedEffect(Unit) {
        if (!permissionGranted && !permissionAsked) {
            permissionAsked = true
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }
    val controller = remember(context) {
        LifecycleCameraController(context).apply {
            setEnabledUseCases(CameraController.IMAGE_CAPTURE)
            cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
        }
    }
    val media3Effect = remember(context) {
        Media3Effect(
            context.applicationContext,
            CameraEffect.PREVIEW or CameraEffect.IMAGE_CAPTURE,
            ContextCompat.getMainExecutor(context)
        ) { throwable -> Log.w("BaatlyCamera", "Live filter pipeline error: ${throwable.message}") }
    }

    LaunchedEffect(controller, lifecycleOwner) {
        runCatching { controller.bindToLifecycle(lifecycleOwner) }
            .onFailure { Log.w("BaatlyCamera", "Camera bind failed: ${it.message}") }
    }
    LaunchedEffect(controller, media3Effect, selectedFilter) {
        val effects = MediaEditorExporter.videoFilterEffects(selectedFilter)
        media3Effect.setEffects(effects)
        controller.setEffects(if (effects.isEmpty()) emptySet() else setOf(media3Effect))
    }

    BackHandler { onDismiss() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (permissionGranted) {
                androidx.compose.ui.viewinterop.AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                            this.controller = controller
                        }
                    },
                    update = { preview -> preview.controller = controller }
                )
            } else {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(46.dp))
                    Text("Camera permission is needed to take a filtered photo.", color = Color.White)
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF2E78))) { Text("Allow camera") }
                }
            }

            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.ArrowBack, contentDescription = "Close camera", tint = Color.White) }
                Text("BAATLY CAMERA", color = Color.White, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    usingFrontCamera = !usingFrontCamera
                    controller.cameraSelector = if (usingFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                }) { Icon(Icons.Filled.FlipCameraAndroid, contentDescription = "Switch camera", tint = Color.White) }
            }

            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    filters.forEach { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter, fontSize = 11.sp) },
                            colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFFF2E78), selectedLabelColor = Color.White,
                                containerColor = Color(0xAA1C1630), labelColor = Color.White
                            )
                        )
                    }
                }
                Text("Live filter is applied to preview and captured photo", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                Surface(
                    modifier = Modifier.size(78.dp).clip(CircleShape),
                    color = Color.White,
                    shape = CircleShape,
                    border = androidx.compose.foundation.BorderStroke(4.dp, Color(0xFFFF2E78))
                ) {
                    IconButton(
                        enabled = permissionGranted && !isCapturing,
                        onClick = {
                            if (isCapturing) return@IconButton
                            isCapturing = true
                            val file = File(context.cacheDir, "baatly_camera_${System.currentTimeMillis()}.jpg")
                            val options = ImageCapture.OutputFileOptions.Builder(file).build()
                            controller.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                    isCapturing = false
                                    if (file.exists() && file.length() > 0L) onCaptured(Uri.fromFile(file))
                                    else Toast.makeText(context, "Could not save photo", Toast.LENGTH_SHORT).show()
                                }
                                override fun onError(exception: ImageCaptureException) {
                                    isCapturing = false
                                    Toast.makeText(context, exception.message ?: "Camera capture failed", Toast.LENGTH_SHORT).show()
                                }
                            })
                        }
                    ) {
                        if (isCapturing) androidx.compose.material3.CircularProgressIndicator(color = Color(0xFFFF2E78), modifier = Modifier.size(27.dp))
                        else Icon(Icons.Filled.CameraAlt, contentDescription = "Capture photo", tint = Color(0xFF2B163D), modifier = Modifier.size(32.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
    DisposableEffect(controller, media3Effect) {
        onDispose {
            runCatching { controller.setEffects(emptySet()) }
            runCatching { controller.unbind() }
            runCatching { media3Effect.close() }
        }
    }
}
