## Latest patch — v44 media and chat fixes

See `BAATLY_V44_MEDIA_CHAT_FIXES.md` for details. This patch force-refreshes failed photo URLs from canonical storage keys, leaves normal-user message billing to the server (free user-to-user DMs), and restricts calls to approved hosts.

# BAATLY User App — v44

Native Android application built with Kotlin and Jetpack Compose.

## Open and build

1. Open this project root in Android Studio.
2. Use JDK 17 for the Gradle build.
3. Create `.env` from `.env.example` and populate the project's existing Supabase and Agora runtime configuration using your own values.
4. For a signed Release APK, configure the signing variables/secrets in your CI workflow. Do not commit the upload keystore or passwords.
5. Run `./gradlew :app:assembleRelease`.

The project `versionCode` is set to **44** and `versionName` is `1.0.44`.

## v42 social-media fixes

See `BAATLY_V42_SOCIAL_FIXES.md` for profile/Highlights, Followers/Following, private accounts, Story viewers, comments and targeted chat routing. See `BAATLY_V43_RECOMMENDATION_ENGINE.md` for the recommendation engine details. Its SQL migration is in `app/supabase/migrations/20261025_social_recommendation_engine.sql`; the corresponding migration and Edge Function update have already been applied to the connected BAATLY backend in this session.

## Build verification note

The changes are supplied as Android source in this ZIP, not as a verified APK. The Gradle 9.3.1 distribution could not be downloaded in the editing environment because the Gradle host was unreachable. Run the Release APK workflow in a network-enabled build environment and test the flows listed in `BAATLY_V42_SOCIAL_FIXES.md` on a physical device before publishing.

Earlier v40/v41 update notes remain in the repository for reference.


## v42 compile fix

The `SocialProfileScreen.kt` experimental Material3 API compiler diagnostics were addressed with `@OptIn(ExperimentalMaterial3Api::class)`. The source ZIP is not a compiled/verified APK; run the GitHub Actions Release build to validate in a network-enabled environment.

## Cloudflare AI and Super AI integration (v44 test bundle)

This bundle now includes the Cloudflare Worker source under `cloudflare/baatly-ai-gateway/`, the AI Gateway settings snapshot under `cloudflare/ai-gateway-settings.json`, and the migration/test reports. The live Worker is `https://baatly-ai.baatly-ai.workers.dev` (Worker code version 1.6.1).

- Super AI's main chat uses Cloudflare's tool-calling agent route for web search, page reading and explicit long-term memory saves.
- The app can archive chats/attachments in the user's private R2 prefix, maintain project workspaces, edit supported text/source files with revision backups and export updated ZIPs.
- Image understanding, image generation and astrology routes are implemented on Cloudflare Workers AI.
- AI Chat Host, AI call-turn LLM/STT, realtime voice LLM and Agora conversational LLM are routed to Cloudflare; Support Agent `partner-ai-chat` and `partner-ai-chat-v2` deliberately stay on Groq.
- Video generation requires prepaid Cloudflare AI Gateway credits. A restricted static HTML preview works for saved `index.html` files with supported local assets. Dynamic web preview/build, arbitrary source-code execution, Android emulator, Gradle build runner and APK packaging are not enabled yet. ZIP is the default Android source output; APK must be explicitly requested and only after a secure build runner is available.

Read `BAATLY_CLOUDFLARE_MIGRATION_REPORT.md` and `CLOUDFLARE_TESTING_CHECKLIST.md` before production rollout. The Android Gradle compile could not be completed in this environment because the Gradle wrapper could not resolve `services.gradle.org`; do not treat this ZIP as a verified build or installable APK.
