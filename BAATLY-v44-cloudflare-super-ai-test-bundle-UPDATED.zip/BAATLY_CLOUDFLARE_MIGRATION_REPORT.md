# BAATLY v44 — Cloudflare AI Migration and Testing Report

Date: 2026-10-27

Live Cloudflare Worker code release: **1.6.1**.

## Implemented in live connected projects

- Created/deployed `baatly-ai-gateway` at `https://baatly-ai.baatly-ai.workers.dev`, with Workers AI, R2 `baatly-media`, Supabase JWT validation, health metadata, observability, and a private Agora service-token binding.
- Created AI Gateway `baatly-ai` with authentication enabled, logs off, 30 requests/minute rate limit, and a $2/24-hour gateway spend limit. AI Gateway prepaid balance was $0 during audit; no top-up was made. The spend limit applies to traffic routed through AI Gateway, not direct native Workers AI invocations.
- Added autonomous tool selection to `POST /v1/agent/chat`: the model can call authenticated web search, safe public-page reading, and explicit memory saving. Conversation turns and selected memory facts are stored in the user's private R2 prefix.
- Added native Workers AI image generation with R2 persistence, Llama 4 Scout image understanding, Cloudflare Whisper transcription, astrology-style readings, attachment storage, conversation history, and persistent source-file workspace APIs. Added a restricted static HTML preview endpoint for saved `index.html` projects; it inlines supported local CSS/JS/images and does not run npm/Vite/React.
- `ai-chat` v45: migrated AI Chat Host LLM calls from AionLabs to Cloudflare Workers AI; kept Supabase billing/refund, host/user memory, persona/safety rules, and response cleaning.
- `ai-call-turn` v27: migrated LLM and speech-to-text from AionLabs/Groq Whisper to Cloudflare Workers AI; kept Sarvam TTS, call-session ownership/status validation, and existing billing settlement flow.
- `ai-voice-stream` v17: migrated LLM streaming to Cloudflare Workers AI; retained Sarvam realtime audio sockets and existing session validation.
- `ai-call-start` v26: Agora Conversational AI LLM URL now points to the private Cloudflare `/v1/agora/chat/completions` route; model changed to Cloudflare Workers AI. The private token reference is stored in non-public Supabase `app_config` and the matching value is a Cloudflare secret.
- Support Agent Edge Functions `partner-ai-chat` v22 and `partner-ai-chat-v2` v31 were not modified and remain on Groq.
- Updated Android `SuperAiScreen.kt` and added `CloudflareAiClient.kt` for prompt-based chat, attachments, image analysis, image/video screens, saved R2 project workspaces, ZIP import/extraction, prompt-based source editing, version backup, conversation history, and updated ZIP export. `AstrologerScreen.kt` now calls the Cloudflare astrology route; `MainActivity.kt` routes to the updated screens.

## Tests completed

- Cloudflare API confirmed the Worker deployments, bindings, R2 bucket, secret binding, AI Gateway settings and live Supabase Edge Function versions.
- Direct Workers AI inference succeeded for the Llama chat model and produced a Roman-Hindi companion response.
- Tested model function-calling: the model selected the `web_search` tool for a current-information prompt. Tested the tool-result round-trip and received a final answer.
- Tested Llama 4 Scout image understanding using a tiny image input; it returned `A black square.` The live Worker image route was updated to use the model's supported message content format.
- Local Worker source passes `node --check`; Cloudflare accepted the deployed Worker script module.
- ZIP import has size/entry safety limits, skips build caches and `.git` folders, avoids path traversal, and file edits are restricted to recognized text/source file types. Previous project file versions are copied to R2 before AI edits.

## Not yet verified / blockers

- Authenticated app-to-Worker end-to-end tests need a signed-in BAATLY app/user session. This environment did not run the Android app with a real user JWT, so the new authenticated routes are deployment-confirmed but not yet device-verified.
- Android `compileDebugKotlin`/Gradle build could not be completed because the Gradle wrapper needs to download Gradle 9.3.1 from `services.gradle.org`, and DNS/network access from this runtime failed. Do not treat this as a successful APK build.
- No secure arbitrary-code execution sandbox has been deployed yet. A restricted static HTML preview is available for saved `index.html` files only; dynamic web-app preview servers, npm/Vite/React builds, package installation, Android emulator preview, Gradle build and APK packaging are not enabled. Source files can be edited and exported as ZIP. APK must not auto-build; it must be opt-in after the build runner is ready.
- AI Gateway reports $0 prepaid credits. The third-party video-generation route is implemented but cannot be relied on until credit balance and model access are provisioned; no purchase/top-up was made.
- Sarvam remains for Hindi TTS/realtime speech because a compatible Cloudflare-native Hindi realtime replacement was not verified. Agora remains the RTC transport/provider for call sessions. These are explicit remaining provider dependencies rather than hidden migration claims.
- Web-page reading can return errors for redirects, blocked pages, or non-text/binary content. Binary PDF/DOCX parsing is not implemented in this app pass.

## Testing checklist for the BAATLY team

1. Sign in to the updated BAATLY app and open Super AI.
2. Send a normal Roman-Hindi prompt; verify response and R2 history after reopening the conversation.
3. Ask a current question such as “India ka latest CPI inflation kya hai?”; verify the result includes web search sources and check `tools_used` from the response/logging.
4. Send a public URL and ask for a summary; verify web page reading or a transparent read failure.
5. Upload a small photo; verify R2 attachment, image analysis, and a returned answer.
6. Open Image Generator; generate one low-cost test image and verify R2 persistence plus local save.
7. Import a small Web/Android source ZIP, reopen the saved workspace, make a one-file change, and download an updated ZIP; confirm previous revision backup exists in R2.
8. Test AI audio call with a test user/host and verify Agora starts, LLM responds, Sarvam audio works, and call reservation/settlement is unchanged.
9. Test astrology reading. Test video only after AI Gateway credits and model access are available.
10. Static HTML preview only applies to saved `index.html` projects; do not mark dynamic web-app preview or APK generation complete until an isolated sandbox runner and full Gradle/emulator tests pass.
