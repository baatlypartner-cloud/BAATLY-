package com.example.ui.social

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.SocialPost
import com.example.data.model.SocialHighlight
import com.example.ui.BaatlyViewModel
import com.example.ui.components.rememberResolvedProfileImageUrl
import com.example.ui.Screen
import com.example.ui.theme.*
import kotlinx.coroutines.launch

private val Plum = Color(0xFF2B163D)
private val Cream = Color(0xFFFFF8F3)
private val SocialSoftPink = Color(0xFFFFEEF2)

@Composable
fun SocialProfileScreen(viewModel: BaatlyViewModel) {
    val targetUserId by viewModel.socialProfileTargetUserId.collectAsState()
    val ownProfile by viewModel.mySocialProfile.collectAsState()
    val ownPosts by viewModel.mySocialPosts.collectAsState()
    val viewedProfile by viewModel.viewedSocialProfile.collectAsState()
    val viewedPosts by viewModel.viewedSocialPosts.collectAsState()
    val stories by viewModel.socialStories.collectAsState()
    val authUserId by viewModel.sessionManager.userId.collectAsState()
    val isOwn = targetUserId.isNullOrBlank()
    val profile = if (isOwn) ownProfile else viewedProfile
    val posts = if (isOwn) ownPosts else viewedPosts
    val resolvedProfileAvatar by rememberResolvedProfileImageUrl(profile?.avatarUrl, viewModel.dataService)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf("Posts") }
    var showCreateHighlightDialog by remember { mutableStateOf(false) }
    var highlightTitle by remember { mutableStateOf("") }
    var selectedStoryId by remember { mutableStateOf<String?>(null) }
    var isSavingHighlight by remember { mutableStateOf(false) }
    var highlights by remember { mutableStateOf<List<SocialHighlight>>(emptyList()) }

    val saveHighlightFromPickedMedia: (Uri) -> Unit = { uri ->
        val title = highlightTitle.trim().take(40)
        if (title.isBlank()) {
            viewModel.showUserMessage("Enter a Highlight name first")
        } else if (!isSavingHighlight) {
            isSavingHighlight = true
            scope.launch {
                viewModel.dataService.createSocialHighlightFromMedia(context, uri, title).onSuccess {
                    viewModel.dataService.getSocialHighlights(targetUserId).onSuccess { highlights = it }
                    showCreateHighlightDialog = false
                    viewModel.showUserMessage("Highlight saved")
                }.onFailure { error ->
                    viewModel.showUserMessage("Couldn't save Highlight: ${error.message ?: "please retry"}")
                }
                isSavingHighlight = false
            }
        }
    }
    val highlightPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveHighlightFromPickedMedia(uri)
    }
    val highlightVideoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveHighlightFromPickedMedia(uri)
    }

    LaunchedEffect(targetUserId) {
        if (targetUserId.isNullOrBlank()) {
            viewModel.loadMySocialProfile()
            viewModel.refreshSocialStories()
        }
        viewModel.dataService.getSocialHighlights(targetUserId).onSuccess { highlights = it }
            .onFailure { viewModel.showUserMessage("Couldn't load Highlights: ${it.message ?: "please retry"}") }
    }

    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { viewModel.setScreen(Screen.SOCIAL) }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Plum) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("BAATLY", color = Plum, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("S O C I A L  M E D I A", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 7.sp, letterSpacing = 1.1.sp)
            }
            IconButton(onClick = { viewModel.setScreen(Screen.PROFILE) }) { Icon(if (isOwn) Icons.Filled.Settings else Icons.Filled.MoreHoriz, contentDescription = "Profile options", tint = Plum) }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Box(Modifier.size(104.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(VibrantPink, Color(0xFFFFB703), VibrantPink))).padding(4.dp)) {
                    AsyncImage(model = resolvedProfileAvatar, contentDescription = "Profile photo", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape).background(SocialSoftPink))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(profile?.username?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: profile?.displayName?.ifBlank { "baatly_member" } ?: "baatly_member", color = Plum, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(profile?.displayName?.ifBlank { "BAATLY member" } ?: "BAATLY member", color = Plum, fontSize = 13.sp)
                    Text(profile?.bio?.ifBlank { "Sharing moments, stories and good vibes ✨" } ?: "Sharing moments, stories and good vibes ✨", color = TextSecondary, fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                ProfileStat(profile?.postsCount ?: posts.size, "Posts")
                ProfileStat(profile?.followersCount ?: 0, "Followers")
                ProfileStat(profile?.followingCount ?: 0, "Following")
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isOwn) {
                    Button(onClick = { viewModel.setScreen(Screen.PROFILE) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(16.dp)) { Text("Edit profile", fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = { viewModel.showUserMessage("Profile sharing will be available soon") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)) { Text("Share profile", color = Plum) }
                } else {
                    Button(onClick = { viewModel.toggleSocialFollow(profile?.userId.orEmpty()) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(16.dp)) { Text(if (profile?.isFollowing == true) "Following" else "Follow", fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = { viewModel.setScreen(Screen.CHAT_LIST) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)) {
                        Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp), tint = Plum); Spacer(Modifier.width(5.dp)); Text("Message", color = Plum)
                    }
                }
            }

            Text("Highlights", color = Plum, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 17.dp, top = 8.dp, bottom = 9.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (isOwn) {
                    HighlightBubble("+", "New", isAdd = true, onClick = {
                        highlightTitle = ""
                        selectedStoryId = stories.firstOrNull { it.userId == authUserId }?.id
                        showCreateHighlightDialog = true
                    })
                }
                highlights.take(7).forEach { highlight ->
                    HighlightBubble(
                        title = "",
                        label = highlight.title,
                        imageUrl = highlight.coverUrl,
                        onClick = {
                            val media = highlight.firstMediaUrl ?: highlight.coverUrl
                            if (!media.isNullOrBlank()) viewModel.openFullScreenMedia(media, highlight.firstMediaType)
                            else viewModel.showUserMessage("This Highlight has no available media")
                        }
                    )
                }
            }
            if (highlights.isEmpty() && !isOwn) {
                Text("No Highlights yet", color = TextTertiary, fontSize = 11.sp, modifier = Modifier.padding(start = 17.dp, top = 4.dp))
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().border(width = 1.dp, color = Color(0xFFF1E9E5)).background(Color.White), horizontalArrangement = Arrangement.SpaceEvenly) {
                ProfileTab("Posts", selectedTab == "Posts", Icons.Filled.GridOn, Modifier.weight(1f)) { selectedTab = "Posts" }
                ProfileTab("Reels", selectedTab == "Reels", Icons.Filled.PlayCircleOutline, Modifier.weight(1f)) { selectedTab = "Reels" }
                ProfileTab("Tagged", selectedTab == "Tagged", Icons.Filled.Tag, Modifier.weight(1f)) { selectedTab = "Tagged" }
            }
            val visiblePosts = when (selectedTab) {
                "Reels" -> posts.filter { it.mediaType.equals("video", true) }
                "Tagged" -> emptyList()
                else -> posts
            }
            if (visiblePosts.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Icon(if (selectedTab == "Reels") Icons.Filled.PlayCircleOutline else Icons.Filled.GridOn, contentDescription = null, tint = Color(0xFFBBAABF), modifier = Modifier.size(36.dp))
                        Text(if (selectedTab == "Reels") "No reels yet" else if (selectedTab == "Tagged") "No tagged posts yet" else "No posts yet", color = Plum, fontWeight = FontWeight.SemiBold)
                        if (isOwn && selectedTab == "Posts") Text("Your photos and videos will appear here.", color = TextTertiary, fontSize = 11.sp)
                    }
                }
            } else {
                visiblePosts.chunked(3).forEach { rowPosts ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        rowPosts.forEach { post ->
                            ProfileGridTile(post = post, viewModel = viewModel, modifier = Modifier.weight(1f))
                        }
                        repeat((3 - rowPosts.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
        }
    }

    if (showCreateHighlightDialog) {
        val ownStories = stories.filter { it.userId == authUserId }
        AlertDialog(
            onDismissRequest = { if (!isSavingHighlight) showCreateHighlightDialog = false },
            containerColor = Color.White,
            title = { Text("Create Story Highlight", color = Plum, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Name your Highlight, then save an active Story or upload a photo/video. Highlights stay on your profile after ordinary Stories expire.", color = TextSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = highlightTitle,
                        onValueChange = { highlightTitle = it.take(40) },
                        singleLine = true,
                        label = { Text("Highlight name") },
                        placeholder = { Text("e.g. Moments") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (ownStories.isEmpty()) {
                        Text("No active Stories right now. You can upload a photo or video directly below.", color = TextSecondary, fontSize = 12.sp)
                    } else {
                        ownStories.take(12).forEach { story ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFFFFF8F3))
                                    .clickable { selectedStoryId = story.id }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                RadioButton(selected = selectedStoryId == story.id, onClick = { selectedStoryId = story.id }, colors = RadioButtonDefaults.colors(selectedColor = VibrantPink))
                                Column(Modifier.weight(1f)) {
                                    Text(story.caption.ifBlank { "Story media" }, color = Plum, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(if (story.mediaPath.orEmpty().substringAfterLast('.', "").lowercase() in setOf("mp4", "mov", "m4v", "webm")) "Video story" else "Photo story", color = TextSecondary, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { highlightPhotoPicker.launch("image/*") },
                            enabled = !isSavingHighlight,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Upload photo", color = VibrantPink, maxLines = 1) }
                        OutlinedButton(
                            onClick = { highlightVideoPicker.launch("video/*") },
                            enabled = !isSavingHighlight,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Upload video", color = VibrantPink, maxLines = 1) }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = selectedStoryId != null && ownStories.any { it.id == selectedStoryId } && !isSavingHighlight,
                    onClick = {
                        val storyId = selectedStoryId ?: return@TextButton
                        isSavingHighlight = true
                        scope.launch {
                            viewModel.dataService.addSocialHighlightFromStory(storyId, highlightTitle).onSuccess {
                                viewModel.dataService.getSocialHighlights().onSuccess { highlights = it }
                                showCreateHighlightDialog = false
                                viewModel.showUserMessage("Story saved to Highlights")
                            }.onFailure { error -> viewModel.showUserMessage("Couldn't save Highlight: ${error.message ?: "please retry"}") }
                            isSavingHighlight = false
                        }
                    }
                ) {
                    if (isSavingHighlight) CircularProgressIndicator(modifier = Modifier.size(16.dp), color = VibrantPink, strokeWidth = 2.dp)
                    else Text("Save selected Story", color = VibrantPink)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateHighlightDialog = false }, enabled = !isSavingHighlight) { Text("Cancel", color = TextSecondary) }
            }
        )
    }

}

@Composable
private fun ProfileStat(value: Int, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(value.toString(), color = Plum, fontSize = 17.sp, fontWeight = FontWeight.Black)
        Text(label, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun HighlightBubble(
    title: String,
    label: String,
    isAdd: Boolean = false,
    imageUrl: String? = null,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(62.dp).clickable(onClick = onClick)) {
        Box(
            Modifier.size(58.dp).clip(CircleShape)
                .background(if (isAdd) Color.White else Color(0xFFF3E8FA))
                .border(1.dp, if (isAdd) DarkCardBorder else Color(0xFFE7D7F0), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (!imageUrl.isNullOrBlank()) {
                AsyncImage(model = imageUrl, contentDescription = label, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Text(title.ifBlank { "✨" }, color = if (isAdd) Plum else VibrantPink, fontSize = if (isAdd) 26.sp else 22.sp, fontWeight = FontWeight.Bold)
            }
            if (isAdd) {
                Box(Modifier.align(Alignment.BottomEnd).size(19.dp).clip(CircleShape).background(VibrantPink), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Add, contentDescription = "Add Highlight", tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = Plum, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ProfileTab(title: String, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(icon, contentDescription = title, tint = if (selected) VibrantPink else TextSecondary, modifier = Modifier.size(20.dp))
        Text(title, color = if (selected) VibrantPink else TextSecondary, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
        Box(Modifier.fillMaxWidth().height(2.dp).background(if (selected) VibrantPink else Color.Transparent))
    }
}

@Composable
private fun ProfileGridTile(post: SocialPost, viewModel: BaatlyViewModel, modifier: Modifier = Modifier) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket) {
        val raw = post.mediaUrl?.takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id).takeIf { it.isNotBlank() }
    }
    Box(modifier.height(132.dp).background(Color(0xFFE9DFE4)).clickable(enabled = !mediaUrl.isNullOrBlank()) {
        if (!mediaUrl.isNullOrBlank()) viewModel.openFullScreenMedia(mediaUrl!!, post.mediaType)
    }) {
        AsyncImage(model = mediaUrl, contentDescription = post.caption, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        if (post.mediaType.equals("video", true)) {
            Icon(Icons.Filled.PlayCircleOutline, contentDescription = "Video", tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp))
        }
    }
}
