package com.example.ui.social

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.SocialPost
import com.example.data.model.SocialStory
import com.example.data.model.SocialProfile
import com.example.ui.media.BaatlyVideoPlayer
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.rememberResolvedProfileImageUrl
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val BrandPlum = Color(0xFF2B163D)
private val SocialCream = Color(0xFFFFF8F3)
private val SocialSoftPink = Color(0xFFFFEEF2)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val posts by viewModel.socialPosts.collectAsState()
    val stories by viewModel.socialStories.collectAsState()
    val isLoading by viewModel.isSocialLoading.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val authUserId by viewModel.sessionManager.userId.collectAsState()
    val activeLikeOperations by viewModel.activeLikeOperations.collectAsState()
    val availablePartners by viewModel.availablePartners.collectAsState()
    var selectedTab by remember { mutableStateOf("Feeds") }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedStory by remember { mutableStateOf<SocialStory?>(null) }
    var commentTarget by remember { mutableStateOf<SocialPost?>(null) }
    var loveNoteTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var createStoryDialog by remember { mutableStateOf(false) }
    var pendingMedia by remember { mutableStateOf<PendingSocialMedia?>(null) }
    var showCamera by remember { mutableStateOf(false) }
    var cameraPurpose by remember { mutableStateOf("post") }

    LaunchedEffect(Unit) { viewModel.refreshSocialFeed() }

    fun prepareMediaForEditor(uri: Uri?, purpose: String, prefix: String) {
        if (uri == null) return
        scope.launch {
            try {
                val originalMime = context.contentResolver.getType(uri)?.lowercase()?.substringBefore(';').orEmpty()
                val file = withContext(Dispatchers.IO) { copySelectedMediaToCache(context, uri, prefix) }
                val finalMime = originalMime.ifBlank { mimeTypeForExtension(file.extension) }
                pendingMedia = PendingSocialMedia(Uri.fromFile(file), purpose, finalMime)
            } catch (error: Exception) {
                viewModel.showUserMessage("Could not open selected media: ${error.message ?: "Choose a supported photo or video and retry."}")
            }
        }
    }

    val storyPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "story", "baatly_story_source")
    }

    val storyVideoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "story", "baatly_story_source")
    }

    val postPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "post", "baatly_post_source")
    }

    val postVideoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "post", "baatly_post_source")
    }

    val reelPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "reel", "baatly_reel_source")
    }

    val resolvedAvatar by rememberResolvedProfileImageUrl(currentUser?.avatarUrl, viewModel.dataService)

    Column(Modifier.fillMaxSize().background(SocialCream)) {
        SocialHeader(
            avatarUrl = resolvedAvatar,
            onProfile = { viewModel.openSocialProfile(null) },
            onSearch = { showSearch = true },
            onMessages = { viewModel.setScreen(Screen.CHAT_LIST) }
        )
        if (selectedTab == "Reels") {
            val reels = remember(posts) { posts.filter { it.mediaType.equals("video", ignoreCase = true) } }
            Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black)) {
                if (reels.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(horizontal = 26.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(54.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("Reels are on their way", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(5.dp))
                        Text("Vertical videos will autoplay here as you swipe.", color = Color.White.copy(alpha = 0.78f), fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { reelPicker.launch("video/*") }, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(24.dp)) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Create Reel")
                        }
                    }
                } else {
                    val pagerState = rememberPagerState(pageCount = { reels.size })
                    VerticalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize().testTag("social_reels_vertical_pager"),
                        beyondViewportPageCount = 1,
                        pageSpacing = 0.dp
                    ) { page ->
                        val post = reels[page]
                        ReelPage(
                            post = post,
                            viewModel = viewModel,
                            shouldPlay = pagerState.currentPage == page,
                            isLiking = activeLikeOperations.contains(post.id),
                            onLike = { viewModel.toggleSocialLike(post) },
                            onFollow = { viewModel.toggleSocialFollow(post.userId) },
                            onComment = { commentTarget = post },
                            onProfile = { viewModel.openSocialProfile(post.userId) },
                            onCall = {
                                val partner = availablePartners.firstOrNull { it.id == post.userId || it.userId == post.userId }
                                if (post.isHost && post.canVoiceCall && partner != null) viewModel.requestCall(partner)
                                else viewModel.showUserMessage("This host isn't available for a call right now")
                            },
                            onLoveNote = { loveNoteTarget = "post" to post.id }
                        )
                    }
                }
                FeedsReelsTabs(
                    selected = selectedTab,
                    onSelect = { selectedTab = it },
                    modifier = Modifier.align(Alignment.TopCenter).zIndex(2f)
                )
                if (selectedTab == "Reels" && reels.isNotEmpty()) {
                    Surface(
                        shape = CircleShape,
                        color = VibrantPink,
                        shadowElevation = 5.dp,
                        modifier = Modifier.align(Alignment.TopEnd).padding(top = 56.dp, end = 16.dp).size(38.dp).zIndex(3f)
                            .clickable { reelPicker.launch("video/*") }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Add, contentDescription = "Create Reel", tint = Color.White, modifier = Modifier.size(23.dp))
                        }
                    }
                }
            }
        } else {
            FeedsReelsTabs(selected = selectedTab, onSelect = { selectedTab = it })
            PullToRefreshBox(
                isRefreshing = isLoading,
                onRefresh = { viewModel.refreshSocialFeed() },
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item(key = "social_stories") {
                        SocialStoriesRow(
                            stories = stories,
                            currentUserId = authUserId.orEmpty(),
                            currentUserAvatarUrl = resolvedAvatar,
                            viewModel = viewModel,
                            onAddStory = { createStoryDialog = true },
                            onStoryClick = { selectedStory = it }
                        )
                    }
                    item(key = "social_post_create") {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { cameraPurpose = "post"; showCamera = true }) {
                                Icon(Icons.Filled.CameraAlt, contentDescription = null, tint = VibrantPink)
                                Spacer(Modifier.width(4.dp))
                                Text("Camera", color = VibrantPink, fontWeight = FontWeight.SemiBold)
                            }
                            TextButton(onClick = { postVideoPicker.launch("video/*") }) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = VibrantPink)
                                Spacer(Modifier.width(4.dp))
                                Text("Video", color = VibrantPink, fontWeight = FontWeight.SemiBold)
                            }
                            TextButton(onClick = { postPicker.launch("image/*") }) {
                                Icon(Icons.Filled.Add, contentDescription = null, tint = VibrantPink)
                                Spacer(Modifier.width(4.dp))
                                Text("Create post", color = VibrantPink, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    if (isLoading && posts.isEmpty()) {
                        item(key = "social_loading") {
                            Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = VibrantPink)
                            }
                        }
                    } else if (posts.isEmpty()) {
                        item(key = "social_empty") {
                            Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(48.dp))
                                    Text("Your feed starts here", color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Text("Share a photo or video with your BAATLY community.", color = TextSecondary, fontSize = 13.sp)
                                }
                            }
                        }
                    } else {
                        items(posts, key = { it.id }) { post ->
                            SocialFeedPostCard(
                                post = post,
                                viewModel = viewModel,
                                isLiking = activeLikeOperations.contains(post.id),
                                onLike = { viewModel.toggleSocialLike(post) },
                                onFollow = { viewModel.toggleSocialFollow(post.userId) },
                                onProfile = { viewModel.openSocialProfile(post.userId) },
                                onComment = { commentTarget = post },
                                onCall = {
                                    val partner = availablePartners.firstOrNull { it.id == post.userId || it.userId == post.userId }
                                    if (post.isHost && post.canVoiceCall && partner != null) viewModel.requestCall(partner)
                                    else viewModel.showUserMessage("This host isn't available for a call right now")
                                },
                                onLoveNote = { loveNoteTarget = "post" to post.id }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSearch) {
        Dialog(
            onDismissRequest = { showSearch = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = SocialCream,
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { showSearch = false }) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Back to social media", tint = BrandPlum)
                        }
                        Text("Search BAATLY", color = BrandPlum, fontWeight = FontWeight.Black, fontSize = 22.sp, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            viewModel.searchSocialHosts(it)
                        },
                        singleLine = true,
                        placeholder = { Text("Search people or hosts") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = BrandPlum) },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VibrantPink,
                            unfocusedBorderColor = Color(0xFFE6DDE6),
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        )
                    )
                    val results by viewModel.socialSearchResults.collectAsState()
                    val searching by viewModel.isSocialSearching.collectAsState()
                    val searchError by viewModel.socialSearchError.collectAsState()
                    when {
                        searching -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = VibrantPink)
                        }
                        searchQuery.isBlank() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Filled.Search, contentDescription = null, tint = Color(0xFFC8B8CF), modifier = Modifier.size(44.dp))
                                Text("Find people on BAATLY", color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("Search by name or username", color = TextSecondary, fontSize = 13.sp)
                            }
                        }
                        !searchError.isNullOrBlank() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            Text(searchError.orEmpty(), color = TextSecondary, modifier = Modifier.padding(24.dp))
                        }
                        results.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            Text("No people found", color = TextSecondary)
                        }
                        else -> LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(results, key = { it.userId }) { profile ->
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White)
                                        .clickable {
                                            showSearch = false
                                            viewModel.openSocialProfile(profile.userId)
                                        }.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    val resultAvatar by rememberResolvedProfileImageUrl(profile.avatarUrl, viewModel.dataService)
                                    AsyncImage(model = resultAvatar, contentDescription = profile.displayName, contentScale = ContentScale.Crop, modifier = Modifier.size(50.dp).clip(CircleShape).background(SocialSoftPink))
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(profile.displayName.ifBlank { profile.username.ifBlank { "BAATLY member" } }, color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(profile.username.takeIf { it.isNotBlank() }?.let { "@$it" } ?: if (profile.isHost) "Approved host" else "BAATLY member", color = TextSecondary, fontSize = 12.sp)
                                    }
                                    Text("View profile", color = VibrantPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCamera) {
        BaatlyCameraScreen(
            onDismiss = { showCamera = false },
            onCaptured = { uri, chosenFilter ->
                showCamera = false
                pendingMedia = PendingSocialMedia(uri, cameraPurpose, "image/jpeg", chosenFilter)
            }
        )
    }

    pendingMedia?.let { media ->
        MediaEditorScreen(
            pending = media,
            dataService = viewModel.dataService,
            onDismiss = { pendingMedia = null },
            onPublish = { editedUri, caption ->
                pendingMedia = null
                when (media.purpose) {
                    "story" -> viewModel.createSocialStoryFromUri(context, editedUri, caption.ifBlank { "My Story" }) { }
                    "reel" -> viewModel.createSocialPostFromUri(context, editedUri, caption.ifBlank { "Reel on BAATLY" }) { }
                    else -> viewModel.createSocialPostFromUri(context, editedUri, caption) { }
                }
            }
        )
    }

    if (createStoryDialog) {
        AlertDialog(
            onDismissRequest = { createStoryDialog = false },
            containerColor = Color.White,
            title = { Text("Create Story", color = BrandPlum, fontWeight = FontWeight.Bold) },
            text = { Text("Choose a photo or short video for your 24-hour story.", color = TextSecondary) },
            confirmButton = {
                TextButton(onClick = { createStoryDialog = false; storyPicker.launch("image/*") }) { Text("Photo", color = VibrantPink) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { createStoryDialog = false; storyVideoPicker.launch("video/*") }) { Text("Video", color = VibrantPink) }
                    TextButton(onClick = { createStoryDialog = false; cameraPurpose = "story"; showCamera = true }) { Text("Camera", color = VibrantPink) }
                    TextButton(onClick = { createStoryDialog = false }) { Text("Cancel", color = TextSecondary) }
                }
            }
        )
    }

    selectedStory?.let { story ->
        val storySequence = remember(stories, story.userId) {
            stories.filter { it.userId == story.userId }.sortedBy { it.createdAt }.ifEmpty { listOf(story) }
        }
        StoryViewerDialog(
            stories = storySequence,
            initialStoryId = story.id,
            viewModel = viewModel,
            onDismiss = { selectedStory = null },
            onLike = { viewModel.showUserMessage("Story likes will be connected in the backend pass") },
            onComment = { viewModel.showUserMessage("Story comments will be connected in the backend pass") },
            onFollow = { item -> viewModel.toggleSocialFollow(item.userId) },
            onCall = { item ->
                val partner = availablePartners.firstOrNull { it.id == item.userId || it.userId == item.userId }
                if (item.isHost && item.canVoiceCall && partner != null) viewModel.requestCall(partner)
                else viewModel.showUserMessage("This host isn't available for a call right now")
            },
            onLoveNote = { item -> loveNoteTarget = "story" to item.id }
        )
    }

    commentTarget?.let { post ->
        var commentText by remember(post.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { commentTarget = null },
            containerColor = Color.White,
            title = { Text("Comments", color = BrandPlum, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Comments on ${post.creatorName}'s post", color = TextSecondary, fontSize = 13.sp)
                    OutlinedTextField(value = commentText, onValueChange = { commentText = it }, placeholder = { Text("Write a comment…") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    Text("Comment posting will be connected in the backend pass.", color = TextTertiary, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { commentTarget = null }) { Text("Close", color = VibrantPink) } }
        )
    }


    loveNoteTarget?.let { target ->
        var message by remember(target) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { loveNoteTarget = null },
            containerColor = Color.White,
            title = { Text("Send Love Note 💌", color = BrandPlum, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Write a note to this approved host.", color = TextSecondary, fontSize = 13.sp)
                    OutlinedTextField(value = message, onValueChange = { message = it }, placeholder = { Text("Write your message…") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = message.isNotBlank(), onClick = {
                    viewModel.sendSocialLoveNote(target.first, target.second, message.trim()) { loveNoteTarget = null }
                }) { Text("Send", color = VibrantPink) }
            },
            dismissButton = { TextButton(onClick = { loveNoteTarget = null }) { Text("Cancel", color = TextSecondary) } }
        )
    }
}

@Composable
private fun SocialHeader(
    avatarUrl: String?,
    onProfile: () -> Unit,
    onSearch: () -> Unit,
    onMessages: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(SocialCream).statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        AsyncImage(
            model = avatarUrl,
            contentDescription = "My profile",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(42.dp).clip(CircleShape).background(SocialSoftPink).clickable(onClick = onProfile).testTag("btn_social_my_profile")
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
            Text("BAATLY", fontSize = 26.sp, fontWeight = FontWeight.Black, color = BrandPlum, letterSpacing = 0.2.sp)
            Text("U S E R  A P P", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = VibrantPink, letterSpacing = 1.5.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onSearch, modifier = Modifier.size(38.dp).testTag("btn_social_search")) {
                Icon(Icons.Filled.Search, contentDescription = "Search", tint = BrandPlum, modifier = Modifier.size(25.dp))
            }
            IconButton(onClick = onMessages, modifier = Modifier.size(38.dp).testTag("btn_social_messages")) {
                Icon(Icons.Outlined.MailOutline, contentDescription = "Messages", tint = BrandPlum, modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
private fun FeedsReelsTabs(selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFFF3ECEA),
        modifier = modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 4.dp)
    ) {
        Row(Modifier.padding(2.dp)) {
            listOf("Feeds", "Reels").forEach { tab ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (selected == tab) VibrantPink else Color.Transparent,
                    modifier = Modifier.weight(1f).clickable { onSelect(tab) }.testTag("tab_social_${tab.lowercase()}")
                ) {
                    Box(Modifier.padding(vertical = 7.dp), contentAlignment = Alignment.Center) {
                        Text(tab, color = if (selected == tab) Color.White else BrandPlum, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialStoriesRow(
    stories: List<SocialStory>,
    currentUserId: String,
    currentUserAvatarUrl: String?,
    viewModel: BaatlyViewModel,
    onAddStory: () -> Unit,
    onStoryClick: (SocialStory) -> Unit
) {
    val groups = remember(stories, currentUserId) {
        stories.filter { it.userId.isNotBlank() }
            .groupBy { it.userId }
            .mapValues { (_, group) -> group.sortedBy { it.createdAt } }
    }
    val ownStories = groups[currentUserId].orEmpty()
    val otherGroups = remember(groups, currentUserId) {
        groups.filterKeys { it != currentUserId }.values
            .sortedByDescending { group -> group.lastOrNull()?.createdAt.orEmpty() }
    }
    val ownAvatar by rememberResolvedProfileImageUrl(ownStories.firstOrNull()?.creatorAvatarUrl ?: currentUserAvatarUrl, viewModel.dataService)

    LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(13.dp), modifier = Modifier.padding(top = 8.dp)) {
        item(key = "my_story") {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
                Box(Modifier.size(72.dp)) {
                    val ownRing = if (ownStories.isEmpty()) {
                        Modifier.border(2.dp, DarkCardBorder, CircleShape)
                    } else {
                        Modifier.border(3.dp, Brush.sweepGradient(listOf(VibrantPink, Color(0xFFFFB703), VibrantPink)), CircleShape)
                    }
                    Box(
                        Modifier.fillMaxSize().clip(CircleShape).then(ownRing)
                            .padding(if (ownStories.isEmpty()) 0.dp else 4.dp)
                            .clip(CircleShape).background(Color.White)
                            .clickable { if (ownStories.isEmpty()) onAddStory() else onStoryClick(ownStories.first()) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (ownStories.isEmpty()) {
                            Icon(Icons.Filled.Add, contentDescription = "Add story", tint = BrandPlum, modifier = Modifier.size(30.dp))
                        } else {
                            AsyncImage(model = ownAvatar, contentDescription = "Your story", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape))
                        }
                    }
                    if (ownStories.isNotEmpty()) {
                        Surface(
                            modifier = Modifier.align(Alignment.BottomEnd).size(25.dp).clickable(onClick = onAddStory),
                            shape = CircleShape, color = VibrantPink, border = androidx.compose.foundation.BorderStroke(2.dp, SocialCream)
                        ) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Add, contentDescription = "Add to your story", tint = Color.White, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text("Your story", color = BrandPlum, fontSize = 11.sp, maxLines = 1)
            }
        }
        items(otherGroups, key = { it.firstOrNull()?.userId ?: it.firstOrNull()?.id ?: "story_group_${it.hashCode()}" }) { group ->
            val story = group.first()
            val groupAvatar by rememberResolvedProfileImageUrl(story.creatorAvatarUrl, viewModel.dataService)
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp).clickable { onStoryClick(story) }) {
                Box(Modifier.size(72.dp).clip(CircleShape).border(3.dp, Brush.sweepGradient(listOf(VibrantPink, Color(0xFFFFB703), VibrantPink)), CircleShape).padding(4.dp)) {
                    AsyncImage(model = groupAvatar, contentDescription = story.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape).background(SocialSoftPink))
                }
                Spacer(Modifier.height(5.dp))
                Text(story.creatorName.ifBlank { "Member" }, color = BrandPlum, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SocialFeedPostCard(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    isLiking: Boolean,
    onLike: () -> Unit,
    onFollow: () -> Unit,
    onProfile: () -> Unit,
    onComment: () -> Unit,
    onCall: () -> Unit,
    onLoveNote: () -> Unit
) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    val resolvedAvatar by rememberResolvedProfileImageUrl(post.creatorAvatarUrl, viewModel.dataService)
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket) {
        val raw = post.mediaUrl?.takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id).takeIf { it.isNotBlank() }
    }
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF0E8E4)),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
    ) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onProfile).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AsyncImage(model = resolvedAvatar, contentDescription = post.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.size(44.dp).clip(CircleShape).background(SocialSoftPink))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(post.creatorName.ifBlank { "BAATLY member" }, color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (post.isHost) Text("✓", color = VibrantPink, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                    Text(if (post.isHost) "Approved host" else "BAATLY community", color = TextSecondary, fontSize = 11.sp)
                }
                TextButton(onClick = onFollow, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)) { Text(if (post.isFollowing) "Following" else "Follow", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                Icon(Icons.Filled.MoreHoriz, contentDescription = "More", tint = BrandPlum)
            }
            if (post.caption.isNotBlank()) Text(post.caption, color = BrandPlum, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 15.dp, vertical = 4.dp))
            Box(Modifier.fillMaxWidth().height(365.dp).background(Color(0xFFEFE7E4)).clickable(enabled = !mediaUrl.isNullOrBlank()) { if (!mediaUrl.isNullOrBlank()) viewModel.openFullScreenMedia(mediaUrl!!, post.mediaType) }) {
                if (post.mediaType.equals("video", ignoreCase = true)) {
                    if (!mediaUrl.isNullOrBlank()) {
                        // Show a real poster frame in the feed immediately; the video opens on tap.
                        SocialVideoThumbnail(url = mediaUrl!!, modifier = Modifier.fillMaxSize())
                    } else {
                        Box(Modifier.fillMaxSize().background(Color(0xFF24152F)), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    }
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play video", tint = Color.White, modifier = Modifier.align(Alignment.Center).size(52.dp).background(Color.Black.copy(alpha = 0.35f), CircleShape).padding(12.dp))
                } else {
                    AsyncImage(model = mediaUrl, contentDescription = post.caption, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                ActionItem(icon = if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, label = "${post.likesCount}", tint = if (post.isLiked) VibrantPink else BrandPlum, onClick = onLike, isLoading = isLiking)
                ActionItem(icon = Icons.Filled.ChatBubbleOutline, label = "Comment", tint = BrandPlum, onClick = onComment)
                if (post.isHost) {
                    ActionItem(icon = Icons.Filled.Call, label = "Call Now", tint = VibrantPink, onClick = onCall)
                    ActionItem(icon = Icons.Filled.MailOutline, label = "Love Note", tint = PrimaryLavender, onClick = onLoveNote)
                }
            }
        }
    }
}

@Composable
private fun ReelPage(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    shouldPlay: Boolean,
    isLiking: Boolean,
    onLike: () -> Unit,
    onFollow: () -> Unit,
    onComment: () -> Unit,
    onProfile: () -> Unit,
    onCall: () -> Unit,
    onLoveNote: () -> Unit
) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    val resolvedAvatar by rememberResolvedProfileImageUrl(post.creatorAvatarUrl, viewModel.dataService)
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket) {
        val raw = post.mediaUrl?.takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id).takeIf { it.isNotBlank() }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!mediaUrl.isNullOrBlank()) BaatlyVideoPlayer(mediaUrl!!, shouldPlay = shouldPlay, modifier = Modifier.fillMaxSize(), soundEnabled = true)
        else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }

        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.16f), Color.Transparent, Color.Black.copy(alpha = 0.62f)))))
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp, bottom = 46.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onLike)) {
                Icon(if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, contentDescription = "Like", tint = if (post.isLiked) VibrantPink else Color.White, modifier = Modifier.size(32.dp))
                Text(if (post.likesCount > 0) compactCount(post.likesCount) else "Like", color = Color.White, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onComment)) {
                Icon(Icons.Filled.ChatBubbleOutline, contentDescription = "Comment", tint = Color.White, modifier = Modifier.size(30.dp))
                Text("Comment", color = Color.White, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onFollow)) {
                Icon(Icons.Filled.Add, contentDescription = "Follow", tint = Color.White, modifier = Modifier.size(30.dp))
                Text(if (post.isFollowing) "Following" else "Follow", color = Color.White, fontSize = 11.sp)
            }
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = 16.dp, end = 88.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.clickable(onClick = onProfile)) {
                AsyncImage(model = resolvedAvatar, contentDescription = post.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.size(42.dp).clip(CircleShape).border(2.dp, Color.White, CircleShape))
                Text(post.creatorName.ifBlank { "BAATLY member" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (post.isHost) Text("✓", color = Color.White, fontWeight = FontWeight.Black)
            }
            if (post.caption.isNotBlank()) Text(post.caption, color = Color.White, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (post.isHost) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onCall, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Call Now", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = onLoveNote, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.MailOutline, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Love Note", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    isLoading: Boolean = false
) {
    Row(modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(enabled = !isLoading, onClick = onClick).padding(horizontal = 5.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        if (isLoading) CircularProgressIndicator(modifier = Modifier.size(16.dp), color = tint, strokeWidth = 2.dp)
        else Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun StoryViewerDialog(
    stories: List<SocialStory>,
    initialStoryId: String?,
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit,
    onLike: (SocialStory) -> Unit,
    onComment: (SocialStory) -> Unit,
    onFollow: (SocialStory) -> Unit,
    onCall: (SocialStory) -> Unit,
    onLoveNote: (SocialStory) -> Unit
) {
    val sequence = remember(stories) { stories.sortedBy { it.createdAt } }
    var currentIndex by remember(sequence, initialStoryId) {
        mutableIntStateOf(sequence.indexOfFirst { it.id == initialStoryId }.takeIf { it >= 0 } ?: 0)
    }
    val story = sequence.getOrNull(currentIndex) ?: return
    var mediaUrl by remember(story.id) { mutableStateOf<String?>(null) }
    var progress by remember(story.id) { mutableFloatStateOf(0f) }
    val isVideoStory = remember(story.id, story.mediaPath, story.mediaUrl) {
        story.mediaPath.orEmpty().substringBefore('?').substringAfterLast('.', "").lowercase() in setOf("mp4", "mov", "m4v", "webm", "m3u8", "3gp")
            || story.mediaUrl.orEmpty().substringBefore('?').substringAfterLast('.', "").lowercase() in setOf("mp4", "mov", "m4v", "webm", "m3u8", "3gp")
    }

    LaunchedEffect(story.id, story.mediaPath, story.mediaUrl) {
        val raw = story.mediaUrl?.takeIf { it.startsWith("https://") || it.startsWith("http://") }
            ?: story.mediaPath?.takeIf { it.isNotBlank() } ?: story.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, isStory = true, explicitBucket = story.mediaBucket, contentType = "story", contentId = story.id).takeIf { it.isNotBlank() }
    }
    LaunchedEffect(story.id, currentIndex, sequence.size) {
        progress = 0f
        val durationMs = if (isVideoStory) 12_000L else 5_000L
        val step = 100L
        var elapsed = 0L
        while (elapsed < durationMs) {
            kotlinx.coroutines.delay(step)
            elapsed += step
            progress = (elapsed.toFloat() / durationMs).coerceIn(0f, 1f)
        }
        if (currentIndex < sequence.lastIndex) currentIndex++ else onDismiss()
    }

    fun moveNext() {
        if (currentIndex < sequence.lastIndex) currentIndex++ else onDismiss()
    }
    fun movePrevious() {
        if (currentIndex > 0) currentIndex--
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (isVideoStory && !mediaUrl.isNullOrBlank()) {
                BaatlyVideoPlayer(mediaUrl!!, shouldPlay = true, modifier = Modifier.fillMaxSize(), soundEnabled = true)
            } else {
                AsyncImage(model = mediaUrl, contentDescription = story.caption, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            // Transparent tap zones deliver Instagram-like previous/next navigation.
            Row(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxSize().clickable { movePrevious() })
                Box(Modifier.weight(1f).fillMaxSize().clickable { moveNext() })
            }
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent, Color.Black.copy(alpha = 0.34f)))))
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    sequence.forEachIndexed { index, _ ->
                        val segment = when {
                            index < currentIndex -> 1f
                            index == currentIndex -> progress
                            else -> 0f
                        }
                        androidx.compose.material3.LinearProgressIndicator(
                            progress = { segment },
                            modifier = Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(4.dp)),
                            color = Color.White,
                            trackColor = Color.White.copy(alpha = 0.35f)
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AsyncImage(model = story.creatorAvatarUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(38.dp).clip(CircleShape).border(1.dp, Color.White, CircleShape))
                        Column {
                            Text(story.creatorName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${currentIndex + 1} of ${sequence.size}", color = Color.White.copy(alpha = 0.75f), fontSize = 10.sp)
                        }
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Close story", tint = Color.White) }
                }
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (story.caption.isNotBlank()) Text(story.caption, color = Color.White, fontSize = 14.sp)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onLike(story) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.FavoriteBorder, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Like")
                    }
                    OutlinedButton(onClick = { onComment(story) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Comment")
                    }
                    OutlinedButton(onClick = { onFollow(story) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text("Follow") }
                }
                if (story.isHost) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onCall(story) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(22.dp)) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Call Now")
                        }
                        OutlinedButton(onClick = { onLoveNote(story) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(22.dp)) {
                            Icon(Icons.Filled.MailOutline, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Love Note")
                        }
                    }
                }
            }
        }
    }
}

private fun compactCount(value: Int): String = when {
    value >= 1_000_000 -> "%.1fM".format(value / 1_000_000f)
    value >= 1_000 -> "%.1fK".format(value / 1_000f)
    else -> value.toString()
}


private fun mimeTypeForExtension(extensionRaw: String): String = when (extensionRaw.lowercase()) {
    "jpg", "jpeg" -> "image/jpeg"
    "png" -> "image/png"
    "webp" -> "image/webp"
    "mp4", "m4v" -> "video/mp4"
    "mov" -> "video/quicktime"
    "webm" -> "video/webm"
    "3gp" -> "video/3gpp"
    else -> "application/octet-stream"
}

private fun copySelectedMediaToCache(context: Context, uri: Uri, prefix: String): File {
    val resolver = context.contentResolver
    val mime = resolver.getType(uri)?.lowercase()?.substringBefore(';').orEmpty()
    val displayName = runCatching {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
        }.orEmpty()
    }.getOrDefault("")
    val candidateExtension = (displayName.ifBlank { uri.lastPathSegment.orEmpty() }).substringAfterLast('.', "").lowercase()
    val extension = when (mime) {
        "image/jpeg", "image/jpg" -> "jpg"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "video/mp4" -> "mp4"
        "video/quicktime" -> "mov"
        "video/webm" -> "webm"
        "video/3gpp" -> "3gp"
        else -> candidateExtension.takeIf { it in setOf("jpg", "jpeg", "png", "webp", "mp4", "m4v", "mov", "webm", "3gp") }
            ?: throw IllegalArgumentException("Supported formats are JPG, PNG, WebP, MP4, MOV, WebM and 3GP")
    }
    val file = File(context.cacheDir, "${prefix}_${System.currentTimeMillis()}.$extension")
    val input = resolver.openInputStream(uri) ?: throw IllegalStateException("Could not open selected media")
    input.use { source -> file.outputStream().use { output -> source.copyTo(output) } }
    if (file.length() <= 0L) {
        file.delete()
        throw IllegalStateException("Selected media is empty")
    }
    return file
}
