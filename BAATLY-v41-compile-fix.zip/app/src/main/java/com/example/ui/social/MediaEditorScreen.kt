package com.example.ui.social

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CropRotate
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.ui.media.BaatlyVideoPlayer
import com.example.data.model.BaatlyMusicTrack
import com.example.data.network.SupabaseDataService
import com.example.ui.media.MediaEditorExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val EditorInk = Color(0xFF24152F)
private val EditorPink = Color(0xFFFF2E78)
private val EditorCream = Color(0xFFFFF8F4)

data class PendingSocialMedia(
    val uri: Uri,
    val purpose: String, // post, story or reel
    val mimeType: String,
    val initialFilter: String = "Original"
)

@Composable
fun MediaEditorScreen(
    pending: PendingSocialMedia,
    dataService: SupabaseDataService,
    onDismiss: () -> Unit,
    onPublish: (Uri, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isVideo = remember(pending.uri, pending.mimeType) {
        pending.mimeType.startsWith("video/") || MediaEditorExporter.isVideo(context, pending.uri)
    }
    val filters = listOf("Original", "Warm", "Vivid", "Mono", "Vintage", "Invert")
    var selectedFilter by remember(pending.uri) { mutableStateOf(pending.initialFilter) }
    var showMusicLibrary by remember(pending.uri) { mutableStateOf(false) }
    var caption by remember(pending.uri) {
        mutableStateOf(when (pending.purpose) { "story" -> "My Story"; "reel" -> ""; else -> "" })
    }
    var overlayText by remember(pending.uri) { mutableStateOf("") }
    var selectedMusicUri by remember(pending.uri) { mutableStateOf<Uri?>(null) }
    var selectedMusicName by remember(pending.uri) { mutableStateOf("") }
    var musicVolume by remember(pending.uri) { mutableFloatStateOf(0.82f) }
    var originalAudioVolume by remember(pending.uri) { mutableFloatStateOf(0.32f) }
    var rotationDegrees by remember(pending.uri) { mutableStateOf(0) }
    var durationMs by remember(pending.uri) { mutableStateOf(0L) }
    var trimStartSeconds by remember(pending.uri) { mutableFloatStateOf(0f) }
    var trimEndSeconds by remember(pending.uri) { mutableFloatStateOf(0f) }
    var processing by remember(pending.uri) { mutableStateOf(false) }
    var errorText by remember(pending.uri) { mutableStateOf<String?>(null) }

    LaunchedEffect(pending.uri, isVideo) {
        if (isVideo) {
            durationMs = withContext(Dispatchers.IO) { MediaEditorExporter.getDurationMs(context, pending.uri) }
            trimEndSeconds = (durationMs / 1000f).coerceAtLeast(1f)
        }
    }
    BackHandler(enabled = true) { if (!processing) onDismiss() }

    Dialog(onDismissRequest = { if (!processing) onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(EditorCream).statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss, enabled = !processing) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = EditorInk) }
                Column(Modifier.weight(1f)) {
                    Text("BAATLY CREATOR STUDIO", color = EditorInk, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
                    Text(when (pending.purpose) { "story" -> "STORY EDITOR"; "reel" -> "REEL EDITOR"; else -> "POST EDITOR" }, color = EditorPink, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                }
                Text(if (isVideo) "VIDEO" else "PHOTO", color = EditorInk.copy(alpha = 0.65f), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 13.dp))
            }

            Box(Modifier.fillMaxWidth().weight(0.82f).padding(horizontal = 14.dp).clip(RoundedCornerShape(24.dp)).background(Color.Black)) {
                if (isVideo) {
                    BaatlyVideoPlayer(
                        url = pending.uri.toString(), shouldPlay = true, loop = true, soundEnabled = true,
                        cropToFill = false, showControls = true, filterName = selectedFilter,
                        modifier = Modifier.fillMaxSize().graphicsLayer(rotationZ = rotationDegrees.toFloat())
                    )
                } else {
                    AsyncImage(
                        model = pending.uri,
                        contentDescription = "Photo editor preview",
                        contentScale = ContentScale.Fit,
                        colorFilter = MediaEditorExporter.composeFilter(selectedFilter),
                        modifier = Modifier.fillMaxSize().graphicsLayer(rotationZ = rotationDegrees.toFloat())
                    )
                }
                if (overlayText.isNotBlank()) {
                    Text(
                        overlayText.take(80), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color.Black.copy(alpha = 0.35f)).padding(18.dp)
                    )
                }
                if (processing) {
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.64f)), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            CircularProgressIndicator(color = EditorPink)
                            Text(if (isVideo) "Preparing edited video…" else "Preparing photo…", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Long videos can take a little while to export.", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                        }
                    }
                }
            }

            Column(
                Modifier.fillMaxWidth().weight(1.18f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Filters", color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFF7E4ED)) {
                        IconButton(onClick = { rotationDegrees = (rotationDegrees + 90) % 360 }, enabled = !processing) {
                            Icon(Icons.Filled.CropRotate, contentDescription = "Rotate 90 degrees", tint = EditorPink)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    filters.forEach { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter, fontSize = 11.sp) },
                            colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EditorPink,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                if (isVideo) {
                    Text("Trim video", color = EditorInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    if (durationMs > 0L) {
                        Text("Start: ${trimStartSeconds.toInt()}s  ·  End: ${trimEndSeconds.toInt()}s  ·  Total: ${(durationMs / 1000).toInt()}s", color = EditorInk.copy(alpha = 0.7f), fontSize = 10.sp)
                        Slider(value = trimStartSeconds.coerceIn(0f, (trimEndSeconds - 1f).coerceAtLeast(0f)), onValueChange = { trimStartSeconds = it }, valueRange = 0f..(trimEndSeconds - 1f).coerceAtLeast(0f), enabled = !processing)
                        Slider(value = trimEndSeconds.coerceIn((trimStartSeconds + 1f).coerceAtMost((durationMs / 1000f)), (durationMs / 1000f).coerceAtLeast(1f)), onValueChange = { trimEndSeconds = it }, valueRange = (trimStartSeconds + 1f).coerceAtMost((durationMs / 1000f)).coerceAtLeast(1f)..(durationMs / 1000f).coerceAtLeast(1f), enabled = !processing)
                    } else {
                        Text("Video duration is not available; the whole clip will be kept.", color = EditorInk.copy(alpha = 0.65f), fontSize = 10.sp)
                    }
                    Button(onClick = { showMusicLibrary = true }, enabled = !processing, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF352247)), shape = RoundedCornerShape(18.dp)) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text(if (selectedMusicUri == null) "Add music" else "Change music")
                    }
                    if (selectedMusicUri != null) {
                        Text("Music selected: ${selectedMusicName.ifBlank { "Audio track" }}", color = EditorInk, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Original video sound · ${(originalAudioVolume * 100).toInt()}%", color = EditorInk, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        Slider(value = originalAudioVolume, onValueChange = { originalAudioVolume = it }, valueRange = 0f..1f, enabled = !processing)
                        Text("Music volume · ${(musicVolume * 100).toInt()}%", color = EditorInk, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        Slider(value = musicVolume, onValueChange = { musicVolume = it }, valueRange = 0f..1f, enabled = !processing)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.TextFields, contentDescription = null, tint = EditorPink, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Text overlay", color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                OutlinedTextField(
                    value = overlayText,
                    onValueChange = { overlayText = it.take(80) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Add text on your photo/video (optional)", fontSize = 12.sp) },
                    enabled = !processing,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    shape = RoundedCornerShape(14.dp)
                )
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it.take(2000) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = false,
                    maxLines = 2,
                    placeholder = { Text("Write a caption…", fontSize = 12.sp) },
                    enabled = !processing,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    shape = RoundedCornerShape(14.dp)
                )
                if (errorText != null) Text(errorText!!, color = Color(0xFFB3261E), fontSize = 11.sp)
                Button(
                    onClick = {
                        if (processing) return@Button
                        processing = true
                        errorText = null
                        scope.launch {
                            try {
                                val needsVideoExport = isVideo && (
                                    selectedFilter != "Original" || selectedMusicUri != null || rotationDegrees != 0 ||
                                        trimStartSeconds > 0f || (durationMs > 0L && trimEndSeconds < durationMs / 1000f - 0.25f) || overlayText.isNotBlank()
                                )
                                val needsPhotoExport = selectedFilter != "Original" || rotationDegrees != 0 || overlayText.isNotBlank()
                                val outputUri = when {
                                    isVideo && needsVideoExport -> MediaEditorExporter.exportVideo(
                                        context, pending.uri, selectedMusicUri, selectedFilter, rotationDegrees,
                                        (trimStartSeconds * 1000f).toLong(), (trimEndSeconds * 1000f).toLong(), overlayText,
                                        originalAudioVolume = originalAudioVolume,
                                        musicVolume = musicVolume
                                    )
                                    isVideo -> pending.uri
                                    needsPhotoExport -> MediaEditorExporter.exportPhoto(context, pending.uri, selectedFilter, rotationDegrees, overlayText)
                                    else -> pending.uri
                                }
                                processing = false
                                onPublish(outputUri, caption.trim())
                            } catch (error: Exception) {
                                processing = false
                                errorText = error.message?.take(180) ?: "Could not prepare this media. Try a shorter or supported file."
                            }
                        }
                    },
                    enabled = !processing,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EditorPink),
                    shape = RoundedCornerShape(17.dp)
                ) {
                    if (processing) CircularProgressIndicator(Modifier.size(19.dp), color = Color.White, strokeWidth = 2.dp)
                    else Text(if (pending.purpose == "story") "Save & Publish Story" else if (pending.purpose == "reel") "Publish Reel" else "Publish Post", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showMusicLibrary) {
        BaatlyMusicLibraryDialog(
            dataService = dataService,
            onDismiss = { showMusicLibrary = false },
            onTrackSelected = { track ->
                selectedMusicUri = Uri.parse(track.mediaUrl)
                selectedMusicName = listOf(track.title, track.artist).filter { it.isNotBlank() }.joinToString(" · ")
                showMusicLibrary = false
            }
        )
    }
}

@Composable
private fun BaatlyMusicLibraryDialog(
    dataService: SupabaseDataService,
    onDismiss: () -> Unit,
    onTrackSelected: (BaatlyMusicTrack) -> Unit
) {
    var tracks by remember { mutableStateOf<List<BaatlyMusicTrack>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var searchText by remember { mutableStateOf("") }
    var loadRequest by remember { mutableIntStateOf(0) }

    LaunchedEffect(loadRequest) {
        isLoading = true
        errorText = null
        dataService.getBaatlyMusicLibrary().onSuccess { tracks = it }.onFailure {
            tracks = emptyList()
            errorText = it.message ?: "Could not load BAATLY Music Library"
        }
        isLoading = false
    }

    val filteredTracks = remember(tracks, searchText) {
        val q = searchText.trim().lowercase()
        if (q.isBlank()) tracks else tracks.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) ||
                it.language.lowercase().contains(q) || it.category.lowercase().contains(q)
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).heightIn(min = 330.dp, max = 640.dp),
            shape = RoundedCornerShape(26.dp),
            color = Color.White,
            shadowElevation = 16.dp
        ) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFF8E4ED), modifier = Modifier.size(42.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.MusicNote, contentDescription = null, tint = EditorPink, modifier = Modifier.size(23.dp))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("BAATLY MUSIC LIBRARY", color = EditorInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        Text("Licensed sounds for your video", color = EditorInk.copy(alpha = 0.65f), fontSize = 11.sp)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Close music library", tint = EditorInk) }
                }
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search songs, artists or language", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = EditorPink) },
                    shape = RoundedCornerShape(14.dp)
                )
                when {
                    isLoading -> Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = EditorPink)
                    }
                    errorText != null -> Column(Modifier.fillMaxWidth().padding(vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(errorText!!, color = Color(0xFFB3261E), fontSize = 12.sp)
                        TextButton(onClick = { loadRequest++ }) { Text("Retry", color = EditorPink) }
                    }
                    tracks.isEmpty() -> Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color(0xFFBDA7B7), modifier = Modifier.size(40.dp))
                        Text("BAATLY Music Library is empty", color = EditorInk, fontWeight = FontWeight.Bold)
                        Text("Licensed tracks published by the BAATLY admin team will appear here. Phone files will not open from this button.", color = EditorInk.copy(alpha = 0.72f), fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        TextButton(onClick = { loadRequest++ }) { Text("Refresh library", color = EditorPink) }
                    }
                    filteredTracks.isEmpty() -> Box(Modifier.fillMaxWidth().height(140.dp), contentAlignment = Alignment.Center) {
                        Text("No tracks match your search.", color = EditorInk.copy(alpha = 0.7f), fontSize = 12.sp)
                    }
                    else -> Column(
                        Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(max = 340.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        filteredTracks.forEach { track ->
                            Surface(
                                modifier = Modifier.fillMaxWidth().clickable { onTrackSelected(track) },
                                shape = RoundedCornerShape(15.dp),
                                color = Color(0xFFFFF7FA),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1E3EB))
                            ) {
                                Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Surface(shape = CircleShape, color = Color(0xFFF2DDE7), modifier = Modifier.size(38.dp)) {
                                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.MusicNote, contentDescription = null, tint = EditorPink, modifier = Modifier.size(20.dp)) }
                                    }
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(track.title, color = EditorInk, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(listOf(track.artist, track.language, track.category).filter { it.isNotBlank() }.joinToString(" · "), color = EditorInk.copy(alpha = 0.65f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    if (track.durationSeconds != null) Text("${track.durationSeconds / 60}:${(track.durationSeconds % 60).toString().padStart(2, '0')}", color = EditorInk.copy(alpha = 0.65f), fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
