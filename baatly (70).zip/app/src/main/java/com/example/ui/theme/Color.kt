package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Colorful, Modern Deep Twilight Surface & Canvas Palette
val DarkBackground = Color(0xFF0E0C1B)
val DarkSurface = Color(0xFF18152E)
val DarkSurfaceVariant = Color(0xFF231F3F)
val DarkNavBackground = Color(0xFF131026)
val DarkCardBorder = Color(0xFF332D5C)
val DarkBorderSubtle = Color(0xFF463E7D)

// Vibrant Radiant Accents
val VibrantPink = Color(0xFFFF3366)
val VibrantViolet = Color(0xFF8B5CF6)
val ElectricIndigo = Color(0xFF6366F1)
val NeonCyan = Color(0xFF06B6D4)
val VibrantAmber = Color(0xFFFFB703)
val VibrantOrange = Color(0xFFFB8500)

val PrimaryLavender = Color(0xFFD4B2FF)
val PrimaryLavenderContainer = Color(0xFF4A2B75)
val PrimaryLavenderDark = Color(0xFF351C56)

// Retain aliases for existing references while offering richer, colourful styling
val PrimaryCoral = Color(0xFFFF4370)
val PrimaryCoralLight = Color(0xFFFF7A9E)
val PrimaryCoralDark = Color(0xFF5A142A)

val SecondaryAmber = Color(0xFFFFC043)
val SecondaryAmberLight = Color(0xFFFFE599)

val AccentPurple = Color(0xFF9333EA)
val AccentPurpleLight = Color(0xFFD8B4FE)

// Text Colors with crisp contrast
val TextPrimary = Color(0xFFF8F7FF)
val TextSecondary = Color(0xFFB4B0D4)
val TextTertiary = Color(0xFF7E79A8)

// Status & Action Colors
val OnlineGreen = Color(0xFF10B981)
val OfflineGray = Color(0xFF6B7280)
val BusyAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFFF385C)
val WarningYellow = Color(0xFFFFB703)

// Compatibility Aliases
val DarkCard = DarkSurface
val DarkCardBackground = DarkSurface
val DarkBorder = DarkCardBorder
val NeonPink = Color(0xFFFF2A85)
val DarkPink = Color(0xFFC2185B)
val TextMuted = TextSecondary
val ErrorRed = DangerRed
val SuccessGreen = OnlineGreen
val CoinGold = Color(0xFFFFD700)

// Vibrant Modern Gradients
val PrimaryGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFF3366), Color(0xFF8B5CF6))
)

val AccentGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF8B5CF6), Color(0xFF06B6D4))
)

val GoldGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFFD166), Color(0xFFFB8500))
)

val CardGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF1C1838), Color(0xFF14112B))
)

val HeroHeaderGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF2B2050), Color(0xFF0E0C1B))
)

val HostAvatarGradient = Brush.linearGradient(
    colors = listOf(Color(0xFFFF3366), Color(0xFFFFB703))
)



