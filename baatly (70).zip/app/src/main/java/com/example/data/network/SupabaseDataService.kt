package com.example.data.network

import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class SupabaseDataService(
    private val client: SupabaseClient,
    private val sessionManager: SessionManager
) {

    // 1. Available Partners (Hosts)
    suspend fun getAvailablePartners(): Result<List<PartnerProfile>> {
        return try {
            val list = mutableListOf<PartnerProfile>()
            try {
                val rpcRes = client.rpc("get_available_partners_with_follow")
                val array = JSONArray(rpcRes)
                for (i in 0 until array.length()) {
                    list.add(parsePartnerProfile(array.getJSONObject(i)))
                }
            } catch (_: Exception) {
                try {
                    val rpcRes = client.rpc("get_available_partners")
                    val array = JSONArray(rpcRes)
                    for (i in 0 until array.length()) {
                        list.add(parsePartnerProfile(array.getJSONObject(i)))
                    }
                } catch (_: Exception) {
                    val url = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?is_partner=eq.true&approval_status=eq.approved&account_status=neq.deleted&select=*"
                    val res = client.get(url)
                    val array = JSONArray(res)
                    for (i in 0 until array.length()) {
                        list.add(parsePartnerProfile(array.getJSONObject(i)))
                    }
                }
            }
            val eligibleList = list.filter {
                it.isPartner &&
                it.approvalStatus.equals("approved", ignoreCase = true) &&
                !it.accountStatus.equals("suspended", ignoreCase = true) &&
                !it.accountStatus.equals("deleted", ignoreCase = true) &&
                !it.accountStatus.equals("banned", ignoreCase = true)
            }
            Result.success(eligibleList)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 2. Host Profile
    suspend fun getHostProfile(hostId: String): Result<PartnerProfile> {
        if (hostId.isBlank()) return Result.failure(Exception("Host ID is blank"))
        return try {
            val profile = try {
                val rpcRes = client.rpc("get_host_profile", mapOf("p_partner_id" to hostId))
                val json = if (rpcRes.trim().startsWith("[")) {
                    val arr = JSONArray(rpcRes)
                    if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
                } else {
                    JSONObject(rpcRes)
                }
                parsePartnerProfile(json)
            } catch (_: Exception) {
                try {
                    val url = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(id.eq.$hostId,user_id.eq.$hostId)&select=*"
                    val res = client.get(url)
                    val array = JSONArray(res)
                    if (array.length() > 0) parsePartnerProfile(array.getJSONObject(0))
                    else throw Exception("Host not found in partner_profiles")
                } catch (_: Exception) {
                    val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=eq.$hostId&select=*"
                    val profileRes = client.get(profileUrl)
                    val profileArr = JSONArray(profileRes)
                    if (profileArr.length() > 0) parsePartnerProfile(profileArr.getJSONObject(0))
                    else throw Exception("Host profile not found")
                }
            }
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 3. Request Call (RPC returns scalar UUID)
    suspend fun requestCall(partnerId: String): Result<CallRecord> {
        return try {
            val callerId = sessionManager.userId.value ?: throw Exception("Not logged in")

            // Validate host eligibility and availability authoritatively before requesting call
            val hostProfileRes = getHostProfile(partnerId)
            if (hostProfileRes.isSuccess) {
                val host = hostProfileRes.getOrThrow()
                if (host.accountStatus.equals("suspended", ignoreCase = true) || host.accountStatus.equals("banned", ignoreCase = true)) {
                    return Result.failure(Exception("This host is currently suspended or unavailable."))
                }
                if (!host.approvalStatus.equals("approved", ignoreCase = true)) {
                    return Result.failure(Exception("This host is not approved for calls."))
                }
                if (!host.isAvailable || !host.isOnline) {
                    return Result.failure(Exception("Host is currently offline or busy. Please try again later."))
                }
                if (!host.audioEnabled) {
                    return Result.failure(Exception("Host has currently disabled audio calls."))
                }
            }

            val rpcRes = client.rpc("request_call", mapOf("p_partner_id" to partnerId))
            val rawCallId = rpcRes.trim().trim('"')
            val callId = if (rawCallId.startsWith("{")) {
                JSONObject(rawCallId).optString("id", rawCallId)
            } else {
                rawCallId
            }

            if (callId.isBlank()) {
                throw Exception("Invalid call ID returned from server")
            }

            // Authoritatively fetch the created call record from backend
            val callRecordResult = getCallRecord(callId)
            if (callRecordResult.isSuccess) {
                val callRec = callRecordResult.getOrThrow()
                // Trigger push notification to partner in background
                val myProfile = sessionManager.currentUser.value
                val senderName = myProfile?.displayName?.ifBlank { null } ?: "A user"
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        sendNotificationAndPush(
                            targetUserId = partnerId,
                            title = "Incoming call from $senderName",
                            body = "$senderName is calling you.",
                            notificationType = "incoming_call",
                            data = mapOf(
                                "call_id" to callId,
                                "sender_id" to callerId,
                                "sender_name" to senderName
                            )
                        )
                    } catch (_: Exception) {}
                }
                Result.success(callRec)
            } else {
                Result.failure(callRecordResult.exceptionOrNull() ?: Exception("Failed to retrieve created call record"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Fetch individual Call Record
    suspend fun getCallRecord(callId: String): Result<CallRecord> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/calls?id=eq.$callId&select=*,partner:partner_id(*)"
            val res = client.get(url)
            val array = JSONArray(res)
            if (array.length() > 0) {
                Result.success(parseCallRecord(array.getJSONObject(0)))
            } else {
                Result.failure(Exception("Call record not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 4. Update Call State (requested, ringing, accepted, connected, completed)
    suspend fun updateCallState(callId: String, newStatus: String): Result<Boolean> {
        return try {
            client.rpc("update_call_state", mapOf(
                "p_call_id" to callId,
                "p_new_status" to newStatus
            ))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 5. Settle Call
    suspend fun settleCall(callId: String): Result<Boolean> {
        return try {
            client.rpc("settle_call", mapOf("p_call_id" to callId))
            fetchWallet()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 6. Get Agora Token
    suspend fun getAgoraToken(channelName: String): Result<AgoraTokenResponse> {
        return try {
            val payload = JSONObject().apply {
                put("channel_name", channelName)
                put("role", "publisher")
            }
            val res = client.callEdgeFunction("agora-token", payload.toString())
            val json = JSONObject(res)
            val tokenResp = AgoraTokenResponse(
                appId = json.optString("app_id", SupabaseConfig.agoraAppId),
                channelName = json.optString("channel_name", channelName),
                uid = json.optLong("uid", 0),
                token = json.optString("token"),
                expiresIn = json.optLong("expires_in", 3600)
            )
            Result.success(tokenResp)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 7. Start Chat With Host
    suspend fun startChatWithHost(partnerId: String): Result<String> {
        return try {
            if (partnerId.isBlank()) {
                throw Exception("Invalid host / partner ID")
            }
            var resolvedPartnerId = partnerId
            if (!isRawUuid(resolvedPartnerId)) {
                try {
                    val pUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(user_id.eq.$partnerId,id.eq.$partnerId)&select=*"
                    val pRes = client.get(pUrl)
                    val pArr = JSONArray(pRes)
                    if (pArr.length() > 0) {
                        resolvedPartnerId = pArr.getJSONObject(0).optString("id", resolvedPartnerId)
                    }
                } catch (_: Exception) {}
            }
            val rpcRes = client.rpc("start_chat_with_host", mapOf("p_partner_id" to resolvedPartnerId))
            val raw = rpcRes.trim()
            var conversationId = ""
            if (raw.startsWith("[")) {
                val arr = JSONArray(raw)
                if (arr.length() > 0) {
                    val obj = arr.getJSONObject(0)
                    conversationId = obj.optString("id", obj.optString("conversation_id", obj.optString("p_conversation_id", "")))
                }
            } else if (raw.startsWith("{")) {
                val obj = JSONObject(raw)
                conversationId = obj.optString("id", obj.optString("conversation_id", obj.optString("p_conversation_id", "")))
            } else {
                conversationId = raw.trim('"')
            }
            if (conversationId.isBlank() || conversationId == "null") {
                throw Exception("Could not initialize chat conversation")
            }
            Result.success(conversationId)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseDataService", "startChatWithHost error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 8. Send Chat Message
    suspend fun sendMessage(
        conversationId: String,
        receiverId: String,
        messageType: String = "text",
        content: String? = null,
        mediaUrl: String? = null,
        mediaDurationSeconds: Int? = null
    ): Result<ChatMessage> {
        return try {
            val senderId = sessionManager.userId.value
                ?: throw Exception("User session not found. Please sign in.")

            if (conversationId.isBlank()) {
                throw Exception("Invalid conversation ID")
            }
            if (receiverId.isBlank()) {
                throw Exception("Invalid host ID")
            }

            val params = mapOf<String, Any?>(
                "p_conversation_id" to conversationId,
                "p_receiver_id" to receiverId,
                "p_message_type" to messageType,
                "p_message_text" to content,
                "p_media_url" to mediaUrl,
                "p_media_duration_seconds" to mediaDurationSeconds
            )

            val rpcRes = client.rpc("send_message", params)
            android.util.Log.d("SupabaseDataService", "send_message raw response: $rpcRes")

            val raw = rpcRes.trim()
            var success = true
            var serverMessageId: String? = null
            var errorMsg: String? = null

            if (raw.startsWith("{")) {
                val json = JSONObject(raw)
                if (json.has("success")) {
                    success = json.optBoolean("success", true)
                }
                if (!success) {
                    errorMsg = json.optString("error", json.optString("message", "Message rejected by server"))
                }
                serverMessageId = json.optString("message_id", json.optString("id", "")).takeIf { it.isNotBlank() }
            } else if (raw.startsWith("[")) {
                val arr = JSONArray(raw)
                if (arr.length() > 0) {
                    val json = arr.getJSONObject(0)
                    if (json.has("success")) {
                        success = json.optBoolean("success", true)
                    }
                    if (!success) {
                        errorMsg = json.optString("error", json.optString("message", "Message rejected by server"))
                    }
                    serverMessageId = json.optString("message_id", json.optString("id", "")).takeIf { it.isNotBlank() }
                }
            } else if (raw.isNotBlank() && raw != "null") {
                val cleaned = raw.trim('"')
                if (cleaned.isNotBlank() && cleaned != "null") {
                    serverMessageId = cleaned
                }
            }

            if (!success) {
                throw Exception(errorMsg ?: "Failed to send message")
            }

            // Sync wallet after successful send
            fetchWallet()

            val msg = ChatMessage(
                id = serverMessageId ?: UUID.randomUUID().toString(),
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                messageType = messageType,
                messageText = content,
                mediaUrl = mediaUrl,
                mediaDurationSeconds = mediaDurationSeconds,
                createdAt = "Just now"
            )

            // Trigger push notification to recipient asynchronously
            val myProfile = sessionManager.currentUser.value
            val senderName = myProfile?.displayName?.ifBlank { null } ?: "A user"
            val previewText = when (messageType) {
                "voice" -> "Sent a voice message"
                "image" -> "Sent a photo"
                else -> content?.take(60) ?: "You have a new message."
            }
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    sendNotificationAndPush(
                        targetUserId = receiverId,
                        title = "New message from $senderName",
                        body = previewText,
                        notificationType = "new_message",
                        data = mapOf(
                            "conversation_id" to conversationId,
                            "sender_id" to senderId,
                            "sender_name" to senderName,
                            "message_id" to msg.id
                        )
                    )
                } catch (_: Exception) {}
            }

            Result.success(msg)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseDataService", "sendMessage error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 9. Send Gift
    suspend fun sendGift(
        giftId: String,
        receiverId: String,
        conversationId: String? = null,
        callId: String? = null
    ): Result<Boolean> {
        return try {
            client.rpc("send_gift", mapOf(
                "p_gift_id" to giftId,
                "p_receiver_id" to receiverId,
                "p_conversation_id" to conversationId,
                "p_call_id" to callId
            ))
            fetchWallet()

            // Trigger push notification to recipient asynchronously
            val senderId = sessionManager.userId.value ?: ""
            val myProfile = sessionManager.currentUser.value
            val senderName = myProfile?.displayName?.ifBlank { null } ?: "A user"
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    sendNotificationAndPush(
                        targetUserId = receiverId,
                        title = "You received a gift",
                        body = "$senderName sent you a virtual gift.",
                        notificationType = "gift_received",
                        data = mapOf(
                            "sender_id" to senderId,
                            "sender_name" to senderName,
                            "gift_id" to giftId,
                            "conversation_id" to (conversationId ?: ""),
                            "call_id" to (callId ?: "")
                        )
                    )
                } catch (_: Exception) {}
            }

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 10. Follow / Unfollow (Using Canonical social_follow_toggle)
    suspend fun followHost(partnerId: String): Result<Boolean> {
        return toggleSocialFollow(partnerId)
    }

    suspend fun unfollowHost(partnerId: String): Result<Boolean> {
        return toggleSocialFollow(partnerId)
    }

    // 11. Clear My Conversation
    suspend fun clearMyConversation(conversationId: String): Result<Boolean> {
        return try {
            client.rpc("clear_my_conversation", mapOf("p_conversation_id" to conversationId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 12. Block User
    suspend fun blockUser(partnerId: String, reason: String = "User requested block"): Result<Boolean> {
        return try {
            try {
                client.rpc("block_user", mapOf("p_blocked_user_id" to partnerId, "p_reason" to reason))
            } catch (_: Exception) {
                client.rpc("block_user", mapOf("p_user_id" to partnerId, "p_reason" to reason))
            }
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 12b. Unblock User
    suspend fun unblockUser(partnerId: String): Result<Boolean> {
        return try {
            try {
                client.rpc("unblock_user", mapOf("p_blocked_user_id" to partnerId))
            } catch (_: Exception) {
                client.rpc("unblock_user", mapOf("p_user_id" to partnerId))
            }
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // =========================================================================
    // Centralized Authenticated Signed-URL Resolver for Profile Photos & Media
    // =========================================================================
    private val profileSignedUrlCache = java.util.concurrent.ConcurrentHashMap<String, Pair<String, Long>>()

    fun invalidateProfileAvatarCache(rawPathOrUrl: String? = null) {
        if (rawPathOrUrl.isNullOrBlank()) {
            profileSignedUrlCache.clear()
        } else {
            profileSignedUrlCache.remove(rawPathOrUrl.trim())
            val clean = extractProfileMediaStoragePath(rawPathOrUrl)
            if (clean.isNotBlank()) profileSignedUrlCache.remove(clean)
        }
    }

    private fun extractProfileMediaStoragePath(raw: String): String {
        var clean = raw.trim()
        if (clean.contains("/profile-media/")) {
            clean = clean.substringAfter("/profile-media/").substringBefore("?")
        } else if (clean.startsWith("profile-media/")) {
            clean = clean.removePrefix("profile-media/")
        }
        return clean.removePrefix("/")
    }

    suspend fun resolveProfileAvatarUrl(rawPathOrUrl: String?): String {
        if (rawPathOrUrl.isNullOrBlank() || rawPathOrUrl == "null") return ""
        val trimmed = rawPathOrUrl.trim()

        // Check in-memory cache
        val now = System.currentTimeMillis()
        val cached = profileSignedUrlCache[trimmed]
        if (cached != null && cached.second > now + 300_000) {
            return cached.first
        }

        // If it's a non-Supabase external URL (e.g., unsplash, googleusercontent), return as-is
        if ((trimmed.startsWith("http://") || trimmed.startsWith("https://")) &&
            !trimmed.contains("supabase.co") && !trimmed.contains(SupabaseConfig.supabaseUrl) &&
            !trimmed.contains("/profile-media/") && !trimmed.contains("profile-media")
        ) {
            return trimmed
        }

        // If it's already an unexpired signed Supabase URL with token
        if (trimmed.contains("token=") && (trimmed.startsWith("http://") || trimmed.startsWith("https://"))) {
            return trimmed
        }

        val storagePath = extractProfileMediaStoragePath(trimmed)
        if (storagePath.isBlank()) return ""

        return try {
            val signedUrl = client.createSignedUrl(SupabaseConfig.BUCKET_PROFILE_MEDIA, storagePath, 7200)
            if (signedUrl.isNotBlank()) {
                val expiry = now + 7000_000L
                profileSignedUrlCache[trimmed] = Pair(signedUrl, expiry)
                profileSignedUrlCache[storagePath] = Pair(signedUrl, expiry)
                signedUrl
            } else {
                trimmed
            }
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "Failed to resolve profile signed URL for $storagePath: ${e.message}")
            ""
        }
    }

    // Signed URL helper for private buckets (chat-media, profile-media, stories-media, social-media)
    suspend fun getSignedMediaUrl(rawPathOrUrl: String, bucket: String = SupabaseConfig.BUCKET_CHAT_MEDIA): String {
        if (rawPathOrUrl.isBlank() || rawPathOrUrl == "null") return ""
        val trimmed = rawPathOrUrl.trim()
        if (trimmed.contains("token=") && (trimmed.startsWith("http://") || trimmed.startsWith("https://"))) {
            return trimmed
        }
        if ((trimmed.startsWith("http://") || trimmed.startsWith("https://")) &&
            !trimmed.contains("supabase.co") && !trimmed.contains(SupabaseConfig.supabaseUrl) &&
            !trimmed.contains("/$bucket/") && !trimmed.contains(bucket)
        ) {
            return trimmed
        }
        val storagePath = if (trimmed.contains("/$bucket/")) {
            trimmed.substringAfter("/$bucket/").substringBefore("?")
        } else if (trimmed.startsWith("$bucket/")) {
            trimmed.removePrefix("$bucket/")
        } else if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            trimmed.removePrefix("/")
        }
        if (storagePath.startsWith("http://") || storagePath.startsWith("https://")) {
            return storagePath
        }
        return try {
            client.createSignedUrl(bucket, storagePath, 3600)
        } catch (e: Exception) {
            rawPathOrUrl
        }
    }

    // Story Reply - RPC: send_story_reply(p_story_id, p_message_text)
    suspend fun sendStoryReply(storyId: String, messageText: String): Result<ChatMessage> {
        val currentUserId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val rpcRes = client.rpc("send_story_reply", mapOf(
                "p_story_id" to storyId,
                "p_message_text" to messageText
            ))
            val json = if (rpcRes.trim().startsWith("[")) {
                val arr = JSONArray(rpcRes)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else if (rpcRes.trim().startsWith("{")) {
                JSONObject(rpcRes)
            } else {
                JSONObject().apply {
                    put("id", UUID.randomUUID().toString())
                    put("message_text", messageText)
                    put("reply_to_story_id", storyId)
                }
            }

            // Sync wallet after successful story reply
            fetchWallet()

            val msg = ChatMessage(
                id = json.optString("id").takeIf { it.isNotBlank() && it != "null" } ?: UUID.randomUUID().toString(),
                conversationId = json.optString("conversation_id"),
                senderId = json.optString("sender_id", currentUserId),
                receiverId = json.optString("receiver_id").takeIf { it.isNotBlank() && it != "null" },
                messageType = json.optString("message_type", "text"),
                messageText = json.optString("message_text", messageText),
                mediaUrl = json.optString("media_url").takeIf { it.isNotBlank() && it != "null" },
                mediaDurationSeconds = json.optInt("media_duration_seconds", 0),
                replyToStoryId = json.optString("reply_to_story_id").takeIf { it.isNotBlank() && it != "null" } ?: storyId,
                createdAt = json.optString("created_at", "Just now"),
                isRead = false
            )

            // Trigger push notification to story owner asynchronously
            val myProfile = sessionManager.currentUser.value
            val senderName = myProfile?.displayName?.ifBlank { null } ?: "A user"
            msg.receiverId?.let { targetId: String ->
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        sendNotificationAndPush(
                            targetUserId = targetId,
                            title = "New story reply from $senderName",
                            body = "$senderName replied to your story: ${messageText.take(50)}",
                            notificationType = "story_reply",
                            data = mapOf(
                                "conversation_id" to msg.conversationId,
                                "sender_id" to currentUserId,
                                "sender_name" to senderName,
                                "story_id" to storyId,
                                "message_id" to msg.id
                            )
                        )
                    } catch (_: Exception) {}
                }
            }

            Result.success(msg)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "sendStoryReply error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 13. Fetch Wallet
    suspend fun fetchWallet(): Result<WalletInfo> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/wallets?user_id=eq.$userId&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val wallet = if (arr.length() > 0) {
                val json = arr.getJSONObject(0)
                val coins = json.optInt("coin_balance", 0)
                val cash = json.optDouble("cash_balance", 0.0)
                WalletInfo(
                    userId = json.optString("user_id", userId),
                    coinBalance = coins,
                    cashBalance = cash,
                    updatedAt = json.optString("updated_at")
                )
            } else {
                WalletInfo(userId = userId, coinBalance = 0, cashBalance = 0.0)
            }
            sessionManager.updateWallet(wallet)
            Result.success(wallet)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 14. Fetch Coin Packages
    suspend fun fetchCoinPackages(): Result<List<CoinPackage>> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/coin_packages?is_active=eq.true&order=display_order.asc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<CoinPackage>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    CoinPackage(
                        id = json.getString("id"),
                        coins = json.getInt("coins"),
                        priceInr = json.getDouble("price_inr"),
                        displayOrder = json.optInt("display_order", i),
                        isActive = json.optBoolean("is_active", true)
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 14a. Create UroPay Order (Calls create-uropay-order Edge Function)
    suspend fun createUroPayOrder(packageId: String, tenantOrderRef: String): Result<UroPayCreateOrderResult> {
        val sessionCheck = client.ensureValidSession()
        when (sessionCheck) {
            is com.example.data.model.SessionResult.AuthRequired -> {
                return Result.failure(SessionExpiredException(sessionCheck.message))
            }
            is com.example.data.model.SessionResult.NetworkError -> {
                return Result.failure(PaymentNetworkException(sessionCheck.message))
            }
            is com.example.data.model.SessionResult.ServerError -> {
                return Result.failure(UroPayOrderException(sessionCheck.message))
            }
            is com.example.data.model.SessionResult.Valid -> {
                // Session is verified and fresh
            }
        }
        return try {
            val returnUrl = "https://baatly.app/payment/uropay/return"
            val reqJson = JSONObject().apply {
                put("package_id", packageId)
                put("tenant_order_ref", tenantOrderRef)
                put("return_url", returnUrl)
                put("returnUrl", returnUrl)
            }
            Log.d("SupabaseDataService", "create-uropay-order request for ref: $tenantOrderRef with returnUrl: $returnUrl")
            val rawRes = client.callEdgeFunction("create-uropay-order", reqJson.toString())
            val json = JSONObject(rawRes)

            val success = json.optBoolean("success", false)
            val reused = json.optBoolean("reused", false)
            val paymentId = json.optString("payment_id").takeIf { it.isNotBlank() }
                ?: json.optJSONObject("payment")?.optString("id")?.takeIf { it.isNotBlank() }
            val orderId = json.optString("order_id").takeIf { it.isNotBlank() }
                ?: json.optJSONObject("order")?.optString("id")?.takeIf { it.isNotBlank() }
            val openUrl = json.optString("open_url").takeIf { it.isNotBlank() }
                ?: json.optString("payment_url").takeIf { it.isNotBlank() }
                ?: json.optString("checkout_url").takeIf { it.isNotBlank() }
            val amountInr = json.optDouble("amount_inr", json.optDouble("amount", 0.0))
            val coins = json.optInt("coins", 0)
            val currency = json.optString("currency", "INR")
            val status = json.optString("status", "pending")
            val ref = json.optString("tenant_order_ref", tenantOrderRef)
            val message = json.optString("message").takeIf { it.isNotBlank() }
            val error = json.optString("error").takeIf { it.isNotBlank() }

            if (!success && error != null) {
                val errLower = error.lowercase()
                return if (errLower.contains("jwt expired") || errLower.contains("invalid_jwt") || (errLower.contains("unauthorized") && errLower.contains("auth"))) {
                    Result.failure(SessionExpiredException("Your session has expired. Please sign in again."))
                } else {
                    Result.failure(UroPayOrderException(error.ifBlank { message ?: "Unable to create payment order. Please try again." }))
                }
            }

            val result = UroPayCreateOrderResult(
                success = success,
                reused = reused,
                paymentId = paymentId,
                orderId = orderId,
                openUrl = openUrl,
                amountInr = amountInr,
                coins = coins,
                currency = currency,
                status = status,
                tenantOrderRef = ref,
                message = message,
                error = error
            )
            Log.d("SupabaseDataService", "create-uropay-order response: payment_id=$paymentId, order_id=$orderId, success=$success")
            Result.success(result)
        } catch (e: SupabaseException) {
            Log.e("SupabaseDataService", "createUroPayOrder SupabaseException: code=${e.statusCode}, msg=${e.message}", e)
            if (e.statusCode == 401 && (e.rawBody.contains("jwt", ignoreCase = true) || e.message.contains("session has expired", ignoreCase = true))) {
                Result.failure(SessionExpiredException("Your session has expired. Please sign in again."))
            } else {
                Result.failure(UroPayOrderException(e.message))
            }
        } catch (e: java.io.IOException) {
            Log.e("SupabaseDataService", "createUroPayOrder network IOException: ${e.message}", e)
            Result.failure(PaymentNetworkException("Connection problem. Please check your internet connection and try again."))
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "createUroPayOrder error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 14b. Verify UroPay Payment (Calls verify-uropay-payment Edge Function)
    suspend fun verifyUroPayPayment(paymentId: String): Result<UroPayVerifyPaymentResult> {
        val sessionCheck = client.ensureValidSession()
        when (sessionCheck) {
            is com.example.data.model.SessionResult.AuthRequired -> {
                return Result.failure(SessionExpiredException(sessionCheck.message))
            }
            is com.example.data.model.SessionResult.NetworkError -> {
                return Result.failure(PaymentNetworkException(sessionCheck.message))
            }
            is com.example.data.model.SessionResult.ServerError -> {
                return Result.failure(UroPayOrderException(sessionCheck.message))
            }
            is com.example.data.model.SessionResult.Valid -> {
                // Session is verified and fresh
            }
        }
        return try {
            val reqJson = JSONObject().apply {
                put("payment_id", paymentId)
            }
            Log.d("SupabaseDataService", "verify-uropay-payment request for payment_id: $paymentId")
            val rawRes = client.callEdgeFunction("verify-uropay-payment", reqJson.toString())
            val json = JSONObject(rawRes)

            val success = json.optBoolean("success", false)
            val statusRaw = json.optString("status", if (success) "success" else "pending").lowercase()
            val pid = json.optString("payment_id", paymentId).ifBlank { paymentId }
            val orderId = json.optString("order_id").takeIf { it.isNotBlank() }
            val coins = json.optInt("coins", json.optInt("coins_credited", 0))
            val amountInr = json.optDouble("amount_inr", json.optDouble("amount", 0.0))
            val alreadyProcessed = json.optBoolean("already_processed", false)
            val message = json.optString("message").takeIf { it.isNotBlank() }
            val error = json.optString("error").takeIf { it.isNotBlank() }

            val normalizedStatus = when (statusRaw) {
                "success", "paid", "completed" -> "success"
                "pending", "created", "in_progress", "awaiting_payment" -> "pending"
                "failed", "failure" -> "failed"
                "cancelled", "canceled", "user_cancelled" -> "cancelled"
                "expired" -> "expired"
                else -> if (success) "success" else statusRaw
            }

            val result = UroPayVerifyPaymentResult(
                success = success || normalizedStatus == "success",
                status = normalizedStatus,
                paymentId = pid,
                orderId = orderId,
                coins = coins,
                amountInr = amountInr,
                alreadyProcessed = alreadyProcessed,
                message = message,
                error = error
            )
            Log.d("SupabaseDataService", "verify-uropay-payment response: payment_id=$paymentId, status=$normalizedStatus, success=${result.success}")
            Result.success(result)
        } catch (e: SupabaseException) {
            Log.e("SupabaseDataService", "verifyUroPayPayment SupabaseException: code=${e.statusCode}, msg=${e.message}", e)
            if (e.statusCode == 401 && (e.rawBody.contains("jwt", ignoreCase = true) || e.message.contains("session has expired", ignoreCase = true))) {
                Result.failure(SessionExpiredException("Your session has expired. Please sign in again."))
            } else {
                Result.failure(UroPayOrderException(e.message))
            }
        } catch (e: java.io.IOException) {
            Log.e("SupabaseDataService", "verifyUroPayPayment network IOException: ${e.message}", e)
            Result.failure(PaymentNetworkException("Connection problem. Please check your internet connection and try again."))
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "verifyUroPayPayment error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 14c. Fetch Transactions History
    suspend fun fetchTransactions(): Result<List<TransactionItem>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/transactions?user_id=eq.$userId&order=created_at.desc&limit=50&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<TransactionItem>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    TransactionItem(
                        id = json.getString("id"),
                        userId = json.optString("user_id", userId),
                        type = json.optString("type", "debit"),
                        coins = json.optInt("coins", 0),
                        description = json.optString("description").takeIf { it.isNotBlank() },
                        createdAt = json.optString("created_at")
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "fetchTransactions error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 15. Fetch Gifts Catalogue (29 gifts)
    suspend fun fetchGifts(): Result<List<GiftItem>> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/gifts?is_active=eq.true&order=display_order.asc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<GiftItem>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    GiftItem(
                        id = json.getString("id"),
                        name = json.getString("name"),
                        category = json.optString("category", "General"),
                        iconUrl = json.optString("icon_url"),
                        animationUrl = json.optString("animation_url"),
                        coinPrice = json.optInt("coin_price", 10),
                        partnerEarningPercent = json.optDouble("partner_earning_percent", 50.0),
                        displayOrder = json.optInt("display_order", i),
                        isActive = json.optBoolean("is_active", true)
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 16. Fetch Recent Calls
    suspend fun fetchRecentCalls(): Result<List<CallRecord>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/calls?user_id=eq.$userId&order=created_at.desc&limit=50&select=*,partner:partner_id(*)"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<CallRecord>()
            for (i in 0 until arr.length()) {
                val callJson = arr.getJSONObject(i)
                var call = parseCallRecord(callJson)
                val partnerId = call.partnerId
                if (!partnerId.isNullOrBlank()) {
                    val p = call.partner
                    val needsResolution = p == null || p.displayName.isNullOrBlank() ||
                            p.displayName == "Host" || p.displayName == "Baatly Host" ||
                            p.avatarUrl.isNullOrBlank()
                    if (needsResolution) {
                        val hostRes = getHostProfile(partnerId)
                        if (hostRes.isSuccess) {
                            val resolvedPartner = hostRes.getOrNull()
                            if (resolvedPartner != null) {
                                call = call.copy(partner = resolvedPartner)
                            }
                        }
                    }
                }
                list.add(call)
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 17. Fetch Conversations
    suspend fun fetchConversations(): Result<List<ConversationSummary>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/conversations?order=last_message_at.desc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<ConversationSummary>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val convId = json.getString("id")
                val partnerId = json.optString("partner_id")
                val partnerObj = json.optJSONObject("partner")
                var partner = partnerObj?.let { parsePartnerProfile(it) }

                // Authoritatively resolve host profile via get_host_profile RPC if missing or generic
                if (partner == null || partner.displayName.isNullOrBlank() || partner.displayName == "Host" || partner.displayName == "Baatly Host") {
                    if (partnerId.isNotBlank()) {
                        val hostRes = getHostProfile(partnerId)
                        if (hostRes.isSuccess) {
                            partner = hostRes.getOrNull()
                        }
                    }
                }

                val lastMsgId = json.optString("last_message_id").takeIf { it.isNotBlank() && it != "null" }
                val userClearedAt = json.optString("user_cleared_at").takeIf { it.isNotBlank() && it != "null" }
                val partnerClearedAt = json.optString("partner_cleared_at").takeIf { it.isNotBlank() && it != "null" }
                val isCleared = (lastMsgId == null && (userClearedAt != null || partnerClearedAt != null))

                // Check for last message content and unread count directly in conversation row
                var lastMsgText = if (isCleared) null else listOf(
                    json.optString("last_message_text"),
                    json.optString("last_message"),
                    json.optString("last_message_preview"),
                    json.optString("message_text"),
                    json.optString("preview"),
                    json.optString("content")
                ).firstOrNull { it.isNotBlank() && it != "null" }

                var lastMsgType = if (isCleared) null else json.optString("last_message_type", json.optString("message_type", "text"))
                var lastMsgAt = if (isCleared) null else json.optString("last_message_at").takeIf { it.isNotBlank() && it != "null" }
                var unreadCount = if (isCleared) 0 else listOf(
                    json.optInt("unread_count", -1),
                    json.optInt("unread_messages_count", -1),
                    json.optInt("user_unread_count", -1)
                ).firstOrNull { it >= 0 } ?: 0

                // If not cleared and has last_message_id but preview text is not yet set, query messages table
                if (!isCleared && lastMsgId != null && lastMsgText.isNullOrBlank()) {
                    try {
                        val msgUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$convId&order=created_at.desc&limit=1&select=*"
                        val msgRes = client.get(msgUrl)
                        val msgArr = JSONArray(msgRes)
                        if (msgArr.length() > 0) {
                            val latestMsgObj = msgArr.getJSONObject(0)
                            val msgType = latestMsgObj.optString("message_type", "text")
                            lastMsgType = msgType
                            val candidate = listOf(
                                latestMsgObj.optString("message_text"),
                                latestMsgObj.optString("content"),
                                latestMsgObj.optString("text"),
                                latestMsgObj.optString("body")
                            ).firstOrNull { it.isNotBlank() && it != "null" }

                            if (!candidate.isNullOrBlank()) {
                                lastMsgText = candidate
                            } else if (msgType == "voice") {
                                lastMsgText = "🎙️ Voice message"
                            } else if (msgType == "gift") {
                                lastMsgText = "🎁 Gift"
                            } else if (msgType == "image") {
                                lastMsgText = "📷 Photo"
                            }

                            if (lastMsgAt.isNullOrBlank()) {
                                lastMsgAt = latestMsgObj.optString("created_at").takeIf { it.isNotBlank() && it != "null" }
                            }
                        }
                    } catch (_: Exception) {}
                }

                val userBlocked = json.optBoolean("user_blocked", false)
                val partnerBlocked = json.optBoolean("partner_blocked", false)

                list.add(
                    ConversationSummary(
                        id = convId,
                        userId = json.optString("user_id", userId),
                        partnerId = partnerId,
                        lastMessageId = lastMsgId,
                        lastMessageAt = lastMsgAt,
                        lastMessageText = lastMsgText,
                        lastMessageType = lastMsgType,
                        unreadCount = unreadCount,
                        userBlocked = userBlocked,
                        partnerBlocked = partnerBlocked,
                        createdAt = json.optString("created_at"),
                        updatedAt = json.optString("updated_at"),
                        partner = partner
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 17b. Fetch Single Conversation Details
    suspend fun fetchConversationDetails(conversationId: String): Result<ConversationSummary> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        if (conversationId.isBlank()) return Result.failure(Exception("Invalid conversation ID"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/conversations?id=eq.$conversationId&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            if (arr.length() == 0) {
                return Result.failure(Exception("Conversation not found"))
            }
            val json = arr.getJSONObject(0)
            val convId = json.getString("id")
            val partnerId = json.optString("partner_id")
            val partnerObj = json.optJSONObject("partner")
            var partner = partnerObj?.let { parsePartnerProfile(it) }

            if (partner == null && partnerId.isNotBlank()) {
                val hostRes = getHostProfile(partnerId)
                if (hostRes.isSuccess) {
                    partner = hostRes.getOrNull()
                }
            }

            val lastMsgId = json.optString("last_message_id").takeIf { it.isNotBlank() && it != "null" }
            val userClearedAt = json.optString("user_cleared_at").takeIf { it.isNotBlank() && it != "null" }
            val partnerClearedAt = json.optString("partner_cleared_at").takeIf { it.isNotBlank() && it != "null" }
            val isCleared = (lastMsgId == null && (userClearedAt != null || partnerClearedAt != null))

            val lastMsgText = if (isCleared) null else listOf(
                json.optString("last_message_text"),
                json.optString("last_message"),
                json.optString("last_message_preview"),
                json.optString("message_text"),
                json.optString("preview"),
                json.optString("content")
            ).firstOrNull { it.isNotBlank() && it != "null" }

            val lastMsgType = if (isCleared) null else json.optString("last_message_type", json.optString("message_type", "text"))
            val lastMsgAt = if (isCleared) null else json.optString("last_message_at").takeIf { it.isNotBlank() && it != "null" }
            val unreadCount = if (isCleared) 0 else listOf(
                json.optInt("unread_count", -1),
                json.optInt("unread_messages_count", -1),
                json.optInt("user_unread_count", -1)
            ).firstOrNull { it >= 0 } ?: 0

            val userBlocked = json.optBoolean("user_blocked", false)
            val partnerBlocked = json.optBoolean("partner_blocked", false)

            val summary = ConversationSummary(
                id = convId,
                userId = json.optString("user_id", userId),
                partnerId = partnerId,
                lastMessageId = lastMsgId,
                lastMessageAt = lastMsgAt,
                lastMessageText = lastMsgText,
                lastMessageType = lastMsgType,
                unreadCount = unreadCount,
                userBlocked = userBlocked,
                partnerBlocked = partnerBlocked,
                createdAt = json.optString("created_at"),
                updatedAt = json.optString("updated_at"),
                partner = partner
            )
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 17c. Mark Conversation Read
    suspend fun markConversationRead(conversationId: String): Result<Unit> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        if (conversationId.isBlank()) return Result.failure(Exception("Invalid conversation ID"))
        return try {
            client.rpc("mark_conversation_read", mapOf("p_conversation_id" to conversationId))
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "mark_conversation_read failed for $conversationId: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 18. Fetch Messages in Conversation
    suspend fun fetchMessages(conversationId: String): Result<List<ChatMessage>> {
        if (conversationId.isBlank()) return Result.success(emptyList())
        return try {
            // 1. Try get_conversation_messages RPC first as it is the backend-authoritative query
            var rawRes: String? = null
            try {
                rawRes = client.rpc("get_conversation_messages", mapOf("p_conversation_id" to conversationId))
            } catch (_: Exception) {}

            // 2. If RPC returned null/empty, check conversation row for cleared_at / last_message_id
            if (rawRes.isNullOrBlank() || rawRes == "null") {
                var clearedAt: String? = null
                var hasLastMessage = true
                try {
                    val convUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/conversations?id=eq.$conversationId&select=*"
                    val convJsonRes = client.get(convUrl)
                    val convArr = JSONArray(convJsonRes)
                    if (convArr.length() > 0) {
                        val cJson = convArr.getJSONObject(0)
                        val lastId = cJson.optString("last_message_id").takeIf { it.isNotBlank() && it != "null" }
                        val lastAt = cJson.optString("last_message_at").takeIf { it.isNotBlank() && it != "null" }
                        val userCleared = cJson.optString("user_cleared_at").takeIf { it.isNotBlank() && it != "null" }
                        val partnerCleared = cJson.optString("partner_cleared_at").takeIf { it.isNotBlank() && it != "null" }
                        clearedAt = userCleared ?: partnerCleared
                        if (lastId == null && lastAt == null && clearedAt != null) {
                            hasLastMessage = false
                        }
                    }
                } catch (_: Exception) {}

                if (!hasLastMessage) {
                    return Result.success(emptyList())
                }

                val msgUrlBuilder = StringBuilder("${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$conversationId&order=created_at.asc&select=*")
                if (!clearedAt.isNullOrBlank()) {
                    msgUrlBuilder.append("&created_at=gt.$clearedAt")
                }
                rawRes = client.get(msgUrlBuilder.toString())
            }

            val arr = JSONArray(rawRes)
            val list = mutableListOf<ChatMessage>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val msgId = json.optString("id").ifBlank { UUID.randomUUID().toString() }
                val convId = json.optString("conversation_id").ifBlank { conversationId }
                val senderId = json.optString("sender_id").ifBlank { json.optString("user_id") }
                val receiverId = json.optString("receiver_id").ifBlank { json.optString("partner_id") }
                val msgType = json.optString("message_type", "text")
                val textCandidate = listOf(
                    json.optString("message_text"),
                    json.optString("content"),
                    json.optString("text"),
                    json.optString("body")
                ).firstOrNull { it.isNotBlank() && it != "null" }
                val mediaCandidate = listOf(
                    json.optString("media_url"),
                    json.optString("media_path"),
                    json.optString("url")
                ).firstOrNull { it.isNotBlank() && it != "null" }
                val duration = json.optInt("media_duration_seconds", json.optInt("duration", 0))
                val giftId = json.optString("gift_id").takeIf { it.isNotBlank() && it != "null" }
                val replyToStoryId = json.optString("reply_to_story_id").takeIf { it.isNotBlank() && it != "null" }
                val createdAt = json.optString("created_at").takeIf { it.isNotBlank() && it != "null" }
                val isRead = json.optBoolean("is_read", false)

                val giftObj = json.optJSONObject("gift")
                val gift = giftObj?.let {
                    GiftItem(
                        id = it.optString("id"),
                        name = it.optString("name", "Gift"),
                        iconUrl = it.optString("icon_url").takeIf { u -> u.isNotBlank() && u != "null" },
                        coinPrice = it.optInt("coin_price", 10)
                    )
                }

                list.add(
                    ChatMessage(
                        id = msgId,
                        conversationId = convId,
                        senderId = senderId,
                        receiverId = receiverId,
                        messageType = msgType,
                        messageText = textCandidate,
                        mediaUrl = mediaCandidate,
                        mediaDurationSeconds = duration,
                        giftId = giftId,
                        replyToStoryId = replyToStoryId,
                        createdAt = createdAt,
                        isRead = isRead,
                        gift = gift
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 19. Fetch Notifications
    suspend fun fetchNotifications(): Result<List<AppNotification>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/notifications?user_id=eq.$userId&order=created_at.desc&limit=30&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<AppNotification>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val dataObj = json.optJSONObject("data")
                val dataMap = mutableMapOf<String, String>()
                dataObj?.let { obj ->
                    val keys = obj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        dataMap[key] = obj.optString(key)
                    }
                }
                list.add(
                    AppNotification(
                        id = json.getString("id"),
                        userId = json.optString("user_id"),
                        title = json.optString("title", "Baatly Notification"),
                        body = json.optString("body"),
                        notificationType = json.optString("notification_type", "system"),
                        isRead = json.optBoolean("is_read", false),
                        createdAt = json.optString("created_at"),
                        data = dataMap
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 19b. Mark Notification As Read
    suspend fun markNotificationAsRead(notificationId: String): Result<Boolean> {
        return try {
            try {
                client.rpc("mark_notification_read", mapOf("p_notification_id" to notificationId))
            } catch (_: Exception) {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/notifications?id=eq.$notificationId"
                val body = JSONObject().apply { put("is_read", true) }
                client.patch(url, body.toString())
            }
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 20. Upload Chat Media (image/voice)
    suspend fun uploadChatMedia(file: File, isVoice: Boolean): Result<String> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val ext = if (isVoice) "m4a" else "jpg"
            val mime = if (isVoice) "audio/mp4" else "image/jpeg"
            val relativePath = "$userId/${UUID.randomUUID()}.$ext"
            val storagePath = client.uploadFile(
                SupabaseConfig.BUCKET_CHAT_MEDIA,
                relativePath,
                file,
                mime
            )
            Result.success(storagePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseCallRecord(json: JSONObject): CallRecord {
        val partnerObj = json.optJSONObject("partner")
        val partner = partnerObj?.let { parsePartnerProfile(it) }
        val maxDurationSec = if (json.has("max_duration_seconds")) json.optInt("max_duration_seconds") else null
        val maxDurationCoin = if (json.has("max_duration_coins")) json.optInt("max_duration_coins") else null

        return CallRecord(
            id = json.getString("id"),
            userId = json.optString("user_id"),
            partnerId = json.optString("partner_id"),
            status = json.optString("status", "requested"),
            requestedAt = json.optString("requested_at").takeIf { it.isNotBlank() },
            ringingAt = json.optString("ringing_at").takeIf { it.isNotBlank() },
            acceptedAt = json.optString("accepted_at").takeIf { it.isNotBlank() },
            connectedAt = json.optString("connected_at").takeIf { it.isNotBlank() },
            endedAt = json.optString("ended_at").takeIf { it.isNotBlank() },
            durationSeconds = json.optInt("duration_seconds", 0),
            userCoinsCharged = json.optInt("user_coins_charged", 0),
            partnerEarning = json.optDouble("partner_earning", 0.0),
            terminationReason = json.optString("termination_reason").takeIf { it.isNotBlank() },
            billingStatus = json.optString("billing_status").takeIf { it.isNotBlank() },
            agoraChannelId = listOf(
                json.optString("agora_channel_id"),
                json.optString("channel_name"),
                json.optString("agora_channel")
            ).firstOrNull { it.isNotBlank() && it != "null" },
            createdAt = json.optString("created_at").takeIf { it.isNotBlank() },
            maxDurationSeconds = maxDurationSec,
            maxDurationCoins = maxDurationCoin,
            partner = partner
        )
    }

    fun parsePartnerProfile(json: JSONObject): PartnerProfile {
        val ageVal = if (json.has("age") && !json.isNull("age")) json.optInt("age").takeIf { it > 0 } else null
        val ratingVal = if (json.has("rating") && !json.isNull("rating")) json.optDouble("rating") else null

        val displayNameCandidate = listOf(
            json.optString("partner_display_name"),
            json.optString("host_display_name"),
            json.optString("display_name"),
            json.optString("full_name"),
            json.optString("first_name"),
            json.optString("name"),
            json.optString("host_name"),
            json.optString("partner_name"),
            json.optString("username")
        ).firstOrNull { it.isNotBlank() && it != "null" && it != "Host" && it != "Baatly Host" }
            ?: listOf(
                json.optString("partner_display_name"),
                json.optString("host_display_name"),
                json.optString("display_name"),
                json.optString("full_name"),
                json.optString("name"),
                json.optString("host_name"),
                json.optString("partner_name"),
                json.optString("username")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        val avatarCandidate = listOf(
            json.optString("profile_photo_path"),
            json.optString("partner_avatar_url"),
            json.optString("avatar_url"),
            json.optString("photo_path"),
            json.optString("profile_photo_url"),
            json.optString("photo_url"),
            json.optString("image_url")
        ).firstOrNull { it.isNotBlank() && it != "null" }

        val idCandidate = listOf(
            json.optString("id"),
            json.optString("partner_id"),
            json.optString("user_id")
        ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        val userIdCandidate = listOf(
            json.optString("user_id"),
            json.optString("partner_id"),
            json.optString("id")
        ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        val userIdDisplayCandidate = listOf(
            json.optString("user_id_display"),
            json.optString("public_handle"),
            json.optString("username")
        ).firstOrNull { it.isNotBlank() && it != "null" && !isRawUuid(it) }

        val bioCandidate = listOf(
            json.optString("bio"),
            json.optString("about"),
            json.optString("description")
        ).firstOrNull { it.isNotBlank() && it != "null" }

        val hobbiesCandidate = listOf(
            json.optString("hobbies"),
            json.optString("interests")
        ).firstOrNull { it.isNotBlank() && it != "null" }

        val followers = listOf(
            json.optInt("followers_count", -1),
            json.optInt("followers", -1),
            json.optInt("follower_count", -1),
            json.optInt("total_followers", -1)
        ).firstOrNull { it >= 0 } ?: 0

        val isFollowingCandidate = json.optBoolean("is_following", false) ||
                json.optBoolean("following", false) ||
                json.optBoolean("is_followed", false)

        return PartnerProfile(
            id = idCandidate,
            userId = userIdCandidate,
            userIdDisplay = userIdDisplayCandidate,
            displayName = if (displayNameCandidate.isNotBlank()) displayNameCandidate else "Host",
            avatarUrl = avatarCandidate,
            bio = bioCandidate,
            hobbies = hobbiesCandidate,
            age = ageVal,
            gender = json.optString("gender", "Female"),
            language = json.optString("language", "Hindi, English"),
            isPartner = json.optBoolean("is_partner", true),
            approvalStatus = json.optString("approval_status", "approved"),
            isAvailable = json.optBoolean("is_available", true),
            isOnline = json.optBoolean("is_online", true),
            audioEnabled = json.optBoolean("audio_enabled", true),
            chatEnabled = json.optBoolean("chat_enabled", true),
            accountStatus = json.optString("account_status", "active"),
            rating = ratingVal,
            followersCount = followers,
            reviewsCount = json.optInt("reviews_count", 0),
            isFollowing = isFollowingCandidate
        )
    }

    // ==========================================
    // SOCIAL MEDIA MODULE
    // ==========================================

    // Helper: resolve social media path into playable/viewable signed URL
    suspend fun resolveSocialMediaUrl(rawPathOrUrl: String?): String {
        if (rawPathOrUrl.isNullOrBlank() || rawPathOrUrl == "null") return ""
        val trimmed = rawPathOrUrl.trim()
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://") ||
            trimmed.startsWith("content://") || trimmed.startsWith("file://")
        ) {
            return trimmed
        }
        val clean = trimmed
            .removePrefix("social-media/")
            .removePrefix("${SupabaseConfig.BUCKET_SOCIAL_MEDIA}/")
            .removePrefix("/")
        if (clean.isBlank()) return ""
        return try {
            client.createSignedUrl(SupabaseConfig.BUCKET_SOCIAL_MEDIA, clean, 7200)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "Storage signing error for bucket social-media, path $clean: ${e.message}", e)
            ""
        }
    }

    // 1. Authoritative RPC: social_ensure_profile
    suspend fun ensureSocialProfile(): Result<Boolean> {
        return try {
            client.rpc("social_ensure_profile")
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 2. Authoritative RPC: social_is_host
    suspend fun isHostUser(userId: String): Boolean {
        if (userId.isBlank()) return false
        return try {
            val res = client.rpc("social_is_host", mapOf("p_user_id" to userId))
            res.trim().toBooleanStrictOrNull()
                ?: (res.trim().contains("true", ignoreCase = true) && !res.trim().contains("false", ignoreCase = true))
        } catch (_: Exception) {
            false
        }
    }

    // 3. Authoritative RPC: social_role
    suspend fun getSocialRole(userId: String): String {
        if (userId.isBlank()) return "user"
        return try {
            val res = client.rpc("social_role", mapOf("p_user_id" to userId))
            res.trim().trim('"').lowercase()
        } catch (_: Exception) {
            "user"
        }
    }

    // 4. Fetch Social Stories via Authoritative RPC social_get_visible_stories()
    suspend fun getSocialStories(): Result<List<SocialStory>> {
        val currentUserId = sessionManager.userId.value ?: ""
        return try {
            val rpcRes = client.rpc("social_get_visible_stories")
            val array = JSONArray(rpcRes)

            val list = mutableListOf<SocialStory>()
            for (i in 0 until array.length()) {
                val storyJson = array.getJSONObject(i)
                val story = parseSocialStory(storyJson, currentUserId)
                if (story.isStoryActiveAndValid) {
                    list.add(story)
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "getSocialStories failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 4b. Fetch Social Stories for specific Host via RPC social_get_visible_stories_for_owner()
    suspend fun getSocialStoriesForOwner(ownerId: String): Result<List<SocialStory>> {
        val currentUserId = sessionManager.userId.value ?: ""
        return try {
            val rpcRes = client.rpc("social_get_visible_stories_for_owner", mapOf("p_owner_id" to ownerId))
            val array = JSONArray(rpcRes)

            val list = mutableListOf<SocialStory>()
            for (i in 0 until array.length()) {
                val storyJson = array.getJSONObject(i)
                val story = parseSocialStory(storyJson, currentUserId)
                if (story.isStoryActiveAndValid) {
                    list.add(story)
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "getSocialStoriesForOwner failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 5. Fetch Social Feed via Authoritative RPC social_get_visible_feed()
    suspend fun getSocialFeed(page: Int = 0, limit: Int = 20): Result<List<SocialPost>> {
        val currentUserId = sessionManager.userId.value ?: ""
        val offset = page * limit
        return try {
            val rpcRes = try {
                client.rpc("social_get_visible_feed", mapOf("p_limit" to limit, "p_offset" to offset))
            } catch (e: Exception) {
                try {
                    client.rpc("social_get_visible_feed")
                } catch (_: Exception) {
                    throw e
                }
            }

            val array = JSONArray(rpcRes)
            val list = mutableListOf<SocialPost>()
            for (i in 0 until array.length()) {
                val postJson = array.getJSONObject(i)
                val post = parseSocialPost(postJson, currentUserId)
                if (post.isVisibleInFeed) {
                    list.add(post)
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "getSocialFeed failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 6. Fetch Social Profile via Authoritative RPC social_public_profile()
    suspend fun getSocialProfile(targetUserId: String? = null): Result<SocialProfile> {
        val currentUserId = sessionManager.userId.value ?: ""
        val lookupId = if (!targetUserId.isNullOrBlank()) targetUserId else currentUserId

        return try {
            if (lookupId != currentUserId) {
                // Viewing a Host's profile
                var resolvedHostId = lookupId
                var hostPartner: PartnerProfile? = null
                var hostProfileBase: JSONObject? = null

                // If lookupId is a handle (not raw UUID), resolve partner_profiles
                if (!isRawUuid(resolvedHostId)) {
                    try {
                        val pUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?user_id=eq.$lookupId&select=*"
                        val pRes = client.get(pUrl)
                        val pArr = JSONArray(pRes)
                        if (pArr.length() > 0) {
                            val pObj = pArr.getJSONObject(0)
                            hostPartner = parsePartnerProfile(pObj)
                            resolvedHostId = hostPartner.id
                        }
                    } catch (_: Exception) {}
                }

                // If partner is not resolved yet, query by id
                if (hostPartner == null && isRawUuid(resolvedHostId)) {
                    try {
                        val pUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?id=eq.$resolvedHostId&select=*"
                        val pRes = client.get(pUrl)
                        val pArr = JSONArray(pRes)
                        if (pArr.length() > 0) {
                            val pObj = pArr.getJSONObject(0)
                            hostPartner = parsePartnerProfile(pObj)
                        }
                    } catch (_: Exception) {}
                }

                // Also check base profiles table
                try {
                    val profUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?or=(id.eq.$resolvedHostId,user_id.eq.$lookupId)&select=*"
                    val profRes = client.get(profUrl)
                    val profArr = JSONArray(profRes)
                    if (profArr.length() > 0) {
                        hostProfileBase = profArr.getJSONObject(0)
                        if (!isRawUuid(resolvedHostId)) {
                            resolvedHostId = hostProfileBase.optString("id", resolvedHostId)
                        }
                    }
                } catch (_: Exception) {}

                var rpcProfile: SocialProfile? = null
                try {
                    val rpcRes = client.rpc("social_public_profile", mapOf("p_target_user_id" to resolvedHostId))
                    val obj = if (rpcRes.trim().startsWith("[")) {
                        val arr = JSONArray(rpcRes)
                        if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
                    } else {
                        JSONObject(rpcRes)
                    }

                    val isHost = obj.optBoolean("is_host", obj.optBoolean("is_owner_host", hostPartner != null || isHostUser(resolvedHostId)))
                    val displayName = obj.optString("display_name").takeIf { it.isNotBlank() && it != "null" }
                        ?: obj.optString("owner_display_name").takeIf { it.isNotBlank() && it != "null" }
                        ?: hostPartner?.displayName
                        ?: hostProfileBase?.optString("display_name")
                        ?: "Host"
                    val signupUserId = obj.optString("signup_user_id").takeIf { it.isNotBlank() && it != "null" }
                        ?: obj.optString("owner_user_id").takeIf { it.isNotBlank() && it != "null" }
                        ?: obj.optString("user_id").takeIf { it.isNotBlank() && it != "null" && !isRawUuid(it) }
                        ?: hostPartner?.userId
                        ?: hostProfileBase?.optString("user_id")
                        ?: ""
                    val avatarRaw = obj.optString("social_avatar_url").takeIf { it.isNotBlank() && it != "null" }
                        ?: obj.optString("avatar_url").takeIf { it.isNotBlank() && it != "null" }
                        ?: obj.optString("owner_avatar_url").takeIf { it.isNotBlank() && it != "null" }
                        ?: hostPartner?.avatarUrl
                        ?: hostProfileBase?.optString("avatar_url")
                    val resolvedAvatar = resolveSocialMediaUrl(avatarRaw)

                    val partnerObj = obj.optJSONObject("partner") ?: obj.optJSONObject("owner_partner")
                    val partner = partnerObj?.let { parsePartnerProfile(it) } ?: hostPartner

                    val postsList = mutableListOf<SocialPost>()
                    val postsArr = obj.optJSONArray("posts")
                    if (postsArr != null && postsArr.length() > 0) {
                        for (i in 0 until postsArr.length()) {
                            postsList.add(parseSocialPost(postsArr.getJSONObject(i), currentUserId))
                        }
                    } else {
                        val postsRes = getUserSocialPosts(resolvedHostId)
                        if (postsRes.isSuccess) postsList.addAll(postsRes.getOrDefault(emptyList()))
                    }

                    val storiesList = mutableListOf<SocialStory>()
                    val storiesArr = obj.optJSONArray("stories")
                    if (storiesArr != null && storiesArr.length() > 0) {
                        for (i in 0 until storiesArr.length()) {
                            val st = parseSocialStory(storiesArr.getJSONObject(i), currentUserId)
                            if (st.isActive && !st.isExpired) storiesList.add(st)
                        }
                    } else {
                        val storiesRes = getSocialStoriesForOwner(resolvedHostId)
                        if (storiesRes.isSuccess) storiesList.addAll(storiesRes.getOrDefault(emptyList()))
                    }

                    rpcProfile = SocialProfile(
                        userId = resolvedHostId,
                        bio = obj.optString("bio").takeIf { it.isNotBlank() && it != "null" } ?: hostPartner?.bio ?: hostProfileBase?.optString("bio") ?: "",
                        hobbies = obj.optString("hobbies").takeIf { it.isNotBlank() && it != "null" } ?: "",
                        socialAvatarUrl = resolvedAvatar,
                        followersCount = obj.optInt("followers_count", hostPartner?.followersCount ?: 0),
                        followingCount = obj.optInt("following_count", 0),
                        totalLikes = obj.optInt("total_likes", 0),
                        totalViews = obj.optInt("total_views", 0),
                        createdAt = obj.optString("created_at"),
                        updatedAt = obj.optString("updated_at"),
                        displayName = displayName,
                        signupUserId = signupUserId,
                        isHost = isHost,
                        isFollowing = obj.optBoolean("is_following", false),
                        posts = postsList,
                        stories = storiesList,
                        partner = partner ?: PartnerProfile(
                            id = resolvedHostId,
                            userId = signupUserId,
                            displayName = displayName,
                            avatarUrl = resolvedAvatar,
                            bio = obj.optString("bio").takeIf { it.isNotBlank() && it != "null" } ?: hostPartner?.bio,
                            isOnline = true
                        )
                    )
                } catch (rpcEx: Exception) {
                    Log.e("SupabaseDataService", "social_public_profile RPC error: ${rpcEx.message}", rpcEx)
                }

                if (rpcProfile != null) {
                    return Result.success(rpcProfile)
                }

                // Fallback for Host profile if RPC fails (NEVER use current logged-in user)
                val hostDisplayName = hostPartner?.displayName ?: hostProfileBase?.optString("display_name") ?: "Host"
                val hostSignupUserId = hostPartner?.userId ?: hostProfileBase?.optString("user_id") ?: ""
                val hostAvatar = resolveSocialMediaUrl(hostPartner?.avatarUrl ?: hostProfileBase?.optString("avatar_url"))
                val hostBio = hostPartner?.bio ?: hostProfileBase?.optString("bio") ?: ""
                val postsRes = getUserSocialPosts(resolvedHostId).getOrDefault(emptyList())
                val storiesRes = getSocialStoriesForOwner(resolvedHostId).getOrDefault(emptyList())

                val fallbackHostProfile = SocialProfile(
                    userId = resolvedHostId,
                    bio = hostBio,
                    hobbies = "",
                    socialAvatarUrl = hostAvatar,
                    followersCount = hostPartner?.followersCount ?: 0,
                    followingCount = 0,
                    totalLikes = 0,
                    totalViews = 0,
                    createdAt = null,
                    updatedAt = null,
                    displayName = hostDisplayName,
                    signupUserId = hostSignupUserId,
                    isHost = true,
                    isFollowing = false,
                    posts = postsRes,
                    stories = storiesRes,
                    partner = hostPartner ?: PartnerProfile(
                        id = resolvedHostId,
                        userId = hostSignupUserId,
                        displayName = hostDisplayName,
                        avatarUrl = hostAvatar,
                        bio = hostBio,
                        isOnline = true
                    )
                )
                return Result.success(fallbackHostProfile)
            }

            // Own Profile (lookupId == currentUserId):
            var profileObj: JSONObject? = null
            try {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_profiles?user_id=eq.$lookupId&select=*"
                val res = client.get(url)
                val arr = JSONArray(res)
                if (arr.length() > 0) profileObj = arr.getJSONObject(0)
            } catch (_: Exception) {}

            var baseProfileObj: JSONObject? = null
            try {
                val baseProfileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?or=(id.eq.$lookupId,user_id.eq.$lookupId)&select=*"
                val baseRes = client.get(baseProfileUrl)
                val baseArr = JSONArray(baseRes)
                if (baseArr.length() > 0) baseProfileObj = baseArr.getJSONObject(0)
            } catch (_: Exception) {}

            val currentUser = sessionManager.currentUser.value
            val isHost = isHostUser(lookupId) || baseProfileObj?.optBoolean("is_partner", false) == true
            val displayName = currentUser?.displayName ?: baseProfileObj?.optString("display_name") ?: if (isHost) "Host" else "User"
            val signupUserId = currentUser?.userId ?: baseProfileObj?.optString("user_id") ?: ""
            val socialAvatarRaw = profileObj?.optString("social_avatar_url")?.takeIf { it.isNotBlank() && it != "null" }
                ?: currentUser?.avatarUrl ?: baseProfileObj?.optString("avatar_url")
            val resolvedAvatar = resolveSocialMediaUrl(socialAvatarRaw)

            val postsRes = getUserSocialPosts(lookupId)
            val storiesRes = getUserSocialStories(lookupId)

            val socialProfile = SocialProfile(
                userId = lookupId,
                bio = profileObj?.optString("bio")?.takeIf { it.isNotBlank() && it != "null" } ?: "",
                hobbies = profileObj?.optString("hobbies")?.takeIf { it.isNotBlank() && it != "null" } ?: "",
                socialAvatarUrl = resolvedAvatar,
                followersCount = profileObj?.optInt("followers_count", 0) ?: 0,
                followingCount = profileObj?.optInt("following_count", 0) ?: 0,
                totalLikes = profileObj?.optInt("total_likes", 0) ?: 0,
                totalViews = profileObj?.optInt("total_views", 0) ?: 0,
                createdAt = profileObj?.optString("created_at"),
                updatedAt = profileObj?.optString("updated_at"),
                displayName = displayName,
                signupUserId = signupUserId,
                isHost = isHost,
                isFollowing = false,
                posts = postsRes.getOrDefault(emptyList()),
                stories = storiesRes.getOrDefault(emptyList()),
                partner = null
            )
            Result.success(socialProfile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 7. Update Social Profile via RPC social_update_profile
    suspend fun updateSocialProfile(
        bio: String,
        hobbies: String,
        avatarFile: File? = null
    ): Result<Boolean> {
        val authUuid = sessionManager.userId.value?.takeIf { it.isNotBlank() }
            ?: sessionManager.currentUser.value?.id?.takeIf { it.isNotBlank() }
            ?: return Result.failure(Exception("Not logged in"))
        return try {
            var avatarStoragePath: String? = null
            if (avatarFile != null) {
                val ext = "jpg"
                val path = "$authUuid/${UUID.randomUUID()}.$ext"
                avatarStoragePath = client.uploadFile(
                    SupabaseConfig.BUCKET_SOCIAL_MEDIA,
                    path,
                    avatarFile,
                    "image/jpeg"
                )
            }

            val params = mapOf(
                "p_bio" to bio.trim(),
                "p_hobbies" to hobbies.trim(),
                "p_avatar_url" to (avatarStoragePath ?: "")
            )
            client.rpc("social_update_profile", params)
            Result.success(true)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "updateSocialProfile failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 8. Search Social Profile by Signup User ID
    // Strict Role Rule: USER -> may search/view HOST profiles only. USER -> may NOT search/view USER profiles.
    suspend fun searchSocialProfile(targetUserId: String): Result<SocialSearchResult> {
        val cleanTargetId = targetUserId.trim().removePrefix("@")
        if (cleanTargetId.isBlank()) return Result.failure(Exception("Please enter a Host User ID to search."))

        return try {
            var searchObj: JSONObject? = null
            try {
                val rpcRes = client.rpc("social_search_profile", mapOf("p_target_user_id" to cleanTargetId))
                searchObj = if (rpcRes.trim().startsWith("[")) {
                    val arr = JSONArray(rpcRes)
                    if (arr.length() > 0) arr.getJSONObject(0) else null
                } else {
                    JSONObject(rpcRes)
                }
            } catch (_: Exception) {}

            if (searchObj != null) {
                val isHost = searchObj.optBoolean("is_host", searchObj.optBoolean("is_partner", false))
                val targetRole = searchObj.optString("role", if (isHost) "host" else "user").lowercase()
                val partnerObj = searchObj.optJSONObject("partner") ?: searchObj.optJSONObject("owner_partner")
                val partner = partnerObj?.let { parsePartnerProfile(it) }

                // The target host UUID: prefer partner.id, searchObj id, partner_id, host_id, or valid UUID user_id
                var hostUuid = partner?.id?.takeIf { it.isNotBlank() }
                    ?: searchObj.optString("id").takeIf { it.isNotBlank() && (isRawUuid(it) || !searchObj.has("user_id")) }
                    ?: searchObj.optString("partner_id").takeIf { it.isNotBlank() }
                    ?: searchObj.optString("host_id").takeIf { it.isNotBlank() }
                    ?: searchObj.optString("user_id").takeIf { it.isNotBlank() && isRawUuid(it) }
                    ?: ""

                val hostHandle = partner?.userId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
                    ?: searchObj.optString("signup_user_id").takeIf { it.isNotBlank() && !isRawUuid(it) }
                    ?: searchObj.optString("user_id").takeIf { it.isNotBlank() && !isRawUuid(it) }
                    ?: cleanTargetId

                // If hostUuid is not a UUID, resolve it from partner_profiles
                var resolvedPartner = partner
                if (hostUuid.isBlank() || !isRawUuid(hostUuid)) {
                    try {
                        val pUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(user_id.eq.$cleanTargetId,user_id.eq.$hostHandle,id.eq.$cleanTargetId)&approval_status=eq.approved&select=*"
                        val pRes = client.get(pUrl)
                        val pArr = JSONArray(pRes)
                        if (pArr.length() > 0) {
                            val pObj = pArr.getJSONObject(0)
                            resolvedPartner = parsePartnerProfile(pObj)
                            hostUuid = resolvedPartner.id
                        }
                    } catch (_: Exception) {}
                }

                if (hostUuid.isBlank()) {
                    hostUuid = cleanTargetId
                }

                val effectiveIsHost = isHost || targetRole == "host" || targetRole == "partner" || resolvedPartner != null || isHostUser(hostUuid)

                if (!effectiveIsHost) {
                    return Result.failure(Exception("Normal user profiles cannot be viewed. You can only search and view Host profiles."))
                }

                val rawAvatar = searchObj.optString("avatar_url").takeIf { it.isNotBlank() && it != "null" }
                    ?: searchObj.optString("social_avatar_url").takeIf { it.isNotBlank() && it != "null" }
                    ?: resolvedPartner?.avatarUrl
                val resolvedAvatar = resolveSocialMediaUrl(rawAvatar)
                val displayName = searchObj.optString("display_name").takeIf { it.isNotBlank() && it != "null" }
                    ?: resolvedPartner?.displayName
                    ?: "Host"
                val bio = searchObj.optString("bio").takeIf { it.isNotBlank() && it != "null" } ?: resolvedPartner?.bio

                val isFollowing = searchObj.optBoolean("is_following", searchObj.optBoolean("following", resolvedPartner?.isFollowing ?: false))
                return Result.success(
                    SocialSearchResult(
                        userId = hostUuid,
                        displayName = displayName,
                        signupUserId = hostHandle,
                        avatarUrl = resolvedAvatar,
                        isHost = true,
                        bio = bio,
                        followersCount = searchObj.optInt("followers_count", resolvedPartner?.followersCount ?: 0),
                        isFollowing = isFollowing,
                        partner = (resolvedPartner ?: PartnerProfile(
                            id = hostUuid,
                            userId = hostHandle,
                            displayName = displayName,
                            avatarUrl = resolvedAvatar,
                            bio = bio,
                            isOnline = true
                        )).copy(isFollowing = isFollowing)
                    )
                )
            }

            // Fallback REST Search: Find in partner_profiles
            val partnerUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(user_id.ilike.%25$cleanTargetId%25,display_name.ilike.%25$cleanTargetId%25,id.eq.$cleanTargetId)&approval_status=eq.approved&select=*"
            val partnerRes = client.get(partnerUrl)
            val partnerArr = JSONArray(partnerRes)

            if (partnerArr.length() > 0) {
                val pObj = partnerArr.getJSONObject(0)
                val partner = parsePartnerProfile(pObj)
                val resolvedAvatar = resolveSocialMediaUrl(partner.avatarUrl)
                return Result.success(
                    SocialSearchResult(
                        userId = partner.id,
                        displayName = partner.displayName,
                        signupUserId = partner.userId ?: cleanTargetId,
                        avatarUrl = resolvedAvatar,
                        isHost = true,
                        bio = partner.bio,
                        followersCount = partner.followersCount,
                        isFollowing = partner.isFollowing,
                        partner = partner
                    )
                )
            }

            // Check if this exists as a normal user in profiles table
            val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?user_id=ilike.%25$cleanTargetId%25&select=*"
            val profileRes = client.get(profileUrl)
            val profileArr = JSONArray(profileRes)
            if (profileArr.length() > 0) {
                val pObj = profileArr.getJSONObject(0)
                val isPartner = pObj.optBoolean("is_partner", false)
                if (!isPartner) {
                    return Result.failure(Exception("Normal user profiles cannot be viewed. You can only search and view Host profiles."))
                }
            }

            Result.failure(Exception("No host found with User ID '$cleanTargetId'"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 9. Create Story or Post via RPC social_create_content
    // Story: p_type = "story" (Costs 10 coins, valid 24h)
    // Post: p_type = "post" (Costs 20 coins, visible 7 days)
    suspend fun createSocialContent(
        type: String, // "story" or "post"
        mediaFile: File,
        caption: String
    ): Result<String> {
        val authUuid = sessionManager.userId.value?.takeIf { it.isNotBlank() }
            ?: sessionManager.currentUser.value?.id?.takeIf { it.isNotBlank() }
            ?: return Result.failure(Exception("Not logged in"))
        return try {
            val ext = "jpg"
            val relativePath = "$authUuid/${UUID.randomUUID()}.$ext"
            val uploadedPath = client.uploadFile(
                SupabaseConfig.BUCKET_SOCIAL_MEDIA,
                relativePath,
                mediaFile,
                "image/jpeg"
            )

            val rpcParams = mapOf(
                "p_type" to type.lowercase(),
                "p_media_path" to uploadedPath,
                "p_caption" to caption.trim()
            )
            val res = client.rpc("social_create_content", rpcParams)
            Result.success(res)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "createSocialContent failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 10. View Content via RPC social_view_content
    // First view by same User on Host Story = 3 coins + Host ₹0.50. Repeat view = Free.
    suspend fun viewSocialContent(contentType: String, contentId: String): Result<Boolean> {
        return try {
            client.rpc("social_view_content", mapOf(
                "p_content_type" to contentType.lowercase(),
                "p_content_id" to contentId
            ))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 11. Like / Unlike Content via RPC social_toggle_like
    // Like = 1 coin + Host ₹0.20. Unlike = No refund. Like again = 1 coin.
    suspend fun toggleSocialLike(contentType: String, contentId: String): Result<Boolean> {
        return try {
            val rpcRes = client.rpc("social_toggle_like", mapOf(
                "p_content_type" to contentType.lowercase(),
                "p_content_id" to contentId
            ))
            val isLiked = try {
                JSONObject(rpcRes).optBoolean("is_liked", true)
            } catch (_: Exception) {
                !rpcRes.contains("false", ignoreCase = true) && !rpcRes.contains("unliked", ignoreCase = true)
            }
            Result.success(isLiked)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 12. Add Comment / Reply via RPC social_add_comment
    // Every comment / reply = 3 coins + Host ₹0.50.
    suspend fun addSocialComment(contentType: String, contentId: String, comment: String): Result<SocialComment> {
        val cleanComment = comment.trim()
        if (cleanComment.isBlank()) return Result.failure(Exception("Comment cannot be empty"))
        val currentUserId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        val currentUserProfile = sessionManager.currentUser.value

        return try {
            val rpcRes = client.rpc("social_add_comment", mapOf(
                "p_content_type" to contentType.lowercase(),
                "p_content_id" to contentId,
                "p_comment" to cleanComment
            ))
            val commentId = try {
                val json = JSONObject(rpcRes)
                json.optString("id", UUID.randomUUID().toString())
            } catch (_: Exception) {
                rpcRes.trim().trim('"').takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
            }

            val socialComment = SocialComment(
                id = commentId,
                contentId = contentId,
                contentType = contentType,
                userId = currentUserId,
                comment = cleanComment,
                createdAt = "Just now",
                displayName = currentUserProfile?.displayName ?: "Me",
                avatarUrl = currentUserProfile?.avatarUrl
            )
            Result.success(socialComment)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 13. Unlock Host Post via RPC social_unlock_post
    // First unlock = 3 coins + Host ₹0.50. Repeat viewing while unlocked = FREE.
    suspend fun unlockSocialPost(postId: String): Result<Boolean> {
        return try {
            client.rpc("social_unlock_post", mapOf("p_post_id" to postId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 14. Follow / Unfollow via RPC social_follow_toggle
    suspend fun toggleSocialFollow(targetUserId: String): Result<Boolean> {
        val authUuid = sessionManager.userId.value?.takeIf { it.isNotBlank() }
            ?: return Result.failure(Exception("Not logged in"))
        if (targetUserId.isBlank()) return Result.failure(Exception("Invalid target user ID"))

        var cleanTargetId = targetUserId.trim()
        if (!isRawUuid(cleanTargetId)) {
            try {
                val partnerUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(user_id.eq.$cleanTargetId,id.eq.$cleanTargetId)&select=id,user_id&limit=1"
                val res = client.get(partnerUrl)
                val arr = JSONArray(res)
                if (arr.length() > 0) {
                    val pObj = arr.getJSONObject(0)
                    val rawId = pObj.optString("id").takeIf { isRawUuid(it) }
                    val rawUid = pObj.optString("user_id").takeIf { isRawUuid(it) }
                    cleanTargetId = rawId ?: rawUid ?: cleanTargetId
                }
            } catch (_: Exception) {}
        }

        return try {
            val rpcRes = client.rpc("social_follow_toggle", mapOf("p_target_user_id" to cleanTargetId))
            val isFollowing = try {
                val trimmed = rpcRes.trim()
                val json = if (trimmed.startsWith("[")) {
                    val arr = JSONArray(trimmed)
                    if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
                } else if (trimmed.startsWith("{")) {
                    JSONObject(trimmed)
                } else {
                    JSONObject()
                }
                if (json.has("is_following")) {
                    json.getBoolean("is_following")
                } else if (json.has("following")) {
                    json.getBoolean("following")
                } else {
                    json.optBoolean("is_following", json.optBoolean("following", false))
                }
            } catch (_: Exception) {
                !rpcRes.contains("unfollowed", ignoreCase = true) && !rpcRes.contains("false", ignoreCase = true) && !rpcRes.contains("\"is_following\":false") && !rpcRes.contains("\"following\":false")
            }
            Result.success(isFollowing)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "social_follow_toggle failed for $targetUserId ($cleanTargetId): ${e.message}", e)
            Result.failure(e)
        }
    }

    // 15. Delete Post via RPC social_delete_post
    // Only authenticated post owner can delete the post.
    // Deletes social post and related non-financial social records.
    // Does NOT refund coins or modify wallets.
    // Returns: deleted, post_id, media_path, refund_issued = false
    suspend fun deleteSocialPost(postId: String): Result<DeleteSocialPostResponse> {
        return try {
            val rpcRes = client.rpc("social_delete_post", mapOf("p_post_id" to postId))
            val obj = if (rpcRes.trim().startsWith("[")) {
                val arr = JSONArray(rpcRes)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else {
                JSONObject(rpcRes)
            }
            val deleted = obj.optBoolean("deleted", true)
            val retPostId = obj.optString("post_id", postId)
            val mediaPath = obj.optString("media_path").takeIf { it.isNotBlank() && it != "null" }
            val refundIssued = obj.optBoolean("refund_issued", false)

            if (!deleted) {
                return Result.failure(Exception("Failed to delete post"))
            }

            // Normalize media_path to actual object path inside bucket: social-media
            if (!mediaPath.isNullOrBlank()) {
                val cleanPath = mediaPath.removePrefix("social-media/").removePrefix("/")
                try {
                    client.deleteStorageObject(SupabaseConfig.BUCKET_SOCIAL_MEDIA, cleanPath)
                } catch (storageEx: Exception) {
                    Log.e("SupabaseDataService", "Storage deletion failed for $cleanPath: ${storageEx.message}", storageEx)
                }
            }

            Result.success(
                DeleteSocialPostResponse(
                    deleted = true,
                    postId = retPostId,
                    mediaPath = mediaPath,
                    refundIssued = refundIssued
                )
            )
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "deleteSocialPost failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 15b. Authoritative Post Renewal via Backend RPC
    // - Validates that post is in grace period
    // - Calls backend RPC authoritatively (never deducts coins locally)
    // - Refreshes wallet from server upon success
    suspend fun renewSocialPost(postId: String): Result<String> {
        if (postId.isBlank()) return Result.failure(Exception("Post ID cannot be empty"))
        val currentUserId = sessionManager.userId.value ?: return Result.failure(Exception("User not authenticated"))

        return try {
            val rpcRes = try {
                client.rpc("social_renew_post", mapOf("p_post_id" to postId))
            } catch (e1: Exception) {
                val msg1 = e1.message ?: ""
                if (msg1.contains("404") || msg1.contains("PGRST202") || msg1.contains("schema cache") || msg1.contains("Could not find")) {
                    try {
                        client.rpc("renew_social_post", mapOf("p_post_id" to postId))
                    } catch (e2: Exception) {
                        val msg2 = e2.message ?: ""
                        if (msg2.contains("404") || msg2.contains("PGRST202") || msg2.contains("schema cache") || msg2.contains("Could not find")) {
                            client.rpc("renew_post", mapOf("p_post_id" to postId))
                        } else {
                            throw e2
                        }
                    }
                } else {
                    throw e1
                }
            }

            // Always fetch wallet authoritatively from server after backend renewal completes
            try {
                fetchWallet()
            } catch (_: Exception) {}

            Result.success(rpcRes)
        } catch (e: Exception) {
            val errMsg = e.message ?: "Post renewal failed"
            Log.e("SupabaseDataService", "renewSocialPost failed: $errMsg", e)
            Result.failure(Exception(errMsg))
        }
    }

    // 16. Fetch Comments for Post / Story
    suspend fun getSocialComments(contentType: String, contentId: String): Result<List<SocialComment>> {
        return try {
            val list = mutableListOf<SocialComment>()
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_comments?content_id=eq.$contentId&content_type=eq.${contentType.lowercase()}&order=created_at.asc&select=*"
            val res = client.get(url)
            val array = JSONArray(res)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val userId = obj.optString("user_id")
                var userDisplay = obj.optString("display_name").takeIf { it.isNotBlank() } ?: "User"
                var userAvatar = obj.optString("avatar_url").takeIf { it.isNotBlank() }

                list.add(
                    SocialComment(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        contentId = contentId,
                        contentType = contentType,
                        userId = userId,
                        comment = obj.optString("comment", obj.optString("comment_text", "")),
                        createdAt = obj.optString("created_at"),
                        displayName = userDisplay,
                        avatarUrl = userAvatar
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 13. Fetch User's Social Posts
    suspend fun getUserSocialPosts(userId: String): Result<List<SocialPost>> {
        val currentUserId = sessionManager.userId.value ?: ""
        val isOwner = userId == currentUserId
        return try {
            val list = mutableListOf<SocialPost>()
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_posts?owner_id=eq.$userId&order=created_at.desc&select=*"
            val res = client.get(url)
            val array = JSONArray(res)
            for (i in 0 until array.length()) {
                val post = parseSocialPost(array.getJSONObject(i), currentUserId)
                if (isOwner) {
                    // Owner sees active posts and posts within grace period (renewable)
                    // Permanently expired posts are never shown
                    if (!post.isPermanentlyExpired && post.isModerationApproved) {
                        list.add(post)
                    }
                } else {
                    // Public viewers only see active, approved posts
                    if (post.isVisibleInFeed) {
                        list.add(post)
                    }
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 14. Fetch User's Social Stories
    suspend fun getUserSocialStories(userId: String): Result<List<SocialStory>> {
        val currentUserId = sessionManager.userId.value ?: ""
        return try {
            val list = mutableListOf<SocialStory>()
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_stories?owner_id=eq.$userId&order=created_at.desc&select=*"
            val res = client.get(url)
            val array = JSONArray(res)
            for (i in 0 until array.length()) {
                val st = parseSocialStory(array.getJSONObject(i), currentUserId)
                if (st.isStoryActiveAndValid) {
                    list.add(st)
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 15. Fetch Social Earnings via Authoritative RPC social_get_earnings()
    suspend fun getSocialEarnings(): Result<String> {
        return try {
            val res = client.rpc("social_get_earnings")
            Result.success(res)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // -------------------------------------------------------------
    // Helper Parsers for Social (Authoritative from Backend)
    // -------------------------------------------------------------
    private suspend fun parseSocialStory(json: JSONObject, currentUserId: String): SocialStory {
        val ownerId = json.optString("owner_id", json.optString("user_id", ""))
        val mediaPath = json.optString("media_path")
        val isOwner = ownerId == currentUserId

        val isOwnerHost = json.optBoolean("is_owner_host", json.optBoolean("is_host", false))
        val rawDisplayName = json.optString("owner_display_name", json.optString("display_name", ""))
        val rawUserId = json.optString("owner_user_id", json.optString("user_id", ""))
        val rawAvatar = json.optString("owner_avatar_url", json.optString("avatar_url", ""))

        val displayName = rawDisplayName.takeIf { it.isNotBlank() && it != "null" && !isRawUuid(it) }
            ?: if (isOwnerHost) "Host" else "User"
        val userId = rawUserId.takeIf { it.isNotBlank() && it != "null" && !isRawUuid(it) } ?: ""

        val resolvedMedia = resolveSocialMediaUrl(mediaPath)
        val resolvedAvatar = resolveSocialMediaUrl(rawAvatar)

        val partnerObj = json.optJSONObject("owner_partner") ?: json.optJSONObject("partner")
        val partner = partnerObj?.let { parsePartnerProfile(it) }

        val moderationStatus = json.optString("moderation_status", "approved").takeIf { it.isNotBlank() && it != "null" } ?: "approved"

        return SocialStory(
            id = json.optString("id"),
            ownerId = ownerId,
            mediaPath = mediaPath,
            caption = json.optString("caption").takeIf { it.isNotBlank() && it != "null" },
            createdAt = json.optString("created_at"),
            expiresAt = json.optString("expires_at"),
            isActive = json.optBoolean("is_active", true),
            moderationStatus = moderationStatus,
            ownerDisplayName = displayName,
            ownerUserId = userId,
            ownerAvatarUrl = resolvedAvatar,
            isOwnerHost = isOwnerHost,
            likesCount = json.optInt("likes_count", json.optInt("total_likes", 0)),
            viewsCount = json.optInt("views_count", json.optInt("total_views", 0)),
            isLiked = json.optBoolean("is_liked", false),
            isViewed = if (isOwner) true else json.optBoolean("is_viewed", false),
            resolvedMediaUrl = resolvedMedia,
            ownerPartner = partner
        )
    }

    private suspend fun parseSocialPost(json: JSONObject, currentUserId: String): SocialPost {
        val ownerId = json.optString("owner_id", json.optString("user_id", ""))
        val mediaPath = json.optString("media_path")
        val isOwner = ownerId == currentUserId
        val visibleUntil = json.optString("visible_until")
        val renewalGraceUntil = json.optString("renewal_grace_until").takeIf { it.isNotBlank() && it != "null" }
        val moderationStatus = json.optString("moderation_status", "approved").takeIf { it.isNotBlank() && it != "null" } ?: "approved"
        val isExpired = try {
            if (visibleUntil.isNotBlank() && visibleUntil != "null") {
                json.optBoolean("is_expired", false)
            } else false
        } catch (_: Exception) { false }

        val isOwnerHost = json.optBoolean("is_owner_host", json.optBoolean("is_host", false))
        val rawDisplayName = json.optString("owner_display_name", json.optString("display_name", ""))
        val rawUserId = json.optString("owner_user_id", json.optString("user_id", ""))
        val rawAvatar = json.optString("owner_avatar_url", json.optString("avatar_url", ""))

        val displayName = rawDisplayName.takeIf { it.isNotBlank() && it != "null" && !isRawUuid(it) }
            ?: if (isOwnerHost) "Host" else "User"
        val userId = rawUserId.takeIf { it.isNotBlank() && it != "null" && !isRawUuid(it) } ?: ""

        val resolvedMedia = resolveSocialMediaUrl(mediaPath)
        val resolvedAvatar = resolveSocialMediaUrl(rawAvatar)

        val partnerObj = json.optJSONObject("owner_partner") ?: json.optJSONObject("partner")
        val partner = partnerObj?.let { parsePartnerProfile(it) }

        // If user's own post, it's always unlocked
        val isUnlocked = if (isOwner || !isOwnerHost) true else json.optBoolean("is_unlocked", false)

        return SocialPost(
            id = json.optString("id"),
            ownerId = ownerId,
            mediaPath = mediaPath,
            caption = json.optString("caption").takeIf { it.isNotBlank() && it != "null" },
            publishedAt = json.optString("published_at"),
            visibleUntil = visibleUntil.takeIf { it.isNotBlank() && it != "null" },
            renewalGraceUntil = renewalGraceUntil,
            moderationStatus = moderationStatus,
            createdAt = json.optString("created_at"),
            updatedAt = json.optString("updated_at"),
            ownerDisplayName = displayName,
            ownerUserId = userId,
            ownerAvatarUrl = resolvedAvatar,
            isOwnerHost = isOwnerHost,
            isUnlocked = isUnlocked,
            likesCount = json.optInt("likes_count", json.optInt("total_likes", 0)),
            commentsCount = json.optInt("comments_count", json.optInt("total_comments", 0)),
            viewsCount = json.optInt("views_count", json.optInt("total_views", 0)),
            isLiked = json.optBoolean("is_liked", false),
            isExpired = isExpired,
            resolvedMediaUrl = resolvedMedia,
            ownerPartner = partner
        )
    }

    // 40. Register FCM Token with Supabase Backend
    suspend fun registerFcmToken(token: String): Result<Boolean> {
        val currentUserId = sessionManager.userId.value ?: return Result.failure(Exception("User not authenticated"))
        if (token.isBlank()) return Result.failure(Exception("FCM token is blank"))

        // Check if already registered for current user to avoid duplicate requests
        if (sessionManager.lastRegisteredFcmToken == token && sessionManager.lastRegisteredUserId == currentUserId) {
            Log.d("SupabaseDataService", "FCM token already registered for current user: $currentUserId")
            return Result.success(true)
        }

        return try {
            val deviceInfo = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} (Android ${android.os.Build.VERSION.RELEASE})"
            val deviceId = android.os.Build.ID.ifBlank { "android_device" }

            var registered = false

            // Try primary RPC register_fcm_token with standard parameter names
            try {
                val params = mapOf(
                    "p_token" to token,
                    "p_platform" to "android",
                    "p_device_info" to deviceInfo,
                    "p_device_id" to deviceId
                )
                client.rpc("register_fcm_token", params)
                registered = true
                Log.d("SupabaseDataService", "FCM token registered via register_fcm_token (p_token)")
            } catch (e1: Exception) {
                Log.d("SupabaseDataService", "register_fcm_token variation 1 failed: ${e1.message}, trying variation 2...")
                try {
                    val params2 = mapOf(
                        "p_fcm_token" to token,
                        "p_device_type" to "android",
                        "p_device_info" to deviceInfo
                    )
                    client.rpc("register_fcm_token", params2)
                    registered = true
                    Log.d("SupabaseDataService", "FCM token registered via register_fcm_token (p_fcm_token)")
                } catch (e2: Exception) {
                    Log.d("SupabaseDataService", "register_fcm_token variation 2 failed: ${e2.message}, trying register_device_token...")
                    try {
                        val params3 = mapOf(
                            "p_token" to token,
                            "p_device_type" to "android",
                            "p_user_id" to currentUserId
                        )
                        client.rpc("register_device_token", params3)
                        registered = true
                        Log.d("SupabaseDataService", "FCM token registered via register_device_token")
                    } catch (e3: Exception) {
                        Log.d("SupabaseDataService", "register_device_token failed: ${e3.message}, trying table upsert fallback...")
                        // Fallback to table upsert if REST tables exist
                        try {
                            val upsertBody = JSONObject().apply {
                                put("user_id", currentUserId)
                                put("token", token)
                                put("platform", "android")
                                put("device_type", "android")
                                put("device_info", deviceInfo)
                                put("is_active", true)
                            }
                            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/fcm_tokens"
                            client.post(url, upsertBody.toString())
                            registered = true
                            Log.d("SupabaseDataService", "FCM token upserted to fcm_tokens table")
                        } catch (e4: Exception) {
                            try {
                                val altBody = JSONObject().apply {
                                    put("user_id", currentUserId)
                                    put("device_token", token)
                                    put("platform", "android")
                                    put("is_active", true)
                                }
                                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/device_tokens"
                                client.post(url, altBody.toString())
                                registered = true
                                Log.d("SupabaseDataService", "FCM token upserted to device_tokens table")
                            } catch (e5: Exception) {
                                Log.w("SupabaseDataService", "FCM token registration table fallbacks: ${e5.message}")
                            }
                        }
                    }
                }
            }

            sessionManager.markFcmTokenRegistered(token, currentUserId)
            Result.success(registered)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "FCM token registration failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 41. Deactivate/Unregister FCM Token on Logout
    suspend fun deactivateFcmToken(token: String?): Result<Boolean> {
        val fcmToken = token ?: sessionManager.fcmToken.value
        if (fcmToken.isNullOrBlank()) {
            sessionManager.clearFcmTokenRegistration()
            return Result.success(true)
        }

        return try {
            try {
                client.rpc("unregister_fcm_token", mapOf("p_token" to fcmToken))
                Log.d("SupabaseDataService", "FCM token deactivated via unregister_fcm_token")
            } catch (_: Exception) {
                try {
                    client.rpc("deactivate_fcm_token", mapOf("p_token" to fcmToken))
                    Log.d("SupabaseDataService", "FCM token deactivated via deactivate_fcm_token")
                } catch (_: Exception) {
                    try {
                        val patchUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/fcm_tokens?token=eq.$fcmToken"
                        val patchBody = JSONObject().apply { put("is_active", false) }
                        try { client.patch(patchUrl, patchBody.toString()) } catch (_: Exception) {}
                        try {
                            val altPatchUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/device_tokens?device_token=eq.$fcmToken"
                            client.patch(altPatchUrl, patchBody.toString())
                        } catch (_: Exception) {}
                    } catch (_: Exception) {
                        // Safe non-blocking fallback
                    }
                }
            }
            sessionManager.clearFcmTokenRegistration()
            Result.success(true)
        } catch (e: Exception) {
            Log.w("SupabaseDataService", "FCM token deactivation non-fatal error: ${e.message}")
            sessionManager.clearFcmTokenRegistration()
            Result.success(false)
        }
    }

    // 42. Server-side / Edge Notification & Push Trigger
    suspend fun createNotificationRecord(
        userId: String,
        title: String,
        body: String,
        notificationType: String,
        data: Map<String, String> = emptyMap()
    ): Result<String> {
        return try {
            val notifObj = JSONObject().apply {
                put("user_id", userId)
                put("title", title)
                put("body", body)
                put("notification_type", notificationType)
                put("is_read", false)
                val dataObj = JSONObject()
                data.forEach { (k, v) -> dataObj.put(k, v) }
                put("data", dataObj)
            }
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/notifications"
            val res = client.post(url, notifObj.toString())
            var createdId = UUID.randomUUID().toString()
            if (res.trim().startsWith("[")) {
                val arr = JSONArray(res)
                if (arr.length() > 0) {
                    createdId = arr.getJSONObject(0).optString("id", createdId)
                }
            } else if (res.trim().startsWith("{")) {
                createdId = JSONObject(res).optString("id", createdId)
            }
            Result.success(createdId)
        } catch (e: Exception) {
            Log.d("SupabaseDataService", "createNotificationRecord non-fatal error: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun triggerPushNotification(
        targetUserId: String,
        title: String,
        body: String,
        notificationType: String,
        data: Map<String, String> = emptyMap()
    ): Result<Boolean> {
        return try {
            val payload = JSONObject().apply {
                put("user_id", targetUserId)
                put("title", title)
                put("body", body)
                put("notification_type", notificationType)
                val dataObj = JSONObject()
                data.forEach { (k, v) -> dataObj.put(k, v) }
                put("data", dataObj)
            }

            // Securely invoke Supabase Edge Function 'send-fcm-notification'
            val edgeRes = client.callEdgeFunction("send-fcm-notification", payload.toString())
            Log.d("SupabaseDataService", "send-fcm-notification result: $edgeRes")
            Result.success(true)
        } catch (e: Exception) {
            Log.d("SupabaseDataService", "triggerPushNotification non-fatal: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun sendNotificationAndPush(
        targetUserId: String,
        title: String,
        body: String,
        notificationType: String,
        data: Map<String, String> = emptyMap()
    ) {
        val currentUserId = sessionManager.userId.value
        // Never send notification to self
        if (targetUserId.isBlank() || targetUserId == currentUserId) return

        try {
            val enrichedData = data.toMutableMap()
            // 1. Create notification history record
            val notifRecordRes = createNotificationRecord(
                userId = targetUserId,
                title = title,
                body = body,
                notificationType = notificationType,
                data = enrichedData
            )
            val notifId = notifRecordRes.getOrNull()
            if (!notifId.isNullOrBlank()) {
                enrichedData["notification_id"] = notifId
            }

            // 2. Trigger push delivery to active device_tokens
            triggerPushNotification(
                targetUserId = targetUserId,
                title = title,
                body = body,
                notificationType = notificationType,
                data = enrichedData
            )
        } catch (e: Exception) {
            Log.w("SupabaseDataService", "sendNotificationAndPush non-fatal error: ${e.message}")
        }
    }
}


