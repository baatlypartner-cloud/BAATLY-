package com.example.data.network

import com.example.data.local.SessionManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class SupabaseClient(private val sessionManager: SessionManager) {

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val refreshLock = Any()

    private fun getBaseHeaders(url: String = ""): Map<String, String> {
        val headers = mutableMapOf(
            "apikey" to SupabaseConfig.publishableKey,
            "Content-Type" to "application/json"
        )
        val isAuthEndpoint = url.contains("/auth/v1/token") || url.contains("/auth/v1/signup")
        val token = sessionManager.accessToken.value
        if (!token.isNullOrBlank() && !isAuthEndpoint) {
            headers["Authorization"] = "Bearer $token"
        }
        return headers
    }

    private fun performTokenRefresh(): Boolean {
        val refreshToken = sessionManager.refreshToken.value ?: return false
        synchronized(refreshLock) {
            val currentRefresh = sessionManager.refreshToken.value ?: return false
            return try {
                val refreshUrl = "${SupabaseConfig.supabaseUrl}/auth/v1/token?grant_type=refresh_token"
                val body = JSONObject().apply { put("refresh_token", currentRefresh) }
                val request = Request.Builder()
                    .url(refreshUrl)
                    .addHeader("apikey", SupabaseConfig.publishableKey)
                    .addHeader("Content-Type", "application/json")
                    .post(body.toString().toRequestBody(jsonMediaType))
                    .build()

                val response = okHttpClient.newCall(request).execute()
                val respBody = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val json = JSONObject(respBody)
                    val newAccessToken = json.optString("access_token")
                    val newRefreshToken = json.optString("refresh_token").takeIf { it.isNotBlank() } ?: currentRefresh
                    val userId = json.optJSONObject("user")?.optString("id")
                        ?: json.optString("id").takeIf { it.isNotBlank() }
                        ?: sessionManager.userId.value
                        ?: ""
                    if (newAccessToken.isNotBlank() && userId.isNotBlank()) {
                        sessionManager.saveSession(newAccessToken, userId, refreshToken = newRefreshToken)
                        true
                    } else {
                        false
                    }
                } else {
                    if (response.code == 400 || response.code == 401) {
                        val lower = respBody.lowercase()
                        if (lower.contains("invalid_grant") || lower.contains("not_found") || lower.contains("invalid refresh token")) {
                            sessionManager.clearSession()
                        }
                    }
                    false
                }
            } catch (_: Exception) {
                false
            }
        }
    }

    suspend fun get(url: String, params: Map<String, String> = emptyMap()): String = withContext(Dispatchers.IO) {
        val urlBuilder = StringBuilder(url)
        if (params.isNotEmpty()) {
            urlBuilder.append(if (url.contains("?")) "&" else "?")
            params.entries.forEachIndexed { index, entry ->
                if (index > 0) urlBuilder.append("&")
                urlBuilder.append(entry.key).append("=").append(entry.value)
            }
        }

        val requestBuilder = Request.Builder().url(urlBuilder.toString())
        getBaseHeaders(url).forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        var response = okHttpClient.newCall(requestBuilder.build()).execute()
        if (response.code == 401 && !url.contains("/auth/v1/")) {
            if (performTokenRefresh()) {
                val retryBuilder = Request.Builder().url(urlBuilder.toString())
                getBaseHeaders(url).forEach { (k, v) -> retryBuilder.addHeader(k, v) }
                response = okHttpClient.newCall(retryBuilder.build()).execute()
            }
        }
        handleResponse(response)
    }

    suspend fun post(url: String, jsonBody: String = "{}"): String = withContext(Dispatchers.IO) {
        val requestBody = jsonBody.toRequestBody(jsonMediaType)
        val requestBuilder = Request.Builder().url(url).post(requestBody)
        getBaseHeaders(url).forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        var response = okHttpClient.newCall(requestBuilder.build()).execute()
        if (response.code == 401 && !url.contains("/auth/v1/")) {
            if (performTokenRefresh()) {
                val retryBuilder = Request.Builder().url(url).post(jsonBody.toRequestBody(jsonMediaType))
                getBaseHeaders(url).forEach { (k, v) -> retryBuilder.addHeader(k, v) }
                response = okHttpClient.newCall(retryBuilder.build()).execute()
            }
        }
        handleResponse(response)
    }

    suspend fun patch(url: String, jsonBody: String = "{}"): String = withContext(Dispatchers.IO) {
        val requestBody = jsonBody.toRequestBody(jsonMediaType)
        val requestBuilder = Request.Builder().url(url).patch(requestBody)
        getBaseHeaders(url).forEach { (k, v) -> requestBuilder.addHeader(k, v) }
        requestBuilder.addHeader("Prefer", "return=representation")

        var response = okHttpClient.newCall(requestBuilder.build()).execute()
        if (response.code == 401 && !url.contains("/auth/v1/")) {
            if (performTokenRefresh()) {
                val retryBuilder = Request.Builder().url(url).patch(jsonBody.toRequestBody(jsonMediaType))
                getBaseHeaders(url).forEach { (k, v) -> retryBuilder.addHeader(k, v) }
                retryBuilder.addHeader("Prefer", "return=representation")
                response = okHttpClient.newCall(retryBuilder.build()).execute()
            }
        }
        handleResponse(response)
    }

    suspend fun rpc(rpcName: String, params: Map<String, Any?> = emptyMap()): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/rest/v1/rpc/$rpcName"
        val jsonObject = JSONObject()
        params.forEach { (k, v) ->
            if (v == null) {
                jsonObject.put(k, JSONObject.NULL)
            } else {
                jsonObject.put(k, v)
            }
        }
        val requestBody = jsonObject.toString().toRequestBody(jsonMediaType)

        val requestBuilder = Request.Builder().url(url).post(requestBody)
        getBaseHeaders(url).forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        var response = okHttpClient.newCall(requestBuilder.build()).execute()
        if (response.code == 401) {
            if (performTokenRefresh()) {
                val retryBody = jsonObject.toString().toRequestBody(jsonMediaType)
                val retryBuilder = Request.Builder().url(url).post(retryBody)
                getBaseHeaders(url).forEach { (k, v) -> retryBuilder.addHeader(k, v) }
                response = okHttpClient.newCall(retryBuilder.build()).execute()
            }
        }
        handleResponse(response)
    }

    suspend fun callEdgeFunction(functionName: String, jsonBody: String = "{}"): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/functions/v1/$functionName"
        val requestBody = jsonBody.toRequestBody(jsonMediaType)

        val requestBuilder = Request.Builder().url(url).post(requestBody)
        getBaseHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }

        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        handleResponse(response)
    }

    suspend fun uploadFile(bucket: String, path: String, file: File, mimeType: String): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/storage/v1/object/$bucket/$path"
        val requestBody = RequestBody.create(mimeType.toMediaType(), file)

        val requestBuilder = Request.Builder()
            .url(url)
            .post(requestBody)
        getBaseHeaders().forEach { (k, v) ->
            if (k != "Content-Type") {
                requestBuilder.addHeader(k, v)
            }
        }
        requestBuilder.addHeader("Content-Type", mimeType)

        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        if (response.isSuccessful) {
            "$bucket/$path"
        } else {
            handleResponse(response)
        }
    }

    suspend fun deleteStorageObject(bucket: String, path: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
            val url = "${SupabaseConfig.supabaseUrl}/storage/v1/object/$bucket/$cleanPath"
            val requestBuilder = Request.Builder().url(url).delete()
            getBaseHeaders().forEach { (k, v) -> requestBuilder.addHeader(k, v) }

            val response = okHttpClient.newCall(requestBuilder.build()).execute()
            response.isSuccessful
        } catch (e: Exception) {
            android.util.Log.e("SupabaseClient", "deleteStorageObject failed for $bucket/$path: ${e.message}", e)
            false
        }
    }

    suspend fun createSignedUrl(bucket: String, path: String, expiresInSeconds: Int = 3600): String = withContext(Dispatchers.IO) {
        val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
        val url = "${SupabaseConfig.supabaseUrl}/storage/v1/object/sign/$bucket/$cleanPath"
        val payload = JSONObject().apply { put("expiresIn", expiresInSeconds) }
        val responseStr = post(url, payload.toString())
        val json = JSONObject(responseStr)
        val signedUrlPath = json.optString("signedURL").ifBlank {
            json.optString("signedUrl").ifBlank {
                json.optString("url", "")
            }
        }
        if (signedUrlPath.isBlank()) {
            throw SupabaseException("Empty signedURL returned from Supabase storage sign for $bucket/$cleanPath", 500, responseStr)
        }
        val fullUrl = when {
            signedUrlPath.startsWith("http://") || signedUrlPath.startsWith("https://") -> signedUrlPath
            signedUrlPath.startsWith("/storage/v1/") -> "${SupabaseConfig.supabaseUrl}$signedUrlPath"
            signedUrlPath.startsWith("/") -> "${SupabaseConfig.supabaseUrl}/storage/v1$signedUrlPath"
            else -> "${SupabaseConfig.supabaseUrl}/storage/v1/$signedUrlPath"
        }
        fullUrl
    }

    private fun handleResponse(response: Response): String {
        val responseBody = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            val userFriendlyError = parseFriendlyError(response.code, responseBody)
            throw SupabaseException(userFriendlyError, response.code, responseBody)
        }
        return responseBody
    }

    private fun parseFriendlyError(code: Int, body: String): String {
        val lower = body.lowercase()
        return when {
            code == 401 || code == 400 && lower.contains("invalid login") || lower.contains("invalid_credentials") ->
                "Invalid User ID or Password. Please check your credentials."
            lower.contains("user_id already exists") || lower.contains("duplicate key") && lower.contains("user_id") ->
                "This User ID is already taken."
            lower.contains("invalid referral code") || lower.contains("referral code not found") ->
                "Invalid referral code."
            lower.contains("insufficient") || lower.contains("not enough coins") || lower.contains("balance") ->
                "You don't have enough coins."
            lower.contains("host is not available") || lower.contains("partner not online") ->
                "This host is not available right now."
            lower.contains("blocked") || lower.contains("cannot message") ->
                "You cannot message this host."
            (lower.contains("duplicate key") && lower.contains("mobile_number")) || lower.contains("mobile_number already exists") ->
                "This mobile number is already registered."
            lower.contains("contact_sharing_violation") || lower.contains("number_sharing_violation") ->
                "Number or contact-sharing content is not allowed."
            code == 404 -> "Requested item not found."
            code >= 500 -> "Server temporarily busy. Please try again."
            else -> {
                try {
                    val json = JSONObject(body)
                    json.optString("message", json.optString("error_description", "Operation failed. Please try again."))
                } catch (_: Exception) {
                    "Operation failed. Please try again."
                }
            }
        }
    }
}

class SupabaseException(
    override val message: String,
    val statusCode: Int,
    val rawBody: String
) : Exception(message)
