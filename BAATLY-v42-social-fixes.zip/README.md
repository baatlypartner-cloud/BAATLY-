# BAATLY User App — v42

Native Android application built with Kotlin and Jetpack Compose.

## Open and build

1. Open this project root in Android Studio.
2. Use JDK 17 for the Gradle build.
3. Create `.env` from `.env.example` and populate the project's existing Supabase and Agora runtime configuration using your own values.
4. For a signed Release APK, configure the signing variables/secrets in your CI workflow. Do not commit the upload keystore or passwords.
5. Run `./gradlew :app:assembleRelease`.

The project `versionCode` is set to **42**.

## v42 social-media fixes

See `BAATLY_V42_SOCIAL_FIXES.md` for profile/Highlights, Followers/Following, private accounts, Story viewers, comments, targeted chat routing, hashtag search and recommendation logic.

## Build verification note

The changes are supplied as Android source in this ZIP, not as a verified APK. The Gradle 9.3.1 distribution could not be downloaded in the editing environment because the Gradle host was unreachable. Run the Release APK workflow in a network-enabled build environment and test the flows listed in `BAATLY_V42_SOCIAL_FIXES.md` on a physical device before publishing.

Earlier v40/v41 update notes remain in the repository for reference.
