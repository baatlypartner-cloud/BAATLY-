# BAATLY v48.5 – ImageIcon Compile Error Fix

## User-reported Release build error

`app/src/main/java/com/example/ui/social/SocialScreen.kt:817` failed in `:app:compileReleaseKotlin` with an unresolved-reference / receiver-type-mismatch diagnostic for the Compose `Icons.Filled.Image` icon.

## Root cause

The file imported the extension property with an alias:

```kotlin
import androidx.compose.material.icons.filled.Image as ImageIcon
```

but passed `ImageIcon` as a standalone value to `StoryChoiceCard`. Compose icon properties must be accessed from their `Icons.Filled` receiver. The existing Super AI screen in this same project already demonstrates the correct form.

## Change made

Changed the Photo story card argument from:

```kotlin
StoryChoiceCard("Photo", "Gallery", ImageIcon, ...)
```

to:

```kotlin
StoryChoiceCard("Photo", "Gallery", Icons.Filled.ImageIcon, ...)
```

No feature, backend call, screen layout, or other behavior was changed for this fix.

## Checks performed

- Confirmed `androidx.compose.material.icons.extended` is declared in `app/build.gradle.kts`.
- Searched all app Kotlin sources for `ImageIcon`; both uses now follow the `Icons.Filled.ImageIcon` receiver form.
- Scanned 72 Kotlin files for balanced code delimiters / unterminated comments and strings: no structural issues found.
- Parsed 10 XML files: passed.
- Parsed 5 JSON files: passed.
- Parsed TOML configuration files: passed.
- Repacked archive and verified ZIP CRC/integrity.

## Build verification limitation

A full Android Release compile was **not verified** in this environment. The project requests Gradle 9.3.1, but that distribution is not installed locally; no Android SDK is configured. A local Kotlin compiler invocation did not complete within the available execution window. These source/configuration checks do not replace `:app:compileReleaseKotlin` or `assembleRelease`.

The reported `ImageIcon` receiver error is corrected in source. Further compiler diagnostics can only be ruled out by running the actual Gradle Release build in an Android SDK/Gradle environment.
