package com.example

import android.app.Activity
import android.app.Application
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager

/**
 * BaatlyApplication configuration.
 *
 * Ensures FLAG_SECURE and recents screenshot preview disabling are strictly enforced
 * across all activities and windows in the BAATLY User App.
 */
class BaatlyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        setupGlobalWindowPolicy()
        com.example.ui.payment.UroPayCheckoutLauncher.prewarm(this)
    }

    /**
     * Registers ActivityLifecycleCallbacks to ensure all Activities receive
     * FLAG_SECURE screenshot and screen recording protection upon creation, start, and resumption.
     */
    private fun setupGlobalWindowPolicy() {
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                applyWindowProtection(activity)
            }

            override fun onActivityStarted(activity: Activity) {
                applyWindowProtection(activity)
            }

            override fun onActivityResumed(activity: Activity) {
                applyWindowProtection(activity)
            }

            override fun onActivityPaused(activity: Activity) {}

            override fun onActivityStopped(activity: Activity) {}

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {}
        })
    }

    companion object {
        private const val TAG = "BaatlySecurity"

        /**
         * Applies Android FLAG_SECURE and disables recents screenshot preview on the given Activity.
         */
        fun applyWindowProtection(activity: Activity) {
            try {
                activity.window.setFlags(
                    WindowManager.LayoutParams.FLAG_SECURE,
                    WindowManager.LayoutParams.FLAG_SECURE
                )

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    activity.setRecentsScreenshotEnabled(false)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to apply window protection: ${e.message}")
            }
        }

        // Backward compatibility alias for any callers
        fun ensureWindowCaptureAllowed(activity: Activity) {
            applyWindowProtection(activity)
        }
    }
}
