package com.example.ui.astrologer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.data.ai.CloudflareAiClient
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONObject
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val AstroPlum = Color(0xFFF5EEFF)       // bright foreground on the cosmic dark theme
private val AstroCream = Color(0xFF151321)      // dark plum/navy canvas
private val AstroPink = Color(0xFFFF4D91)
private val AstroGold = Color(0xFFFFC86B)
private val AstroLilac = Color(0xFF9B82FF)
private val AstroCard = Color(0xFF211B31)
private val AstroMuted = Color(0xFFB9AEC9)
private val AstroBorder = Color(0xFF463452)

private data class ZodiacSign(val name: String, val glyph: String)

private data class OrbitingPlanet(
    val name: String,
    val rx: Float,
    val ry: Float,
    val radius: Float,
    val colour: Color,
    val shade: Color,
    val speed: Float,
    val phase: Float,
    val saturnRing: Boolean = false,
    val earthMark: Boolean = false
)

@Composable
fun AstrologerScreen(viewModel: BaatlyViewModel) {
    val signs = remember {
        listOf(
            ZodiacSign("Aries", "♈"), ZodiacSign("Taurus", "♉"), ZodiacSign("Gemini", "♊"),
            ZodiacSign("Cancer", "♋"), ZodiacSign("Leo", "♌"), ZodiacSign("Virgo", "♍"),
            ZodiacSign("Libra", "♎"), ZodiacSign("Scorpio", "♏"), ZodiacSign("Sagittarius", "♐"),
            ZodiacSign("Capricorn", "♑"), ZodiacSign("Aquarius", "♒"), ZodiacSign("Pisces", "♓")
        )
    }
    var selectedZodiac by remember { mutableStateOf("Aries") }
    var birthDetails by remember { mutableStateOf("") }
    var partnerDetails by remember { mutableStateOf("") }
    var userQuestion by remember { mutableStateOf("") }
    var reading by remember { mutableStateOf("") }
    var readingType by remember { mutableStateOf("daily") }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val client = remember { CloudflareAiClient(viewModel.sessionManager) }
    val selectedGlyph = signs.firstOrNull { it.name == selectedZodiac }?.glyph ?: "♈"

    fun generate(type: String) {
        if (isLoading) return
        readingType = type
        isLoading = true
        error = null
        reading = ""
        scope.launch {
            try {
                val prompt = when (type) {
                    "daily" -> "Today's reflective horoscope for $selectedZodiac on ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())}. Give practical themes for the day without deterministic predictions."
                    "birth_chart" -> "Give a traditional Vedic-style interpretive birth chart overview from the details provided. Be clear about missing date, exact time or place and do not claim exact planetary positions if not calculated."
                    "compatibility" -> "Give a respectful Vedic-style compatibility reflection for the two sets of birth details. Avoid deterministic relationship verdicts."
                    else -> userQuestion.trim()
                }
                val result = client.post("/v1/astrology/readings", JSONObject()
                    .put("type", type)
                    .put("sign", selectedZodiac)
                    .put("question", if (type == "question") userQuestion.trim() else prompt)
                    .put("birth_details", birthDetails.trim())
                    .put("partner_details", partnerDetails.trim()))
                reading = result.optString("reading").ifBlank { "No reading returned." }
            } catch (e: Exception) {
                error = e.message ?: "Astrology service is unavailable."
            } finally {
                isLoading = false
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(AstroCream).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(AstroPink, AstroLilac))), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = "Astrology", tint = Color.White, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Vedic astrology", color = AstroPlum, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("A reflective reading for your questions", color = AstroMuted, fontSize = 13.sp, lineHeight = 19.sp)
            }
        }

        AstrologyOrbitArtwork(modifier = Modifier.fillMaxWidth().height(226.dp), selectedGlyph = selectedGlyph)

        Surface(
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = AstroCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, AstroBorder), shadowElevation = 1.dp
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF3A263D)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.NightsStay, contentDescription = null, tint = AstroPink, modifier = Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("AI-powered interpretation", color = AstroPlum, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Cloudflare Workers AI generates the reading. It is reflective entertainment, not a scientific prediction or precise planetary calculation.", color = AstroMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }

        Text("Choose your zodiac", color = AstroPlum, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            signs.forEach { sign ->
                val active = selectedZodiac == sign.name
                Surface(
                    shape = RoundedCornerShape(17.dp), color = if (active) AstroPink else AstroCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (active) AstroPink else AstroBorder),
                    modifier = Modifier.width(80.dp).clickable { selectedZodiac = sign.name }
                ) {
                    Column(Modifier.padding(vertical = 10.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(sign.glyph, fontSize = 24.sp, color = if (active) Color.White else AstroPlum)
                        Text(sign.name, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (active) Color.White else AstroPlum, maxLines = 1)
                    }
                }
            }
        }

        Text("Birth details (optional)", color = AstroPlum, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = birthDetails, onValueChange = { birthDetails = it.take(1200) }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Date, time and place of birth") }, placeholder = { Text("e.g. 25 Aug 2006, 8:30 AM, Kaithal") },
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = AstroPlum, unfocusedTextColor = AstroPlum, focusedBorderColor = AstroPink, unfocusedBorderColor = AstroBorder, focusedLabelColor = AstroPink, unfocusedLabelColor = AstroMuted)
        )
        OutlinedTextField(
            value = partnerDetails, onValueChange = { partnerDetails = it.take(1200) }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Partner birth details (for compatibility)") }, placeholder = { Text("Optional") },
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = AstroPlum, unfocusedTextColor = AstroPlum, focusedBorderColor = AstroPink, unfocusedBorderColor = AstroBorder, focusedLabelColor = AstroPink, unfocusedLabelColor = AstroMuted)
        )
        OutlinedTextField(
            value = userQuestion, onValueChange = { userQuestion = it.take(1800) }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Ask an astrology question") }, placeholder = { Text("What would you like to reflect on?") },
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = AstroPlum, unfocusedTextColor = AstroPlum, focusedBorderColor = AstroPink, unfocusedBorderColor = AstroBorder, focusedLabelColor = AstroPink, unfocusedLabelColor = AstroMuted)
        )

        Text("Astrology services", color = AstroPlum, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        AstroServiceCard("Daily Vedic Horoscope", "A sign-based reading for today.", "GENERATE") { generate("daily") }
        AstroServiceCard("Birth Chart Reflection", "Interpretive guidance based on the birth details supplied.", "GENERATE") { generate("birth_chart") }
        AstroServiceCard("Compatibility", "A reflective view of two sets of birth details.", "GENERATE") { generate("compatibility") }
        Button(onClick = { generate("question") }, enabled = !isLoading && userQuestion.isNotBlank(), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = AstroPink)) {
            if (isLoading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            else Icon(Icons.Outlined.FavoriteBorder, contentDescription = null)
            Spacer(Modifier.width(8.dp)); Text(if (isLoading) "Preparing your reading…" else "Ask AI astrologer")
        }
        error?.let { Text(it, color = Color(0xFFFFA5B8), fontSize = 12.sp) }
        if (reading.isNotBlank()) {
            Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = AstroCard, border = androidx.compose.foundation.BorderStroke(1.dp, AstroBorder)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Your reading", color = AstroGold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(reading, color = AstroPlum, fontSize = 14.sp, lineHeight = 21.sp)
                    Text("For reflection and entertainment only; no scientific or deterministic prediction is implied.", color = AstroMuted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun AstrologyOrbitArtwork(modifier: Modifier, selectedGlyph: String) {
    val motion = rememberInfiniteTransition(label = "real-solar-system-motion")
    val rotation by motion.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(52000, easing = LinearEasing), RepeatMode.Restart),
        label = "planetary-revolution"
    )
    val pulse by motion.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Reverse),
        label = "solar-glow"
    )

    Box(
        modifier
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF080B1D), Color(0xFF11183B), Color(0xFF1C1850), Color(0xFF0B0D22))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.53f
            val base = min(size.width * 0.138f, size.height * 0.34f)
            val center = Offset(cx, cy)

            // Deep-space nebula, subtle enough to keep the solar system as the hero.
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0x553E55BB), Color(0x33251B75), Color.Transparent),
                    center,
                    size.width * 0.58f
                ),
                radius = size.width * 0.58f,
                center = center
            )
            for (i in 0 until 94) {
                val x = ((i * 73 + 29) % 991) / 991f * size.width
                val y = ((i * 137 + 47) % 983) / 983f * size.height
                val bright = i % 11 == 0
                drawCircle(
                    if (bright) Color(0xFFFFD9A0).copy(alpha = 0.88f) else Color(0xFFD8E3FF).copy(alpha = 0.38f),
                    radius = (if (bright) 1.8f else 0.8f).dp.toPx(),
                    center = Offset(x, y)
                )
            }

            // Orbital paths are elliptical; planet colours are intentionally differentiated by planet.
            val orbits = listOf(
                0.56f to 0.34f, 0.80f to 0.49f, 1.04f to 0.65f, 1.29f to 0.81f,
                1.57f to 0.99f, 1.86f to 1.18f, 2.16f to 1.37f, 2.47f to 1.56f
            )
            orbits.forEachIndexed { index, orbit ->
                drawOval(
                    color = when (index) {
                        0, 1 -> Color(0xFF7A8BAA).copy(alpha = 0.30f)
                        2 -> Color(0xFF4E8DCE).copy(alpha = 0.34f)
                        3 -> Color(0xFFCB755F).copy(alpha = 0.28f)
                        4 -> Color(0xFFD5A273).copy(alpha = 0.27f)
                        5 -> Color(0xFFD6C08B).copy(alpha = 0.29f)
                        else -> Color(0xFF7D83E9).copy(alpha = 0.24f)
                    },
                    topLeft = Offset(cx - base * orbit.first, cy - base * orbit.second),
                    size = Size(base * orbit.first * 2f, base * orbit.second * 2f),
                    style = Stroke(width = (if (index == 2) 1.15f else 0.75f).dp.toPx())
                )
            }

            // Sun: small, warm and bright rather than an oversized fantasy orb.
            val sunRadius = base * 0.27f * pulse
            drawCircle(Color(0xFFFF8A34).copy(alpha = 0.16f), sunRadius * 2.7f, center)
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0xFFFFFFD0), Color(0xFFFFD45F), Color(0xFFFF933A), Color(0xFFEC552F)),
                    center,
                    sunRadius * 1.55f
                ),
                sunRadius,
                center
            )
            drawCircle(Color.White.copy(alpha = 0.6f), sunRadius * 0.18f, Offset(cx - sunRadius * 0.3f, cy - sunRadius * 0.28f))

            val planets = listOf(
                OrbitingPlanet("Mercury", 0.56f, 0.34f, 0.025f, Color(0xFFB5B2AC), Color(0xFF656875), 2.55f, 14f),
                OrbitingPlanet("Venus",   0.80f, 0.49f, 0.036f, Color(0xFFE4C08B), Color(0xFF9C684C), 1.92f, 92f),
                OrbitingPlanet("Earth",   1.04f, 0.65f, 0.039f, Color(0xFF4F9DFF), Color(0xFF123A91), 1.48f, 190f, earthMark = true),
                OrbitingPlanet("Mars",    1.29f, 0.81f, 0.031f, Color(0xFFD66B4B), Color(0xFF803A32), 1.16f, 38f),
                OrbitingPlanet("Jupiter", 1.57f, 0.99f, 0.066f, Color(0xFFE2B48A), Color(0xFF8C5941), 0.78f, 236f),
                OrbitingPlanet("Saturn",  1.86f, 1.18f, 0.056f, Color(0xFFE8D49B), Color(0xFF9F8257), 0.59f, 132f, saturnRing = true),
                OrbitingPlanet("Uranus",  2.16f, 1.37f, 0.043f, Color(0xFF8DE2E3), Color(0xFF367C9D), 0.42f, 305f),
                OrbitingPlanet("Neptune", 2.47f, 1.56f, 0.043f, Color(0xFF5478F4), Color(0xFF172C8C), 0.32f, 260f)
            )
            val positions = planets.map { planet ->
                val angle = Math.toRadians((rotation * planet.speed + planet.phase).toDouble())
                val position = Offset(
                    cx + (base * planet.rx * cos(angle)).toFloat(),
                    cy + (base * planet.ry * sin(angle)).toFloat()
                )
                planet to position
            }

            // Saturn's rings sit behind its globe.
            positions.filter { it.first.saturnRing }.forEach { (planet, pos) ->
                val r = base * planet.radius
                rotate(degrees = -23f, pivot = pos) {
                    drawOval(
                        color = Color(0xFFE9D5A4).copy(alpha = 0.82f),
                        topLeft = Offset(pos.x - r * 2.2f, pos.y - r * 0.60f),
                        size = Size(r * 4.4f, r * 1.2f),
                        style = Stroke(width = maxOf(1.1f.dp.toPx(), r * 0.14f))
                    )
                    drawOval(
                        color = Color(0xFF8D7AA1).copy(alpha = 0.48f),
                        topLeft = Offset(pos.x - r * 1.55f, pos.y - r * 0.38f),
                        size = Size(r * 3.1f, r * 0.76f),
                        style = Stroke(width = maxOf(0.7f.dp.toPx(), r * 0.08f))
                    )
                }
            }
            positions.forEach { (planet, pos) ->
                val r = (base * planet.radius).coerceAtLeast(2.1f.dp.toPx())
                drawCircle(planet.colour.copy(alpha = 0.17f), r * 1.8f, pos)
                drawCircle(
                    Brush.radialGradient(listOf(planet.colour, planet.shade), Offset(pos.x - r * 0.35f, pos.y - r * 0.35f), r * 2.4f),
                    r,
                    pos
                )
                drawCircle(Color.White.copy(alpha = 0.25f), r * 0.23f, Offset(pos.x - r * 0.27f, pos.y - r * 0.28f))
                if (planet.earthMark) {
                    drawCircle(Color(0xFF5BD39B), r * 0.29f, Offset(pos.x + r * 0.23f, pos.y - r * 0.05f))
                    drawCircle(Color(0xFF2EAA83), r * 0.15f, Offset(pos.x - r * 0.1f, pos.y + r * 0.29f))
                }
                if (planet.name == "Jupiter") {
                    drawLine(Color(0xFF9D604C).copy(alpha = 0.8f), Offset(pos.x - r * 0.65f, pos.y - r * 0.16f), Offset(pos.x + r * 0.65f, pos.y - r * 0.16f), strokeWidth = maxOf(0.8f.dp.toPx(), r * 0.15f))
                    drawLine(Color(0xFFB47B58).copy(alpha = 0.9f), Offset(pos.x - r * 0.55f, pos.y + r * 0.23f), Offset(pos.x + r * 0.55f, pos.y + r * 0.23f), strokeWidth = maxOf(0.8f.dp.toPx(), r * 0.13f))
                }
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 13.dp),
            color = Color(0xDB080D27), shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.14f))
        ) {
            Text("SOLAR SYSTEM  ·  ZODIAC", color = Color(0xFFFFD493), fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp))
        }
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
            color = Color(0xED111631), shape = CircleShape,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7B81E7).copy(alpha = 0.6f))
        ) {
            Text("Selected sign  $selectedGlyph", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 15.dp, vertical = 7.dp))
        }
    }
}

@Composable
private fun AstroServiceCard(title: String, description: String, tag: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = AstroCard,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, AstroBorder)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF3A263D)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.WbSunny, contentDescription = null, tint = AstroPink, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = AstroPlum, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(description, color = AstroMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
            Text(tag, color = AstroGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}
