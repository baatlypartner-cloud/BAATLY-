## Latest patch — v44 media and chat fixes

See `BAATLY_V44_MEDIA_CHAT_FIXES.md` for details. This patch force-refreshes failed photo URLs from canonical storage keys, leaves normal-user message billing to the server (free user-to-user DMs), and restricts calls to approved hosts.

# BAATLY User App — v44

Native Android application built with Kotlin and Jetpack Compose.

## Open and build

1. Open this project root in Android Studio.
2. Use JDK 17 for the Gradle build.
3. Create `.env` from `.env.example` and populate the project's existing Supabase and Agora runtime configuration using your own values.
4. For a signed Release APK, configure the signing variables/secrets in your CI workflow. Do not commit the upload keystore or passwords.
5. Run `./gradlew :app:assembleRelease`.

The project `versionCode` is set to **44** and `versionName` is `1.0.44`.

## v42 social-media fixes

See `BAATLY_V42_SOCIAL_FIXES.md` for profile/Highlights, Followers/Following, private accounts, Story viewers, comments and targeted chat routing. See `BAATLY_V43_RECOMMENDATION_ENGINE.md` for the recommendation engine details. Its SQL migration is in `app/supabase/migrations/20261025_social_recommendation_engine.sql`; the corresponding migration and Edge Function update have already been applied to the connected BAATLY backend in this session.

## Build verification note

The changes are supplied as Android source in this ZIP, not as a verified APK. The Gradle 9.3.1 distribution could not be downloaded in the editing environment because the Gradle host was unreachable. Run the Release APK workflow in a network-enabled build environment and test the flows listed in `BAATLY_V42_SOCIAL_FIXES.md` on a physical device before publishing.

Earlier v40/v41 update notes remain in the repository for reference.


## v42 compile fix

The `SocialProfileScreen.kt` experimental Material3 API compiler diagnostics were addressed with `@OptIn(ExperimentalMaterial3Api::class)`. The source ZIP is not a compiled/verified APK; run the GitHub Actions Release build to validate in a network-enabled environment.

## Cloudflare AI and Super AI integration (v44 test bundle)

This bundle now includes the Cloudflare Worker source under `cloudflare/baatly-ai-gateway/`, the AI Gateway settings snapshot under `cloudflare/ai-gateway-settings.json`, and the migration/test reports. The live Worker is `https://baatly-ai-gateway.baatly-ai.workers.dev` (Worker code version 1.7.1).

- Super AI's main chat uses Cloudflare's tool-calling agent route for web search, page reading and explicit long-term memory saves. Worker v1.8.2 tries DuckDuckGo, Bing, Google web results and Google News RSS (English/Hindi), retries common Manoj/Bubli spelling variations for the Karora query, and reports a search-provider failure honestly instead of claiming no information exists.
- The app can archive chats/attachments in the user's private R2 prefix, maintain project workspaces, edit supported text/source files with revision backups and export updated ZIPs.
- Image understanding, image generation and astrology routes are implemented on Cloudflare Workers AI.
- AI Chat Host, AI call-turn LLM/STT, and realtime voice LLM are routed to Cloudflare; AI audio calls now use Supabase WebSocket + Sarvam streaming rather than Agora Conversational AI. The private Agora LLM token and Worker route were removed. Support Agent `partner-ai-chat` and `partner-ai-chat-v2` deliberately stay on Groq.
- Video generation requires prepaid Cloudflare AI Gateway credits. A restricted static HTML preview works for saved `index.html` files with supported local assets. Dynamic web preview/build, arbitrary source-code execution, Android emulator, Gradle build runner and APK packaging are not enabled yet. ZIP is the default Android source output; APK must be explicitly requested and only after a secure build runner is available.

Read `BAATLY_CLOUDFLARE_MIGRATION_REPORT.md` and `CLOUDFLARE_TESTING_CHECKLIST.md` before production rollout. The Android Gradle compile could not be completed in this environment because the Gradle wrapper could not resolve `services.gradle.org`; do not treat this ZIP as a verified build or installable APK.


## v44 photo editing fix (Worker v1.8.2)

When a photo is attached and the prompt requests an edit (for example, “remove the watch and send the new photo”), the Android Super AI chat now routes it to the authenticated `/v1/images/edits` endpoint backed by `@cf/black-forest-labs/flux-2-klein-4b`. The app downsizes reference input to below 512×512 as required by the model, then displays the returned image inside the chat with a Save image action. The original attachment and generated edit are kept in the signed-in user's private R2 prefix. Ordinary image questions still route to image understanding. This is a source ZIP; APK build must be verified in a network-enabled Gradle environment.
