package com.example.data.network

import android.util.Log
import android.net.Uri
import com.example.data.model.CallRecord
import com.example.data.model.ChatMessage
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

class SupabaseRealtimeManager(
    private val okHttpClient: OkHttpClient,
    private val sessionManager: com.example.data.local.SessionManager
) {
    private var webSocket: WebSocket? = null
    private var activeConversationId: String? = null
    private var activeCallId: String? = null
    private var onNewMessageCallback: ((ChatMessage) -> Unit)? = null
    private var onMessageUpdatedCallback: ((ChatMessage) -> Unit)? = null
    private var onCallUpdatedCallback: ((CallRecord) -> Unit)? = null
    private var onResyncCallback: (() -> Unit)? = null

    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null
    private var pollJob: Job? = null
    private val knownMessageRecords = mutableMapOf<String, String>()
    private var lastCallFingerprint: String? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var isConnected = false
    private var refCount = 1

    fun subscribeToConversation(
        conversationId: String,
        onNewMessage: (ChatMessage) -> Unit,
        onMessageUpdated: ((ChatMessage) -> Unit)? = null,
        onResync: () -> Unit
    ) {
        if (activeConversationId == conversationId && isConnected) {
            return
        }

        unsubscribe()
        activeConversationId = conversationId
        onNewMessageCallback = onNewMessage
        onMessageUpdatedCallback = onMessageUpdated
        onResyncCallback = onResync

        connectWebSocket()
    }

    fun subscribeToCall(
        callId: String,
        onCallUpdated: (CallRecord) -> Unit
    ) {
        if (activeCallId == callId && isConnected) {
            return
        }

        unsubscribe()
        activeCallId = callId
        onCallUpdatedCallback = onCallUpdated

        connectWebSocket()
    }

    private fun connectWebSocket() {
        if (activeConversationId == null && activeCallId == null) return

        // The deployed API Gateway is HTTP-only. Use authenticated REST polling while a
        // call/chat is open instead of trying to speak the Supabase Phoenix protocol.
        pollJob?.cancel()
        isConnected = true // active subscription; updates are delivered through bounded polling
        onResyncCallback?.let { callback -> scope.launch(Dispatchers.Main) { callback.invoke() } }
        pollJob = scope.launch(Dispatchers.IO) {
            var initialConversationSnapshot = true
            var initialCallSnapshot = true
            while (isActive && (activeConversationId != null || activeCallId != null)) {
                val conversationId = activeConversationId
                val callId = activeCallId
                try {
                    if (!sessionManager.accessToken.value.isNullOrBlank()) {
                        if (!conversationId.isNullOrBlank()) {
                            val path = "/v1/messages?conversation_id=eq.${Uri.encode(conversationId)}&order=created_at.asc&limit=100&select=*"
                            val records = fetchAwsRecords(path)
                            for (record in records) {
                                val id = record.optString("id")
                                if (id.isBlank()) continue
                                val fingerprint = record.toString()
                                val previous = knownMessageRecords[id]
                                if (previous == null) {
                                    if (!initialConversationSnapshot) dispatchRealtimeRecord("messages", "INSERT", record)
                                } else if (previous != fingerprint) {
                                    dispatchRealtimeRecord("messages", "UPDATE", record)
                                }
                                knownMessageRecords[id] = fingerprint
                            }
                            initialConversationSnapshot = false
                        }
                        if (!callId.isNullOrBlank()) {
                            val path = "/v1/calls?id=eq.${Uri.encode(callId)}&limit=1&select=*"
                            val record = fetchAwsRecords(path).firstOrNull()
                            if (record != null) {
                                val fingerprint = record.toString()
                                if (!initialCallSnapshot && fingerprint != lastCallFingerprint) {
                                    dispatchRealtimeRecord("calls", "UPDATE", record)
                                }
                                lastCallFingerprint = fingerprint
                            }
                            initialCallSnapshot = false
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w("RealtimeManager", "AWS REST update poll failed: ${e.message}")
                }
                delay(if (callId != null) 2500 else 4000)
            }
        }
    }

    private fun fetchAwsRecords(pathAndQuery: String): List<JSONObject> {
        val token = sessionManager.accessToken.value
        val requestBuilder = Request.Builder()
            .url("${SupabaseConfig.apiBaseUrl}$pathAndQuery")
            .get()
        if (!token.isNullOrBlank()) requestBuilder.header("Authorization", "Bearer $token")
        requestBuilder.header("Accept", "application/json")
        okHttpClient.newCall(requestBuilder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("AWS poll returned HTTP ${response.code}")
            if (body.isBlank()) return emptyList()
            return try {
                val array = JSONArray(body)
                (0 until array.length()).mapNotNull { index -> array.optJSONObject(index) }
            } catch (_: Exception) {
                val root = JSONObject(body)
                val array = root.optJSONArray("data") ?: root.optJSONArray("records") ?: return emptyList()
                (0 until array.length()).mapNotNull { index -> array.optJSONObject(index) }
            }
        }
    }

    private fun dispatchRealtimeRecord(table: String, type: String, record: JSONObject) {
        val event = JSONObject().apply {
            put("event", "postgres_changes")
            put("payload", JSONObject().apply {
                put("data", JSONObject().apply {
                    put("table", table)
                    put("type", type)
                    put("record", record)
                })
            })
        }
        handleWebSocketMessage(event.toString())
    }

    private fun joinConversationChannel(ws: WebSocket, conversationId: String) {
        val token = sessionManager.accessToken.value
        if (!token.isNullOrBlank()) {
            val authMsg = JSONObject().apply {
                put("topic", "realtime")
                put("event", "access_token")
                put("payload", JSONObject().apply {
                    put("access_token", token)
                })
                put("ref", (refCount++).toString())
            }
            ws.send(authMsg.toString())
        }

        val topic = "realtime:public:conversation:$conversationId"
        val ref = (refCount++).toString()

        val postgresChanges = org.json.JSONArray().apply {
            put(JSONObject().apply {
                put("event", "*")
                put("schema", "public")
                put("table", "messages")
                put("filter", "conversation_id=eq.$conversationId")
            })
            put(JSONObject().apply {
                put("event", "*")
                put("schema", "public")
                put("table", "conversations")
                put("filter", "id=eq.$conversationId")
            })
        }

        val payload = JSONObject().apply {
            put("config", JSONObject().apply {
                put("postgres_changes", postgresChanges)
            })
            if (!token.isNullOrBlank()) {
                put("access_token", token)
                put("user_token", token)
            }
        }

        val joinMsg = JSONObject().apply {
            put("topic", topic)
            put("event", "phx_join")
            put("payload", payload)
            put("ref", ref)
        }

        ws.send(joinMsg.toString())
        Log.d("RealtimeManager", "Subscribed to channel: $topic")
    }

    private fun joinCallChannel(ws: WebSocket, callId: String) {
        val token = sessionManager.accessToken.value
        if (!token.isNullOrBlank()) {
            val authMsg = JSONObject().apply {
                put("topic", "realtime")
                put("event", "access_token")
                put("payload", JSONObject().apply {
                    put("access_token", token)
                })
                put("ref", (refCount++).toString())
            }
            ws.send(authMsg.toString())
        }

        val topic = "realtime:public:calls:$callId"
        val ref = (refCount++).toString()

        val postgresChanges = org.json.JSONArray().apply {
            put(JSONObject().apply {
                put("event", "*")
                put("schema", "public")
                put("table", "calls")
                put("filter", "id=eq.$callId")
            })
        }

        val payload = JSONObject().apply {
            put("config", JSONObject().apply {
                put("postgres_changes", postgresChanges)
            })
            if (!token.isNullOrBlank()) {
                put("access_token", token)
                put("user_token", token)
            }
        }

        val joinMsg = JSONObject().apply {
            put("topic", topic)
            put("event", "phx_join")
            put("payload", payload)
            put("ref", ref)
        }

        ws.send(joinMsg.toString())
        Log.d("RealtimeManager", "Subscribed to calls channel: $topic")
    }

    private fun startHeartbeat(ws: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && isConnected) {
                delay(25000)
                try {
                    val hb = JSONObject().apply {
                        put("topic", "phoenix")
                        put("event", "heartbeat")
                        put("payload", JSONObject())
                        put("ref", (refCount++).toString())
                    }
                    ws.send(hb.toString())
                } catch (_: Exception) {
                    break
                }
            }
        }
    }

    private fun handleWebSocketMessage(text: String) {
        try {
            val json = JSONObject(text)
            val event = json.optString("event")
            val payload = json.optJSONObject("payload") ?: return

            if (event == "postgres_changes") {
                val data = payload.optJSONObject("data") ?: return
                val table = data.optString("table")
                val type = data.optString("type")
                val record = data.optJSONObject("record")

                if (table == "calls" && record != null) {
                    val connectedAtStr = record.optString("connected_at").takeIf { it.isNotBlank() && it != "null" }
                    val statusStr = record.optString("status", "requested")
                    val isConnected = !connectedAtStr.isNullOrBlank()
                    val isCompleted = statusStr.equals("completed", ignoreCase = true)
                    val durationSec = if (isConnected && isCompleted) record.optInt("duration_seconds", 0) else 0
                    val userCharge = if (isConnected && isCompleted) record.optDouble("user_charge_rupees", record.optDouble("total_amount_rupees", 0.0)) else 0.0

                    val callRecord = CallRecord(
                        id = record.optString("id"),
                        userId = record.optString("user_id"),
                        partnerId = record.optString("partner_id"),
                        channelName = record.optString("agora_channel_id").ifBlank { record.optString("channel_name") },
                        callType = record.optString("call_type", "audio"),
                        status = statusStr,
                        startedAt = record.optString("started_at").takeIf { it.isNotBlank() && it != "null" },
                        connectedAt = connectedAtStr,
                        endedAt = record.optString("ended_at").takeIf { it.isNotBlank() && it != "null" },
                        durationSeconds = durationSec,
                        totalAmountRupees = userCharge,
                        userChargeRupees = userCharge,
                        createdAt = record.optString("created_at", "")
                    )
                    scope.launch(Dispatchers.Main) {
                        onCallUpdatedCallback?.invoke(callRecord)
                    }
                } else if (table == "messages" && type == "INSERT" && record != null) {
                    val mSeenAt = com.example.data.model.parseNullableTimestamp(record, "seen_at")
                    val mDeliveredAt = com.example.data.model.parseNullableTimestamp(record, "delivered_at") ?: mSeenAt
                    val message = ChatMessage(
                        id = record.getString("id"),
                        conversationId = record.getString("conversation_id"),
                        senderId = record.getString("sender_id"),
                        receiverId = record.optString("receiver_id", ""),
                        messageType = record.optString("message_type", "text"),
                        messageText = record.optString("message_text").takeIf { it.isNotBlank() && it != "null" },
                        mediaUrl = record.optString("media_url").takeIf { it.isNotBlank() && it != "null" },
                        mediaDurationSeconds = record.optInt("media_duration_seconds", 0),
                        giftId = record.optString("gift_id").takeIf { it.isNotBlank() && it != "null" },
                        createdAt = record.optString("created_at", ""),
                        isRead = record.optBoolean("is_read", false),
                        deliveredAt = mDeliveredAt,
                        seenAt = mSeenAt,
                        isDelivered = mDeliveredAt != null,
                        isSeen = mSeenAt != null
                    )
                    scope.launch(Dispatchers.Main) {
                        onNewMessageCallback?.invoke(message)
                    }
                } else if (table == "messages" && type == "UPDATE" && record != null) {
                    val mSeenAt = com.example.data.model.parseNullableTimestamp(record, "seen_at")
                    val mDeliveredAt = com.example.data.model.parseNullableTimestamp(record, "delivered_at") ?: mSeenAt
                    val message = ChatMessage(
                        id = record.optString("id", UUID.randomUUID().toString()),
                        conversationId = record.optString("conversation_id", ""),
                        senderId = record.optString("sender_id", ""),
                        receiverId = record.optString("receiver_id", ""),
                        messageType = record.optString("message_type", "text"),
                        messageText = record.optString("message_text").takeIf { it.isNotBlank() && it != "null" },
                        mediaUrl = record.optString("media_url").takeIf { it.isNotBlank() && it != "null" },
                        mediaDurationSeconds = record.optInt("media_duration_seconds", 0),
                        giftId = record.optString("gift_id").takeIf { it.isNotBlank() && it != "null" },
                        createdAt = record.optString("created_at", ""),
                        isRead = record.optBoolean("is_read", false),
                        deliveredAt = mDeliveredAt,
                        seenAt = mSeenAt,
                        isDelivered = mDeliveredAt != null,
                        isSeen = mSeenAt != null
                    )
                    scope.launch(Dispatchers.Main) {
                        if (onMessageUpdatedCallback != null) {
                            onMessageUpdatedCallback?.invoke(message)
                        } else {
                            onResyncCallback?.invoke()
                        }
                    }
                } else {
                    scope.launch(Dispatchers.Main) {
                        onResyncCallback?.invoke()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("RealtimeManager", "Error parsing realtime message: ${e.message}")
        }
    }

    private fun scheduleReconnect() {
        if (activeConversationId == null && activeCallId == null) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(3000)
            if ((activeConversationId != null || activeCallId != null) && !isConnected) {
                Log.d("RealtimeManager", "Attempting Realtime reconnection...")
                connectWebSocket()
            }
        }
    }

    fun unsubscribe() {
        heartbeatJob?.cancel()
        reconnectJob?.cancel()
        pollJob?.cancel()
        pollJob = null
        knownMessageRecords.clear()
        lastCallFingerprint = null
        try {
            webSocket?.close(1000, "Leaving screen")
        } catch (_: Exception) {}
        webSocket = null
        isConnected = false
        activeConversationId = null
        activeCallId = null
        onNewMessageCallback = null
        onMessageUpdatedCallback = null
        onCallUpdatedCallback = null
        onResyncCallback = null
    }

    fun destroy() {
        unsubscribe()
        scope.cancel()
    }
}
