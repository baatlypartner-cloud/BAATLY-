package com.example.data.network

import com.example.BuildConfig

object SupabaseConfig {
    const val DEFAULT_AWS_API_BASE_URL = "https://ivt3f2l78f.execute-api.ap-south-1.amazonaws.com"
    const val DEFAULT_AGORA_APP_ID = "82771d17f30f40b09cb1790e9afc1e3f"

    val apiBaseUrl: String
        get() = try {
            val field = BuildConfig::class.java.getField("AWS_API_BASE_URL").get(null) as? String
            field?.trim()?.trimEnd('/')?.takeIf { it.startsWith("https://") } ?: DEFAULT_AWS_API_BASE_URL
        } catch (_: Exception) {
            DEFAULT_AWS_API_BASE_URL
        }

    // Kept as a compatibility accessor for existing call sites. AWS uses bearer tokens,
    // not a Supabase publishable/anon key; this deliberately returns an empty string.
    val supabaseUrl: String get() = apiBaseUrl
    val publishableKey: String get() = ""

    val agoraAppId: String
        get() = try {
            val key = BuildConfig::class.java.getField("AGORA_APP_ID").get(null) as? String
            key?.takeIf { it.isNotBlank() } ?: DEFAULT_AGORA_APP_ID
        } catch (_: Exception) {
            DEFAULT_AGORA_APP_ID
        }

    const val BUCKET_GIFT_MEDIA = "gift-media"
    const val BUCKET_PROFILE_MEDIA = "profile-media"
    const val BUCKET_CHAT_MEDIA = "chat-media"
    const val BUCKET_SOCIAL_MEDIA = "social-media"
    const val BUCKET_STORIES_MEDIA = "stories-media"

    fun getInternalAuthEmail(userId: String): String {
        val normalized = userId.trim().lowercase()
        return "$normalized@auth.baatly.app"
    }
}
