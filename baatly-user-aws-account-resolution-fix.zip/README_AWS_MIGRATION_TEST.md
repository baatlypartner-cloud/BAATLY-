# BAATLY User App — AWS migration test build

## API configuration
- AWS API Gateway base URL: `https://ivt3f2l78f.execute-api.ap-south-1.amazonaws.com`
- Region: `ap-south-1` (Mumbai)
- Agora App ID remains configured for audio/video calling.
- No Supabase publishable/anon key is sent by the app. `Supabase*` Kotlin names remain only as compatibility wrappers while the endpoints are mapped to AWS.

## First-pass endpoint mappings
- OTP send/verify and password sign-in/registration/refresh: `/v1/auth/...`
- RPC calls: `/v1/rpc/<name>`
- Table calls: `/v1/<resource>`
- Agora token: `/v1/agora/token`
- UroPay order/verification: `/v1/payments/uropay/...`
- Media: `/v1/media/...`
- Social endpoints are not migrated and are directed to the disabled route.
- Realtime chat/call listeners use authenticated REST polling only while the corresponding screen is active (approximately 4s for chat, 2.5s for calls). The current AWS inventory does not include a WebSocket API.

## Important test caveats
This is an initial client-side migration adapter, not a claim that every AWS API contract has been production-verified. Test signup/login/OTP first, then profile save, host list/presence, messaging, calls/Agora, media, UroPay recharge and notifications. Report the exact screen/action and HTTP/log error for any failure.

The deployed health response currently reports `coin_logic=false` and `social_media=supabase_only`. Do not assume coin/social features are available on AWS; these must remain disabled or be implemented in a later backend pass. Real UroPay payments should only be tested with the intended test mode and a small controlled amount.

## Build verification
The ZIP includes the Gradle wrapper. A build in the migration workspace could not be completed because the required Gradle distribution download was blocked by unavailable network/DNS; please build `assembleDebug` in an Android Studio/Gradle environment with network access before treating the APK as verified.
