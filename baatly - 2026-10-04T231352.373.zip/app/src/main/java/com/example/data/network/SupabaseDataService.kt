package com.example.data.network

import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.model.AgoraTokenResponse
import com.example.data.model.AppNotification
import com.example.data.model.CallBalanceEnforcementResult
import com.example.data.model.CallRatingEligibility
import com.example.data.model.CallRecord
import com.example.data.model.ChatMessage
import com.example.data.model.ConversationSummary
import com.example.data.model.EffectiveUserPricing
import com.example.data.model.GiftItem
import com.example.data.model.PartnerProfile
import com.example.data.model.ParticipantProfileResult
import com.example.data.model.PublicUserRating
import com.example.data.model.TransactionItem
import com.example.data.model.UroPayCreateOrderResult
import com.example.data.model.UroPayVerifyPaymentResult
import com.example.data.model.WalletInfo
import com.example.data.model.WalletRechargePackage
import com.example.data.model.WalletSummary
import com.example.data.model.WalletTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class SupabaseDataService(
    val client: SupabaseClient,
    private val sessionManager: SessionManager
) {

    // Cache for signed media URLs to avoid redundant signing calls
    private val mediaUrlCache = java.util.concurrent.ConcurrentHashMap<String, Pair<String, Long>>()
    private val cacheTtlMs = 45 * 60 * 1000L // 45 minutes

    // ==========================================
    // 1. PARTNER DISCOVERY & PROFILES
    // ==========================================

    suspend fun getAvailablePartners(): Result<List<PartnerProfile>> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("get_available_partners")
            val array = JSONArray(response)
            val partners = mutableListOf<PartnerProfile>()
            for (i in 0 until array.length()) {
                val json = array.getJSONObject(i)
                partners.add(parsePartnerProfile(json))
            }
            Result.success(partners)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "getAvailablePartners error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun getHostProfile(hostId: String): Result<PartnerProfile> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("get_host_profile", mapOf("p_partner_id" to hostId))
            val trimmed = response.trim()
            if (trimmed.startsWith("[")) {
                val array = JSONArray(trimmed)
                if (array.length() > 0) {
                    Result.success(parsePartnerProfile(array.getJSONObject(0)))
                } else {
                    Result.failure(Exception("Host not found"))
                }
            } else if (trimmed.startsWith("{")) {
                Result.success(parsePartnerProfile(JSONObject(trimmed)))
            } else {
                Result.failure(Exception("Host not found"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "getHostProfile error: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun parsePartnerProfile(json: JSONObject): PartnerProfile {
        val uid = json.optString("user_id").ifBlank { json.optString("id") }
        val name = json.optString("partner_display_name")
            .ifBlank { json.optString("display_name").ifBlank { "Partner" } }
        val bio = json.optString("bio").takeIf { it.isNotBlank() }
        val hobbies = json.optString("hobbies").takeIf { it.isNotBlank() }
        val avatar = json.optString("avatar_url").takeIf { it.isNotBlank() }
        val age = json.optInt("age", 0)

        val isOnline = json.optBoolean("is_online", false)
        val isAvailable = json.optBoolean("is_available", true)
        val voiceVerified = json.optBoolean("voice_verified", false)
        val audioEnabled = json.optBoolean("audio_enabled", true)
        val videoCallAccess = json.optBoolean("video_call_access", false)
        val videoEnabled = json.optBoolean("video_enabled", false)
        val chatEnabled = json.optBoolean("chat_enabled", true)

        val rating = json.optDouble("rating", 5.0)
        val reviewsCount = json.optInt("reviews_count", 0)
        val totalCalls = json.optInt("total_calls", 0)
        val lastActiveAt = json.optString("last_active_at").takeIf { it.isNotBlank() }

        return PartnerProfile(
            id = uid,
            userId = uid,
            partnerDisplayName = name,
            businessUserId = json.optString("business_user_id").takeIf { it.isNotBlank() },
            age = age,
            bio = bio,
            hobbies = hobbies,
            avatarUrl = avatar,
            isAvailable = isAvailable,
            isOnline = isOnline,
            voiceVerified = voiceVerified,
            audioEnabled = audioEnabled,
            videoCallAccess = videoCallAccess,
            videoEnabled = videoEnabled,
            chatEnabled = chatEnabled,
            rating = rating,
            reviewsCount = reviewsCount,
            totalCalls = totalCalls,
            lastActiveAt = lastActiveAt
        )
    }

    // ==========================================
    // 2. CALLS (AUDIO & VIDEO)
    // ==========================================

    private fun extractCallIdFromRpcResponse(response: String): String {
        val trimmed = response.trim().removeSurrounding("\"")
        if (trimmed.startsWith("{")) {
            val json = JSONObject(trimmed)
            return json.optString("id").ifBlank { json.optString("call_id") }
        } else if (trimmed.startsWith("[")) {
            val arr = JSONArray(trimmed)
            if (arr.length() > 0) {
                val obj = arr.getJSONObject(0)
                return obj.optString("id").ifBlank { obj.optString("call_id") }
            }
        }
        return trimmed
    }

    suspend fun requestCall(partnerId: String): Result<CallRecord> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("request_call", mapOf("p_partner_id" to partnerId))
            val callId = extractCallIdFromRpcResponse(response)
            if (callId.isNotBlank()) {
                getCallRecord(callId)
            } else {
                Result.failure(Exception("Invalid call ID returned from server"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "requestCall error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun requestVideoCall(partnerId: String): Result<CallRecord> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("request_video_call", mapOf("p_partner_id" to partnerId))
            val callId = extractCallIdFromRpcResponse(response)
            if (callId.isNotBlank()) {
                getCallRecord(callId)
            } else {
                Result.failure(Exception("Invalid call ID returned from server"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "requestVideoCall error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun getCallRecord(callId: String): Result<CallRecord> = withContext(Dispatchers.IO) {
        try {
            val selectFields = "id,user_id,partner_id,status,call_type,requested_at,accepted_at,connected_at,ended_at,duration_seconds,agora_channel_id,user_charge_rupees,partner_earning_rupees,partner_earning_rate_rupees_per_minute,pricing_tier,pricing_version,reserved_call_rupees,max_duration_seconds,billing_status,created_at"
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/calls?id=eq.$callId&select=$selectFields"
            val response = client.get(url)
            val arr = JSONArray(response)
            if (arr.length() > 0) {
                val json = arr.getJSONObject(0)
                val connectedAtStr = json.optString("connected_at").takeIf { it.isNotBlank() && it != "null" }
                val isConnected = !connectedAtStr.isNullOrBlank()
                val statusStr = json.optString("status", "requested")
                val isCompleted = statusStr.equals("completed", ignoreCase = true)

                val durationSec = if (isConnected && isCompleted) json.optInt("duration_seconds", 0) else 0
                val userCharge = if (isConnected && isCompleted) json.optDouble("user_charge_rupees", 0.0) else 0.0
                val partnerEarning = if (isConnected && isCompleted) json.optDouble("partner_earning_rupees", 0.0) else 0.0
                val reservedRupees = if (isConnected && isCompleted) json.optDouble("reserved_call_rupees", 0.0) else 0.0
                val billingStat = if (isConnected && isCompleted) json.optString("billing_status").takeIf { it.isNotBlank() } else "not_billed"

                val record = CallRecord(
                    id = json.optString("id"),
                    userId = json.optString("user_id"),
                    partnerId = json.optString("partner_id"),
                    channelName = json.optString("agora_channel_id").ifBlank { json.optString("channel_name") },
                    callType = json.optString("call_type", "audio"),
                    status = statusStr,
                    startedAt = json.optString("requested_at").ifBlank { json.optString("started_at") }.takeIf { it.isNotBlank() && it != "null" },
                    connectedAt = connectedAtStr,
                    endedAt = json.optString("ended_at").takeIf { it.isNotBlank() && it != "null" },
                    durationSeconds = durationSec,
                    totalAmountRupees = userCharge,
                    createdAt = json.optString("created_at"),
                    reservedCallRupees = reservedRupees,
                    maxDurationSeconds = json.optInt("max_duration_seconds", 0),
                    userChargeRupees = userCharge,
                    partnerEarningRupees = partnerEarning,
                    partnerEarningRateRupeesPerMinute = json.optDouble("partner_earning_rate_rupees_per_minute", 0.0),
                    pricingTier = json.optString("pricing_tier").takeIf { it.isNotBlank() },
                    pricingVersion = json.optString("pricing_version").takeIf { it.isNotBlank() },
                    billingStatus = billingStat
                )
                Result.success(record)
            } else {
                Result.failure(Exception("Call not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateCallState(callId: String, newStatus: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc(
                "update_call_state",
                mapOf("p_call_id" to callId, "p_new_status" to newStatus)
            )
            val trimmed = response.trim().removeSurrounding("\"")
            val isSuccess = if (trimmed.startsWith("{")) {
                val json = JSONObject(trimmed)
                if (json.has("error")) {
                    false
                } else if (json.has("success")) {
                    json.optBoolean("success", true)
                } else {
                    true
                }
            } else {
                val lower = trimmed.lowercase()
                when {
                    lower == "true" || lower == "1" || lower == "t" -> true
                    lower == "false" || lower == "0" || lower == "f" -> false
                    lower.contains("error") -> false
                    else -> lower.isNotBlank() && lower != "null"
                }
            }
            if (isSuccess) {
                Result.success(true)
            } else {
                Result.failure(Exception("Backend rejected call state update to $newStatus (response: $response)"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "updateCallState error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun settleCall(callId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            // Defensive rule: Only connected calls with completed status can be settled
            val callCheck = getCallRecord(callId).getOrNull()
            if (callCheck != null) {
                if (!callCheck.isConnected || !callCheck.status.equals("completed", ignoreCase = true)) {
                    Log.w("SupabaseDataService", "settleCall skipped: Call $callId is not connected or not completed (status=${callCheck.status}, connectedAt=${callCheck.connectedAt})")
                    return@withContext Result.success(false)
                }
            }
            val response = client.rpc("settle_call", mapOf("p_call_id" to callId))
            val trimmed = response.trim().removeSurrounding("\"")
            val isSuccess = if (trimmed.startsWith("{")) {
                val json = JSONObject(trimmed)
                !json.has("error")
            } else {
                val lower = trimmed.lowercase()
                when {
                    lower == "true" || lower == "1" || lower == "t" -> true
                    lower == "false" || lower == "0" || lower == "f" -> false
                    lower.contains("error") -> false
                    else -> lower.isNotBlank() && lower != "null"
                }
            }
            if (isSuccess) {
                Result.success(true)
            } else {
                Result.failure(Exception("Call settlement failed on backend (response: $response)"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "settleCall error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun enforceCallBalanceLimit(callId: String): Result<CallBalanceEnforcementResult> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("enforce_call_balance_limit", mapOf("p_call_id" to callId))
            val trimmed = response.trim()
            val json = if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else if (trimmed.startsWith("{")) {
                JSONObject(trimmed)
            } else {
                JSONObject()
            }

            val status = json.optString("status", "ok")
            val isAllowed = json.optBoolean("is_allowed", json.optBoolean("allowed", true))
            val remainingSec = json.optInt("remaining_seconds", json.optInt("remaining_time_seconds", 0))
            val message = json.optString("message", "")
            val balance = json.optDouble("balance_rupees", json.optDouble("balance", 0.0))

            Result.success(
                CallBalanceEnforcementResult(
                    status = status,
                    remainingSeconds = remainingSec,
                    isAllowed = isAllowed,
                    message = message,
                    balanceRupees = balance
                )
            )
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "enforceCallBalanceLimit error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun getAgoraToken(channelName: String): Result<AgoraTokenResponse> = withContext(Dispatchers.IO) {
        try {
            val endpoint = "${SupabaseConfig.supabaseUrl}/functions/v1/agora-token"
            val body = JSONObject().apply {
                put("channel_name", channelName)
            }
            val response = client.post(endpoint, body.toString())
            val json = JSONObject(response)

            val token = json.optString("token")
            val ch = json.optString("channel_name", channelName)
            val rawUid = json.optLong("uid", 0L)
            // Ensure 32-bit unsigned bit alignment between token Edge Function and Android Agora SDK
            val uid = (rawUid and 0xFFFFFFFFL).toInt()
            val role = json.optString("role")
            val expireAt = if (json.has("expire_at")) json.optLong("expire_at") else null

            if (token.isNotBlank()) {
                Result.success(AgoraTokenResponse(token, ch, uid, role, expireAt))
            } else {
                Result.failure(Exception("Empty Agora token returned"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "getAgoraToken error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 3. CHAT & MESSAGING
    // ==========================================

    suspend fun startChatWithHost(partnerId: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("start_chat_with_host", mapOf("p_partner_id" to partnerId))
            val trimmed = response.trim().removeSurrounding("\"")
            if (trimmed.isNotBlank() && !trimmed.startsWith("error", ignoreCase = true)) {
                Result.success(trimmed)
            } else {
                Result.failure(Exception("Could not create chat conversation"))
            }
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "startChatWithHost error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun sendMessage(
        conversationId: String,
        receiverId: String,
        messageType: String = "text",
        messageText: String? = null,
        mediaUrl: String? = null,
        mediaDurationSeconds: Int? = null
    ): Result<ChatMessage> = withContext(Dispatchers.IO) {
        try {
            val params = mutableMapOf<String, Any?>(
                "p_conversation_id" to conversationId,
                "p_receiver_id" to receiverId,
                "p_message_type" to messageType
            )
            if (!messageText.isNullOrBlank()) params["p_message_text"] = messageText
            if (!mediaUrl.isNullOrBlank()) params["p_media_url"] = mediaUrl
            if (mediaDurationSeconds != null && mediaDurationSeconds > 0) {
                params["p_media_duration_seconds"] = mediaDurationSeconds
            }

            val response = client.rpc("send_message", params)
            val trimmed = response.trim()
            val json = if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else if (trimmed.startsWith("{")) {
                JSONObject(trimmed)
            } else {
                JSONObject()
            }

            val currentUserId = sessionManager.userId.value ?: ""
            val parsedSeenAt = com.example.data.model.parseNullableTimestamp(json, "seen_at")
            val parsedDeliveredAt = com.example.data.model.parseNullableTimestamp(json, "delivered_at") ?: parsedSeenAt
            val msg = ChatMessage(
                id = json.optString("id").ifBlank { UUID.randomUUID().toString() },
                conversationId = json.optString("conversation_id", conversationId),
                senderId = json.optString("sender_id", currentUserId),
                receiverId = json.optString("receiver_id", receiverId),
                messageType = json.optString("message_type", messageType),
                messageText = json.optString("message_text").takeIf { it.isNotBlank() } ?: messageText,
                mediaUrl = json.optString("media_url").takeIf { it.isNotBlank() } ?: mediaUrl,
                mediaDurationSeconds = if (json.has("media_duration_seconds")) json.optInt("media_duration_seconds") else mediaDurationSeconds,
                isRead = json.optBoolean("is_read", false),
                deliveredAt = parsedDeliveredAt,
                seenAt = parsedSeenAt,
                isDelivered = parsedDeliveredAt != null,
                isSeen = parsedSeenAt != null,
                createdAt = json.optString("created_at")
            )
            Result.success(msg)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "sendMessage error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun fetchMessages(conversationId: String): Result<List<ChatMessage>> = withContext(Dispatchers.IO) {
        try {
            // First try get_conversation_messages RPC
            val response = try {
                client.rpc("get_conversation_messages", mapOf("p_conversation_id" to conversationId))
            } catch (_: Exception) {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$conversationId&order=created_at.asc&select=*"
                client.get(url)
            }

            val arr = JSONArray(response)
            val messages = mutableListOf<ChatMessage>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val mSeenAt = com.example.data.model.parseNullableTimestamp(json, "seen_at")
                val mDeliveredAt = com.example.data.model.parseNullableTimestamp(json, "delivered_at") ?: mSeenAt
                messages.add(
                    ChatMessage(
                        id = json.optString("id"),
                        conversationId = json.optString("conversation_id"),
                        senderId = json.optString("sender_id"),
                        receiverId = json.optString("receiver_id"),
                        messageType = json.optString("message_type", "text"),
                        messageText = json.optString("message_text").takeIf { it.isNotBlank() },
                        mediaUrl = json.optString("media_url").takeIf { it.isNotBlank() },
                        mediaDurationSeconds = if (json.has("media_duration_seconds") && !json.isNull("media_duration_seconds")) json.getInt("media_duration_seconds") else null,
                        isRead = json.optBoolean("is_read", false),
                        deliveredAt = mDeliveredAt,
                        seenAt = mSeenAt,
                        isDelivered = mDeliveredAt != null,
                        isSeen = mSeenAt != null,
                        createdAt = json.optString("created_at")
                    )
                )
            }
            Result.success(messages)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "fetchMessages error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun markConversationRead(conversationId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            client.rpc("mark_conversation_read", mapOf("p_conversation_id" to conversationId))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markMessagesDelivered(conversationId: String, messageIds: List<String>): Result<Boolean> = withContext(Dispatchers.IO) {
        if (messageIds.isEmpty()) return@withContext Result.success(true)
        try {
            client.rpc(
                "mark_messages_delivered",
                mapOf("p_conversation_id" to conversationId, "p_message_ids" to JSONArray(messageIds))
            )
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markMessagesSeen(conversationId: String, messageIds: List<String>): Result<Boolean> = withContext(Dispatchers.IO) {
        if (messageIds.isEmpty()) return@withContext Result.success(true)
        try {
            client.rpc(
                "mark_messages_seen",
                mapOf("p_conversation_id" to conversationId, "p_message_ids" to JSONArray(messageIds))
            )
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getConversationParticipantProfile(conversationId: String, participantId: String): Result<ParticipantProfileResult> = withContext(Dispatchers.IO) {
        try {
            val params = mapOf(
                "p_conversation_id" to conversationId,
                "p_participant_id" to participantId
            )
            val response = client.rpc("get_conversation_participant_profile", params)
            val trimmed = response.trim()
            val json = if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else if (trimmed.startsWith("{")) {
                JSONObject(trimmed)
            } else {
                JSONObject()
            }
            val userId = json.optString("user_id", participantId)
            val displayName = json.optString("display_name", "").takeIf { it.isNotBlank() }
            val avatarUrl = json.optString("avatar_url", "").takeIf { it.isNotBlank() }

            Result.success(ParticipantProfileResult(userId = userId, displayName = displayName, avatarUrl = avatarUrl))
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "getConversationParticipantProfile error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun fetchConversations(): Result<List<ConversationSummary>> = withContext(Dispatchers.IO) {
        try {
            val currentUserId = sessionManager.userId.value ?: ""
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/conversations?or=(user_id.eq.$currentUserId,partner_id.eq.$currentUserId)&order=last_message_at.desc&select=*"
            val response = client.get(url)
            val arr = JSONArray(response)
            val conversationList = mutableListOf<ConversationSummary>()
            
            val lastMessageIds = mutableListOf<String>()
            val convDataList = mutableListOf<Triple<JSONObject, String, String>>() // json, convId, otherId
            
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val convId = json.optString("id")
                val uId = json.optString("user_id")
                val pId = json.optString("partner_id")
                val otherId = if (uId == currentUserId) pId else uId
                val lastMsgId = json.optString("last_message_id", "").takeIf { it.isNotBlank() }
                if (lastMsgId != null) {
                    lastMessageIds.add(lastMsgId)
                }
                convDataList.add(Triple(json, convId, otherId))
            }

            // Fetch last messages in a single batch
            val messagesMap = mutableMapOf<String, ChatMessage>()
            if (lastMessageIds.isNotEmpty()) {
                try {
                    val selectFields = "id,conversation_id,sender_id,receiver_id,message_type,message_text,created_at,delivered_at,seen_at"
                    val mUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?id=in.(${lastMessageIds.joinToString(",")})&select=$selectFields"
                    val mResponse = client.get(mUrl)
                    val mArr = JSONArray(mResponse)
                    for (j in 0 until mArr.length()) {
                        val mJson = mArr.getJSONObject(j)
                        val mId = mJson.optString("id")
                        val mSeenAt = com.example.data.model.parseNullableTimestamp(mJson, "seen_at")
                        val mDeliveredAt = com.example.data.model.parseNullableTimestamp(mJson, "delivered_at") ?: mSeenAt
                        messagesMap[mId] = ChatMessage(
                            id = mId,
                            conversationId = mJson.optString("conversation_id"),
                            senderId = mJson.optString("sender_id"),
                            receiverId = mJson.optString("receiver_id"),
                            messageType = mJson.optString("message_type", "text"),
                            messageText = mJson.optString("message_text").takeIf { it.isNotBlank() },
                            createdAt = mJson.optString("created_at"),
                            deliveredAt = mDeliveredAt,
                            seenAt = mSeenAt,
                            isDelivered = mDeliveredAt != null,
                            isSeen = mSeenAt != null
                        )
                    }
                } catch (e: Exception) {
                    Log.e("SupabaseDataService", "Batch fetch for last messages failed: ${e.message}", e)
                }

                val missingIds = lastMessageIds.filter { !messagesMap.containsKey(it) }
                if (missingIds.isNotEmpty()) {
                    Log.w("SupabaseDataService", "Batch message fetch missed ${missingIds.size} messages. Running bounded per-conversation fallback queries.")
                    val fallbackDeferreds = missingIds.take(20).map { msgId ->
                        async {
                            try {
                                val sUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?id=eq.$msgId&select=id,conversation_id,sender_id,receiver_id,message_type,message_text,created_at,delivered_at,seen_at"
                                val sResp = client.get(sUrl)
                                val sArr = JSONArray(sResp)
                                if (sArr.length() > 0) {
                                    val mJson = sArr.getJSONObject(0)
                                    val mId = mJson.optString("id")
                                    val mSeenAt = com.example.data.model.parseNullableTimestamp(mJson, "seen_at")
                                    val mDeliveredAt = com.example.data.model.parseNullableTimestamp(mJson, "delivered_at") ?: mSeenAt
                                    val chatMsg = ChatMessage(
                                        id = mId,
                                        conversationId = mJson.optString("conversation_id"),
                                        senderId = mJson.optString("sender_id"),
                                        receiverId = mJson.optString("receiver_id"),
                                        messageType = mJson.optString("message_type", "text"),
                                        messageText = mJson.optString("message_text").takeIf { it.isNotBlank() },
                                        createdAt = mJson.optString("created_at"),
                                        deliveredAt = mDeliveredAt,
                                        seenAt = mSeenAt,
                                        isDelivered = mDeliveredAt != null,
                                        isSeen = mSeenAt != null
                                    )
                                    mId to chatMsg
                                } else null
                            } catch (e: Exception) {
                                Log.e("SupabaseDataService", "Per-conversation fallback failed for message $msgId: ${e.message}", e)
                                null
                            }
                        }
                    }
                    fallbackDeferreds.awaitAll().filterNotNull().forEach { (id, msg) ->
                        messagesMap[id] = msg
                    }
                }
            }

            // Fetch profiles in parallel
            val profileResults = convDataList.map { (_, convId, otherId) ->
                async {
                    var finalName = ""
                    var finalAvatar: String? = null
                    
                    try {
                        val pProfile = getConversationParticipantProfile(convId, otherId).getOrNull()
                        if (pProfile != null) {
                            if (!pProfile.displayName.isNullOrBlank()) {
                                finalName = pProfile.displayName!!
                            }
                            if (!pProfile.avatarUrl.isNullOrBlank()) {
                                finalAvatar = pProfile.avatarUrl
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("SupabaseDataService", "RPC profile load failed for $otherId: ${e.message}")
                    }

                    if (finalName.isBlank()) {
                        try {
                            val hostProfile = getHostProfile(otherId).getOrNull()
                            if (hostProfile != null) {
                                finalName = hostProfile.displayName
                                if (finalAvatar.isNullOrBlank()) {
                                    finalAvatar = hostProfile.avatarUrl?.takeIf { it.isNotBlank() }
                                }
                            }
                        } catch (e: Exception) {
                            Log.w("SupabaseDataService", "Fallback getHostProfile failed for $otherId: ${e.message}")
                        }
                    }

                    if (finalName.isBlank()) {
                        finalName = "User"
                    }

                    Triple(convId, finalName, finalAvatar)
                }
            }
            
            val profilesMap = awaitAll(*profileResults.toTypedArray()).associateBy { it.first }

            // Build summaries
            for (data in convDataList) {
                val json = data.first
                val convId = data.second
                val otherId = data.third
                
                val uId = json.optString("user_id")
                val pId = json.optString("partner_id")
                
                val userUnread = json.optInt("user_unread_count", 0)
                val partnerUnread = json.optInt("partner_unread_count", 0)
                val unreadCount = if (currentUserId == uId) userUnread else if (currentUserId == pId) partnerUnread else 0

                val lastMsgTime = json.optString("last_message_at").takeIf { it.isNotBlank() } ?: json.optString("updated_at", "")
                val lastMsgId = json.optString("last_message_id", "").takeIf { it.isNotBlank() }
                
                val profileTuple = profilesMap[convId]
                val finalName = profileTuple?.second ?: "User"
                val finalAvatar = profileTuple?.third

                val mappedMsg = lastMsgId?.let { messagesMap[it] }
                var lastMsgText = ""
                var lastMsgType = "text"
                var lastMsgSenderId: String? = null
                var lastMsgDeliveredAt: String? = null
                var lastMsgSeenAt: String? = null

                if (mappedMsg != null) {
                    lastMsgText = when (mappedMsg.messageType.lowercase()) {
                        "text" -> mappedMsg.messageText ?: ""
                        "image" -> "📷 Photo"
                        "voice" -> "🎙️ Voice message"
                        "gift" -> "🎁 Gift"
                        else -> if (!mappedMsg.messageText.isNullOrBlank()) mappedMsg.messageText else "New message"
                    }
                    lastMsgType = mappedMsg.messageType
                    lastMsgSenderId = mappedMsg.senderId
                    lastMsgDeliveredAt = mappedMsg.deliveredAt
                    lastMsgSeenAt = mappedMsg.seenAt
                } else {
                    lastMsgText = if (lastMsgId == null) "No messages" else "Message"
                }

                conversationList.add(
                    ConversationSummary(
                        id = convId,
                        partnerId = otherId,
                        partnerName = finalName,
                        partnerAvatar = finalAvatar,
                        unreadCount = unreadCount,
                        lastMessage = lastMsgText,
                        lastMessageTime = lastMsgTime,
                        lastMessageType = lastMsgType,
                        lastMessageId = lastMsgId,
                        lastMessageSenderId = lastMsgSenderId,
                        lastMessageDeliveredAt = lastMsgDeliveredAt,
                        lastMessageSeenAt = lastMsgSeenAt
                    )
                )
            }
            Result.success(conversationList)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "fetchConversations error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 4. GIFTS
    // ==========================================

    suspend fun fetchGifts(): Result<List<GiftItem>> = withContext(Dispatchers.IO) {
        try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/gifts?is_active=eq.true&order=display_order.asc&select=*"
            val response = client.get(url)
            val arr = JSONArray(response)
            val gifts = mutableListOf<GiftItem>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                gifts.add(
                    GiftItem(
                        id = json.optString("id"),
                        name = json.optString("name"),
                        description = json.optString("description").takeIf { it.isNotBlank() },
                        priceRupees = json.optDouble("price_rupees", json.optDouble("price", 0.0)),
                        iconUrl = json.optString("icon_url").takeIf { it.isNotBlank() },
                        isActive = json.optBoolean("is_active", true),
                        displayOrder = json.optInt("display_order", 0)
                    )
                )
            }
            Result.success(gifts)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "fetchGifts error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun sendGift(
        giftId: String,
        receiverId: String,
        conversationId: String? = null,
        callId: String? = null
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val params = mutableMapOf<String, Any?>(
                "p_gift_id" to giftId,
                "p_receiver_id" to receiverId
            )
            if (!conversationId.isNullOrBlank()) params["p_conversation_id"] = conversationId
            if (!callId.isNullOrBlank()) params["p_call_id"] = callId

            val response = client.rpc("send_gift", params)
            val trimmed = response.trim().lowercase()
            val success = trimmed == "true" || trimmed == "\"true\"" || trimmed == "1" || !trimmed.contains("error")
            Result.success(success)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "sendGift error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 5. WALLET & PRICING
    // ==========================================

    suspend fun fetchWalletSummary(): Result<WalletSummary> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("get_wallet_summary")
            val trimmed = response.trim()
            val json = if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else if (trimmed.startsWith("{")) {
                JSONObject(trimmed)
            } else {
                JSONObject()
            }

            val summary = WalletSummary(
                balanceRupees = json.optDouble("balance_rupees", json.optDouble("balance", 0.0)),
                callReservedRupees = json.optDouble("call_reserved_rupees", 0.0),
                availableBalanceRupees = json.optDouble("available_balance_rupees", json.optDouble("available_balance", 0.0)),
                earningBalanceRupees = json.optDouble("earning_balance_rupees", 0.0),
                withdrawalReservedRupees = json.optDouble("withdrawal_reserved_rupees", 0.0),
                availableEarningBalanceRupees = json.optDouble("available_earning_balance_rupees", 0.0)
            )

            // Keep session cached wallet updated
            val currentUid = sessionManager.userId.value ?: ""
            sessionManager.updateWallet(
                WalletInfo(
                    userId = currentUid,
                    balanceRupees = summary.balanceRupees,
                    availableBalanceRupees = summary.availableBalanceRupees,
                    updatedAt = System.currentTimeMillis().toString()
                )
            )

            Result.success(summary)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "fetchWalletSummary error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun fetchWalletRechargePackages(): Result<List<WalletRechargePackage>> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("get_wallet_recharge_packages")
            val arr = JSONArray(response)
            val packages = mutableListOf<WalletRechargePackage>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val isActive = json.optBoolean("is_active", true)
                val amount = json.optDouble("amount_rupees", json.optDouble("amount", 0.0))
                if (isActive) {
                    packages.add(
                        WalletRechargePackage(
                            id = json.optString("id"),
                            amountRupees = amount,
                            displayOrder = json.optInt("display_order", i + 1),
                            isActive = isActive
                        )
                    )
                }
            }
            Result.success(packages.sortedBy { it.displayOrder })
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "fetchWalletRechargePackages error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun fetchWalletTransactions(limit: Int = 50, offset: Int = 0): Result<List<WalletTransaction>> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc(
                "get_wallet_transactions",
                mapOf("p_limit" to limit, "p_offset" to offset)
            )
            val arr = JSONArray(response)
            val list = mutableListOf<WalletTransaction>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    WalletTransaction(
                        id = json.optString("id"),
                        userId = json.optString("user_id"),
                        transactionType = json.optString("transaction_type"),
                        amountRupees = json.optDouble("amount_rupees", 0.0),
                        balanceAfterRupees = json.optDouble("balance_after_rupees", 0.0),
                        referenceId = json.optString("reference_id").takeIf { it.isNotBlank() },
                        description = json.optString("description"),
                        status = json.optString("status", "completed"),
                        createdAt = json.optString("created_at")
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "fetchWalletTransactions error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun getEffectiveUserPricing(userId: String): Result<EffectiveUserPricing> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("get_effective_user_pricing", mapOf("p_user_id" to userId))
            val trimmed = response.trim()
            val json = if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else if (trimmed.startsWith("{")) {
                JSONObject(trimmed)
            } else {
                JSONObject()
            }

            val pricing = EffectiveUserPricing(
                callRateRupeesPerMinute = json.optDouble("call_rate_rupees_per_minute", json.optDouble("audio_call_rate_rupees", 5.0)),
                videoCallRateRupeesPerMinute = json.optDouble("video_call_rate_rupees_per_minute", json.optDouble("video_call_rate_rupees", 20.0)),
                messageRateRupees = json.optDouble("message_rate_rupees", json.optDouble("chat_message_rate_rupees", 2.0))
            )
            Result.success(pricing)
        } catch (e: Exception) {
            Log.w("SupabaseDataService", "getEffectiveUserPricing exception: ${e.message}")
            Result.success(EffectiveUserPricing.DEFAULT)
        }
    }

    suspend fun fetchTransactions(): Result<List<TransactionItem>> = withContext(Dispatchers.IO) {
        fetchWalletTransactions(limit = 50, offset = 0).map { walletTxs ->
            walletTxs.map { wt ->
                TransactionItem(
                    id = wt.id,
                    type = wt.transactionType,
                    amountRupees = wt.amountRupees,
                    description = wt.description.ifBlank { wt.transactionType.replace("_", " ").uppercase() },
                    timestamp = wt.createdAt,
                    status = wt.status
                )
            }
        }
    }

    suspend fun fetchRecentCalls(): Result<List<CallRecord>> = withContext(Dispatchers.IO) {
        try {
            val currentUserId = sessionManager.userId.value ?: ""
            val selectFields = "id,user_id,partner_id,status,call_type,requested_at,accepted_at,connected_at,ended_at,duration_seconds,agora_channel_id,user_charge_rupees,partner_earning_rupees,partner_earning_rate_rupees_per_minute,pricing_tier,pricing_version,reserved_call_rupees,max_duration_seconds,billing_status,created_at"
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/calls?user_id=eq.$currentUserId&order=created_at.desc&limit=50&select=$selectFields"
            val response = client.get(url)
            val arr = JSONArray(response)
            val tempCalls = mutableListOf<CallRecord>()
            val partnerIds = mutableSetOf<String>()
            
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val partnerId = json.optString("partner_id")
                if (partnerId.isNotBlank()) {
                    partnerIds.add(partnerId)
                }
                
                val connectedAtStr = json.optString("connected_at").takeIf { it.isNotBlank() && it != "null" }
                val requestedAtStr = json.optString("requested_at").takeIf { it.isNotBlank() && it != "null" }
                val startedAtVal = connectedAtStr ?: requestedAtStr
                val statusStr = json.optString("status", "requested")
                val isConnected = !connectedAtStr.isNullOrBlank()
                val isCompleted = statusStr.equals("completed", ignoreCase = true)

                val durationSec = if (isConnected && isCompleted) json.optInt("duration_seconds", 0) else 0
                val userCharge = if (isConnected && isCompleted) json.optDouble("user_charge_rupees", 0.0) else 0.0
                val partnerEarning = if (isConnected && isCompleted) json.optDouble("partner_earning_rupees", 0.0) else 0.0
                val reservedRupees = if (isConnected && isCompleted) json.optDouble("reserved_call_rupees", 0.0) else 0.0
                val billingStat = if (isConnected && isCompleted) json.optString("billing_status").takeIf { it.isNotBlank() } else "not_billed"

                tempCalls.add(
                    CallRecord(
                        id = json.optString("id"),
                        userId = json.optString("user_id"),
                        partnerId = partnerId,
                        channelName = json.optString("agora_channel_id").ifBlank { json.optString("channel_name") },
                        callType = json.optString("call_type", "audio"),
                        status = statusStr,
                        startedAt = startedAtVal,
                        connectedAt = connectedAtStr,
                        endedAt = json.optString("ended_at").takeIf { it.isNotBlank() && it != "null" },
                        durationSeconds = durationSec,
                        totalAmountRupees = userCharge,
                        createdAt = json.optString("created_at"),
                        reservedCallRupees = reservedRupees,
                        maxDurationSeconds = json.optInt("max_duration_seconds", 0),
                        userChargeRupees = userCharge,
                        partnerEarningRupees = partnerEarning,
                        partnerEarningRateRupeesPerMinute = json.optDouble("partner_earning_rate_rupees_per_minute", 0.0),
                        pricingTier = json.optString("pricing_tier").takeIf { it.isNotBlank() },
                        pricingVersion = json.optString("pricing_version").takeIf { it.isNotBlank() },
                        billingStatus = billingStat
                    )
                )
            }

            val partnerProfiles = mutableMapOf<String, PartnerProfile>()
            if (partnerIds.isNotEmpty()) {
                val deferreds = partnerIds.map { pId ->
                    async {
                        pId to getHostProfile(pId).getOrNull()
                    }
                }
                awaitAll(*deferreds.toTypedArray()).forEach { (pId, profile) ->
                    if (profile != null) {
                        partnerProfiles[pId] = profile
                    }
                }
            }

            val finalizedCalls = tempCalls.map { call ->
                val profile = partnerProfiles[call.partnerId]
                if (profile != null) {
                    call.copy(
                        partnerName = profile.displayName,
                        partnerAvatarUrl = profile.avatarUrl
                    )
                } else {
                    call.copy(
                        partnerName = "Host",
                        partnerAvatarUrl = null
                    )
                }
            }

            Result.success(finalizedCalls)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "fetchRecentCalls error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 6. UROPAY RECHARGE
    // ==========================================

    suspend fun createUroPayOrder(
        packageId: String,
        tenantOrderRef: String,
        targetCallId: String? = null
    ): Result<UroPayCreateOrderResult> = withContext(Dispatchers.IO) {
        try {
            val endpoint = "${SupabaseConfig.supabaseUrl}/functions/v1/create-uropay-order"
            val body = JSONObject().apply {
                put("package_id", packageId)
                put("tenant_order_ref", tenantOrderRef)
                if (!targetCallId.isNullOrBlank()) {
                    put("target_call_id", targetCallId)
                }
            }
            val response = client.post(endpoint, body.toString())
            val json = JSONObject(response)
            val dataObj = json.optJSONObject("data")

            val orderId = json.optString(
                "order_id",
                json.optString("orderId", json.optString("provider_order_id", dataObj?.optString("order_id", dataObj?.optString("provider_order_id", "")) ?: ""))
            )
            val paymentId = json.optString(
                "payment_id",
                json.optString("paymentId", json.optString("id", dataObj?.optString("payment_id", dataObj?.optString("id", "")) ?: ""))
            )

            // Extract open URL with full support for provider_checkout_url and open_url
            val openUrlCandidate = when {
                json.has("open_url") && json.optString("open_url").isNotBlank() -> json.optString("open_url")
                json.has("provider_checkout_url") && json.optString("provider_checkout_url").isNotBlank() -> json.optString("provider_checkout_url")
                json.has("openUrl") && json.optString("openUrl").isNotBlank() -> json.optString("openUrl")
                json.has("checkout_url") && json.optString("checkout_url").isNotBlank() -> json.optString("checkout_url")
                dataObj != null && dataObj.optString("open_url").isNotBlank() -> dataObj.optString("open_url")
                dataObj != null && dataObj.optString("provider_checkout_url").isNotBlank() -> dataObj.optString("provider_checkout_url")
                dataObj != null && dataObj.optString("checkout_url").isNotBlank() -> dataObj.optString("checkout_url")
                else -> ""
            }.trim()

            val amountRupees = if (!json.isNull("wallet_credit_rupees")) {
                json.optDouble("wallet_credit_rupees")
            } else if (!json.isNull("amount_inr")) {
                json.optDouble("amount_inr")
            } else if (!json.isNull("amount_rupees")) {
                json.optDouble("amount_rupees")
            } else if (dataObj != null && !dataObj.isNull("amount_rupees")) {
                dataObj.optDouble("amount_rupees")
            } else {
                json.optDouble("amount", 0.0)
            }
            val status = json.optString("status", dataObj?.optString("status", "created") ?: "created")

            Result.success(
                UroPayCreateOrderResult(
                    orderId = orderId,
                    paymentId = paymentId,
                    tenantOrderRef = tenantOrderRef,
                    amountRupees = amountRupees,
                    openUrl = openUrlCandidate,
                    status = status
                )
            )
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "createUroPayOrder error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun verifyUroPayPayment(paymentId: String): Result<UroPayVerifyPaymentResult> = withContext(Dispatchers.IO) {
        try {
            val endpoint = "${SupabaseConfig.supabaseUrl}/functions/v1/verify-uropay-payment"
            val body = JSONObject().apply {
                put("payment_id", paymentId)
            }
            val response = client.post(endpoint, body.toString())
            val json = JSONObject(response)

            val verified = json.optBoolean("verified", false)
            val status = json.optString("status", "")
            val amountRupees = json.optDouble("wallet_credit_rupees", json.optDouble("amount_rupees", json.optDouble("amount", 0.0)))
            val extendedSeconds = json.optInt("active_call_extended_seconds", json.optInt("activeCallExtendedSeconds", 0))
            val message = json.optString("message", "")

            Result.success(
                UroPayVerifyPaymentResult(
                    paymentId = paymentId,
                    verified = verified,
                    status = status,
                    amountRupees = amountRupees,
                    activeCallExtendedSeconds = extendedSeconds,
                    message = message
                )
            )
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "verifyUroPayPayment error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 7. RATINGS & REVIEWS
    // ==========================================

    suspend fun getCallRatingEligibility(callId: String): Result<CallRatingEligibility> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("get_call_rating_eligibility", mapOf("p_call_id" to callId))
            val trimmed = response.trim()
            val json = if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else if (trimmed.startsWith("{")) {
                JSONObject(trimmed)
            } else {
                JSONObject()
            }

            val isEligible = json.optBoolean("is_eligible", json.optBoolean("eligible", false))
            val pId = json.optString("partner_id")
            val reason = json.optString("reason", "")

            Result.success(
                CallRatingEligibility(
                    isEligible = isEligible,
                    callId = callId,
                    partnerId = pId,
                    reason = reason
                )
            )
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "getCallRatingEligibility error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun submitCallRating(
        callId: String,
        ratedUserId: String,
        rating: Int,
        reviewText: String? = null
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val boundedRating = rating.coerceIn(1, 5)
            val params = mutableMapOf<String, Any?>(
                "p_call_id" to callId,
                "p_rated_user_id" to ratedUserId,
                "p_rating" to boundedRating
            )
            if (!reviewText.isNullOrBlank()) {
                params["p_review_text"] = reviewText.trim()
            }

            val response = client.rpc("submit_call_rating", params)
            val trimmed = response.trim().lowercase()
            val success = trimmed == "true" || trimmed == "\"true\"" || trimmed == "1" || !trimmed.contains("error")
            Result.success(success)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "submitCallRating error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun getPublicUserRating(userId: String): Result<PublicUserRating> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("get_public_user_rating", mapOf("p_user_id" to userId))
            val trimmed = response.trim()
            val json = if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
            } else if (trimmed.startsWith("{")) {
                JSONObject(trimmed)
            } else {
                JSONObject()
            }

            val avg = json.optDouble("average_rating", json.optDouble("rating", 5.0))
            val total = json.optInt("total_reviews", json.optInt("reviews_count", 0))

            Result.success(
                PublicUserRating(
                    averageRating = avg,
                    totalReviews = total,
                    fiveStarCount = json.optInt("five_star_count", 0),
                    fourStarCount = json.optInt("four_star_count", 0),
                    threeStarCount = json.optInt("three_star_count", 0),
                    twoStarCount = json.optInt("two_star_count", 0),
                    oneStarCount = json.optInt("one_star_count", 0)
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // 8. NOTIFICATIONS & FCM
    // ==========================================

    suspend fun registerFcmToken(
        token: String,
        platform: String = "android",
        deviceId: String? = null,
        deviceInfo: String? = null
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val params = mutableMapOf<String, Any?>(
                "p_token" to token,
                "p_platform" to platform
            )
            if (!deviceId.isNullOrBlank()) params["p_device_id"] = deviceId
            if (!deviceInfo.isNullOrBlank()) params["p_device_info"] = deviceInfo

            client.rpc("register_fcm_token", params)
            Result.success(true)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "registerFcmToken error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun unregisterFcmToken(token: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            client.rpc("unregister_fcm_token", mapOf("p_token" to token))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchNotifications(): Result<List<AppNotification>> = withContext(Dispatchers.IO) {
        try {
            val currentUserId = sessionManager.userId.value ?: ""
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/notifications?user_id=eq.$currentUserId&order=created_at.desc&limit=50&select=*"
            val response = client.get(url)
            val arr = JSONArray(response)
            val list = mutableListOf<AppNotification>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    AppNotification(
                        id = json.optString("id"),
                        userId = json.optString("user_id"),
                        title = json.optString("title"),
                        body = json.optString("body"),
                        type = json.optString("notification_type").ifBlank { json.optString("type", "system") },
                        isRead = json.optBoolean("is_read", false),
                        createdAt = json.optString("created_at")
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markNotificationAsRead(notificationId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            client.rpc("mark_notification_read", mapOf("p_notification_id" to notificationId))
            Result.success(true)
        } catch (_: Exception) {
            try {
                val patchUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/notifications?id=eq.$notificationId"
                client.patch(patchUrl, JSONObject().put("is_read", true).toString())
                Result.success(true)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    // ==========================================
    // 9. BLOCK, REPORT & ACCOUNT
    // ==========================================

    suspend fun isUserBlocked(otherUserId: String): Result<com.example.data.model.UserBlockStatus> = withContext(Dispatchers.IO) {
        try {
            val response = client.rpc("is_user_blocked", mapOf("p_other_user_id" to otherUserId))
            val trimmed = response.trim()
            var blocked = false
            var blockedByMe = false
            var blockedMe = false
            
            if (trimmed.startsWith("[")) {
                val array = JSONArray(trimmed)
                if (array.length() > 0) {
                    val json = array.getJSONObject(0)
                    blocked = json.optBoolean("blocked", false)
                    blockedByMe = json.optBoolean("blocked_by_me", false)
                    blockedMe = json.optBoolean("blocked_me", false)
                }
            } else if (trimmed.startsWith("{")) {
                val json = JSONObject(trimmed)
                blocked = json.optBoolean("blocked", false)
                blockedByMe = json.optBoolean("blocked_by_me", false)
                blockedMe = json.optBoolean("blocked_me", false)
            }
            Result.success(com.example.data.model.UserBlockStatus(blocked, blockedByMe, blockedMe))
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "isUserBlocked error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun blockUser(partnerId: String, reason: String = "User requested block"): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            client.rpc("block_user", mapOf("p_blocked_user_id" to partnerId, "p_reason" to reason))
            Result.success(true)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "blockUser error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun unblockUser(partnerId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            client.rpc("unblock_user", mapOf("p_blocked_user_id" to partnerId))
            Result.success(true)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "unblockUser error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun submitUserReport(
        reportedUserId: String,
        category: String,
        description: String,
        callId: String? = null,
        messageId: String? = null,
        priority: String = "normal"
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val params = mutableMapOf<String, Any?>(
                "p_reported_user_id" to reportedUserId,
                "p_category" to category,
                "p_description" to description,
                "p_call_id" to callId,
                "p_message_id" to messageId,
                "p_priority" to priority
            )
            client.rpc("submit_user_report", params)
            Result.success(true)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "submitUserReport error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun requestAccountDeletion(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            client.rpc("request_account_deletion")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "requestAccountDeletion error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 10. MEDIA & STORAGE
    // ==========================================

    suspend fun uploadChatMedia(file: File, isVoice: Boolean): Result<String> = withContext(Dispatchers.IO) {
        val currentUserId = sessionManager.userId.value
        if (currentUserId.isNullOrBlank()) {
            return@withContext Result.failure(IllegalStateException("User is not authenticated"))
        }

        try {
            val ext = if (isVoice) "m4a" else (file.extension.ifBlank { "jpg" })
            val mime = if (isVoice) "audio/mp4" else "image/jpeg"
            val relativePath = "$currentUserId/${UUID.randomUUID()}.$ext"

            val uploadedPath = client.uploadFile(
                bucket = SupabaseConfig.BUCKET_CHAT_MEDIA,
                path = relativePath,
                file = file,
                mimeType = mime
            )
            val finalPath = if (!uploadedPath.startsWith("${SupabaseConfig.BUCKET_CHAT_MEDIA}/")) {
                "${SupabaseConfig.BUCKET_CHAT_MEDIA}/$relativePath"
            } else {
                uploadedPath
            }
            Result.success(finalPath)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "uploadChatMedia failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun resolveAvatarUrl(rawPathOrUrl: String?): String {
        return resolveProfileAvatarUrl(rawPathOrUrl)
    }

    suspend fun resolveProfileAvatarUrl(rawPathOrUrl: String?): String {
        if (rawPathOrUrl.isNullOrBlank()) return ""
        val trimmed = rawPathOrUrl.trim()
        if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
            return trimmed
        }
        return getSignedMediaUrl(trimmed, SupabaseConfig.BUCKET_PROFILE_MEDIA)
    }

    fun invalidateSignedMediaUrl(rawPathOrUrl: String, bucket: String = SupabaseConfig.BUCKET_CHAT_MEDIA) {
        val trimmed = rawPathOrUrl.trim()
        var cleanPath = trimmed.trimStart('/')
        while (cleanPath.startsWith("$bucket/")) {
            cleanPath = cleanPath.removePrefix("$bucket/").trimStart('/')
        }
        mediaUrlCache.remove("$bucket:$cleanPath")
        mediaUrlCache.remove("$bucket:$trimmed")
    }

    suspend fun resolveChatVoiceUrl(rawPathOrUrl: String?): String {
        if (rawPathOrUrl.isNullOrBlank()) return ""
        return getSignedMediaUrl(rawPathOrUrl, SupabaseConfig.BUCKET_CHAT_MEDIA)
    }

    suspend fun getSignedMediaUrl(rawPathOrUrl: String, bucket: String = SupabaseConfig.BUCKET_CHAT_MEDIA): String {
        if (rawPathOrUrl.isBlank()) return ""
        val trimmed = rawPathOrUrl.trim()
        if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
            return trimmed
        }

        // Bounded normalization: safely strip any duplicate bucket prefix
        var cleanPath = trimmed.trimStart('/')
        while (cleanPath.startsWith("$bucket/")) {
            cleanPath = cleanPath.removePrefix("$bucket/").trimStart('/')
        }
        if (cleanPath.isBlank()) return ""

        val cacheKey = "$bucket:$cleanPath"
        val cached = mediaUrlCache[cacheKey]
        val now = System.currentTimeMillis()
        // Use bounded cache TTL (50 mins) shorter than signed URL expiry (60 mins)
        if (cached != null && (now - cached.second) < cacheTtlMs) {
            return cached.first
        }

        return try {
            val signed = client.createSignedUrl(bucket, cleanPath, expiresInSeconds = 3600)
            if (signed.isNotBlank()) {
                mediaUrlCache[cacheKey] = Pair(signed, now)
                signed
            } else {
                Log.w("SupabaseDataService", "Empty signed URL received for $cleanPath in $bucket")
                ""
            }
        } catch (e: Exception) {
            Log.w("SupabaseDataService", "Failed to resolve signed URL for $trimmed in $bucket: ${e.message}")
            ""
        }
    }
}
