package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

class BaatlyUserCallForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_CALL
        Log.i(TAG, "onStartCommand: action=$action")

        when (action) {
            ACTION_START_CALL -> {
                val partnerName = intent?.getStringExtra(EXTRA_PARTNER_NAME) ?: "Host"
                val isVideo = intent?.getBooleanExtra(EXTRA_IS_VIDEO, false) ?: false
                startCallForeground(partnerName, isVideo)
                acquireWakeLock()
            }
            ACTION_STOP_CALL -> {
                stopCallForeground()
            }
        }
        return START_NOT_STICKY
    }

    private fun startCallForeground(partnerName: String, isVideo: Boolean) {
        createNotificationChannel()

        val notificationIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("extra_navigate_to_call", true)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isVideo) "Active Video Call" else "Active Audio Call"
        val body = "Call in progress with $partnerName. Tap to return."

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val hasCameraPermission = ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED

                var serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (isVideo && hasCameraPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
                startForeground(NOTIFICATION_ID, notification, serviceType)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            Log.i(TAG, "Call foreground service started successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start call foreground service: ${e.message}", e)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "Baatly:UserCallWakeLock"
            )?.apply {
                setReferenceCounted(false)
                // Hold lock for up to 2 hours maximum per call
                acquire(2 * 60 * 60 * 1000L)
            }
            Log.i(TAG, "Acquired PARTIAL_WAKE_LOCK for active call")
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
                Log.i(TAG, "Released PARTIAL_WAKE_LOCK")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing WakeLock: ${e.message}")
        } finally {
            wakeLock = null
        }
    }

    private fun stopCallForeground() {
        releaseWakeLock()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
        Log.i(TAG, "Call foreground service stopped cleanly")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Ongoing Call",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Maintains active audio/video call connection in background"
                    setShowBadge(false)
                }
                nm.createNotificationChannel(channel)
            }
        }
    }

    override fun onDestroy() {
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "BaatlyUserCallService"
        const val CHANNEL_ID = "baatly_ongoing_call_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_CALL = "com.example.service.ACTION_START_CALL"
        const val ACTION_STOP_CALL = "com.example.service.ACTION_STOP_CALL"
        const val EXTRA_PARTNER_NAME = "extra_partner_name"
        const val EXTRA_IS_VIDEO = "extra_is_video"

        fun startService(context: Context, partnerName: String, isVideo: Boolean) {
            try {
                val intent = Intent(context, BaatlyUserCallForegroundService::class.java).apply {
                    action = ACTION_START_CALL
                    putExtra(EXTRA_PARTNER_NAME, partnerName)
                    putExtra(EXTRA_IS_VIDEO, isVideo)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting BaatlyUserCallForegroundService: ${e.message}", e)
            }
        }

        fun stopService(context: Context) {
            try {
                val intent = Intent(context, BaatlyUserCallForegroundService::class.java).apply {
                    action = ACTION_STOP_CALL
                }
                context.startService(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping BaatlyUserCallForegroundService: ${e.message}", e)
            }
        }
    }
}
