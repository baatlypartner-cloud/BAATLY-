# BAATLY v50 — AdMob integration and mandatory update gate

## AdMob integration

- Google Mobile Ads Next-Gen Android SDK `1.6.0`.
- Google User Messaging Platform consent SDK `4.0.0`.
- Centralized AdMob IDs and placement/frequency mapping.
- Debug builds use Google's official test ad-unit IDs; release builds use BAATLY production IDs.
- UMP consent is requested at startup. Ads initialize only when consent allows ad requests.

### AdMob App ID

`ca-app-pub-9363095174633972~9323820583`

### Ad unit mapping

| Unit | Ad unit ID | App placement / trigger |
|---|---|---|
| `BAATLY_Home_AppOpen` | `ca-app-pub-9363095174633972/4795775416` | Eligible warm return after at least 4 hours in background; suppressed during calls and update dialog |
| `BAATLY_HostList_Native` | `ca-app-pub-9363095174633972/3291122057` | After every 5 host cards |
| `BAATLY_ChatList_Native` | `ca-app-pub-9363095174633972/2085851599` | After the 8th conversation, then every 10 conversations |
| `BAATLY_Reels_Native` | `ca-app-pub-9363095174633972/1485271702` | Native ad slot after every 8 organic reels |
| `BAATLY_PanditAI_Native` | `ca-app-pub-9363095174633972/3351840962` | After each completed PanditAI response |
| `BAATLY_SuperAI_Native` | `ca-app-pub-9363095174633972/9473387024` | After each completed SuperAI response |
| `BAATLY_Entertainment_Banner` | `ca-app-pub-9363095174633972/6354455002` | Entertainment catalogue screen while visible |
| `BAATLY_Entertainment_Native` | `ca-app-pub-9363095174633972/8980618347` | After first 6 catalogue cards, then every 10 cards in a section |
| `BAATLY_PostCall_Interstitial` | `ca-app-pub-9363095174633972/5375369073` | After successful call completion through the shared callback; runtime verification is needed for each call type |

## Mandatory update behavior — corrected in v50

- Play Store package: `com.aistudio.baatly.app`.
- Listing: `https://play.google.com/store/apps/details?id=com.aistudio.baatly.app`.
- BAATLY opens immediately while Play's update availability check runs silently in the background.
- The non-dismissable `BAATLY Update Required` dialog appears only after Play successfully reports `UPDATE_AVAILABLE` and `availableVersionCode` is greater than the installed `BuildConfig.VERSION_CODE`.
- Offline errors, Play API failures, unsupported/sideloaded installs, account eligibility issues, and request timeouts do not lock the app. Such a failure is not evidence that a new mandatory update exists.
- The app checks once per process launch, not on every ordinary Activity resume. It rechecks after the user chooses the Play Store button and returns.
- When a higher version is positively confirmed, the dialog has no close button, outside-tap dismissal, or back dismissal. Its Update button opens the BAATLY Play Store listing.
- To enforce a future release, upload an AAB with the same package name, same Play upload/signing identity, and a version code higher than the currently published build. The prompt appears only after Google Play makes that higher version available to that user's account/device.
- Release builds require the owner's existing upload key through `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD`; no debug-signing fallback is used.

## Entertainment video mid-roll

The separate IMA/VAST movie/episode ad system is not included in this ZIP; it remains a separately scoped feature as requested.

## Version

- `versionCode = 50`
- `versionName = 1.0.50`

## Validation status

Source-level checks, XML parsing, AdMob ID checks, and ZIP integrity checks were run. A full Gradle Android build could not be completed in this environment because the Gradle 9.3.1 wrapper distribution was not cached and `services.gradle.org` was unreachable. This is an updated source ZIP, not a verified APK/AAB; build and runtime-test it in Android Studio or CI before Play release.
