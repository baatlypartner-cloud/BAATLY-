package com.example.ui.social

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.SocialPost
import com.example.ui.BaatlyViewModel
import com.example.ui.components.rememberResolvedProfileImageUrl
import com.example.ui.Screen
import com.example.ui.theme.*

private val Plum = Color(0xFF2B163D)
private val Cream = Color(0xFFFFF8F3)
private val SocialSoftPink = Color(0xFFFFEEF2)

@Composable
fun SocialProfileScreen(viewModel: BaatlyViewModel) {
    val targetUserId by viewModel.socialProfileTargetUserId.collectAsState()
    val ownProfile by viewModel.mySocialProfile.collectAsState()
    val ownPosts by viewModel.mySocialPosts.collectAsState()
    val viewedProfile by viewModel.viewedSocialProfile.collectAsState()
    val viewedPosts by viewModel.viewedSocialPosts.collectAsState()
    val isOwn = targetUserId.isNullOrBlank()
    val profile = if (isOwn) ownProfile else viewedProfile
    val posts = if (isOwn) ownPosts else viewedPosts
    val resolvedProfileAvatar by rememberResolvedProfileImageUrl(profile?.avatarUrl, viewModel.dataService)
    var selectedTab by remember { mutableStateOf("Posts") }
    var showHighlightsInfo by remember { mutableStateOf(false) }

    LaunchedEffect(targetUserId) {
        if (targetUserId.isNullOrBlank()) viewModel.loadMySocialProfile()
    }

    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { viewModel.setScreen(Screen.SOCIAL) }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Plum) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("BAATLY", color = Plum, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("S O C I A L  M E D I A", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 7.sp, letterSpacing = 1.1.sp)
            }
            IconButton(onClick = { viewModel.setScreen(Screen.PROFILE) }) { Icon(if (isOwn) Icons.Filled.Settings else Icons.Filled.MoreHoriz, contentDescription = "Profile options", tint = Plum) }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Box(Modifier.size(104.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(VibrantPink, Color(0xFFFFB703), VibrantPink))).padding(4.dp)) {
                    AsyncImage(model = resolvedProfileAvatar, contentDescription = "Profile photo", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape).background(SocialSoftPink))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(profile?.username?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: profile?.displayName?.ifBlank { "baatly_member" } ?: "baatly_member", color = Plum, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(profile?.displayName?.ifBlank { "BAATLY member" } ?: "BAATLY member", color = Plum, fontSize = 13.sp)
                    Text(profile?.bio?.ifBlank { "Sharing moments, stories and good vibes ✨" } ?: "Sharing moments, stories and good vibes ✨", color = TextSecondary, fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                ProfileStat(profile?.postsCount ?: posts.size, "Posts")
                ProfileStat(profile?.followersCount ?: 0, "Followers")
                ProfileStat(profile?.followingCount ?: 0, "Following")
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isOwn) {
                    Button(onClick = { viewModel.setScreen(Screen.PROFILE) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(16.dp)) { Text("Edit profile", fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = { showHighlightsInfo = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)) { Text("Share profile", color = Plum) }
                } else {
                    Button(onClick = { viewModel.toggleSocialFollow(profile?.userId.orEmpty()) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(16.dp)) { Text(if (profile?.isFollowing == true) "Following" else "Follow", fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = { viewModel.setScreen(Screen.CHAT_LIST) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)) {
                        Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp), tint = Plum); Spacer(Modifier.width(5.dp)); Text("Message", color = Plum)
                    }
                }
            }

            Text("Highlights", color = Plum, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 17.dp, top = 8.dp, bottom = 9.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                HighlightBubble("+", "New", isAdd = true, onClick = { showHighlightsInfo = true })
                HighlightBubble("♥", "Moments", onClick = { showHighlightsInfo = true })
                HighlightBubble("✈", "Travel", onClick = { showHighlightsInfo = true })
                HighlightBubble("☕", "Daily", onClick = { showHighlightsInfo = true })
                HighlightBubble("✨", "Favs", onClick = { showHighlightsInfo = true })
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().border(width = 1.dp, color = Color(0xFFF1E9E5)).background(Color.White), horizontalArrangement = Arrangement.SpaceEvenly) {
                ProfileTab("Posts", selectedTab == "Posts", Icons.Filled.GridOn, Modifier.weight(1f)) { selectedTab = "Posts" }
                ProfileTab("Reels", selectedTab == "Reels", Icons.Filled.PlayCircleOutline, Modifier.weight(1f)) { selectedTab = "Reels" }
                ProfileTab("Tagged", selectedTab == "Tagged", Icons.Filled.Tag, Modifier.weight(1f)) { selectedTab = "Tagged" }
            }
            val visiblePosts = when (selectedTab) {
                "Reels" -> posts.filter { it.mediaType.equals("video", true) }
                "Tagged" -> emptyList()
                else -> posts
            }
            if (visiblePosts.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Icon(if (selectedTab == "Reels") Icons.Filled.PlayCircleOutline else Icons.Filled.GridOn, contentDescription = null, tint = Color(0xFFBBAABF), modifier = Modifier.size(36.dp))
                        Text(if (selectedTab == "Reels") "No reels yet" else if (selectedTab == "Tagged") "No tagged posts yet" else "No posts yet", color = Plum, fontWeight = FontWeight.SemiBold)
                        if (isOwn && selectedTab == "Posts") Text("Your photos and videos will appear here.", color = TextTertiary, fontSize = 11.sp)
                    }
                }
            } else {
                visiblePosts.chunked(3).forEach { rowPosts ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        rowPosts.forEach { post ->
                            ProfileGridTile(post = post, viewModel = viewModel, modifier = Modifier.weight(1f))
                        }
                        repeat((3 - rowPosts.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
        }
    }

    if (showHighlightsInfo) {
        AlertDialog(
            onDismissRequest = { showHighlightsInfo = false },
            containerColor = Color.White,
            title = { Text("Story Highlights", color = Plum, fontWeight = FontWeight.Bold) },
            text = { Text("The Highlights layout is ready. Highlight creation and R2 media linking will be wired in the media integration pass.", color = TextSecondary) },
            confirmButton = { TextButton(onClick = { showHighlightsInfo = false }) { Text("Got it", color = VibrantPink) } }
        )
    }
}

@Composable
private fun ProfileStat(value: Int, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(value.toString(), color = Plum, fontSize = 17.sp, fontWeight = FontWeight.Black)
        Text(label, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun HighlightBubble(title: String, label: String, isAdd: Boolean = false, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(58.dp).clickable(onClick = onClick)) {
        Box(Modifier.size(58.dp).clip(CircleShape).background(if (isAdd) Color.White else Color(0xFFF3E8FA)).border(1.dp, if (isAdd) DarkCardBorder else Color(0xFFE7D7F0), CircleShape), contentAlignment = Alignment.Center) {
            Text(title, color = if (isAdd) Plum else VibrantPink, fontSize = if (isAdd) 26.sp else 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = Plum, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun ProfileTab(title: String, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(icon, contentDescription = title, tint = if (selected) VibrantPink else TextSecondary, modifier = Modifier.size(20.dp))
        Text(title, color = if (selected) VibrantPink else TextSecondary, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
        Box(Modifier.fillMaxWidth().height(2.dp).background(if (selected) VibrantPink else Color.Transparent))
    }
}

@Composable
private fun ProfileGridTile(post: SocialPost, viewModel: BaatlyViewModel, modifier: Modifier = Modifier) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket) {
        val raw = post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket).takeIf { it.isNotBlank() }
    }
    Box(modifier.height(132.dp).background(Color(0xFFE9DFE4)).clickable(enabled = !mediaUrl.isNullOrBlank()) {
        if (!mediaUrl.isNullOrBlank()) viewModel.openFullScreenMedia(mediaUrl!!, post.mediaType)
    }) {
        AsyncImage(model = mediaUrl, contentDescription = post.caption, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        if (post.mediaType.equals("video", true)) {
            Icon(Icons.Filled.PlayCircleOutline, contentDescription = "Video", tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp))
        }
    }
}
