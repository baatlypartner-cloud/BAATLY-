# BAATLY v48.6.2 — Experimental Layout API Build Fix

## Reported build error

The supplied GitHub Actions screenshot identifies this Kotlin compiler diagnostic:

`MainActivity.kt:299:69 The API of this layout is experimental and is likely to change in the future.`

The failing expression is `WindowInsets.isImeVisible` inside `BaatlyApp`. This property is covered by Compose Foundation's `ExperimentalLayoutApi`. `DirectChatScreen.kt` already uses the same API under `@OptIn(ExperimentalLayoutApi::class)`, while `BaatlyApp` did not opt in.

## Code change

- Added explicit import: `androidx.compose.foundation.layout.ExperimentalLayoutApi`.
- Added `@OptIn(ExperimentalLayoutApi::class)` to the `BaatlyApp` composable.
- Kept the IME visibility behavior unchanged; the bottom navigation still hides while the keyboard is visible.
- Preserved the existing `TextAlign` and `ImageIcon` fixes from the v48.6.1 source.
- Preserved app version metadata: versionName `1.0.48`, versionCode `48`.

## Source audit performed

- Scanned all 65 Kotlin files under `app/src/main/java` for IME/experimental layout call sites.
- Confirmed `MainActivity.BaatlyApp` now opts in.
- Confirmed `DirectChatScreen` already opts in for `WindowInsets.isImeVisible` and `imeNestedScroll()`.
- Parsed 10 XML files, 5 JSON files and 1 TOML file successfully.
- Verified the input v48.6.1 ZIP archive integrity before patching.
- Verified the output ZIP archive integrity after packaging.

## Build verification limitation

A complete Android `compileReleaseKotlin` / Release APK build was not verified in this environment. The Gradle 9.3.1 wrapper distribution is not present locally and the Android SDK is not configured here; earlier wrapper download attempts failed at DNS resolution. Static checks are not a substitute for a successful Gradle build. The specific ExperimentalLayoutApi diagnostic shown in the screenshot is addressed by the opt-in annotation.
