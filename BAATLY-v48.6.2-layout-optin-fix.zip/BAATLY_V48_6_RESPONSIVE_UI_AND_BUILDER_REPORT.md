# BAATLY v48.6 – Responsive UI, Super AI Artwork & Builder Workspace

## Changes applied

### Super AI home
- Replaced the generic sparkle-only hero with a custom neon robot artwork asset (`super_ai_hero.webp`).
- Reworked feature cards with gradient icon backplates, glow borders, sparkle accents and responsive compact layouts.
- Added width-aware compact top actions for History and New Chat on narrow phones.
- Styled quick tools with illuminated icon tiles.

### Android App Builder and Web App Builder
- Rebuilt the mobile workspace around the reference structure: Chat / Files / Preview tabs, project selector, saved-state indicator, Create / Upload Project panel, prompt templates, preview status, actual project-file controls and ZIP export.
- New Project calls the existing workspace-creation API.
- Upload Existing ZIP uses the existing extraction/upload flow to Cloudflare R2.
- Files tab reads the actual saved workspace file list and opens stored source files.
- Web Preview uses the existing restricted static `index.html` preview endpoint.
- Android preview clearly states that emulator/Gradle APK execution requires the secure build runner; it does not fabricate an app preview.
- Chat composer remains pinned at the bottom and sends prompts through the existing workspace edit endpoint.

### Keyboard and edge-to-edge behavior
- Super AI root now applies IME insets and no longer adds a second navigation-bar inset on top of the app Scaffold's bottom navigation inset.
- Main navigation is hidden while the IME is visible, leaving the chat composer directly above the keyboard.
- The Activity already uses `adjustResize` and edge-to-edge window configuration; screen-level safe drawing padding is retained.
- Social Camera / Video / Create Post tiles switch to a stacked compact presentation on narrow phones to prevent word-by-word clipping.
- Bottom navigation labels reduced slightly to retain readability inside five equal-width items.

### Version
- `versionCode`: 48
- `versionName`: 1.0.48

## Validation
- Kotlin parser pass: no syntax/parse diagnostics in the four edited Kotlin files. The standalone Kotlin compiler invocation cannot type-check Android/Compose code because its Android and Compose classpaths are not installed in this environment.
- Explicit Material icon usages/import aliases audited in the changed screens; no unmatched icon aliases found.
- XML, JSON, TOML and drawable reference checks recorded alongside archive validation.
- ZIP integrity test required before delivery.

## Build limitation
A real Gradle Release compile could not be executed: Gradle Wrapper attempted to download `gradle-9.3.1-bin.zip`, but DNS resolution for `services.gradle.org` failed (`UnknownHostException`). No Android SDK platform is installed in this runtime. Therefore this package is a source ZIP; successful APK compilation has not been verified here.
