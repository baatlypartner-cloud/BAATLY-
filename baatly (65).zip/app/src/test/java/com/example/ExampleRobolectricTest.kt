package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.SessionManager
import com.example.data.model.AuthState
import com.example.data.model.SessionResult
import com.example.data.network.SupabaseClient
import com.example.domain.BillingEngine
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun read_app_name_from_context() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Baatly", appName)
    }

    @Test
    fun test_billing_engine_call_calculations() {
        // 0 balance -> 0 max duration
        assertEquals(0, BillingEngine.calculateMaxCallDurationSeconds(0))
        assertEquals(0, BillingEngine.calculateMaxCallDurationSeconds(5))

        // 6 coins -> 60s (1 min)
        assertEquals(60, BillingEngine.calculateMaxCallDurationSeconds(6))

        // 18 coins -> 180s (3 min)
        assertEquals(180, BillingEngine.calculateMaxCallDurationSeconds(18))

        // User coins: 6 coins per started minute
        assertEquals(0, BillingEngine.calculateUserCallCostCoins(0))
        assertEquals(6, BillingEngine.calculateUserCallCostCoins(1))
        assertEquals(6, BillingEngine.calculateUserCallCostCoins(59))
        assertEquals(6, BillingEngine.calculateUserCallCostCoins(60))
        assertEquals(12, BillingEngine.calculateUserCallCostCoins(61))
    }

    @Test
    fun test_forbidden_number_moderation() {
        assertTrue(BillingEngine.containsForbiddenNumberContent("call me at 9876543210"))
        assertTrue(BillingEngine.containsForbiddenNumberContent("my number is 9 8 7 6 5 4 3 2 1 0"))
        assertTrue(BillingEngine.containsForbiddenNumberContent("reach me on nine eight seven six five four three two one zero"))
        assertFalse(BillingEngine.containsForbiddenNumberContent("Hello, how are you? Let's chat."))
    }

    @Test
    fun test_session_manager_atomic_save_and_rotation() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)

        sessionManager.clearSession()
        assertNull(sessionManager.accessToken.value)
        assertNull(sessionManager.refreshToken.value)
        assertEquals(AuthState.Unauthenticated, sessionManager.authState.value)

        // Save session
        sessionManager.saveSession("token_A", "user_123", refreshToken = "refresh_A")
        assertEquals("token_A", sessionManager.accessToken.value)
        assertEquals("refresh_A", sessionManager.refreshToken.value)
        assertEquals("user_123", sessionManager.userId.value)
        assertTrue(sessionManager.isLoggedIn)

        // Rotate tokens atomically
        sessionManager.saveSession("token_B", "user_123", refreshToken = "refresh_B")
        assertEquals("token_B", sessionManager.accessToken.value)
        assertEquals("refresh_B", sessionManager.refreshToken.value)
    }

    @Test
    fun test_ensure_valid_session_single_flight_simulation() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)
        sessionManager.clearSession()

        // Create a valid mock unexpired JWT
        // Header: {"alg":"none"} -> eyJhbGciOiJub25lIn0
        // Payload: {"exp": 253402300799, "sub": "test_user"} -> eyJleHAiOjI1MzQwMjMwMDc5OSwic3ViIjoidGVzdF91c2VyIn0
        val mockValidJwt = "eyJhbGciOiJub25lIn0.eyJleHAiOjI1MzQwMjMwMDc5OSwic3ViIjoidGVzdF91c2VyIn0."
        sessionManager.saveSession(mockValidJwt, "test_user", refreshToken = "valid_refresh_token")

        val client = SupabaseClient(sessionManager)

        // Launch 10 concurrent requests to ensureValidSession()
        val deferredList = (1..10).map {
            async {
                client.ensureValidSession()
            }
        }

        val results = deferredList.awaitAll()
        assertEquals(10, results.size)
        results.forEach { res ->
            assertTrue(res is SessionResult.Valid)
            assertEquals(mockValidJwt, (res as SessionResult.Valid).accessToken)
            assertEquals("test_user", res.userId)
        }
    }
}

