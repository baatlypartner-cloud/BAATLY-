package com.example.ui.chat

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ChatMessage
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DirectChatScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val partner by viewModel.chatPartner.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isBlocked by viewModel.isChatBlocked.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val wallet by viewModel.wallet.collectAsState()

    val isRecording by viewModel.audioRecorderManager.isRecording.collectAsState()
    val currentlyPlayingUrl by viewModel.audioPlayerManager.currentlyPlayingUrl.collectAsState()
    val isAudioPlaying by viewModel.audioPlayerManager.isPlaying.collectAsState()

    var messageText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }

    // Voice recording preview state
    var recordedVoiceFile by remember { mutableStateOf<File?>(null) }
    var recordedVoiceDuration by remember { mutableStateOf(0) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val isImeVisible = WindowInsets.isImeVisible

    // Image Picker Launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val tempFile = File(context.cacheDir, "chat_img_${System.currentTimeMillis()}.jpg")
                    tempFile.outputStream().use { output ->
                        inputStream?.copyTo(output)
                    }
                    viewModel.sendImageMessage(tempFile)
                } catch (e: Exception) {
                    viewModel.showMessage("Failed to load selected photo")
                }
            }
        }
    }

    BackHandler {
        viewModel.closeChatScreen()
    }

    LaunchedEffect(Unit) {
        viewModel.ensureChatLoaded()
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    LaunchedEffect(isImeVisible) {
        if (isImeVisible && messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val host = partner
    val hostDisplayName = host?.displayName?.takeIf { it.isNotBlank() && it != "Host" && it != "Baatly Host" }
        ?: host?.displayName?.takeIf { it.isNotBlank() }
        ?: "Host"

    val resolvedHostAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(host?.avatarUrl, viewModel.dataService)
    val isResolvingHostAvatar = !host?.avatarUrl.isNullOrBlank() && host?.avatarUrl != "null" && resolvedHostAvatarUrl == null

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(HostAvatarGradient)
                                .border(1.5.dp, if (host?.isOnline == true) OnlineGreen else DarkCardBorder, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!resolvedHostAvatarUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = resolvedHostAvatarUrl,
                                    contentDescription = hostDisplayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else if (isResolvingHostAvatar) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = PrimaryLavender,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = (hostDisplayName.take(1)).uppercase(),
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color.White.copy(alpha = 0.8f),
                                        fontSize = 16.sp
                                    )
                                )
                            }
                        }
                        Column {
                            Text(
                                text = hostDisplayName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = if (host?.isOnline == true) "Online" else if (host != null) "Offline" else "",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (host?.isOnline == true) OnlineGreen else TextTertiary
                                )
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.closeChatScreen() },
                        modifier = Modifier.testTag("btn_back_direct_chat")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    // Refresh Chat Button
                    IconButton(
                        onClick = { viewModel.refreshCurrentChat() },
                        modifier = Modifier.testTag("btn_chat_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh Chat",
                            tint = TextSecondary
                        )
                    }

                    // Call Shortcut
                    if (host != null) {
                        IconButton(
                            onClick = { viewModel.requestCall(host) },
                            modifier = Modifier.testTag("btn_chat_header_call")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Call,
                                contentDescription = "Call Host",
                                tint = PrimaryLavender
                            )
                        }
                    }

                    // Three-dot Menu
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("btn_chat_menu")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MoreVert,
                            contentDescription = "Options",
                            tint = TextPrimary
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(DarkSurfaceVariant)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Clear Chat", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = TextSecondary) },
                            onClick = {
                                showMenu = false
                                viewModel.clearCurrentConversation()
                            },
                            modifier = Modifier.testTag("menu_clear_chat")
                        )
                        if (isBlocked) {
                            DropdownMenuItem(
                                text = { Text("Unblock Host", color = PrimaryLavender) },
                                leadingIcon = { Icon(Icons.Filled.LockOpen, contentDescription = null, tint = PrimaryLavender) },
                                onClick = {
                                    showMenu = false
                                    viewModel.unblockCurrentHost()
                                },
                                modifier = Modifier.testTag("menu_unblock_host")
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("Block Host", color = DangerRed) },
                                leadingIcon = { Icon(Icons.Filled.Block, contentDescription = null, tint = DangerRed) },
                                onClick = {
                                    showMenu = false
                                    viewModel.blockCurrentHost()
                                },
                                modifier = Modifier.testTag("menu_block_host")
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        contentWindowInsets = WindowInsets.statusBars,
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding())
                .consumeWindowInsets(innerPadding)
                .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
        ) {
            // Rate Information Bar
            Surface(
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Chat Rate: 3 coins/message",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )
                    Text(
                        text = "Balance: ${wallet?.balance ?: 0} coins",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SecondaryAmberLight,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // Message List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .imeNestedScroll(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val myId = viewModel.sessionManager.userId.value ?: currentUser?.id ?: currentUser?.userId
                    val isMe = msg.senderId == myId || (myId != null && msg.senderId == myId)
                    MessageBubble(
                        message = msg,
                        isMe = isMe,
                        isPlaying = isAudioPlaying && currentlyPlayingUrl == msg.mediaUrl,
                        onPlayVoice = { rawUrl -> viewModel.playVoiceMessage(rawUrl) },
                        viewModel = viewModel
                    )
                }
            }

            // Composer Area
            if (isBlocked) {
                val activeConv = viewModel.activeConversation.collectAsState().value
                val isHostBlocked = activeConv?.partnerBlocked == true
                Surface(
                    color = DarkSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isHostBlocked) "You cannot message this host." else "Host is blocked.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = DangerRed),
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (!isHostBlocked) {
                            TextButton(
                                onClick = { viewModel.unblockCurrentHost() },
                                modifier = Modifier.testTag("btn_unblock_host")
                            ) {
                                Text("Unblock", color = PrimaryLavender, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else if (recordedVoiceFile != null) {
                // Voice Note Preview Bar
                Surface(
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = {
                                recordedVoiceFile?.delete()
                                recordedVoiceFile = null
                                recordedVoiceDuration = 0
                            },
                            modifier = Modifier.testTag("btn_discard_voice")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Discard Voice Note",
                                tint = DangerRed
                            )
                        }

                        IconButton(
                            onClick = {
                                recordedVoiceFile?.let {
                                    viewModel.audioPlayerManager.play(it.absolutePath)
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(PrimaryLavender)
                        ) {
                            Icon(
                                imageVector = if (isAudioPlaying && currentlyPlayingUrl == recordedVoiceFile?.absolutePath) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = "Preview",
                                tint = Color(0xFF1C1C22)
                            )
                        }

                        Text(
                            text = "Voice Note (${recordedVoiceDuration}s)",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                val file = recordedVoiceFile
                                val duration = recordedVoiceDuration
                                recordedVoiceFile = null
                                recordedVoiceDuration = 0
                                if (file != null) {
                                    viewModel.sendVoiceMessage(file, duration)
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(PrimaryLavender)
                                .testTag("btn_send_voice_preview")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send Voice Note",
                                tint = Color(0xFF1C1C22),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            } else if (isRecording) {
                // Active Recording Bar
                Surface(
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.audioRecorderManager.cancelRecording() },
                            modifier = Modifier.testTag("btn_cancel_recording")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Cancel Recording",
                                tint = TextTertiary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                        )

                        Text(
                            text = "Recording audio note...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = DangerRed,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                val (file, duration) = viewModel.audioRecorderManager.stopRecording()
                                if (file != null) {
                                    recordedVoiceFile = file
                                    recordedVoiceDuration = duration
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                                .testTag("btn_stop_recording")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Stop,
                                contentDescription = "Stop Recording",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            } else {
                // Standard Composer
                Surface(
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Image / Photo Picker Button
                        IconButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("btn_chat_image")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Photo,
                                contentDescription = "Send Photo",
                                tint = PrimaryLavender,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Gift Button
                        IconButton(
                            onClick = { viewModel.toggleGiftSheet(true) },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("btn_chat_gift")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CardGiftcard,
                                contentDescription = "Send Gift",
                                tint = SecondaryAmber,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Text Field
                        TextField(
                            value = messageText,
                            onValueChange = { messageText = it },
                            placeholder = {
                                Text(
                                    text = "Type message...",
                                    color = TextTertiary,
                                    fontSize = 14.sp
                                )
                            },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = DarkSurfaceVariant,
                                unfocusedContainerColor = DarkSurfaceVariant,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                cursorColor = PrimaryLavender
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 44.dp, max = 100.dp)
                                .testTag("chat_input_field")
                        )

                        // Voice or Send button
                        if (messageText.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    val textToSend = messageText
                                    messageText = ""
                                    viewModel.sendTextMessage(textToSend) { success ->
                                        if (!success) {
                                            if (messageText.isBlank()) {
                                                messageText = textToSend
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryLavender)
                                    .testTag("btn_chat_send")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = Color(0xFF1C1C22),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    viewModel.audioRecorderManager.startRecording()
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(DarkSurfaceVariant)
                                    .testTag("btn_chat_voice_record")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Mic,
                                    contentDescription = "Record Voice Note",
                                    tint = PrimaryLavender,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: ChatMessage,
    isMe: Boolean,
    isPlaying: Boolean,
    onPlayVoice: (String) -> Unit,
    viewModel: BaatlyViewModel
) {
    val resolvedImageUrl by produceState<String?>(initialValue = message.mediaUrl, key1 = message.mediaUrl) {
        val raw = message.mediaUrl
        if (!raw.isNullOrBlank()) {
            value = viewModel.dataService.getSignedMediaUrl(raw, com.example.data.network.SupabaseConfig.BUCKET_CHAT_MEDIA)
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMe) 16.dp else 4.dp,
                bottomEnd = if (isMe) 4.dp else 16.dp
            ),
            color = if (isMe) PrimaryLavenderContainer else DarkSurfaceVariant,
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isMe) DarkBorderSubtle else DarkCardBorder),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (!message.replyToStoryId.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.25f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.History,
                                contentDescription = null,
                                tint = PrimaryLavender,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Replied to story",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = PrimaryLavender,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }

                when (message.messageType) {
                    "image" -> {
                        AsyncImage(
                            model = resolvedImageUrl ?: message.mediaUrl,
                            contentDescription = "Shared Photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                    }
                    "voice" -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(
                                onClick = { message.mediaUrl?.let { onPlayVoice(it) } },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isMe) PrimaryLavender else SecondaryAmber)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = "Play Voice Note",
                                    tint = if (isMe) Color(0xFF1C1C22) else Color.Black,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Voice Note (${message.mediaDurationSeconds ?: 0}s)",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "Audio message",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                )
                            }
                        }
                    }
                    "gift" -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = DarkBackground,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (!message.gift?.iconUrl.isNullOrBlank()) {
                                        AsyncImage(
                                            model = message.gift?.iconUrl,
                                            contentDescription = message.gift?.name,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Filled.CardGiftcard,
                                            contentDescription = "Gift",
                                            tint = SecondaryAmber,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }
                            Column {
                                Text(
                                    text = "Sent ${message.gift?.name ?: "Gift"}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = SecondaryAmberLight,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "${message.gift?.coinPrice ?: 10} Coins",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                )
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = message.content ?: "",
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color.White)
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = message.createdAt ?: "",
            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary, fontSize = 9.sp),
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}
