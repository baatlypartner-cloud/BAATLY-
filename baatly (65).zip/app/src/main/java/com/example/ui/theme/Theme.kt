package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BaatlyColorScheme = darkColorScheme(
    primary = VibrantPink,
    onPrimary = Color.White,
    primaryContainer = PrimaryLavenderContainer,
    onPrimaryContainer = Color.White,
    secondary = SecondaryAmber,
    onSecondary = Color(0xFF1B1402),
    secondaryContainer = Color(0xFF382905),
    onSecondaryContainer = SecondaryAmberLight,
    tertiary = NeonCyan,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkCardBorder,
    outlineVariant = DarkBorderSubtle,
    error = DangerRed,
    onError = Color.White
)

@Composable
fun BaatlyTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = BaatlyColorScheme,
        typography = Typography,
        content = content
    )
}

