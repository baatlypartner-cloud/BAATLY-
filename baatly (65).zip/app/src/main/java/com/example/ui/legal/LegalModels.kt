package com.example.ui.legal

enum class LegalPage(
    val title: String,
    val menuLabel: String,
    val subtitle: String? = null,
    val lastUpdated: String? = "08/08/2026"
) {
    ABOUT_BAATLY(
        title = "About Baatly",
        menuLabel = "About Baatly",
        subtitle = "Connect. Talk. Share.",
        lastUpdated = "08/08/2026"
    ),
    SAFETY_SECURITY(
        title = "Safety & Security",
        menuLabel = "Safety & Security",
        subtitle = "Community Guidelines",
        lastUpdated = "08/08/2026"
    ),
    REFUND_CANCELLATION(
        title = "Refund & Cancellation Policy",
        menuLabel = "Refund & Cancellation",
        subtitle = null,
        lastUpdated = "08/08/2026"
    ),
    TERMS_CONDITIONS(
        title = "Terms & Conditions",
        menuLabel = "Terms & Conditions",
        subtitle = null,
        lastUpdated = "08/08/2026"
    ),
    PRIVACY_POLICY(
        title = "Privacy Policy",
        menuLabel = "Privacy Policy",
        subtitle = null,
        lastUpdated = "08/08/2026"
    )
}

data class LegalSection(
    val heading: String? = null,
    val intro: String? = null,
    val bullets: List<String> = emptyList(),
    val outro: String? = null
)

data class LegalPageContent(
    val page: LegalPage,
    val openingText: String? = null,
    val sections: List<LegalSection>,
    val closingText: String? = null
)
