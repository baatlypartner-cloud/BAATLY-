package com.example.data.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.model.AgoraTokenResponse
import com.example.data.network.SupabaseConfig
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AgoraCallManager(private val context: Context?) {

    private val tag = "AgoraCallManager"
    private var rtcEngine: RtcEngine? = null
    private val audioManager = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isSpeakerOn = MutableStateFlow(true)
    val isSpeakerOn: StateFlow<Boolean> = _isSpeakerOn.asStateFlow()

    private val _isInChannel = MutableStateFlow(false)
    val isInChannel: StateFlow<Boolean> = _isInChannel.asStateFlow()

    private val _remoteUserJoined = MutableStateFlow(false)
    val remoteUserJoined: StateFlow<Boolean> = _remoteUserJoined.asStateFlow()

    private val _remoteAudioPlaying = MutableStateFlow(false)
    val remoteAudioPlaying: StateFlow<Boolean> = _remoteAudioPlaying.asStateFlow()

    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            Log.i(tag, "[DIAGNOSTIC] ON_JOIN_CHANNEL_SUCCESS: channel=$channel, uid=$uid, elapsed=$elapsed")
            _isInChannel.value = true
            setSpeakerphoneOn(true)
        }

        override fun onUserJoined(uid: Int, elapsed: Int) {
            Log.i(tag, "[DIAGNOSTIC] REMOTE_USER_JOINED: uid=$uid, elapsed=$elapsed")
            _remoteUserJoined.value = true
            try {
                rtcEngine?.muteRemoteAudioStream(uid, false)
                rtcEngine?.adjustUserPlaybackSignalVolume(uid, 100)
            } catch (e: Exception) {
                Log.e(tag, "Error configuring remote audio stream for uid=$uid: ${e.message}")
            }
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            Log.i(tag, "Remote user offline: uid=$uid, reason=$reason")
            _remoteUserJoined.value = false
            _remoteAudioPlaying.value = false
        }

        override fun onRemoteAudioStateChanged(uid: Int, state: Int, reason: Int, elapsed: Int) {
            val stateName = when (state) {
                Constants.REMOTE_AUDIO_STATE_STOPPED -> "STOPPED (0)"
                Constants.REMOTE_AUDIO_STATE_STARTING -> "STARTING (1)"
                Constants.REMOTE_AUDIO_STATE_DECODING -> "DECODING/PLAYING (2)"
                Constants.REMOTE_AUDIO_STATE_FROZEN -> "FROZEN (3)"
                Constants.REMOTE_AUDIO_STATE_FAILED -> "FAILED (4)"
                else -> "UNKNOWN ($state)"
            }
            val reasonName = when (reason) {
                Constants.REMOTE_AUDIO_REASON_INTERNAL -> "INTERNAL (0)"
                Constants.REMOTE_AUDIO_REASON_NETWORK_CONGESTION -> "NETWORK_CONGESTION (1)"
                Constants.REMOTE_AUDIO_REASON_NETWORK_RECOVERY -> "NETWORK_RECOVERY (2)"
                Constants.REMOTE_AUDIO_REASON_LOCAL_MUTED -> "LOCAL_MUTED (3)"
                Constants.REMOTE_AUDIO_REASON_LOCAL_UNMUTED -> "LOCAL_UNMUTED (4)"
                Constants.REMOTE_AUDIO_REASON_REMOTE_MUTED -> "REMOTE_MUTED (5)"
                Constants.REMOTE_AUDIO_REASON_REMOTE_UNMUTED -> "REMOTE_UNMUTED (6)"
                Constants.REMOTE_AUDIO_REASON_REMOTE_OFFLINE -> "REMOTE_OFFLINE (7)"
                else -> "REASON ($reason)"
            }

            Log.i(tag, "[DIAGNOSTIC] REMOTE_AUDIO_STATE: uid=$uid, state=$stateName, reason=$reasonName, elapsed=$elapsed")

            when (state) {
                Constants.REMOTE_AUDIO_STATE_DECODING -> {
                    Log.i(tag, "[DIAGNOSTIC] REMOTE_AUDIO_PLAYING: uid=$uid audio is now decoding and playing successfully")
                    _remoteAudioPlaying.value = true
                }
                Constants.REMOTE_AUDIO_STATE_STOPPED -> {
                    Log.w(tag, "[DIAGNOSTIC] REMOTE_AUDIO_STOPPED: uid=$uid audio stopped, reason=$reasonName")
                    _remoteAudioPlaying.value = false
                }
                Constants.REMOTE_AUDIO_STATE_FAILED -> {
                    Log.e(tag, "[DIAGNOSTIC] REMOTE_AUDIO_ERROR: uid=$uid audio failed, reason=$reasonName")
                    _remoteAudioPlaying.value = false
                }
            }
        }

        override fun onAudioRouteChanged(routing: Int) {
            val routeDesc = when (routing) {
                -1 -> "DEFAULT (-1)"
                0 -> "HEADSET (0)"
                1 -> "EARPIECE (1)"
                2 -> "HEADSET_NO_MIC (2)"
                3 -> "SPEAKERPHONE (3)"
                4 -> "LOUDSPEAKER (4)"
                5 -> "BLUETOOTH (5)"
                else -> "ROUTE ($routing)"
            }
            Log.i(tag, "[DIAGNOSTIC] Audio route changed to: $routeDesc")
            _isSpeakerOn.value = (routing == 3 || routing == 4)
        }

        override fun onUserMuteAudio(uid: Int, muted: Boolean) {
            Log.i(tag, "[DIAGNOSTIC] Remote user uid=$uid mute state changed: muted=$muted")
        }

        override fun onLeaveChannel(stats: RtcStats?) {
            Log.i(tag, "Left Agora channel")
            _isInChannel.value = false
            _remoteUserJoined.value = false
            _remoteAudioPlaying.value = false
        }

        override fun onError(err: Int) {
            Log.e(tag, "[DIAGNOSTIC] Agora RTC onError: code=$err")
        }
    }

    private fun checkMicPermission(): Boolean {
        val ctx = context ?: return false
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        Log.i(tag, "[DIAGNOSTIC] LOCAL_MIC_PERMISSION: ${if (granted) "GRANTED" else "DENIED"}")
        return granted
    }

    private fun setupRtcEngine() {
        if (rtcEngine != null) return
        val appContext = context?.applicationContext ?: context ?: run {
            Log.w(tag, "Context is null, skipping Agora setup")
            return
        }
        val appId = SupabaseConfig.agoraAppId
        if (appId.isBlank()) {
            Log.w(tag, "Agora App ID is empty, skipping Agora setup")
            return
        }
        try {
            val config = RtcEngineConfig().apply {
                mContext = appContext
                mAppId = appId
                mEventHandler = rtcEventHandler
                mChannelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                mAudioScenario = Constants.AUDIO_SCENARIO_DEFAULT
            }
            rtcEngine = RtcEngine.create(config)
            Log.i(tag, "[DIAGNOSTIC] AUDIO_ENGINE_CREATED: status=${rtcEngine != null}")

            rtcEngine?.let { engine ->
                val enableAudioRes = engine.enableAudio()
                Log.i(tag, "[DIAGNOSTIC] ENABLE_AUDIO_RESULT: code=$enableAudioRes")
                if (enableAudioRes != 0) {
                    Log.e(tag, "[DIAGNOSTIC] Agora enableAudio() returned error code $enableAudioRes")
                }

                val enableLocalAudioRes = engine.enableLocalAudio(true)
                Log.i(tag, "[DIAGNOSTIC] LOCAL_AUDIO_ENABLED: code=$enableLocalAudioRes")

                engine.setDefaultAudioRoutetoSpeakerphone(true)
                val speakerRes = engine.setEnableSpeakerphone(true)
                Log.i(tag, "[DIAGNOSTIC] SPEAKERPHONE_STATE: result=$speakerRes, on=true")

                val muteRes = engine.muteLocalAudioStream(false)
                _isMuted.value = false
                Log.i(tag, "[DIAGNOSTIC] LOCAL_AUDIO_MUTED: false (result=$muteRes)")

                engine.adjustPlaybackSignalVolume(100)
                engine.adjustRecordingSignalVolume(100)
            }
        } catch (e: Throwable) {
            Log.e(tag, "Failed to initialize Agora RtcEngine: ${e.message}", e)
        }
    }

    fun joinChannel(tokenResponse: AgoraTokenResponse, channelName: String) {
        if (rtcEngine == null) {
            setupRtcEngine()
        }

        checkMicPermission()

        try {
            val engine = rtcEngine ?: run {
                Log.e(tag, "[DIAGNOSTIC] RtcEngine is null, cannot join channel")
                return
            }

            // Ensure audio is enabled and local microphone is active
            val enableAudioRes = engine.enableAudio()
            Log.i(tag, "[DIAGNOSTIC] ENABLE_AUDIO_RESULT: code=$enableAudioRes")

            val enableLocalRes = engine.enableLocalAudio(true)
            Log.i(tag, "[DIAGNOSTIC] LOCAL_AUDIO_ENABLED: code=$enableLocalRes")

            engine.muteLocalAudioStream(false)
            _isMuted.value = false
            Log.i(tag, "[DIAGNOSTIC] LOCAL_AUDIO_MUTED: false")

            val options = ChannelMediaOptions().apply {
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                autoSubscribeAudio = true
                publishMicrophoneTrack = true
            }

            val uid = tokenResponse.uid?.toInt() ?: 0
            val token = tokenResponse.token.takeIf { !it.isNullOrBlank() }

            val joinRes = engine.joinChannel(token, channelName, uid, options)
            Log.i(tag, "[DIAGNOSTIC] JOIN_CHANNEL_RESULT: code=$joinRes, channel=$channelName, uid=$uid")

            setSpeakerphoneOn(true)
        } catch (e: Exception) {
            Log.e(tag, "Error joining Agora channel: ${e.message}", e)
        }
    }

    fun leaveChannel() {
        try {
            rtcEngine?.leaveChannel()
        } catch (e: Exception) {
            Log.e(tag, "Error leaving channel: ${e.message}", e)
        }
        _isInChannel.value = false
        _remoteUserJoined.value = false
        _remoteAudioPlaying.value = false
        try {
            audioManager?.mode = AudioManager.MODE_NORMAL
            audioManager?.isSpeakerphoneOn = false
        } catch (_: Exception) {}
    }

    fun toggleMute() {
        val newMute = !_isMuted.value
        _isMuted.value = newMute
        try {
            val res = rtcEngine?.muteLocalAudioStream(newMute) ?: -1
            Log.i(tag, "[DIAGNOSTIC] LOCAL_AUDIO_MUTED: $newMute (result=$res)")
        } catch (e: Exception) {
            Log.e(tag, "Error toggling mute: ${e.message}")
        }
    }

    fun toggleSpeaker() {
        val newSpeaker = !_isSpeakerOn.value
        setSpeakerphoneOn(newSpeaker)
    }

    fun setSpeakerphoneOn(on: Boolean) {
        _isSpeakerOn.value = on
        try {
            val res = rtcEngine?.setEnableSpeakerphone(on) ?: -1
            Log.i(tag, "[DIAGNOSTIC] SPEAKERPHONE_STATE: result=$res, on=$on")
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager?.isSpeakerphoneOn = on
        } catch (e: Exception) {
            Log.e(tag, "Error setting speakerphone: ${e.message}")
        }
    }

    fun destroy() {
        try {
            leaveChannel()
            RtcEngine.destroy()
            rtcEngine = null
        } catch (e: Exception) {
            Log.e(tag, "Error destroying RtcEngine: ${e.message}")
        }
    }
}


