package com.example.data.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {

    const val CHANNEL_ID_NOTIFICATIONS = "baatly_notifications"
    const val CHANNEL_NAME_NOTIFICATIONS = "Baatly Notifications"
    const val CHANNEL_DESC_NOTIFICATIONS = "Notifications for Baatly messages, updates, and interactions"

    const val CHANNEL_ID_CALLS = "baatly_calls"
    const val CHANNEL_NAME_CALLS = "Baatly Calls"
    const val CHANNEL_DESC_CALLS = "Notifications for incoming and active voice calls"

    @Volatile
    var isAppInForeground: Boolean = false

    @Volatile
    var activeConversationId: String? = null

    @Volatile
    var currentScreenName: String? = null

    // Deduplication tracking: key -> timestamp
    private val recentNotificationTimestamps = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun isRawUuid(str: String?): Boolean {
        if (str.isNullOrBlank()) return false
        return str.matches(Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
    }

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

            // 1. General App & Chat Notifications Channel
            val generalChannel = NotificationChannel(
                CHANNEL_ID_NOTIFICATIONS,
                CHANNEL_NAME_NOTIFICATIONS,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESC_NOTIFICATIONS
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(generalChannel)

            // 2. Call Notifications Channel
            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .build()

            val callsChannel = NotificationChannel(
                CHANNEL_ID_CALLS,
                CHANNEL_NAME_CALLS,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESC_CALLS
                enableLights(true)
                enableVibration(true)
                setSound(defaultSoundUri, audioAttributes)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(callsChannel)
        }
    }

    fun showNotification(
        context: Context,
        title: String?,
        body: String?,
        data: Map<String, String>
    ) {
        createNotificationChannels(context)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return

        val notifType = (data["notification_type"] ?: data["type"] ?: "system").lowercase()
        val conversationId = data["conversation_id"] ?: data["conversationId"]
        val partnerId = data["partner_id"] ?: data["partnerId"] ?: data["sender_id"] ?: data["senderId"] ?: data["creator_id"] ?: data["owner_id"]
        val targetUserId = data["target_user_id"] ?: data["targetUserId"] ?: data["receiver_id"]
        val callId = data["call_id"] ?: data["callId"]
        val storyId = data["story_id"] ?: data["storyId"]
        val postId = data["post_id"] ?: data["postId"]
        val contentId = data["content_id"] ?: data["contentId"] ?: storyId ?: postId
        val contentType = (data["content_type"] ?: data["contentType"] ?: if (storyId != null) "story" else if (postId != null) "post" else "").lowercase()
        val commentId = data["comment_id"] ?: data["commentId"]
        val messageId = data["message_id"] ?: data["messageId"]
        val notificationId = data["notification_id"] ?: data["id"]
        val rawSenderName = data["sender_name"] ?: data["creator_name"] ?: data["display_name"] ?: data["partner_name"] ?: data["host_name"] ?: data["user_name"]
        val senderName = if (!rawSenderName.isNullOrBlank() && !isRawUuid(rawSenderName)) rawSenderName else null

        // 1. Check duplicate notification
        val dedupKey = "$notifType-$conversationId-$callId-$storyId-$postId-$contentId-$messageId-$notificationId"
        val now = System.currentTimeMillis()
        val lastSeen = recentNotificationTimestamps[dedupKey] ?: 0L
        if (now - lastSeen < 3000L) {
            Log.d("NotificationHelper", "Suppressed duplicate notification within 3s window: $dedupKey")
            return
        }
        recentNotificationTimestamps[dedupKey] = now
        // Clean old keys if map grows
        if (recentNotificationTimestamps.size > 50) {
            recentNotificationTimestamps.entries.removeIf { now - it.value > 15000L }
        }

        // 2. Check Foreground Suppression if user is actively on relevant screen
        if (isAppInForeground) {
            if ((notifType == "new_message" || notifType == "chat" || notifType == "story_reply") &&
                !conversationId.isNullOrBlank() && conversationId == activeConversationId) {
                Log.d("NotificationHelper", "Suppressed foreground alert because user is actively inside conversation: $conversationId")
                return
            }
            if ((notifType == "incoming_call" || notifType == "call") && currentScreenName == "ACTIVE_CALL") {
                Log.d("NotificationHelper", "Suppressed foreground call alert because user is in ACTIVE_CALL screen")
                return
            }
        }

        // 3. Resolve Title & Body
        val finalTitle = title?.takeIf { it.isNotBlank() }
            ?: data["title"]?.takeIf { it.isNotBlank() }
            ?: when (notifType) {
                "follow" -> if (senderName != null) "$senderName followed you" else "New Follower"
                "like", "social_like" -> {
                    val label = if (contentType == "story") "story" else "post"
                    if (senderName != null) "$senderName liked your $label" else "New Like"
                }
                "comment", "social_comment" -> {
                    val label = if (contentType == "story") "story" else "post"
                    if (senderName != null) "$senderName commented on your $label" else "New Comment"
                }
                "story_reply" -> if (senderName != null) "Story reply from $senderName" else "New Story Reply"
                "new_post", "social_post" -> if (senderName != null) "New post from $senderName" else "New Post"
                "new_story" -> if (senderName != null) "New story from $senderName" else "New Story"
                "new_message", "chat" -> if (senderName != null) "New message from $senderName" else "New message"
                "incoming_call", "call" -> if (senderName != null) "Incoming call from $senderName" else "Incoming call"
                "gift_received", "gift" -> if (senderName != null) "Gift from $senderName" else "You received a gift"
                "admin" -> "Baatly Update"
                else -> "Baatly"
            }

        val finalBody = body?.takeIf { it.isNotBlank() }
            ?: data["body"]?.takeIf { it.isNotBlank() }
            ?: data["message"]?.takeIf { it.isNotBlank() }
            ?: when (notifType) {
                "follow" -> if (senderName != null) "$senderName started following you." else "Someone started following you."
                "like", "social_like" -> {
                    val label = if (contentType == "story") "story" else "post"
                    if (senderName != null) "$senderName liked your $label." else "Someone liked your $label."
                }
                "comment", "social_comment" -> {
                    val commentText = data["comment"] ?: data["comment_text"] ?: data["text"]
                    if (!commentText.isNullOrBlank()) {
                        if (senderName != null) "$senderName: $commentText" else commentText
                    } else if (senderName != null) {
                        "$senderName commented on your post."
                    } else {
                        "Someone commented on your post."
                    }
                }
                "story_reply" -> {
                    val replyText = data["comment"] ?: data["comment_text"] ?: data["text"] ?: data["message"]
                    if (!replyText.isNullOrBlank()) {
                        if (senderName != null) "$senderName: $replyText" else replyText
                    } else if (senderName != null) {
                        "$senderName replied to your story."
                    } else {
                        "Someone replied to your story."
                    }
                }
                "new_post", "social_post" -> {
                    val caption = data["caption"] ?: data["post_caption"]
                    if (!caption.isNullOrBlank()) {
                        if (senderName != null) "$senderName: $caption" else caption
                    } else if (senderName != null) {
                        "Check out the latest post from $senderName."
                    } else {
                        "A creator you follow shared a new post."
                    }
                }
                "new_story" -> {
                    if (senderName != null) {
                        "$senderName shared a new story."
                    } else {
                        "A creator you follow added a new story."
                    }
                }
                "new_message", "chat" -> "You have a new message."
                "incoming_call", "call" -> if (senderName != null) "$senderName is calling you." else "Someone is calling you."
                "gift_received", "gift" -> if (senderName != null) "$senderName sent you a virtual gift." else "You received a virtual gift."
                else -> ""
            }

        val isCall = notifType == "incoming_call" || notifType == "call"
        val channelId = if (isCall) CHANNEL_ID_CALLS else CHANNEL_ID_NOTIFICATIONS

        // 4. Tap Intent with all payload extras
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("notification_type", notifType)
            putExtra("type", notifType)
            if (!conversationId.isNullOrBlank()) putExtra("conversation_id", conversationId)
            if (!partnerId.isNullOrBlank()) {
                putExtra("partner_id", partnerId)
                putExtra("sender_id", partnerId)
            }
            if (!targetUserId.isNullOrBlank()) putExtra("target_user_id", targetUserId)
            if (!callId.isNullOrBlank()) putExtra("call_id", callId)
            if (!storyId.isNullOrBlank()) putExtra("story_id", storyId)
            if (!postId.isNullOrBlank()) putExtra("post_id", postId)
            if (!contentId.isNullOrBlank()) putExtra("content_id", contentId)
            if (contentType.isNotBlank()) putExtra("content_type", contentType)
            if (!commentId.isNullOrBlank()) putExtra("comment_id", commentId)
            if (!messageId.isNullOrBlank()) putExtra("message_id", messageId)
            if (!notificationId.isNullOrBlank()) putExtra("notification_id", notificationId)
            if (senderName != null) putExtra("sender_name", senderName)
            data.forEach { (k, v) ->
                if (!hasExtra(k)) putExtra(k, v)
            }
        }

        val requestCode = (conversationId?.hashCode() ?: partnerId?.hashCode() ?: callId?.hashCode() ?: notifType.hashCode()) and 0x7FFFFFFF
        val pendingIntent = PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val iconRes = R.mipmap.ic_launcher

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(iconRes)
            .setContentTitle(finalTitle)
            .setContentText(finalBody)
            .setStyle(NotificationCompat.BigTextStyle().bigText(finalBody))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        if (isCall) {
            builder.setCategory(NotificationCompat.CATEGORY_CALL)
            builder.setOngoing(false)
        } else {
            builder.setCategory(NotificationCompat.CATEGORY_MESSAGE)
        }

        val sysNotifId = (notificationId ?: conversationId ?: partnerId ?: callId ?: storyId ?: (System.currentTimeMillis().toString())).hashCode()
        try {
            notificationManager.notify(sysNotifId, builder.build())
            Log.d("NotificationHelper", "Notification displayed: id=$sysNotifId, type=$notifType")
        } catch (e: SecurityException) {
            Log.w("NotificationHelper", "Cannot show notification: POST_NOTIFICATIONS permission not granted")
        } catch (e: Exception) {
            Log.e("NotificationHelper", "Error showing notification: ${e.message}", e)
        }
    }
}
