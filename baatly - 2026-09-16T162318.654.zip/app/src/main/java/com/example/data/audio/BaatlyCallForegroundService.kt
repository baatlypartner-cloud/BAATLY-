package com.example.data.audio

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.notification.NotificationHelper

/**
 * BaatlyCallForegroundService ensures active Agora voice calls continue running
 * with full two-way microphone and remote audio when the app is backgrounded,
 * when the user presses Back, when switching apps, or when the screen is locked.
 */
class BaatlyCallForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "BaatlyCallForegroundService created")
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_CALL
        Log.i(TAG, "onStartCommand: action=$action")

        when (action) {
            ACTION_START_CALL -> {
                val callId = intent?.getStringExtra(EXTRA_CALL_ID)
                val partnerName = intent?.getStringExtra(EXTRA_PARTNER_NAME) ?: "Host"
                startCallForeground(callId, partnerName)
            }
            ACTION_STOP_CALL -> {
                stopCallForeground()
            }
            else -> {
                stopCallForeground()
            }
        }

        return START_NOT_STICKY
    }

    private fun startCallForeground(callId: String?, partnerName: String) {
        NotificationHelper.createNotificationChannels(this)

        val notification = buildOngoingCallNotification(callId, partnerName)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val hasMicPermission = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                val hasCameraPermission = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED

                var serviceType = 0
                if (hasMicPermission) {
                    serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }
                if (hasCameraPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }

                if (serviceType != 0) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        serviceType
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            Log.i(TAG, "Foreground call service active with type")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start foreground service: ${e.message}", e)
            try {
                startForeground(NOTIFICATION_ID, notification)
            } catch (fallbackEx: Exception) {
                Log.e(TAG, "Fallback startForeground failed: ${fallbackEx.message}", fallbackEx)
            }
        }
    }

    private fun buildOngoingCallNotification(callId: String?, partnerName: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_NAVIGATE_TO_CALL, true)
            if (!callId.isNullOrBlank()) {
                putExtra("call_id", callId)
            }
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            NOTIFICATION_ID,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val channelId = NotificationHelper.CHANNEL_ID_CALLS
        val iconRes = R.mipmap.ic_launcher
        val title = "Baatly call"
        val body = if (partnerName.isNotBlank() && partnerName != "Host" && partnerName != "User") {
            "Voice call in progress with $partnerName"
        } else {
            "Voice call in progress"
        }

        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(iconRes)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_menu_call,
                "Return to Call",
                pendingIntent
            )
            .build()
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = powerManager?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "Baatly:ActiveCallWakeLock"
                )?.apply {
                    setReferenceCounted(false)
                    acquire(2 * 60 * 60 * 1000L) // 2 hours max safety timeout
                }
                Log.i(TAG, "WakeLock acquired for background voice call")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error acquiring WakeLock: ${e.message}")
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                    Log.i(TAG, "WakeLock released")
                }
            }
            wakeLock = null
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing WakeLock: ${e.message}")
        }
    }

    private fun stopCallForeground() {
        Log.i(TAG, "Stopping foreground call service")
        releaseWakeLock()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping foreground: ${e.message}")
        }
        stopSelf()
    }

    override fun onDestroy() {
        Log.i(TAG, "BaatlyCallForegroundService destroyed")
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "BaatlyCallFgService"
        const val NOTIFICATION_ID = 8801
        const val ACTION_START_CALL = "com.example.baatly.ACTION_START_CALL"
        const val ACTION_STOP_CALL = "com.example.baatly.ACTION_STOP_CALL"
        const val EXTRA_CALL_ID = "extra_call_id"
        const val EXTRA_PARTNER_NAME = "extra_partner_name"
        const val EXTRA_NAVIGATE_TO_CALL = "extra_navigate_to_call"

        fun start(context: Context, callId: String?, partnerName: String?) {
            try {
                val intent = Intent(context, BaatlyCallForegroundService::class.java).apply {
                    action = ACTION_START_CALL
                    putExtra(EXTRA_CALL_ID, callId)
                    putExtra(EXTRA_PARTNER_NAME, partnerName)
                }
                ContextCompat.startForegroundService(context, intent)
                Log.i(TAG, "start() requested for callId=$callId")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start BaatlyCallForegroundService: ${e.message}", e)
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, BaatlyCallForegroundService::class.java).apply {
                    action = ACTION_STOP_CALL
                }
                context.startService(intent)
                Log.i(TAG, "stop() requested")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to stop BaatlyCallForegroundService: ${e.message}", e)
            }
        }
    }
}
