package com.example.ui.chat

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ChatMessage
import com.example.data.network.AiHostRegistry
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DirectChatScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val partner by viewModel.chatPartner.collectAsState()
    val activeConv by viewModel.activeConversation.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isBlocked by viewModel.isChatBlocked.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val wallet by viewModel.wallet.collectAsState()

    val isRecording by viewModel.audioRecorderManager.isRecording.collectAsState()
    val currentlyPlayingUrl by viewModel.audioPlayerManager.currentlyPlayingUrl.collectAsState()
    val isAudioPlaying by viewModel.audioPlayerManager.isPlaying.collectAsState()

    var messageText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }

    // Voice recording preview state
    var recordedVoiceFile by remember { mutableStateOf<File?>(null) }
    var recordedVoiceDuration by remember { mutableStateOf(0) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val isImeVisible = WindowInsets.isImeVisible

    // Image Picker Launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val tempFile = File(context.cacheDir, "chat_img_${System.currentTimeMillis()}.jpg")
                    tempFile.outputStream().use { output ->
                        inputStream?.copyTo(output)
                    }
                    viewModel.sendImageMessage(tempFile)
                } catch (e: Exception) {
                    viewModel.showMessage("Failed to load selected photo")
                }
            }
        }
    }

    BackHandler {
        viewModel.closeChatScreen()
    }

    LaunchedEffect(Unit) {
        viewModel.ensureChatLoaded()
    }

    val currentUserId = viewModel.sessionManager.userId.value ?: currentUser?.id ?: currentUser?.userId ?: ""

    LaunchedEffect(listState, messages, currentUserId) {
        val convId = activeConv?.id ?: ""
        if (convId.isNotBlank() && currentUserId.isNotBlank()) {
            snapshotFlow {
                val visibleIndices = listState.layoutInfo.visibleItemsInfo.map { it.index }
                visibleIndices.mapNotNull { idx -> messages.getOrNull(idx) }
            }.collect { visibleMessages ->
                val unseenIncomingIds = visibleMessages.filter { msg ->
                    msg.senderId.isNotBlank() && msg.senderId != currentUserId && msg.seenAt.isNullOrBlank()
                }.map { it.id }
                if (unseenIncomingIds.isNotEmpty()) {
                    viewModel.markMessagesSeen(convId, unseenIncomingIds)
                }
            }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    LaunchedEffect(isImeVisible) {
        if (isImeVisible && messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val host = partner
    val hostDisplayName = host?.displayName?.takeIf { it.isNotBlank() && it != "Host" && it != "Baatly Host" }
        ?: host?.displayName?.takeIf { it.isNotBlank() }
        ?: "Host"

    val resolvedHostAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(host?.avatarUrl, viewModel.dataService)
    val isResolvingHostAvatar = !host?.avatarUrl.isNullOrBlank() && host?.avatarUrl != "null" && resolvedHostAvatarUrl == null

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(HostAvatarGradient)
                                .border(1.5.dp, if (host?.isOnline == true) OnlineGreen else Color(0xFFE2DED7), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!resolvedHostAvatarUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = resolvedHostAvatarUrl,
                                    contentDescription = hostDisplayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else if (isResolvingHostAvatar) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color(0xFF00A884),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = (hostDisplayName.take(1)).uppercase(),
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        fontSize = 16.sp
                                    )
                                )
                            }
                        }
                        Column {
                            Text(
                                text = hostDisplayName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF111B21)
                                )
                            )
                            Text(
                                text = if (host?.isOnline == true) "Online" else if (host != null) "Offline" else "",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (host?.isOnline == true) Color(0xFF00A884) else Color(0xFF667781)
                                )
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.closeChatScreen() },
                        modifier = Modifier.testTag("btn_back_direct_chat")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color(0xFF111B21)
                        )
                    }
                },
                actions = {
                    // Refresh Chat Button
                    IconButton(
                        onClick = { viewModel.refreshCurrentChat() },
                        modifier = Modifier.testTag("btn_chat_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh Chat",
                            tint = Color(0xFF54656F)
                        )
                    }

                    // Call Shortcut
                    if (host != null) {
                        IconButton(
                            onClick = {
                                val isAi = AiHostRegistry.isAiHost(host.id) || AiHostRegistry.isAiHost(host.userId)
                                if (isAi) {
                                    viewModel.startAiCall(host)
                                } else {
                                    viewModel.requestCall(host)
                                }
                            },
                            modifier = Modifier.testTag("btn_chat_header_call")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Call,
                                contentDescription = "Call Host",
                                tint = Color(0xFF00A884)
                            )
                        }
                    }

                    // Three-dot Menu
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("btn_chat_menu")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MoreVert,
                            contentDescription = "Options",
                            tint = Color(0xFF111B21)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(Color.White)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Clear Chat", color = Color(0xFF111B21)) },
                            leadingIcon = { Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = Color(0xFF54656F)) },
                            onClick = {
                                showMenu = false
                                viewModel.clearCurrentConversation()
                            },
                            modifier = Modifier.testTag("menu_clear_chat")
                        )
                        DropdownMenuItem(
                            text = { Text("Report User", color = DangerRed) },
                            leadingIcon = { Icon(Icons.Filled.Flag, contentDescription = null, tint = DangerRed) },
                            onClick = {
                                showMenu = false
                                if (host != null) {
                                    val reportedId = host.userId?.takeIf { it.isNotBlank() } ?: host.id
                                    viewModel.openReportDialog(
                                        reportedUserId = reportedId,
                                        targetDisplayName = hostDisplayName
                                    )
                                }
                            },
                            modifier = Modifier.testTag("menu_report_user")
                        )
                        if (isBlocked) {
                            DropdownMenuItem(
                                text = { Text("Unblock Host", color = Color(0xFF00A884)) },
                                leadingIcon = { Icon(Icons.Filled.LockOpen, contentDescription = null, tint = Color(0xFF00A884)) },
                                onClick = {
                                    showMenu = false
                                    viewModel.unblockCurrentHost()
                                },
                                modifier = Modifier.testTag("menu_unblock_host")
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("Block Host", color = DangerRed) },
                                leadingIcon = { Icon(Icons.Filled.Block, contentDescription = null, tint = DangerRed) },
                                onClick = {
                                    showMenu = false
                                    viewModel.blockCurrentHost()
                                },
                                modifier = Modifier.testTag("menu_block_host")
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF7F5F0))
            )
        },
        contentWindowInsets = WindowInsets.statusBars,
        containerColor = WhatsAppChatBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WhatsAppChatBackground)
                .padding(top = innerPadding.calculateTopPadding())
                .consumeWindowInsets(innerPadding)
                .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
        ) {
            // Rate Information Bar
            Surface(
                color = Color(0xFFF0ECE5),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DED7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Chat Rate: 3 coins/message",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF54656F))
                    )
                    Text(
                        text = "Balance: ${wallet?.balance ?: 0} coins",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF00A884),
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // Message List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .imeNestedScroll(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val myId = viewModel.sessionManager.userId.value ?: currentUser?.id ?: currentUser?.userId
                    val isMe = msg.senderId == myId || (myId != null && msg.senderId == myId)
                    MessageBubble(
                        message = msg,
                        isMe = isMe,
                        isPlaying = isAudioPlaying && currentlyPlayingUrl == msg.mediaUrl,
                        onPlayVoice = { rawUrl -> viewModel.playVoiceMessage(rawUrl) },
                        viewModel = viewModel
                    )
                }
            }

            // Composer Area
            if (isBlocked) {
                val activeConvState = viewModel.activeConversation.collectAsState().value
                val isHostBlocked = activeConvState?.partnerBlocked == true
                Surface(
                    color = Color(0xFFF7F5F0),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isHostBlocked) "You cannot message this host." else "Host is blocked.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = DangerRed),
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (!isHostBlocked) {
                            TextButton(
                                onClick = { viewModel.unblockCurrentHost() },
                                modifier = Modifier.testTag("btn_unblock_host")
                            ) {
                                Text("Unblock", color = Color(0xFF00A884), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else if (recordedVoiceFile != null) {
                // Voice Note Preview Bar
                Surface(
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DED7)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = {
                                recordedVoiceFile?.delete()
                                recordedVoiceFile = null
                                recordedVoiceDuration = 0
                            },
                            modifier = Modifier.testTag("btn_discard_voice")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Discard Voice Note",
                                tint = DangerRed
                            )
                        }

                        IconButton(
                            onClick = {
                                recordedVoiceFile?.let {
                                    viewModel.audioPlayerManager.play(it.absolutePath)
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00A884))
                        ) {
                            Icon(
                                imageVector = if (isAudioPlaying && currentlyPlayingUrl == recordedVoiceFile?.absolutePath) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = "Preview",
                                tint = Color.White
                            )
                        }

                        Text(
                            text = "Voice Note (${recordedVoiceDuration}s)",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color(0xFF111B21),
                                fontWeight = FontWeight.SemiBold
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                val file = recordedVoiceFile
                                val duration = recordedVoiceDuration
                                recordedVoiceFile = null
                                recordedVoiceDuration = 0
                                if (file != null) {
                                    viewModel.sendVoiceMessage(file, duration)
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00A884))
                                .testTag("btn_send_voice_preview")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send Voice Note",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            } else if (isRecording) {
                // Active Recording Bar
                Surface(
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.audioRecorderManager.cancelRecording() },
                            modifier = Modifier.testTag("btn_cancel_recording")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Cancel Recording",
                                tint = Color(0xFF667781)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                        )

                        Text(
                            text = "Recording audio note...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = DangerRed,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                val (file, duration) = viewModel.audioRecorderManager.stopRecording()
                                if (file != null) {
                                    recordedVoiceFile = file
                                    recordedVoiceDuration = duration
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                                .testTag("btn_stop_recording")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Stop,
                                contentDescription = "Stop Recording",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            } else {
                // Standard WhatsApp-Style Composer
                Surface(
                    color = Color(0xFFF7F5F0),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DED7)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Image / Photo Picker Button
                        IconButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("btn_chat_image")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Photo,
                                contentDescription = "Send Photo",
                                tint = Color(0xFF54656F),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Gift Button
                        IconButton(
                            onClick = { viewModel.toggleGiftSheet(true) },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("btn_chat_gift")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CardGiftcard,
                                contentDescription = "Send Gift",
                                tint = SecondaryAmber,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Text Field
                        TextField(
                            value = messageText,
                            onValueChange = { messageText = it },
                            placeholder = {
                                Text(
                                    text = "Type message...",
                                    color = Color(0xFF667781),
                                    fontSize = 15.sp
                                )
                            },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = Color(0xFF111B21),
                                unfocusedTextColor = Color(0xFF111B21),
                                cursorColor = Color(0xFF00A884)
                            ),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 44.dp, max = 110.dp)
                                .border(1.dp, Color(0xFFE2DED7), RoundedCornerShape(24.dp))
                                .testTag("chat_input_field")
                        )

                        // Voice or Send button
                        if (messageText.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    val textToSend = messageText
                                    messageText = ""
                                    viewModel.sendTextMessage(textToSend) { success ->
                                        if (!success) {
                                            if (messageText.isBlank()) {
                                                messageText = textToSend
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00A884))
                                    .testTag("btn_chat_send")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    viewModel.audioRecorderManager.startRecording()
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00A884))
                                    .testTag("btn_chat_voice_record")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Mic,
                                    contentDescription = "Record Voice Note",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: ChatMessage,
    isMe: Boolean,
    isPlaying: Boolean,
    onPlayVoice: (String) -> Unit,
    viewModel: BaatlyViewModel
) {
    val resolvedImageUrl by produceState<String?>(initialValue = message.mediaUrl, key1 = message.mediaUrl) {
        val raw = message.mediaUrl?.trim()
        if (raw.isNullOrBlank()) {
            value = null
        } else if (raw.startsWith("http://", ignoreCase = true) || raw.startsWith("https://", ignoreCase = true)) {
            android.util.Log.d("BaatlySecurity", "[AI_IMAGE] loading image URL direct: $raw")
            value = raw
        } else if (raw.contains("neha_") || raw.contains("ai-host-media")) {
            val publicUrl = viewModel.dataService.resolveAiHostMediaUrl(raw)
            android.util.Log.d("BaatlySecurity", "[AI_IMAGE] loading image URL from ai-host-media: $publicUrl")
            value = publicUrl
        } else {
            value = viewModel.dataService.getSignedMediaUrl(raw, com.example.data.network.SupabaseConfig.BUCKET_CHAT_MEDIA)
        }
    }

    val bubbleColor = if (isMe) WhatsAppOutgoingBubble else WhatsAppIncomingBubble
    val textColor = WhatsAppChatTextDark

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMe) 16.dp else 4.dp,
                bottomEnd = if (isMe) 4.dp else 16.dp
            ),
            color = bubbleColor,
            shadowElevation = 1.dp,
            border = androidx.compose.foundation.BorderStroke(0.5.dp, if (isMe) Color(0xFFC7EBC0) else Color(0xFFE5E0D8)),
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (!message.replyToStoryId.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.06f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.History,
                                contentDescription = null,
                                tint = Color(0xFF00A884),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Replied to story",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFF00A884),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }

                when (message.messageType) {
                    "image" -> {
                        val imageSrc = resolvedImageUrl ?: message.mediaUrl
                        if (imageSrc.isNullOrBlank()) {
                            android.util.Log.d("BaatlySecurity", "[AI_IMAGE] sendPhoto=true but photoUrl is null/blank")
                        } else {
                            android.util.Log.d("BaatlySecurity", "[AI_IMAGE] loading image URL: $imageSrc")
                        }
                        AsyncImage(
                            model = imageSrc,
                            contentDescription = "Shared Photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 180.dp, max = 280.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                    }
                    "voice" -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(
                                onClick = { message.mediaUrl?.let { onPlayVoice(it) } },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isMe) Color(0xFF00A884) else SecondaryAmber)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = "Play Voice Note",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Voice Note (${message.mediaDurationSeconds ?: 0}s)",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = textColor,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "Audio message",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF667781)
                                    )
                                )
                            }
                        }
                    }
                    "gift" -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DED7)),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (!message.gift?.iconUrl.isNullOrBlank()) {
                                        AsyncImage(
                                            model = message.gift?.iconUrl,
                                            contentDescription = message.gift?.name,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Filled.CardGiftcard,
                                            contentDescription = "Gift",
                                            tint = SecondaryAmber,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }
                            Column {
                                Text(
                                    text = "Sent ${message.gift?.name ?: "Gift"}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color(0xFF111B21),
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "${message.gift?.coinPrice ?: 10} Coins",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF667781)
                                    )
                                )
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = message.content ?: "",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = textColor,
                                fontSize = 15.sp,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }

                // Status ticks for outgoing messages (NO timestamps displayed)
                if (isMe) {
                    val isSeen = !message.seenAt.isNullOrBlank()
                    val isDelivered = !message.deliveredAt.isNullOrBlank()

                    val tickText = when {
                        isSeen -> "✓✓"
                        isDelivered -> "✓✓"
                        else -> "✓"
                    }
                    val tickColor = if (isSeen) WhatsAppTickBlue else WhatsAppTickGrey

                    Row(
                        modifier = Modifier
                            .align(Alignment.End)
                            .padding(top = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tickText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = tickColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = (-1).sp
                            ),
                            modifier = Modifier.testTag("msg_status_${message.id}")
                        )
                    }
                }
            }
        }
    }
}
