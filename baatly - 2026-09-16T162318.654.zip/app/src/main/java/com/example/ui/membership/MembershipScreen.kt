package com.example.ui.membership

import android.app.Activity
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@Composable
fun MembershipScreen(
    viewModel: BaatlyViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val membershipState by viewModel.membershipState.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()
    val activePlan by viewModel.activePlan.collectAsState()
    val activePlans by viewModel.activePlans.collectAsState()
    val selectedPlan by viewModel.selectedMembershipPlan.collectAsState()
    val activePlanState by viewModel.activePlanState.collectAsState()
    val purchaseUiState by viewModel.membershipPurchaseUiState.collectAsState()
    val wallet by viewModel.wallet.collectAsState()

    // Log screen opened
    LaunchedEffect(Unit) {
        viewModel.onMembershipScreenOpened()
    }

    // Handle purchase dialogs / feedback
    var showSuccessDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var cancelledMessage by remember { mutableStateOf<String?>(null) }
    var pendingMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(purchaseUiState) {
        when (val state = purchaseUiState) {
            is MembershipPurchaseUiState.Success -> {
                showSuccessDialog = true
            }
            is MembershipPurchaseUiState.Failed -> {
                errorMessage = state.message
            }
            is MembershipPurchaseUiState.Cancelled -> {
                cancelledMessage = state.message
            }
            is MembershipPurchaseUiState.Pending -> {
                pendingMessage = state.message
            }
            else -> {}
        }
    }

    // Success Dialog
    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = {
                showSuccessDialog = false
                viewModel.resetMembershipPurchaseUiState()
            },
            containerColor = DarkSurface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            icon = {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(GoldGradient),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = null,
                        tint = Color(0xFF1B1402),
                        modifier = Modifier.size(36.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "Membership Activated 🎉",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                val purchasedPlan = selectedPlan ?: activePlan
                val planName = purchasedPlan?.name ?: "VIP"
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Your $planName Membership is now active!",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Enjoy reduced rates on voice & video calls, chat messages, and social unlocks for the duration of your pass.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color = TextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        viewModel.resetMembershipPurchaseUiState()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("btn_membership_success_ok")
                ) {
                    Text("Start Exploring", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Cancelled / Failed Dialog
    if (cancelledMessage != null) {
        AlertDialog(
            onDismissRequest = {
                cancelledMessage = null
                viewModel.resetMembershipPurchaseUiState()
            },
            containerColor = DarkSurface,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = { Text("Payment Cancelled") },
            text = { Text(cancelledMessage ?: "No amount was added as membership.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        cancelledMessage = null
                        viewModel.resetMembershipPurchaseUiState()
                    }
                ) {
                    Text("OK", color = PrimaryLavender)
                }
            }
        )
    }

    if (errorMessage != null) {
        AlertDialog(
            onDismissRequest = {
                errorMessage = null
                viewModel.resetMembershipPurchaseUiState()
            },
            containerColor = DarkSurface,
            titleContentColor = DangerRed,
            textContentColor = TextSecondary,
            title = { Text("Payment Error") },
            text = { Text(errorMessage ?: "Unable to complete membership purchase.") },
            confirmButton = {
                Button(
                    onClick = {
                        errorMessage = null
                        viewModel.resetMembershipPurchaseUiState()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender)
                ) {
                    Text("Close", color = Color.White)
                }
            }
        )
    }

    if (pendingMessage != null) {
        AlertDialog(
            onDismissRequest = {
                pendingMessage = null
                viewModel.resetMembershipPurchaseUiState()
            },
            containerColor = DarkSurface,
            titleContentColor = SecondaryAmber,
            textContentColor = TextSecondary,
            title = { Text("Payment Verification") },
            text = { Text(pendingMessage ?: "Your membership will activate after payment confirmation.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        pendingMessage = null
                        viewModel.resetMembershipPurchaseUiState()
                    }
                ) {
                    Text("OK", color = PrimaryLavender)
                }
            }
        )
    }

    Scaffold(
        topBar = {
            MembershipTopBar(
                coinBalance = wallet?.balance ?: 0,
                onBack = onBack,
                onCoinClick = { viewModel.setScreen(Screen.WALLET) }
            )
        },
        bottomBar = {
            MembershipBottomBar(
                membershipState = membershipState,
                purchaseUiState = purchaseUiState,
                plan = selectedPlan ?: activePlan,
                onBuyClick = { viewModel.buyMembership(context) },
                onRefreshClick = { viewModel.refreshMembership() }
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Active Membership Banner if Active
            if (membershipState is MembershipState.Active) {
                ActiveMembershipDashboardCard(
                    activeState = membershipState as MembershipState.Active,
                    pricing = effectivePricing
                )
                Spacer(modifier = Modifier.height(18.dp))
            } else if (membershipState is MembershipState.Expired && activePlan != null) {
                ExpiredMembershipBannerCard(
                    onBuyAgain = { viewModel.buyMembership(context) }
                )
                Spacer(modifier = Modifier.height(18.dp))
            }

            val displayPlans = activePlans.ifEmpty { listOfNotNull(activePlan) }
            if (displayPlans.isNotEmpty()) {
                // Hero Section for all active plans from backend
                displayPlans.forEach { planItem ->
                    MembershipHeroCard(
                        plan = planItem,
                        isActive = membershipState is MembershipState.Active && activePlan?.id == planItem.id,
                        isSelected = selectedPlan?.id == planItem.id,
                        onClick = { viewModel.selectMembershipPlan(planItem) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Savings Highlight Card
                SavingsHighlightCard(plan = displayPlans.firstOrNull())

                Spacer(modifier = Modifier.height(20.dp))

                // Normal vs Membership Rate Comparison Table
                MembershipSavingsComparisonSection()

                Spacer(modifier = Modifier.height(20.dp))

                // Non-Discounted Services Section
                NonDiscountedServicesCard()

                Spacer(modifier = Modifier.height(20.dp))

                // Why Membership is Worth It Section
                WhyMembershipWorthItSection()

                Spacer(modifier = Modifier.height(28.dp))
            } else {
                if (membershipState is MembershipState.Active) {
                    // User is already active, but no new plan is available for purchase
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = DarkSurface,
                        border = BorderStroke(1.dp, DarkCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_no_new_plan_info")
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Your membership is active",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "No additional membership plans are currently available for purchase.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    MembershipSavingsComparisonSection()
                    Spacer(modifier = Modifier.height(20.dp))
                    NonDiscountedServicesCard()
                    Spacer(modifier = Modifier.height(20.dp))
                    WhyMembershipWorthItSection()
                    Spacer(modifier = Modifier.height(28.dp))
                } else if (activePlanState is ActivePlanState.Loading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color = PrimaryLavender,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Checking membership plans...",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                            )
                        }
                    }
                } else {
                    // Honest, clean empty state
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = DarkSurface,
                        border = BorderStroke(1.dp, DarkCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp)
                            .testTag("card_no_membership_plan")
                    ) {
                        Column(
                            modifier = Modifier.padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(DarkSurfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.HourglassEmpty,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(18.dp))
                            Text(
                                text = "No membership plan exists currently",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    textAlign = TextAlign.Center
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "There are no active membership passes available at this moment. Please check back later.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 18.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            OutlinedButton(
                                onClick = { viewModel.refreshMembership() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryLavender),
                                border = BorderStroke(1.dp, PrimaryLavender.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.testTag("btn_membership_empty_refresh")
                            ) {
                                Icon(Icons.Filled.Refresh, contentDescription = "Refresh", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Refresh", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MembershipTopBar(
    coinBalance: Int,
    onBack: () -> Unit,
    onCoinClick: () -> Unit
) {
    Surface(
        color = DarkBackground,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .testTag("btn_membership_back")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Baatly Pass",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "24-Hour VIP Privileges",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = PrimaryLavender,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            // Coins badge
            Surface(
                shape = CircleShape,
                color = DarkSurfaceVariant,
                border = BorderStroke(1.dp, DarkBorderSubtle),
                modifier = Modifier
                    .clickable { onCoinClick() }
                    .testTag("badge_membership_coins")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(start = 6.dp, end = 12.dp, top = 4.dp, bottom = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(GoldGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MonetizationOn,
                            contentDescription = "Coins",
                            tint = Color(0xFF1B1402),
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    Text(
                        text = "%,d".format(coinBalance),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SecondaryAmber,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveMembershipDashboardCard(
    activeState: MembershipState.Active,
    pricing: EffectiveUserPricing
) {
    val totalSeconds = (activeState.remainingMillis / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    val countdownText = String.format("%02dh %02dm %02ds", hours, minutes, seconds)

    Surface(
        shape = RoundedCornerShape(22.dp),
        color = DarkSurface,
        border = BorderStroke(1.5.dp, SecondaryAmber.copy(alpha = 0.8f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_active_membership_dashboard")
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        listOf(
                            SecondaryAmber.copy(alpha = 0.15f),
                            DarkSurface
                        )
                    )
                )
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(GoldGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            tint = Color(0xFF1B1402),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Membership Active",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "24-Hour Pass",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = SecondaryAmber,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                // Live Timer Pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF2B2005),
                    border = BorderStroke(1.dp, SecondaryAmber.copy(alpha = 0.5f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Timer,
                            contentDescription = null,
                            tint = SecondaryAmber,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = countdownText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = SecondaryAmber,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = DarkBorderSubtle, thickness = 1.dp)
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Your Active Member Rates:",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextSecondary,
                    fontWeight = FontWeight.SemiBold
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ActiveRatePill(label = "Voice Call", rate = "${pricing.callCoinsPerMinute} coins/min")
                ActiveRatePill(label = "Message", rate = "${pricing.messageCoinsPerMessage} coin")
                ActiveRatePill(label = "Post/Story", rate = "${pricing.postViewCoins} coin")
                ActiveRatePill(label = "Comment", rate = "${pricing.postCommentCoins} coin")
            }
        }
    }
}

@Composable
private fun ActiveRatePill(label: String, rate: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = DarkSurfaceVariant,
        border = BorderStroke(0.5.dp, DarkBorderSubtle)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextTertiary,
                    fontSize = 10.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = rate,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
private fun ExpiredMembershipBannerCard(onBuyAgain: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_expired_membership")
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Filled.HourglassEmpty,
                    contentDescription = null,
                    tint = DangerRed,
                    modifier = Modifier.size(26.dp)
                )
                Column {
                    Text(
                        text = "Membership Expired",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "Your 24-hour pass has ended. Rates reverted to normal.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Button(
                onClick = onBuyAgain,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text("Renew", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MembershipHeroCard(
    plan: MembershipPlan,
    isActive: Boolean,
    isSelected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val infiniteTransition = rememberInfiniteTransition(label = "crown_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val cardBorder = if (isSelected || isActive) {
        BorderStroke(2.5.dp, Brush.linearGradient(listOf(SecondaryAmber, PrimaryLavender)))
    } else {
        BorderStroke(1.dp, DarkBorderSubtle)
    }

    Surface(
        shape = RoundedCornerShape(28.dp),
        color = DarkSurface,
        border = cardBorder,
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .testTag("card_membership_hero_${plan.id}")
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isSelected) VibrantPink.copy(alpha = 0.3f) else VibrantPink.copy(alpha = 0.15f),
                            if (isSelected) ElectricIndigo.copy(alpha = 0.2f) else ElectricIndigo.copy(alpha = 0.08f),
                            DarkSurface
                        ),
                        radius = 900f
                    )
                )
                .padding(22.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Top Tag: "BEST VALUE" / "24H PASS" / "SELECTED"
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Transparent,
                    border = BorderStroke(1.dp, if (isSelected || isActive) SecondaryAmber.copy(alpha = 0.9f) else DarkBorderSubtle)
                ) {
                    Box(
                        modifier = Modifier
                            .background(
                                Brush.horizontalGradient(
                                    listOf(SecondaryAmber.copy(alpha = 0.25f), VibrantPink.copy(alpha = 0.25f))
                                )
                            )
                            .padding(horizontal = 14.dp, vertical = 5.dp)
                    ) {
                        val durationBadge = if (plan.durationHours % 24 == 0 && plan.durationHours >= 48) "${plan.durationHours / 24}D PASS" else "${plan.durationHours}H PASS"
                        val tagLabel = when {
                            isActive -> "ACTIVE PASS"
                            isSelected -> "$durationBadge • SELECTED"
                            else -> "$durationBadge • BEST VALUE"
                        }
                        Text(
                            text = tagLabel,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = if (isSelected || isActive) SecondaryAmber else TextPrimary,
                                letterSpacing = 1.sp,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Pulsing Crown / Star Icon
                Box(
                    modifier = Modifier
                        .scale(pulseScale)
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(GoldGradient),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = "Membership Icon",
                        tint = Color(0xFF1B1402),
                        modifier = Modifier.size(42.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = plan.name,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        fontSize = 24.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                val durationDesc = if (plan.durationHours % 24 == 0 && plan.durationHours >= 48) "${plan.durationHours / 24} days" else "${plan.durationHours} hours"
                Text(
                    text = "Unlock lower conversation & social interaction rates for $durationDesc.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Big Prominent Price Badge
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "₹${plan.priceInr.toInt()}",
                        style = MaterialTheme.typography.displaySmall.copy(
                            fontWeight = FontWeight.Black,
                            color = TextPrimary,
                            fontSize = 42.sp
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    val durationSuffix = if (plan.durationHours % 24 == 0 && plan.durationHours >= 48) "/ ${plan.durationHours / 24} Days" else "/ ${plan.durationHours} Hours"
                    Text(
                        text = durationSuffix,
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = SecondaryAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                val validText = if (plan.durationHours % 24 == 0 && plan.durationHours >= 48) "Valid for ${plan.durationHours / 24} days from activation" else "Valid for exactly ${plan.durationHours} hours from activation"
                Text(
                    text = validText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextTertiary,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun SavingsHighlightCard(plan: MembershipPlan? = null) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = DarkSurfaceVariant,
        border = BorderStroke(1.dp, DarkBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_savings_highlight")
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(OnlineGreen, Color(0xFF00897B)))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Percent,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Save up to 66.67%",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = OnlineGreen,
                            fontSize = 17.sp
                        )
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Pay less coins on calls, messages, comments and post views.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                if (plan != null) {
                    val durationText = if (plan.durationHours % 24 == 0 && plan.durationHours >= 48) "${plan.durationHours / 24} days" else "${plan.durationHours} hours"
                    Text(
                        text = "₹${plan.priceInr.toInt()} for $durationText • Automatically expires after $durationText.",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextTertiary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                } else {
                    Text(
                        text = "Special member pricing applies to all standard voice calls and direct messages.",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextTertiary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun MembershipSavingsComparisonSection() {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_membership_savings_table")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = SecondaryAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Membership Savings",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                }

                Text(
                    text = "Rate Reduction",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = PrimaryLavender,
                        fontSize = 10.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Table Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SERVICE",
                    modifier = Modifier.weight(1.8f),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextTertiary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                )
                Text(
                    text = "NORMAL",
                    modifier = Modifier.weight(1.3f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextTertiary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                )
                Text(
                    text = "MEMBER",
                    modifier = Modifier.weight(1.3f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = SecondaryAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                )
                Text(
                    text = "SAVING",
                    modifier = Modifier.weight(1.4f),
                    textAlign = TextAlign.End,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = OnlineGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                )
            }

            HorizontalDivider(color = DarkBorderSubtle, thickness = 1.dp, modifier = Modifier.padding(vertical = 6.dp))

            // Comparison Rows
            ComparisonRow(service = "Voice Call", normal = "6 coins/min", member = "3 coins/min", saving = "50% OFF")
            ComparisonRow(service = "Video Call", normal = "20 coins/min", member = "16 coins/min", saving = "20% OFF")
            ComparisonRow(service = "Send Message", normal = "3 coins", member = "1 coin", saving = "66.67% OFF")
            ComparisonRow(service = "Story View", normal = "3 coins", member = "1 coin", saving = "66.67% OFF")
            ComparisonRow(service = "Post View", normal = "3 coins", member = "1 coin", saving = "66.67% OFF")
            ComparisonRow(service = "Story Reply", normal = "3 coins", member = "1 coin", saving = "66.67% OFF")
            ComparisonRow(service = "Post Comment", normal = "3 coins", member = "1 coin", saving = "66.67% OFF")
            ComparisonRow(service = "Like", normal = "1 coin", member = "1 coin", saving = "Same price", isDiscounted = false)
        }
    }
}

@Composable
private fun ComparisonRow(
    service: String,
    normal: String,
    member: String,
    saving: String,
    isDiscounted: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = service,
            modifier = Modifier.weight(1.8f),
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )
        )

        // Normal Price (muted, struck-through if discounted)
        Text(
            text = normal,
            modifier = Modifier.weight(1.3f),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextTertiary,
                textDecoration = if (isDiscounted) TextDecoration.LineThrough else TextDecoration.None,
                fontSize = 11.sp
            )
        )

        // Membership Price (highlighted)
        Text(
            text = member,
            modifier = Modifier.weight(1.3f),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodySmall.copy(
                color = if (isDiscounted) SecondaryAmber else TextSecondary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        )

        // Saving Badge
        Box(
            modifier = Modifier.weight(1.4f),
            contentAlignment = Alignment.CenterEnd
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isDiscounted) OnlineGreen.copy(alpha = 0.16f) else DarkSurfaceVariant,
                border = BorderStroke(
                    0.5.dp,
                    if (isDiscounted) OnlineGreen.copy(alpha = 0.5f) else DarkBorderSubtle
                )
            ) {
                Text(
                    text = saving,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (isDiscounted) OnlineGreen else TextTertiary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun NonDiscountedServicesCard() {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = DarkSurfaceVariant.copy(alpha = 0.6f),
        border = BorderStroke(1.dp, DarkBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_non_discounted_services")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = null,
                    tint = TextTertiary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Membership does not change:",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                NonDiscountedItem(title = "Gifts", rate = "Regular catalog")
                NonDiscountedItem(title = "Create Post", rate = "20 coins")
                NonDiscountedItem(title = "Create Story", rate = "10 coins")
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                NonDiscountedItem(title = "Post Renewal", rate = "20 coins")
                NonDiscountedItem(title = "Likes", rate = "1 coin")
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun NonDiscountedItem(title: String, rate: String) {
    Column(modifier = Modifier.padding(4.dp)) {
        Text(
            text = "• $title",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        )
        Text(
            text = "  $rate",
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextTertiary,
                fontSize = 10.sp
            )
        )
    }
}

@Composable
private fun WhyMembershipWorthItSection() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Why Membership is Worth It",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BenefitCard(
                icon = Icons.Filled.Call,
                title = "Talk More",
                subtitle = "Calls from 6 → 3 coins/min",
                modifier = Modifier.weight(1f)
            )
            BenefitCard(
                icon = Icons.AutoMirrored.Filled.Chat,
                title = "Message More",
                subtitle = "Messages from 3 → 1 coin",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BenefitCard(
                icon = Icons.Filled.Visibility,
                title = "Explore More",
                subtitle = "Post & Story views from 3 → 1 coin",
                modifier = Modifier.weight(1f)
            )
            BenefitCard(
                icon = Icons.Filled.Forum,
                title = "Interact More",
                subtitle = "Comments & replies from 3 → 1 coin",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun BenefitCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkCardBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PrimaryLavender.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = PrimaryLavender,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 13.sp
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            )
        }
    }
}

@Composable
private fun MembershipBottomBar(
    membershipState: MembershipState,
    purchaseUiState: MembershipPurchaseUiState,
    plan: MembershipPlan?,
    onBuyClick: () -> Unit,
    onRefreshClick: () -> Unit
) {
    if (plan == null && membershipState !is MembershipState.Active) {
        return
    }

    val isLoading = purchaseUiState is MembershipPurchaseUiState.CreatingPayment ||
            purchaseUiState is MembershipPurchaseUiState.OpeningCheckout ||
            purchaseUiState is MembershipPurchaseUiState.Verifying

    val loadingText = when (purchaseUiState) {
        is MembershipPurchaseUiState.CreatingPayment -> "Creating secure payment..."
        is MembershipPurchaseUiState.OpeningCheckout -> "Opening UroPay..."
        is MembershipPurchaseUiState.Verifying -> "Verifying payment..."
        else -> "Processing..."
    }

    Surface(
        color = DarkBackground.copy(alpha = 0.95f),
        border = BorderStroke(1.dp, DarkBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            if (membershipState is MembershipState.Active) {
                // When already active, don't show an unnecessary primary buy button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Membership Active",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = OnlineGreen
                            )
                        )
                        Text(
                            text = "All discounts applied automatically",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }

                    OutlinedButton(
                        onClick = onRefreshClick,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryLavender),
                        border = BorderStroke(1.dp, DarkBorderSubtle),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.testTag("btn_membership_refresh")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Refresh", fontSize = 12.sp)
                    }
                }
            } else if (plan != null) {
                val priceInr = plan.priceInr
                val durLabel = if (plan.durationHours % 24 == 0 && plan.durationHours >= 48) "${plan.durationHours / 24}D" else "${plan.durationHours}H"
                val ctaText = if (membershipState is MembershipState.Expired) "Buy Again – ₹${priceInr.toInt()}" else "Buy $durLabel Membership – ₹${priceInr.toInt()}"

                // Buy CTA Button
                Button(
                    onClick = onBuyClick,
                    enabled = !isLoading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(18.dp),
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (!isLoading) PrimaryGradient else Brush.linearGradient(listOf(DarkSurfaceVariant, DarkSurfaceVariant)))
                        .testTag("btn_membership_buy")
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLoading) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = loadingText,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Star,
                                    contentDescription = null,
                                    tint = SecondaryAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = ctaText,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        fontSize = 16.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
