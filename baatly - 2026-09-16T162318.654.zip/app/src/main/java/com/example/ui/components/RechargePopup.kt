package com.example.ui.components

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CoinPackage
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*

@Composable
fun RechargePopup(
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val coinPackages by viewModel.coinPackages.collectAsState()
    val isProcessingPayment by viewModel.isProcessingPayment.collectAsState()

    // Find ₹120 and ₹240 packages or fallback gracefully to active packages
    val pkg120 = coinPackages.firstOrNull { it.priceInr.toInt() == 120 }
        ?: coinPackages.getOrNull(0)
        ?: CoinPackage(id = "pkg_120", coins = 100, priceInr = 120.0)

    val pkg240 = coinPackages.firstOrNull { it.priceInr.toInt() == 240 }
        ?: coinPackages.getOrNull(1)
        ?: CoinPackage(id = "pkg_240", coins = 220, priceInr = 240.0)

    Dialog(
        onDismissRequest = {
            if (!isProcessingPayment) onDismiss()
        },
        properties = DialogProperties(
            dismissOnBackPress = !isProcessingPayment,
            dismissOnClickOutside = !isProcessingPayment
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = DarkCard,
            border = BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .testTag("dialog_recharge_popup")
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Header Row with Close Icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VibrantPink.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AccountBalanceWallet,
                                contentDescription = null,
                                tint = VibrantPink,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = "Low Balance",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 18.sp
                            )
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isProcessingPayment,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("btn_close_recharge_popup")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "You need more balance to start this call. Choose a quick recharge to continue:",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    ),
                    textAlign = TextAlign.Start,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                // ₹120 Option Card
                RechargeOptionCard(
                    priceLabel = "₹120",
                    isRecommended = false,
                    isLoading = isProcessingPayment,
                    onClick = {
                        onDismiss()
                        viewModel.purchaseCoinPackage(pkg120, context, activity)
                    },
                    testTag = "btn_recharge_120"
                )

                Spacer(modifier = Modifier.height(12.dp))

                // ₹240 Option Card
                RechargeOptionCard(
                    priceLabel = "₹240",
                    isRecommended = true,
                    isLoading = isProcessingPayment,
                    onClick = {
                        onDismiss()
                        viewModel.purchaseCoinPackage(pkg240, context, activity)
                    },
                    testTag = "btn_recharge_240"
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.FlashOn,
                        contentDescription = null,
                        tint = SecondaryAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Instant 100% secure recharge via UroPay",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextTertiary,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun RechargeOptionCard(
    priceLabel: String,
    isRecommended: Boolean,
    isLoading: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isRecommended) DarkSurfaceVariant else DarkSurface,
        border = BorderStroke(
            1.5.dp,
            if (isRecommended) VibrantPink else DarkCardBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isLoading) { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = priceLabel,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        fontSize = 22.sp
                    )
                )
                if (isRecommended) {
                    Text(
                        text = "Most Popular",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SecondaryAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Button(
                onClick = onClick,
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRecommended) VibrantPink else PrimaryLavenderContainer
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Recharge",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isRecommended) Color.White else PrimaryLavenderDark
                    )
                )
            }
        }
    }
}
