package com.example.ui.profile

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import coil.compose.AsyncImage
import com.example.data.model.MembershipState
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.BaatlyTopBar
import com.example.ui.legal.LegalPage
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val wallet by viewModel.wallet.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val membershipState by viewModel.membershipState.collectAsState()
    val activePlan by viewModel.activePlan.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()

    var showEditDialog by remember { mutableStateOf(false) }
    var editDisplayName by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var editBio by remember { mutableStateOf(currentUser?.bio ?: "") }
    var editAvatarFile by remember { mutableStateOf<java.io.File?>(null) }
    var editAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var isUpdatingProfile by remember { mutableStateOf(false) }
    var editProfileError by remember { mutableStateOf<String?>(null) }

    var showDeleteDialog by remember { mutableStateOf(false) }
    var isSubmittingDeletion by remember { mutableStateOf(false) }
    var deletionErrorMessage by remember { mutableStateOf<String?>(null) }
    var showDeletionSuccessDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            editAvatarUri = uri
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val tempFile = java.io.File(context.cacheDir, "profile_edit_${System.currentTimeMillis()}.jpg")
                tempFile.outputStream().use { output ->
                    inputStream?.copyTo(output)
                }
                editAvatarFile = tempFile
            } catch (e: Exception) {
                editProfileError = "Failed to load image: ${e.message}"
            }
        }
    }

    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    val resolvedAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(currentUser?.avatarUrl, viewModel.dataService)
    val isResolvingAvatar = !currentUser?.avatarUrl.isNullOrBlank() && currentUser?.avatarUrl != "null" && resolvedAvatarUrl == null

    Scaffold(
        topBar = {
            BaatlyTopBar(
                coinBalance = wallet?.balance ?: 0,
                onCoinClick = { viewModel.setScreen(Screen.WALLET) },
                onNotificationClick = { viewModel.setScreen(Screen.NOTIFICATIONS) },
                unreadNotifications = notifications.count { !it.isRead }
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile Avatar
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(HostAvatarGradient)
                    .border(3.dp, PrimaryGradient, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (!resolvedAvatarUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = resolvedAvatarUrl,
                        contentDescription = currentUser?.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (isResolvingAvatar) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(28.dp),
                        color = PrimaryLavender,
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Text(
                        text = (currentUser?.displayName?.take(1) ?: "U").uppercase(),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Name & User ID
            Text(
                text = currentUser?.displayName ?: "Baatly User",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Text(
                text = "@${currentUser?.userId ?: "user"}",
                style = MaterialTheme.typography.bodyMedium.copy(color = PrimaryLavender)
            )

            if (!currentUser?.bio.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = currentUser?.bio ?: "",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 24-Hour VIP Membership Card
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = if (effectivePricing.isMember) Color(0xFF231B0B) else DarkSurface,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (effectivePricing.isMember) Color(0xFFFFD54F).copy(alpha = 0.6f) else DarkCardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setScreen(Screen.MEMBERSHIP) }
                    .testTag("profile_membership_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(if (effectivePricing.isMember) Color(0xFFFFD54F).copy(alpha = 0.2f) else DarkSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("👑", fontSize = 22.sp)
                        }
                        Column {
                            val cardTitle = if (effectivePricing.isMember) {
                                "VIP Membership Active"
                            } else if (activePlan != null) {
                                activePlan!!.name
                            } else {
                                "VIP Membership"
                            }
                            Text(
                                text = cardTitle,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (effectivePricing.isMember) Color(0xFFFFD54F) else TextPrimary
                                )
                            )
                            val active = membershipState as? MembershipState.Active
                            val cardSubtitle = if (effectivePricing.isMember) {
                                active?.let { "${it.remainingHours}h ${it.remainingMinutes % 60}m remaining • 50% Off Calls" } ?: "Active VIP Member"
                            } else if (activePlan != null) {
                                val dur = if (activePlan!!.durationHours % 24 == 0 && activePlan!!.durationHours >= 48) "${activePlan!!.durationHours / 24}d" else "${activePlan!!.durationHours}h"
                                "₹${activePlan!!.priceInr.toInt()} for $dur • Reduced Call & Chat Rates"
                            } else {
                                "View membership benefits & status"
                            }
                            Text(
                                text = cardSubtitle,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Filled.ChevronRight,
                        contentDescription = "View Membership",
                        tint = if (effectivePricing.isMember) Color(0xFFFFD54F) else TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Account Info Card
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    ProfileInfoRow(
                        icon = Icons.Outlined.Phone,
                        label = "Mobile Number",
                        value = if (!currentUser?.mobileNumber.isNullOrBlank()) "+91 ${currentUser?.mobileNumber}" else "Not specified"
                    )

                    HorizontalDivider(
                        color = DarkBorderSubtle,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    ProfileInfoRow(
                        icon = Icons.Outlined.CardGiftcard,
                        label = "My Referral Code",
                        value = currentUser?.referralCode ?: "BAATLYUSER"
                    )

                    HorizontalDivider(
                        color = DarkBorderSubtle,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    ProfileInfoRow(
                        icon = Icons.Outlined.Shield,
                        label = "Account Security",
                        value = "Protected"
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Help & Support Card (WhatsApp)
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/8744048708"))
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=918744048708"))
                            context.startActivity(fallbackIntent)
                        }
                    }
                    .testTag("btn_help_support_whatsapp")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = OnlineGreen.copy(alpha = 0.15f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Outlined.SupportAgent,
                                    contentDescription = "WhatsApp Support",
                                    tint = OnlineGreen,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Help & Support",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Official WhatsApp: +91 8744048708",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Filled.OpenInNew,
                        contentDescription = "Open",
                        tint = PrimaryLavender,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Safety & Platform Rules Card
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Gavel,
                            contentDescription = "Rules",
                            tint = SecondaryAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Platform Rates & Safety Rules",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "• Voice Call Rate: 6 Coins / minute\n" +
                                "• Chat Message Rate: 3 Coins / message\n" +
                                "• Gifts: Coins deducted per gift coin price\n" +
                                "• Strictly NO sharing mobile numbers or external social links\n" +
                                "• Strictly NO abusive, sexual, or fraudulent content\n" +
                                "• Violations lead to immediate permanent ban",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            lineHeight = 20.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Legal & Safety Section Card
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Shield,
                            contentDescription = "Legal & Safety",
                            tint = PrimaryLavender,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Legal & Safety",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LegalMenuItemRow(
                        icon = Icons.Outlined.Info,
                        label = "About Baatly",
                        onClick = { viewModel.openLegalPage(LegalPage.ABOUT_BAATLY) },
                        testTag = "btn_legal_about_baatly"
                    )

                    HorizontalDivider(
                        color = DarkBorderSubtle,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )

                    LegalMenuItemRow(
                        icon = Icons.Outlined.Security,
                        label = "Safety & Security",
                        onClick = { viewModel.openLegalPage(LegalPage.SAFETY_SECURITY) },
                        testTag = "btn_legal_safety_security"
                    )

                    HorizontalDivider(
                        color = DarkBorderSubtle,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )

                    LegalMenuItemRow(
                        icon = Icons.Outlined.ReceiptLong,
                        label = "Refund & Cancellation",
                        onClick = { viewModel.openLegalPage(LegalPage.REFUND_CANCELLATION) },
                        testTag = "btn_legal_refund_cancellation"
                    )

                    HorizontalDivider(
                        color = DarkBorderSubtle,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )

                    LegalMenuItemRow(
                        icon = Icons.Outlined.Description,
                        label = "Terms & Conditions",
                        onClick = { viewModel.openLegalPage(LegalPage.TERMS_CONDITIONS) },
                        testTag = "btn_legal_terms_conditions"
                    )

                    HorizontalDivider(
                        color = DarkBorderSubtle,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )

                    LegalMenuItemRow(
                        icon = Icons.Outlined.Lock,
                        label = "Privacy Policy",
                        onClick = { viewModel.openLegalPage(LegalPage.PRIVACY_POLICY) },
                        testTag = "btn_legal_privacy_policy"
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Edit Profile Button
            Button(
                onClick = {
                    editDisplayName = currentUser?.displayName ?: ""
                    editBio = currentUser?.bio ?: ""
                    editAvatarFile = null
                    editAvatarUri = null
                    editProfileError = null
                    isUpdatingProfile = false
                    showEditDialog = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_edit_profile")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Edit,
                    contentDescription = null,
                    tint = TextPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "EDIT PROFILE",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sign Out Button
            OutlinedButton(
                onClick = { viewModel.signOut() },
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_logout")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = null,
                    tint = DangerRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SIGN OUT",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Delete Account Button (Destructive action)
            OutlinedButton(
                onClick = {
                    deletionErrorMessage = null
                    showDeleteDialog = true
                },
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed.copy(alpha = 0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = DangerRed,
                    containerColor = DangerRed.copy(alpha = 0.08f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_delete_account")
            ) {
                Icon(
                    imageVector = Icons.Outlined.DeleteForever,
                    contentDescription = "Delete Account",
                    tint = DangerRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "DELETE ACCOUNT",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = DangerRed
                    )
                )
            }
        }
    }

    // Edit Profile Modal
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isUpdatingProfile) showEditDialog = false
            },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOff),
            containerColor = DarkSurface,
            title = {
                Text("Edit Profile", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Profile Photo preview & picker
                    Box(
                        contentAlignment = Alignment.BottomEnd,
                        modifier = Modifier.clickable(enabled = !isUpdatingProfile) {
                            photoPickerLauncher.launch("image/*")
                        }
                    ) {
                        AsyncImage(
                            model = editAvatarUri ?: resolvedAvatarUrl ?: currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300",
                            contentDescription = "Profile Photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .border(2.dp, VibrantPink, CircleShape)
                        )
                        Surface(
                            shape = CircleShape,
                            color = VibrantPink,
                            modifier = Modifier.size(26.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.PhotoCamera,
                                    contentDescription = "Change Photo",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    if (!editProfileError.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DangerRed.copy(alpha = 0.15f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = editProfileError ?: "",
                                color = DangerRed,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editDisplayName,
                        onValueChange = { editDisplayName = it },
                        label = { Text("Display Name") },
                        enabled = !isUpdatingProfile,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VibrantPink,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text("Bio") },
                        enabled = !isUpdatingProfile,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VibrantPink,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cleanName = editDisplayName.trim()
                        if (cleanName.isBlank()) {
                            editProfileError = "Display Name cannot be empty."
                            return@Button
                        }
                        isUpdatingProfile = true
                        editProfileError = null
                        viewModel.updateUserProfile(
                            displayName = cleanName,
                            bio = editBio.trim(),
                            avatarFile = editAvatarFile
                        ) { success, err ->
                            isUpdatingProfile = false
                            if (success) {
                                showEditDialog = false
                            } else {
                                editProfileError = err ?: "Failed to update profile. Please try again."
                            }
                        }
                    },
                    enabled = !isUpdatingProfile && editDisplayName.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VibrantPink,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (isUpdatingProfile) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Text("Save", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showEditDialog = false },
                    enabled = !isUpdatingProfile
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Delete Account Confirmation Modal
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isSubmittingDeletion) {
                    showDeleteDialog = false
                    deletionErrorMessage = null
                }
            },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOff),
            containerColor = DarkSurface,
            icon = {
                Icon(
                    imageVector = Icons.Outlined.WarningAmber,
                    contentDescription = null,
                    tint = DangerRed,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Delete Account",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Account deletion is permanent once your request is processed.",
                        color = TextPrimary,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 20.sp
                        )
                    )
                    Text(
                        text = "Once submitted, your account deletion request will be processed. All profile information, chats, calls, and coin balances will be permanently removed. This action cannot be reversed.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp)
                    )

                    if (!deletionErrorMessage.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DangerRed.copy(alpha = 0.15f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = deletionErrorMessage ?: "",
                                color = DangerRed,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    if (isSubmittingDeletion) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = DangerRed,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Submitting request...",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isSubmittingDeletion) return@Button
                        isSubmittingDeletion = true
                        deletionErrorMessage = null
                        viewModel.requestAccountDeletion { success, msg ->
                            isSubmittingDeletion = false
                            if (success) {
                                showDeleteDialog = false
                                showDeletionSuccessDialog = true
                            } else {
                                deletionErrorMessage = msg
                            }
                        }
                    },
                    enabled = !isSubmittingDeletion,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DangerRed,
                        disabledContainerColor = DangerRed.copy(alpha = 0.5f),
                        contentColor = Color.White,
                        disabledContentColor = Color.White.copy(alpha = 0.7f)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("btn_confirm_delete_account")
                ) {
                    if (isSubmittingDeletion) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Submitting...", fontWeight = FontWeight.Bold, color = Color.White)
                    } else {
                        Text("Confirm Deletion", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        deletionErrorMessage = null
                    },
                    enabled = !isSubmittingDeletion,
                    modifier = Modifier.testTag("btn_cancel_delete_account")
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Delete Account Success Modal
    if (showDeletionSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showDeletionSuccessDialog = false },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOff),
            containerColor = DarkSurface,
            icon = {
                Icon(
                    imageVector = Icons.Outlined.CheckCircle,
                    contentDescription = null,
                    tint = OnlineGreen,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Deletion request submitted",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = "Your Baatly account deletion request has been submitted successfully.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp)
                )
            },
            confirmButton = {
                Button(
                    onClick = { showDeletionSuccessDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryLavender,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("btn_close_delete_success")
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun ProfileInfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = PrimaryLavender,
            modifier = Modifier.size(22.dp)
        )
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
            )
        }
    }
}

@Composable
private fun LegalMenuItemRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = PrimaryLavender,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    fontSize = 14.sp
                )
            )
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = "Open $label",
            tint = TextTertiary,
            modifier = Modifier.size(16.dp)
        )
    }
}

