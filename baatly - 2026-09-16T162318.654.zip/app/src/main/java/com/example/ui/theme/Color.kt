package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Warm Light Cream Surface & Canvas Palette
val LightCreamBackground = Color(0xFFFFF8EE)
val LightCardBackground = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFFFFDF7)
val LightNavBackground = Color(0xFFFFFFFF)
val LightCardBorder = Color(0xFFEAE3D9)
val LightBorderSubtle = Color(0xFFF0EAE1)

// Semantic token aliases mapped to Light Cream palette
val DarkBackground = LightCreamBackground
val DarkSurface = LightCardBackground
val DarkSurfaceVariant = LightSurfaceVariant
val DarkNavBackground = LightNavBackground
val DarkCardBorder = LightCardBorder
val DarkBorderSubtle = LightBorderSubtle
val DarkCard = LightCardBackground
val DarkCardBackground = LightCardBackground
val DarkBorder = LightCardBorder

// Vibrant Radiant Accents (Baatly Brand)
val VibrantPink = Color(0xFFFF3366)
val VibrantViolet = Color(0xFF8B5CF6)
val ElectricIndigo = Color(0xFF6366F1)
val NeonCyan = Color(0xFF0284C7)
val VibrantAmber = Color(0xFFFFB703)
val VibrantOrange = Color(0xFFFB8500)

val PrimaryLavender = Color(0xFF9333EA)
val PrimaryLavenderContainer = Color(0xFFF3E8FF)
val PrimaryLavenderDark = Color(0xFF581C87)

val PrimaryCoral = Color(0xFFFF3366)
val PrimaryCoralLight = Color(0xFFFF7A9E)
val PrimaryCoralDark = Color(0xFFBE123C)

val SecondaryAmber = Color(0xFFF59E0B)
val SecondaryAmberLight = Color(0xFFFEF3C7)

val AccentPurple = Color(0xFF9333EA)
val AccentPurpleLight = Color(0xFFE9D5FF)

// Near-Black High-Contrast Text Hierarchy (Strict Light Cream Theme)
val TextPrimary = Color(0xFF171717)
val TextSecondary = Color(0xFF4A4A4A)
val TextMuted = Color(0xFF6B6259)
val TextTertiary = Color(0xFF6B6259)

// Status & Action Colors
val OnlineGreen = Color(0xFF10B981)
val OfflineGray = Color(0xFF9CA3AF)
val BusyAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)
val WarningYellow = Color(0xFFF59E0B)

val NeonPink = Color(0xFFFF2A85)
val DarkPink = Color(0xFFE11D48)
val ErrorRed = DangerRed
val SuccessGreen = OnlineGreen
val CoinGold = Color(0xFFFFB800)

// Chat Bubbles (Light green for outgoing, crisp white for incoming)
val ChatBubbleOutgoing = Color(0xFFDCF8C6)
val ChatBubbleIncoming = Color(0xFFFFFFFF)
val WhatsAppOutgoingBubble = Color(0xFFDCF8C6)
val WhatsAppIncomingBubble = Color(0xFFFFFFFF)
val WhatsAppChatTextDark = Color(0xFF171717)
val WhatsAppChatBackground = Color(0xFFFFF8EE)
val WhatsAppTickGrey = Color(0xFF8696A0)
val WhatsAppTickBlue = Color(0xFF34B7F1)

// Modern Light Gradients
val PrimaryGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFF3366), Color(0xFF9333EA))
)

val AccentGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF8B5CF6), Color(0xFF0284C7))
)

val GoldGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFFD166), Color(0xFFFB8500))
)

val CardGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFFFFFFFF), Color(0xFFFFFDF7))
)

val HeroHeaderGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFFFFF5E6), Color(0xFFFFF8EE))
)

val HostAvatarGradient = Brush.linearGradient(
    colors = listOf(Color(0xFFFF3366), Color(0xFFFFB703))
)
