package com.example.data.network

import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.model.AuthUser
import com.example.data.model.PhoneResolutionResult
import com.example.data.model.UserProfile
import com.example.data.model.UserSession
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class SupabaseAuthService(
    private val client: SupabaseClient,
    private val sessionManager: SessionManager
) {

    suspend fun checkUserIdAvailable(userId: String): Boolean {
        val normalized = userId.trim().lowercase()
        return try {
            // Use the AWS allow-listed action name and parameter shape, not the old raw PostgREST RPC name.
            val response = client.rpc("username.user_id_available", mapOf("user_id" to normalized))
            val root = JSONObject(response)
            val data = root.opt("data")
            when (data) {
                is Boolean -> data
                is Number -> data.toInt() != 0
                else -> when (data?.toString()?.trim()?.lowercase() ?: response.trim().lowercase()) {
                    "true", "1", "\"true\"" -> true
                    "false", "0", "\"false\"" -> false
                    else -> true // The final signup endpoint enforces uniqueness authoritatively.
                }
            }
        } catch (_: Exception) {
            // Avoid sending a legacy /rest/v1/profiles query to a route the AWS API does not expose.
            true
        }
    }
    suspend fun signUp(
        userId: String,
        password: String,
        displayName: String,
        mobileNumber: String,
        avatarFile: File? = null,
        referralCode: String? = null
    ): Result<UserProfile> {
        val normalizedUserId = userId.trim().lowercase()
        val normalizedMobile = mobileNumber.filter { it.isDigit() }
        val cleanDisplayName = displayName.trim()
        val cleanReferral = referralCode?.trim()?.takeIf { it.isNotBlank() }
        val internalEmail = SupabaseConfig.getInternalAuthEmail(normalizedUserId)

        return try {
            var sessionToken: String? = null
            var authUserId: String? = null
            var refreshToken: String? = null

            // STEP 1: Attempt AWS password signup
            val signupUrl = "${SupabaseConfig.apiBaseUrl}/auth/v1/signup"
            val signupBody = JSONObject().apply {
                put("email", internalEmail)
                put("password", password)
                put("data", JSONObject().apply {
                    put("user_id", normalizedUserId)
                    put("display_name", cleanDisplayName)
                    put("mobile_number", normalizedMobile)
                })
            }

            try {
                val signupRes = client.post(signupUrl, signupBody.toString())
                val signupJson = JSONObject(signupRes)
                sessionToken = signupJson.optString("access_token")
                refreshToken = signupJson.optString("refresh_token")
                authUserId = signupJson.optJSONObject("user")?.optString("id")
                    ?: signupJson.optString("id")
            } catch (e: Exception) {
                val errMsg = e.message?.lowercase() ?: ""
                // Orphan recovery: If user is already registered in Auth but profile incomplete, attempt sign in
                if (errMsg.contains("already registered") || errMsg.contains("user already exists") || errMsg.contains("email address already")) {
                    val tokenUrl = "${SupabaseConfig.apiBaseUrl}/auth/v1/token?grant_type=password"
                    val tokenBody = JSONObject().apply {
                        put("email", internalEmail)
                        put("password", password)
                    }
                    val tokenRes = client.post(tokenUrl, tokenBody.toString())
                    val tokenJson = JSONObject(tokenRes)
                    sessionToken = tokenJson.optString("access_token")
                    refreshToken = tokenJson.optString("refresh_token")
                    authUserId = tokenJson.optJSONObject("user")?.optString("id") ?: tokenJson.optString("id")
                } else {
                    throw e
                }
            }

            // If token wasn't directly returned, obtain via token endpoint
            if (sessionToken.isNullOrBlank() || authUserId.isNullOrBlank()) {
                val tokenUrl = "${SupabaseConfig.apiBaseUrl}/auth/v1/token?grant_type=password"
                val tokenBody = JSONObject().apply {
                    put("email", internalEmail)
                    put("password", password)
                }
                val tokenRes = client.post(tokenUrl, tokenBody.toString())
                val tokenJson = JSONObject(tokenRes)
                sessionToken = tokenJson.optString("access_token")
                refreshToken = tokenJson.optString("refresh_token")
                authUserId = tokenJson.optJSONObject("user")?.optString("id") ?: tokenJson.optString("id")
            }

            if (sessionToken.isNullOrBlank() || authUserId.isNullOrBlank()) {
                throw SupabaseException("Could not authenticate session. Please try again.", 400, "")
            }

            // Save temporary token in session so subsequent authenticated calls succeed
            sessionManager.saveSession(sessionToken, authUserId, refreshToken = refreshToken)

            // STEP 2: If profile photo selected, upload to private profile-media bucket
            var avatarPath: String? = null
            if (avatarFile != null) {
                val ext = avatarFile.extension.ifBlank { "jpg" }
                val relativePath = "$authUserId/${UUID.randomUUID()}.$ext"
                avatarPath = client.uploadFile(
                    SupabaseConfig.BUCKET_PROFILE_MEDIA,
                    relativePath,
                    avatarFile,
                    "image/jpeg"
                )
            }

            // STEP 3: Complete user registration via authoritative RPC
            val rpcParams = mutableMapOf<String, Any?>(
                "p_user_id" to normalizedUserId,
                "p_display_name" to cleanDisplayName,
                "p_mobile_number" to normalizedMobile,
                "p_avatar_url" to avatarPath
            )
            if (cleanReferral != null) {
                rpcParams["p_referral_code"] = cleanReferral
            }

            try {
                client.rpc("complete_user_signup", rpcParams)
            } catch (e: Exception) {
                val rpcErr = e.message ?: ""
                if (cleanReferral != null && rpcErr.contains("referral", ignoreCase = true)) {
                    throw SupabaseException("Invalid referral code", 400, "invalid_referral")
                } else {
                    throw e
                }
            }

            // STEP 4: Authoritatively verify profile from backend
            val profileUrl = "${SupabaseConfig.apiBaseUrl}/rest/v1/profiles?id=eq.$authUserId&select=*"
            val profileRes = client.get(profileUrl)
            val profileArray = JSONArray(profileRes)
            if (profileArray.length() == 0) {
                throw SupabaseException("Profile could not be verified after registration.", 500, "")
            }

            val profile = parseUserProfile(profileArray.getJSONObject(0))
            if (profile.userId.isBlank() || profile.mobileNumber.isBlank()) {
                throw SupabaseException("Incomplete user profile data. Please try again.", 500, "")
            }

            sessionManager.saveSession(sessionToken, authUserId, profile, refreshToken = refreshToken)
            Result.success(profile)
        } catch (e: Exception) {
            sessionManager.clearSession()
            Result.failure(e)
        }
    }

    suspend fun signIn(userId: String, password: String): Result<UserProfile> {
        val normalizedUserId = userId.trim().lowercase()
        val internalEmail = SupabaseConfig.getInternalAuthEmail(normalizedUserId)

        return try {
            val tokenUrl = "${SupabaseConfig.apiBaseUrl}/auth/v1/token?grant_type=password"
            val authBody = JSONObject().apply {
                put("email", internalEmail)
                put("password", password)
            }
            val authRes = client.post(tokenUrl, authBody.toString())
            val authJson = JSONObject(authRes)
            val sessionToken = authJson.optString("access_token")
            val refreshToken = authJson.optString("refresh_token")
            val authUserId = authJson.optJSONObject("user")?.optString("id")
                ?: authJson.optString("id")

            if (sessionToken.isNullOrBlank() || authUserId.isNullOrBlank()) {
                throw SupabaseException("Invalid User ID or Password.", 401, "unauthorized")
            }

            sessionManager.saveSession(sessionToken, authUserId, refreshToken = refreshToken)

            // Fetch profile
            val profileUrl = "${SupabaseConfig.apiBaseUrl}/rest/v1/profiles?id=eq.$authUserId&select=*"
            val profileRes = client.get(profileUrl)
            val profileArray = JSONArray(profileRes)
            if (profileArray.length() == 0) {
                throw SupabaseException("User profile not found. Please contact support.", 404, "")
            }

            val profile = parseUserProfile(profileArray.getJSONObject(0))
            if (profile.accountStatus == "deleted" || profile.accountStatus == "banned" || profile.accountStatus == "suspended") {
                sessionManager.clearSession()
                throw SupabaseException("Your account is ${profile.accountStatus}. Please contact support.", 403, "")
            }

            sessionManager.saveSession(sessionToken, authUserId, profile, refreshToken = refreshToken)
            Result.success(profile)
        } catch (e: Exception) {
            sessionManager.clearSession()
            Result.failure(e)
        }
    }

    suspend fun restoreOrRefreshSession(): Boolean {
        if (!sessionManager.hasPersistedSessionCredentials) {
            sessionManager.clearSession()
            return false
        }

        val sessionResult = client.ensureValidSession()
        return when (sessionResult) {
            is com.example.data.model.SessionResult.Valid -> {
                true
            }
            is com.example.data.model.SessionResult.AuthRequired -> {
                sessionManager.clearSession()
                false
            }
            is com.example.data.model.SessionResult.NetworkError,
            is com.example.data.model.SessionResult.ServerError -> {
                val hasCachedUser = sessionManager.currentUser.value != null && !sessionManager.userId.value.isNullOrBlank()
                hasCachedUser || sessionManager.hasPersistedSessionCredentials
            }
        }
    }

    suspend fun fetchCurrentUserProfile(): Result<UserProfile> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val profileUrl = "${SupabaseConfig.apiBaseUrl}/rest/v1/profiles?id=eq.$userId&select=*"
            val profileRes = client.get(profileUrl)
            val profileArray = JSONArray(profileRes)
            if (profileArray.length() > 0) {
                val profile = parseUserProfile(profileArray.getJSONObject(0))
                sessionManager.updateProfile(profile)
                Result.success(profile)
            } else {
                Result.failure(Exception("Profile not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateProfile(displayName: String, bio: String?, avatarFile: File? = null): Result<UserProfile> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            var avatarPath: String? = null
            if (avatarFile != null) {
                val ext = avatarFile.extension.ifBlank { "jpg" }
                val relativePath = "$userId/${UUID.randomUUID()}.$ext"
                avatarPath = client.uploadFile(
                    SupabaseConfig.BUCKET_PROFILE_MEDIA,
                    relativePath,
                    avatarFile,
                    "image/jpeg"
                )
            }

            try {
                val rpcParams = mutableMapOf<String, Any?>(
                    "p_display_name" to displayName
                )
                if (bio != null) rpcParams["p_bio"] = bio
                if (avatarPath != null) rpcParams["p_avatar_url"] = avatarPath
                client.rpc("update_my_profile", rpcParams)
            } catch (_: Exception) {
                // Fallback to update_my_profile_avatar if avatar updated or direct patch
                if (avatarPath != null) {
                    try {
                        client.rpc("update_my_profile_avatar", mapOf("p_avatar_url" to avatarPath))
                    } catch (_: Exception) {}
                }
                val patchUrl = "${SupabaseConfig.apiBaseUrl}/rest/v1/profiles?id=eq.$userId"
                val updateJson = JSONObject().apply {
                    put("display_name", displayName)
                    if (bio != null) put("bio", bio)
                    if (avatarPath != null) put("avatar_url", avatarPath)
                }
                client.patch(patchUrl, updateJson.toString())
            }

            fetchCurrentUserProfile()
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun normalizeIndianPhoneNumber(rawPhone: String): String {
        val digits = rawPhone.filter { it.isDigit() }
        val mobile10 = when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            digits.length > 10 -> digits.takeLast(10)
            else -> digits
        }
        return "+91$mobile10"
    }

    fun extract10DigitMobile(rawPhone: String): String {
        val digits = rawPhone.filter { it.isDigit() }
        return when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            digits.length > 10 -> digits.takeLast(10)
            else -> digits
        }
    }

    fun isValidIndianMobileNumber(rawPhone: String): Boolean {
        val mobile10 = extract10DigitMobile(rawPhone)
        return mobile10.length == 10 && mobile10[0] in listOf('6', '7', '8', '9')
    }

    suspend fun sendPhoneOtp(rawPhone: String): Result<String> {
        val mobile10 = extract10DigitMobile(rawPhone)
        if (mobile10.length != 10) {
            return Result.failure(IllegalArgumentException("Please enter a valid 10-digit mobile number"))
        }
        val e164 = "+91$mobile10"
        return try {
            val otpUrl = "${SupabaseConfig.apiBaseUrl}/auth/v1/otp"
            val body = JSONObject().apply {
                put("phone", e164)
            }
            client.post(otpUrl, body.toString())
            Result.success(e164)
        } catch (e: Exception) {
            val msg = e.message ?: "Failed to send OTP"
            Log.e("SupabaseAuthService", "sendPhoneOtp error: $msg")
            val userFriendlyMsg = when {
                msg.contains("rate limit", ignoreCase = true) || msg.contains("429") ->
                    "Too many OTP requests. Please wait a moment before trying again."
                msg.contains("hook: 502", ignoreCase = true) || msg.contains("502") ->
                    "SMS delivery service temporarily unavailable. Please verify the mobile number or try again."
                else -> msg
            }
            Result.failure(Exception(userFriendlyMsg, e))
        }
    }

    suspend fun verifyPhoneOtp(rawPhone: String, token: String): Result<JSONObject> {
        val mobile10 = extract10DigitMobile(rawPhone)
        val cleanToken = token.trim()
        if (cleanToken.length != 6 || !cleanToken.all { it.isDigit() }) {
            return Result.failure(IllegalArgumentException("Please enter a valid 6-digit OTP code"))
        }
        val e164 = "+91$mobile10"
        return try {
            val verifyUrl = "${SupabaseConfig.apiBaseUrl}/auth/v1/verify"
            val body = JSONObject().apply {
                put("type", "sms")
                put("phone", e164)
                put("token", cleanToken)
            }
            val res = client.post(verifyUrl, body.toString())
            val json = JSONObject(res)
            // AWS OTP verify returns the token inside `session`, while older Supabase
            // responses used a top-level access_token. Accept both response shapes.
            val sessionObj = json.optJSONObject("session")
            val accessToken = json.optString("access_token")
                .ifBlank { sessionObj?.optString("access_token").orEmpty() }
            val userObj = json.optJSONObject("user")
            val userId = (userObj?.optString("id") ?: "").ifBlank { json.optString("id") }
            if (accessToken.isBlank() || userId.isBlank()) {
                Result.failure(Exception("Could not verify session. Please check the OTP and try again."))
            } else {
                Result.success(json)
            }
        } catch (e: Exception) {
            val msg = e.message ?: "Verification failed"
            Log.e("SupabaseAuthService", "verifyPhoneOtp error: $msg")
            val userFriendly = when {
                msg.contains("invalid", ignoreCase = true) || msg.contains("token has expired", ignoreCase = true) || msg.contains("expired", ignoreCase = true) ->
                    "Incorrect or expired OTP code. Please try again."
                else -> msg
            }
            Result.failure(Exception(userFriendly, e))
        }
    }

    /**
     * Resolve the post-OTP state directly from the AWS OTP verification response.
     * The AWS /v1/auth/otp/verify endpoint already performs phone-to-profile matching
     * and returns status, session, user, and (for existing users) profile. Do not make
     * a second call to the legacy Supabase Edge Function, which is not deployed on AWS.
     */
    fun resolveVerifiedPhoneSession(
        verifiedResponse: JSONObject,
        verifiedPhone: String,
        callerUserId: String,
        phoneRefreshToken: String? = null
    ): Result<PhoneResolutionResult> {
        return try {
            val status = verifiedResponse.optString("status")
            val sessionJson = verifiedResponse.optJSONObject("session")
                ?: throw IllegalStateException("OTP verification response is missing the session.")
            val accessToken = sessionJson.optString("access_token").takeIf { it.isNotBlank() }
                ?: verifiedResponse.optString("access_token").takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("OTP verification response is missing the access token.")
            val userObj = verifiedResponse.optJSONObject("user")
            val tokenUserId = sessionManager.getUserIdFromToken(accessToken).orEmpty()
            val responseUserId = userObj?.optString("id").orEmpty().ifBlank { callerUserId }
            val userId = responseUserId.ifBlank { tokenUserId }
            if (userId.isBlank()) {
                throw IllegalStateException("OTP verification response is missing the user ID.")
            }
            if (tokenUserId.isNotBlank() && userId != tokenUserId) {
                throw IllegalStateException("OTP verification returned mismatched session identity.")
            }
            val phoneFromResponse = userObj?.optString("phone").orEmpty().ifBlank { verifiedPhone }
            val mobile10 = extract10DigitMobile(phoneFromResponse)
            if (mobile10.length != 10) {
                throw IllegalStateException("OTP verification returned an invalid phone identity.")
            }
            val e164 = "+91$mobile10"
            val refreshToken = sessionJson.optString("refresh_token")
                .ifBlank { phoneRefreshToken.orEmpty() }
                .takeIf { it.isNotBlank() }
            val userSession = UserSession(
                accessToken = accessToken,
                refreshToken = refreshToken,
                user = AuthUser(id = userId, email = null, phone = e164, role = "authenticated")
            )

            when (status) {
                "existing_user" -> {
                    val profileJson = verifiedResponse.optJSONObject("profile")
                        ?: throw IllegalStateException("Verified account profile was not returned by the server.")
                    val profile = parseUserProfile(profileJson)
                    if (profile.id.isNotBlank() && profile.id != userId) {
                        throw IllegalStateException("Verified profile does not match the authenticated user.")
                    }
                    if (profile.accountStatus.isNotBlank() &&
                        !profile.accountStatus.equals("active", ignoreCase = true) &&
                        !profile.accountStatus.equals("approved", ignoreCase = true)) {
                        sessionManager.clearSession()
                        Result.success(PhoneResolutionResult.AccountRestricted(
                            profile.accountStatus,
                            "Your account is ${profile.accountStatus}. Please contact BAATLY support."
                        ))
                    } else {
                        sessionManager.clearSession()
                        sessionManager.saveSession(accessToken, userId, profile, refreshToken)
                        Result.success(PhoneResolutionResult.ExistingUser(userSession, profile))
                    }
                }
                "new_user" -> {
                    sessionManager.clearSession()
                    sessionManager.saveSession(accessToken, userId, refreshToken = refreshToken)
                    Result.success(PhoneResolutionResult.NewUser(mobile10, userId, userSession))
                }
                "conflict" -> {
                    sessionManager.clearSession()
                    Result.success(PhoneResolutionResult.Conflict(
                        verifiedResponse.optString("message").ifBlank {
                            "We couldn't safely identify your existing account. Please contact BAATLY support."
                        }
                    ))
                }
                "account_restricted" -> {
                    val accountStatus = verifiedResponse.optString("account_status").ifBlank { "restricted" }
                    sessionManager.clearSession()
                    Result.success(PhoneResolutionResult.AccountRestricted(
                        accountStatus,
                        verifiedResponse.optString("message").ifBlank {
                            "Your account is $accountStatus. Please contact BAATLY support."
                        }
                    ))
                }
                else -> {
                    sessionManager.clearSession()
                    Result.failure(IllegalStateException(
                        "OTP verification returned an unsupported account status. Please retry."
                    ))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun resolvePhoneSession(
        verifiedPhone: String,
        phoneAuthToken: String,
        callerUserId: String,
        phoneRefreshToken: String? = null
    ): Result<PhoneResolutionResult> {
        val mobile10 = extract10DigitMobile(verifiedPhone)
        val e164 = "+91$mobile10"

        return try {
            val resolverBody = JSONObject().apply {
                put("phone", e164)
            }.toString()

            val responseStr = client.callEdgeFunction(
                functionName = "resolve-user-phone-session",
                jsonBody = resolverBody,
                tokenOverride = phoneAuthToken
            )
            val json = JSONObject(responseStr)
            val status = json.optString("status")

            when (status) {
                "existing_user" -> {
                    val sessionJson = json.getJSONObject("session")
                    val profileJson = json.getJSONObject("profile")
                    val accToken = sessionJson.getString("access_token")
                    val rawRefToken = sessionJson.optString("refresh_token").takeIf { it.isNotBlank() }
                    val origUserId = sessionJson.getString("user_id")
                    val profile = parseUserProfile(profileJson)

                    // Safe fallback ONLY when the resolved user ID matches callerUserId and is same verified phone identity
                    val refToken = if (rawRefToken != null) {
                        rawRefToken
                    } else if (origUserId == callerUserId && !phoneRefreshToken.isNullOrBlank()) {
                        phoneRefreshToken
                    } else {
                        null
                    }

                    sessionManager.saveSession(accToken, origUserId, profile, refToken)
                    val userSession = UserSession(
                        accessToken = accToken,
                        refreshToken = refToken,
                        user = AuthUser(id = origUserId, email = null, phone = e164, role = "authenticated")
                    )
                    Result.success(PhoneResolutionResult.ExistingUser(userSession, profile))
                }
                "new_user" -> {
                    val tempUserId = json.optString("temp_auth_user_id").takeIf { it.isNotBlank() }
                        ?: callerUserId.takeIf { it.isNotBlank() }
                        ?: sessionManager.getUserIdFromToken(phoneAuthToken)
                        ?: callerUserId
                    sessionManager.saveSession(phoneAuthToken, tempUserId, refreshToken = phoneRefreshToken)
                    val userSession = UserSession(
                        accessToken = phoneAuthToken,
                        refreshToken = phoneRefreshToken,
                        user = AuthUser(id = tempUserId, email = null, phone = e164, role = "authenticated")
                    )
                    Result.success(PhoneResolutionResult.NewUser(mobile10, tempUserId, userSession))
                }
                "conflict" -> {
                    val msg = json.optString("message", "We couldn't safely identify your existing account. Please contact BAATLY support.")
                    sessionManager.clearSession()
                    Result.success(PhoneResolutionResult.Conflict(msg))
                }
                "account_restricted" -> {
                    val accStatus = json.optString("account_status", "restricted")
                    val msg = json.optString("message", "Your account is $accStatus. Please contact BAATLY support.")
                    sessionManager.clearSession()
                    Result.success(PhoneResolutionResult.AccountRestricted(accStatus, msg))
                }
                else -> {
                    val errorMsg = json.optString("error", json.optString("message", "Unexpected account resolution response."))
                    sessionManager.clearSession()
                    Result.failure(Exception(errorMsg))
                }
            }
        } catch (e: Exception) {
            val msg = e.message ?: ""
            Log.e("SupabaseAuthService", "resolvePhoneSession error: $msg", e)
            val userFriendly = when {
                msg.contains("404") || msg.contains("Function not found", ignoreCase = true) ->
                    "Account resolver service is currently undergoing deployment. Please try again shortly."
                msg.contains("timeout", ignoreCase = true) || msg.contains("connection", ignoreCase = true) ->
                    "Network error while verifying account. Please check your connection and try again."
                else -> "Unable to complete account resolution right now. Please try again."
            }
            Result.failure(Exception(userFriendly, e))
        }
    }

    suspend fun generateUniqueUserId(displayName: String): String {
        val base = displayName.trim().lowercase()
            .filter { it.isLetterOrDigit() }
            .take(12)
            .ifBlank { "user" }

        for (i in 0 until 5) {
            val randomNum = (1000..9999).random()
            val candidate = "${base}_$randomNum"
            if (checkUserIdAvailable(candidate)) {
                return candidate
            }
        }
        val timestampCandidate = "${base}_${System.currentTimeMillis() % 1000000}"
        if (checkUserIdAvailable(timestampCandidate)) {
            return timestampCandidate
        }
        return "${base}_${UUID.randomUUID().toString().take(6)}"
    }

    suspend fun completePhoneUserProfile(
        verifiedMobile: String,
        displayName: String,
        bio: String?,
        avatarFile: File?,
        referralCode: String?
    ): Result<UserProfile> {
        val cleanMobile = extract10DigitMobile(verifiedMobile)
        val cleanDisplayName = displayName.trim()
        val cleanBio = bio?.trim()?.takeIf { it.isNotBlank() }
        val cleanReferral = referralCode?.trim()?.takeIf { it.isNotBlank() }
        if (cleanMobile.length != 10 || cleanDisplayName.isBlank()) {
            return Result.failure(IllegalArgumentException("Please check your phone number and display name."))
        }

        // The verified OTP token temporarily authenticates this phone before a profile exists.
        val sessionCheck = client.ensureValidSession()
        val (sessionToken, authUserId) = when (sessionCheck) {
            is com.example.data.model.SessionResult.Valid -> {
                val uid = sessionCheck.userId.ifBlank {
                    sessionManager.userId.value.orEmpty().ifBlank {
                        sessionManager.getUserIdFromToken(sessionCheck.accessToken).orEmpty()
                    }
                }
                sessionCheck.accessToken to uid
            }
            else -> {
                val token = sessionManager.accessToken.value
                val uid = sessionManager.userId.value.takeIf { !it.isNullOrBlank() }
                    ?: sessionManager.getUserIdFromToken(token)
                val isTokenStillValid = !token.isNullOrBlank() && !sessionManager.isTokenExpiredOrNearExpiry(token, 0)
                if (isTokenStillValid && !uid.isNullOrBlank()) {
                    token!! to uid
                } else if (!token.isNullOrBlank() && sessionManager.isTokenExpiredOrNearExpiry(token, 0)) {
                    return Result.failure(IllegalStateException("Your phone verification session has expired. Please restart verification."))
                } else {
                    return Result.failure(IllegalStateException("No verified phone session. Please restart verification."))
                }
            }
        }
        if (authUserId.isBlank() || sessionToken.isBlank()) {
            return Result.failure(IllegalStateException("No verified phone session. Please restart verification."))
        }

        return try {
            // Upload selected profile photo via JSON presign request + direct S3 PUT.
            var avatarPath: String? = null
            if (avatarFile != null) {
                val ext = avatarFile.extension.ifBlank { "jpg" }
                val relativePath = "$authUserId/${UUID.randomUUID()}.$ext"
                avatarPath = client.uploadFile(
                    SupabaseConfig.BUCKET_PROFILE_MEDIA,
                    relativePath,
                    avatarFile,
                    "image/jpeg"
                )
            }

            // The AWS handler exposes /v1/auth/signup; the old complete_user_signup RPC is not allow-listed.
            var attempts = 0
            var lastConflict: Exception? = null
            while (attempts < 4) {
                attempts++
                val assignedUserId = generateUniqueUserId(cleanDisplayName)
                val signupBody = JSONObject()
                    .put("user_id", assignedUserId)
                    .put("display_name", cleanDisplayName)
                    .put("bio", cleanBio ?: JSONObject.NULL)
                if (avatarPath != null) signupBody.put("avatar_url", avatarPath)
                if (cleanReferral != null) signupBody.put("referral_code", cleanReferral)

                try {
                    val signupResponse = client.post(
                        "${SupabaseConfig.apiBaseUrl}/v1/auth/signup",
                        signupBody.toString()
                    )
                    val signupJson = JSONObject(signupResponse)
                    if (!signupJson.optBoolean("success", false)) {
                        throw SupabaseException(
                            signupJson.optString("error", "Profile creation failed. Please try again."),
                            400,
                            signupResponse
                        )
                    }
                    val profileJson = signupJson.optJSONObject("profile")
                        ?: throw SupabaseException("Profile creation returned no profile.", 502, signupResponse)
                    val profile = parseUserProfile(profileJson)
                    val newSession = signupJson.optJSONObject("session")
                    val finalAccessToken = newSession?.optString("access_token")
                        ?.takeIf { it.isNotBlank() } ?: sessionToken
                    val finalRefreshToken = newSession?.optString("refresh_token")
                        ?.takeIf { it.isNotBlank() } ?: sessionManager.refreshToken.value
                    sessionManager.saveSession(
                        finalAccessToken,
                        profile.id.ifBlank { authUserId },
                        profile,
                        finalRefreshToken
                    )
                    return Result.success(profile)
                } catch (e: Exception) {
                    val message = e.message.orEmpty().lowercase()
                    if (message.contains("already registered") ||
                        message.contains("user_id is already taken") ||
                        message.contains("duplicate key") || message.contains("user id already exists")) {
                        lastConflict = e
                        continue
                    }
                    throw e
                }
            }
            throw SupabaseException(
                lastConflict?.message ?: "Failed to generate a unique User ID. Please try again.",
                409,
                lastConflict?.message.orEmpty()
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun signOut() {
        sessionManager.clearSession()
    }

    suspend fun requestAccountDeletion(): Result<Unit> {
        val currentUserId = sessionManager.userId.value
        if (currentUserId.isNullOrBlank()) {
            return Result.failure(IllegalStateException("User is not authenticated"))
        }
        return try {
            val response = client.rpc("request_account_deletion")
            android.util.Log.d("SupabaseAuthService", "request_account_deletion response: $response")
            Result.success(Unit)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseAuthService", "request_account_deletion failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun parseUserProfile(json: JSONObject): UserProfile {
        return UserProfile(
            id = json.optString("id"),
            userId = json.optString("user_id"),
            username = json.optString("username"),
            displayName = json.optString("display_name"),
            avatarUrl = json.optString("avatar_url").takeIf { it.isNotBlank() },
            bio = json.optString("bio").takeIf { it.isNotBlank() },
            gender = json.optString("gender"),
            language = json.optString("language"),
            accountStatus = json.optString("account_status", "active"),
            isOnline = json.optBoolean("is_online", false),
            mobileNumber = json.optString("mobile_number"),
            referralCode = json.optString("referral_code"),
            referralCodeUsed = json.optString("referral_code_used"),
            rating = json.optDouble("rating", 5.0),
            reviewsCount = json.optInt("reviews_count", 0),
            totalCalls = json.optInt("total_calls", 0),
            createdAt = json.optString("created_at")
        )
    }
}
