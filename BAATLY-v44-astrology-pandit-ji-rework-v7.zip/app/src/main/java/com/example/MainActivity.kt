package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.notification.NotificationHelper
import com.example.ui.*
import com.example.ui.auth.AuthScreen
import com.example.ui.call.ActiveCallScreen
import com.example.ui.chat.BaatlySystemChatScreen
import com.example.ui.chat.ChatListScreen
import com.example.ui.chat.DirectChatScreen
import com.example.ui.components.BaatlyBottomNavBar
import com.example.ui.components.CallRatingDialog
import com.example.ui.components.GiftAnimationOverlay
import com.example.ui.components.RechargePopup
import com.example.ui.components.ReportUserDialog
import com.example.ui.gift.GiftBottomSheet
import com.example.ui.home.HomeScreen
import com.example.ui.host.HostProfileScreen
import com.example.ui.notifications.NotificationsScreen
import com.example.ui.onboarding.OnboardingFlow
import com.example.data.model.UroPayPaymentUiState
import com.example.ui.profile.UserProfileScreen
import com.example.ui.recent.RecentCallsScreen
import com.example.ui.theme.BaatlyTheme
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.wallet.WalletScreen
import com.example.ui.astrologer.AstrologerScreen
import com.example.ui.social.SocialScreen
import com.example.ui.social.SocialProfileScreen
import com.example.ui.entertainment.EntertainmentScreen
import com.example.ui.superai.SuperAiScreen
import com.example.ui.media.FullScreenMediaViewer
import com.example.data.model.PhoneAuthStep

class MainActivity : BaseActivity() {

    private val viewModel: BaatlyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BaatlyApplication.applyWindowProtection(this)
        enableEdgeToEdge()

        // Initialize Notification Channels
        NotificationHelper.createNotificationChannels(this)

        // Process any tap from Notification or Deep Link
        handleNotificationIntent(intent)
        handleDeepLinkIntent(intent)

        // Pre-warm Custom Tabs provider for fast checkout launch
        com.example.ui.payment.UroPayCheckoutLauncher.prewarm(this)

        setContent {
            BaatlyTheme {
                BaatlyApp(viewModel = viewModel)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        com.example.ui.payment.UroPayCheckoutLauncher.unbind(this)
    }

    override fun onResume() {
        super.onResume()
        NotificationHelper.isAppInForeground = true
        viewModel.onAppResumed()
    }

    override fun onPause() {
        super.onPause()
        NotificationHelper.isAppInForeground = false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
        handleDeepLinkIntent(intent)
    }

    private fun handleDeepLinkIntent(intent: Intent?) {
        val data = intent?.data ?: return
        android.util.Log.d("MainActivity", "handleDeepLinkIntent: data=$data")
        viewModel.handlePaymentReturnDeepLink(data)
    }

    private fun handleNotificationIntent(intent: Intent?) {
        val extras = intent?.extras ?: return
        val isAcceptCall = extras.getBoolean("extra_accept_call", false)
        if (isAcceptCall) {
            val callId = extras.getString("call_id").orEmpty()
            val partnerId = extras.getString("partner_id").orEmpty()
            val callType = extras.getString("call_type").orEmpty()
            val isVideo = callType.lowercase().contains("video")
            viewModel.acceptIncomingCall(callId, partnerId, isVideo)
            return
        }
        val map = mutableMapOf<String, String?>()
        for (key in extras.keySet()) {
            map[key] = extras.get(key)?.toString()
        }
        val notifType = extras.getString("notification_type") ?: extras.getString("type")
        val navigateToCall = extras.getBoolean("extra_navigate_to_call", false)
        if (navigateToCall) {
            viewModel.setScreen(Screen.ACTIVE_CALL)
            return
        }
        if (!notifType.isNullOrBlank() || map.containsKey("conversation_id") || map.containsKey("call_id") || map.containsKey("partner_id")) {
            viewModel.handleNotificationTap(notifType, map)
        }
    }
}

@Composable
fun BaatlyApp(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val token by viewModel.isLoggedIn.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val phoneAuthStep by viewModel.phoneAuthStep.collectAsState()
    val isOnboardingCompleted by viewModel.isOnboardingCompleted.collectAsState()
    val isRestoringSession by viewModel.isRestoringSession.collectAsState()
    val startupError by viewModel.startupError.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val showGiftSheet by viewModel.showGiftSheet.collectAsState()
    val recentGift by viewModel.recentGiftAnimation.collectAsState()
    val pendingRatingCall by viewModel.pendingRatingCall.collectAsState()
    val isSubmittingRating by viewModel.isSubmittingRating.collectAsState()
    val activeReportTarget by viewModel.activeReportTarget.collectAsState()
    val isSubmittingReport by viewModel.isSubmittingReport.collectAsState()
    val paymentState by viewModel.uropayPaymentState.collectAsState()
    val showRechargePopup by viewModel.showRechargePopup.collectAsState()

    // Trigger UroPay Browser Launch on OpeningCheckout state (one-shot launch)
    LaunchedEffect(paymentState) {
        val state = paymentState
        if (state is UroPayPaymentUiState.OpeningCheckout) {
            val success = com.example.ui.payment.UroPayCheckoutLauncher.launch(
                context = context,
                openUrl = state.openUrl,
                paymentId = state.paymentId,
                onError = { errMsg ->
                    viewModel.onCheckoutLaunchFailed(state.paymentId, errMsg, state.amountRupees)
                }
            )
            if (success) {
                viewModel.onCheckoutLaunched(state.paymentId)
            }
        }
    }

    // Request Audio Permission for Voice Calls & Notes
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    // Request Notification Permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(token) {
        if (!token.isNullOrBlank() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Show User Messages / Toasts
    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    val activeCall by viewModel.activeCall.collectAsState()
    val callState by viewModel.callState.collectAsState()
    val activePartner by viewModel.activeCallPartner.collectAsState()
    val isCallActiveInBackground = activeCall != null && (callState == CallState.CONNECTED || callState == CallState.RINGING)
    val activity = context as? android.app.Activity

    // Back button handling
    BackHandler(enabled = currentScreen !in listOf(Screen.HOME, Screen.SOCIAL, Screen.AUTH)) {
        if (isCallActiveInBackground && currentScreen == Screen.CHAT_LIST) {
            viewModel.setScreen(Screen.ACTIVE_CALL)
        } else {
            when (currentScreen) {
                Screen.PROFILE -> viewModel.setScreen(if (isCallActiveInBackground) Screen.ACTIVE_CALL else Screen.SOCIAL_PROFILE)
                Screen.HOST_PROFILE, Screen.RECENT_CALLS, Screen.WALLET,
                Screen.NOTIFICATIONS, Screen.ASTROLOGER, Screen.SOCIAL_PROFILE,
                Screen.ENTERTAINMENT, Screen.SUPER_AI -> {
                    viewModel.setScreen(if (isCallActiveInBackground) Screen.ACTIVE_CALL else Screen.SOCIAL)
                }
                Screen.LEGAL_DETAIL -> {
                    viewModel.closeLegalPage()
                }
                Screen.CHAT_LIST -> {
                    viewModel.setScreen(if (isCallActiveInBackground) Screen.ACTIVE_CALL else Screen.SOCIAL)
                }
                Screen.DIRECT_CHAT -> {
                    viewModel.closeChatScreen()
                }
                Screen.BAATLY_SYSTEM_CHAT -> {
                    viewModel.setScreen(Screen.CHAT_LIST)
                }
                Screen.FULL_SCREEN_MEDIA_VIEWER -> {
                    viewModel.closeFullScreenMedia()
                }
                Screen.ACTIVE_CALL -> {
                    // Send app to background so ongoing call continues with foreground service
                    activity?.moveTaskToBack(true)
                }
                else -> {}
            }
        }
    }

    val isUserFullyAuthenticated = !token.isNullOrBlank() &&
        currentUser != null &&
        currentUser?.userId?.isNotBlank() == true &&
        currentUser?.displayName?.isNotBlank() == true &&
        phoneAuthStep !is PhoneAuthStep.ProfileCompletion &&
        currentScreen != Screen.AUTH

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = DarkBackground
    ) {
        when {
            startupError != null -> {
                StartupErrorScreen(
                    errorMessage = startupError ?: "Something went wrong. Please retry.",
                    onRetry = { viewModel.retryStartup() }
                )
            }
            isRestoringSession -> {
                StartupLoadingScreen()
            }
            !isOnboardingCompleted && !isUserFullyAuthenticated -> {
                OnboardingFlow(
                    onComplete = {
                        viewModel.completeOnboarding()
                    }
                )
            }
            !isUserFullyAuthenticated -> {
                AuthScreen(viewModel = viewModel)
            }
            else -> {
                Scaffold(
                    bottomBar = {
                        if (currentScreen in listOf(Screen.HOME, Screen.CHAT_LIST, Screen.ASTROLOGER, Screen.SOCIAL, Screen.ENTERTAINMENT, Screen.SUPER_AI, Screen.SOCIAL_PROFILE)) {
                            BaatlyBottomNavBar(
                                currentScreen = currentScreen,
                                onNavigate = { screen -> viewModel.setScreen(screen) }
                            )
                        }
                    },
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    containerColor = DarkBackground
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = if (currentScreen in listOf(Screen.HOME, Screen.CHAT_LIST, Screen.ASTROLOGER, Screen.SOCIAL, Screen.ENTERTAINMENT, Screen.SUPER_AI, Screen.SOCIAL_PROFILE)) innerPadding.calculateBottomPadding() else 0.dp)
                    ) {
                        when (currentScreen) {
                            Screen.AUTH -> AuthScreen(viewModel = viewModel)
                            Screen.HOME -> HomeScreen(viewModel = viewModel)
                            Screen.HOST_PROFILE -> HostProfileScreen(viewModel = viewModel)
                            Screen.ACTIVE_CALL -> {
                                val isVideoCall = viewModel.agoraCallManager.isVideoCall.collectAsState().value ||
                                                  viewModel.activeCall.collectAsState().value?.callType.equals("video", ignoreCase = true)
                                if (isVideoCall) {
                                    com.example.ui.call.VideoCallScreen(viewModel = viewModel)
                                } else {
                                    ActiveCallScreen(viewModel = viewModel)
                                }
                            }
                            Screen.DIRECT_CHAT -> DirectChatScreen(viewModel = viewModel)
                            Screen.BAATLY_SYSTEM_CHAT -> BaatlySystemChatScreen(viewModel = viewModel)
                            Screen.CHAT_LIST -> ChatListScreen(viewModel = viewModel)
                            Screen.WALLET -> WalletScreen(viewModel = viewModel)
                            Screen.RECENT_CALLS -> RecentCallsScreen(viewModel = viewModel)
                            Screen.PROFILE -> UserProfileScreen(viewModel = viewModel)
                            Screen.NOTIFICATIONS -> NotificationsScreen(viewModel = viewModel)
                            Screen.ASTROLOGER -> AstrologerScreen(viewModel = viewModel)
                            Screen.SOCIAL -> SocialScreen(viewModel = viewModel)
                            Screen.SOCIAL_PROFILE -> SocialProfileScreen(viewModel = viewModel)
                            Screen.ENTERTAINMENT -> EntertainmentScreen(viewModel = viewModel)
                            Screen.SUPER_AI -> SuperAiScreen(viewModel = viewModel)
                            Screen.FULL_SCREEN_MEDIA_VIEWER -> {
                                val mediaUrl by viewModel.fullScreenMediaUrl.collectAsState()
                                if (!mediaUrl.isNullOrBlank()) {
                                    FullScreenMediaViewer(
                                        mediaUrl = mediaUrl!!,
                                        mediaType = viewModel.fullScreenMediaType.collectAsState().value,
                                        onDismiss = { viewModel.closeFullScreenMedia() }
                                    )
                                } else {
                                    HomeScreen(viewModel = viewModel)
                                }
                            }
                            Screen.LEGAL_DETAIL -> {
                                val activeLegalPage by viewModel.activeLegalPage.collectAsState()
                                if (activeLegalPage != null) {
                                    com.example.ui.legal.LegalDetailScreen(
                                        page = activeLegalPage!!,
                                        onBack = { viewModel.closeLegalPage() }
                                    )
                                } else {
                                    UserProfileScreen(viewModel = viewModel)
                                }
                            }
                        }

                        // Background Active Call Banner
                        if (isCallActiveInBackground && currentScreen != Screen.ACTIVE_CALL) {
                            Surface(
                                color = androidx.compose.ui.graphics.Color(0xFF2E7D32),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .statusBarsPadding()
                                    .padding(top = 10.dp, start = 16.dp, end = 16.dp)
                                    .fillMaxWidth()
                                    .clickable { viewModel.setScreen(Screen.ACTIVE_CALL) }
                                    .testTag("banner_active_call_in_bg")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Call,
                                            contentDescription = null,
                                            tint = androidx.compose.ui.graphics.Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "Call in progress with ${activePartner?.displayName ?: "Host"}",
                                            color = androidx.compose.ui.graphics.Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                    Text(
                                        text = "TAP TO RETURN",
                                        color = androidx.compose.ui.graphics.Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }

                        if (showGiftSheet) {
                            GiftBottomSheet(viewModel = viewModel)
                        }

                        recentGift?.let { gift ->
                            GiftAnimationOverlay(gift = gift)
                        }

                        // Call-End Rating Dialog (Authoritative)
                        pendingRatingCall?.let { pending ->
                            CallRatingDialog(
                                pendingCall = pending,
                                isSubmitting = isSubmittingRating,
                                onDismiss = { viewModel.dismissRatingPopup() },
                                onSubmit = { rating, reviewText ->
                                    viewModel.submitCallRating(rating, reviewText)
                                }
                            )
                        }

                        // User / Host Reporting Dialog (Authoritative)
                        activeReportTarget?.let { target ->
                            ReportUserDialog(
                                target = target,
                                isSubmitting = isSubmittingReport,
                                onDismiss = { viewModel.closeReportDialog() },
                                onSubmit = { category, description ->
                                    viewModel.submitUserReport(category, description)
                                }
                            )
                        }

                        // Render UroPay Payment Status Dialog globally if not on Wallet screen
                        if (currentScreen != Screen.WALLET && paymentState !is UroPayPaymentUiState.Idle) {
                            com.example.ui.wallet.UroPayPaymentStatusDialog(
                                state = paymentState,
                                onDismiss = { viewModel.resetPaymentState() },
                                onLaunchCheckoutAgain = { url ->
                                    val pid = (paymentState as? UroPayPaymentUiState.OpeningCheckout)?.paymentId
                                    com.example.ui.payment.UroPayCheckoutLauncher.launch(
                                        context = context,
                                        openUrl = url,
                                        paymentId = pid,
                                        force = true,
                                        onError = { errMsg ->
                                            viewModel.showUserMessage(errMsg)
                                        }
                                    )
                                },
                                onVerifyAgain = { paymentId -> viewModel.verifyUroPayPayment(paymentId) }
                            )
                        }

                        // Low Balance Call Quick Recharge Popup
                        if (showRechargePopup) {
                            RechargePopup(
                                viewModel = viewModel,
                                onDismiss = { viewModel.closeRechargePopup() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StartupLoadingScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(
                color = NeonPink,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = "Starting Baatly...",
                color = TextMuted,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun StartupErrorScreen(errorMessage: String, onRetry: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = null,
                    tint = NeonPink,
                    modifier = Modifier.size(56.dp)
                )
                Text(
                    text = "Something went wrong",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = errorMessage,
                    color = TextMuted,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_retry_startup")
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Retry", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
