# BAATLY v50 — AdMob placement, sizing and host filters

## Changes applied

### 1. Compact native ad component
- Replaced the tall native-ad layout (large media block, long body copy and oversized assets) with a compact native card.
- The compact card uses a small media/icon area, short headline/body lines, a small CTA and visible `Ad` attribution. Its Compose height is constrained to 70–116 dp.
- Removed the large anchored adaptive-banner implementation from the Entertainment flow so it cannot occupy the previous oversized banner area.
- Pandit Ji and Super AI keep their existing post-reply native-ad placements, but they now use the compact component too. The same applies to host lists, chat list, Feed, Reels and Entertainment.

### 2. Host service filters and actions
- Voice Call list now includes only online, available hosts with `audio_enabled = true`.
- Video Call list now includes only online, available hosts with both `video_enabled = true` and `video_call_access = true`. Selecting Video Call changes the actual list mode rather than showing the old unsupported toast.
- Love Note list now includes only online, available hosts with `chat_enabled = true`.
- Each host card displays only its selected service action: Voice Call, Video Call or Send Love Note. The Video Call action now invokes the existing `requestVideoCall` flow; the Love Note action remains the host chat entry point.
- Native ads remain in the Voice Call list after every five hosts. Video Call and Love Note lists insert a native ad after every three hosts so those filtered lists can show placements with fewer entries.

### 3. Social and Entertainment ad placements
- Feeds now insert a native ad after every five feed posts.
- Reels now insert a sponsored native-ad page after every five reels (previously every eight).
- Entertainment now has a compact native placement immediately after its category filters, even while the catalogue is loading or empty. Existing horizontal catalogue ad slots after item six and every ten additional items remain compact.

### 4. App-open ad lifecycle
- App-open eligibility is no longer tied only to the Play update callback. `MainActivity` now waits for both the update gate and AdMob readiness, and retries when either becomes ready.
- Ad preloading starts before the SDK-ready state is emitted to observers.
- A first app launch is no longer suppressed by a first-launch flag. A 10-minute cooldown prevents repeated launch ads during quick app switches. Background time is recorded in `onStop`, not `onPause`, and UMP consent-flow state is excluded, so the consent screen does not accidentally suppress the first-launch ad.
- If the app-open preload is not ready at the first poll, the code retries up to eight times at 900 ms intervals. The actual lifecycle helper is present in `MainActivity`; it checks AdMob readiness, update-gate resolution, Activity resumed state and active call state/record or the `ACTIVE_CALL` screen before showing and during retries.

## Verification completed
- ZIP source extracted successfully and source integrity checked.
- Kotlin parser checks completed without parser/syntax diagnostics for all five edited Kotlin files.
- Static source checks confirm the three host capability filters, corresponding action callbacks, Feed/Reels/Entertainment ad insertion points, and app-open lifecycle coordination.

## Build and runtime verification limits
- A full Android Gradle compile could not be completed here. The wrapper attempted to download Gradle 9.3.1 but DNS resolution for `services.gradle.org` failed (`UnknownHostException`). The standalone Kotlin parser check is not a substitute for Android/Compose type-checking.
- Actual ad impressions still depend on UMP consent, network connectivity, AdMob account/ad-unit serving status and inventory fill. A native slot can correctly request an ad yet remain hidden when Google returns no fill; confirm delivery in AdMob diagnostics and on a release-signed device.
- Before publishing, test each list with hosts whose relevant service flags are enabled, verify that only the matching action is visible, check a feed with at least five posts and a reels list with at least five items, check Entertainment while the catalogue is empty and populated, and verify app-open on first launch plus after the 30-minute cooldown.
