# BAATLY v51.1 — Release Kotlin compile fix

## Reported build failure

GitHub Actions failed during `:app:compileReleaseKotlin` with:

`MainActivity.kt:... Unresolved reference: BackHandler`

## Root cause

`MainActivity.kt` calls the Jetpack Compose `BackHandler` composable in `BaatlyApp`, but did not import it. Other project screens using the same API already import `androidx.activity.compose.BackHandler`.

## Fix applied

Added the missing import to:

`app/src/main/java/com/example/MainActivity.kt`

```kotlin
import androidx.activity.compose.BackHandler
```

No dependency change was needed. `app/build.gradle.kts` already includes `implementation(libs.androidx.activity.compose)`, and `gradle/libs.versions.toml` maps that alias to `androidx.activity:activity-compose:1.10.1`.

## Checks completed

- Confirmed the `BackHandler` import, call site, Gradle dependency alias and catalog version are consistent.
- Scanned every Kotlin source file: every file that calls `BackHandler` now has the matching import.
- Kotlin parser check of `MainActivity.kt`: no syntax/parser diagnostics. Standalone parser cannot type-check Android/Compose references without the Android dependency classpath.
- Parsed `AndroidManifest.xml`.
- Parsed `gradle/libs.versions.toml`.
- Parsed all 5 project JSON files.
- Verified the source ZIP integrity after packaging.

## Build verification limitation

A full Gradle compile could not be run in this environment because the wrapper distribution is not cached and `services.gradle.org` fails DNS resolution (`UnknownHostException`). Therefore this archive contains the source fix, not a compiled or device-tested APK. Run the existing GitHub Actions `Build signed Release APK` workflow again to perform the definitive `compileReleaseKotlin` and release build with the project's normal dependency environment.

## Versioning

Kept Android `versionCode` 51 and `versionName` 1.0.51 unchanged; this corrects the failed v51 source build and does not arbitrarily consume a new Play release version code.
