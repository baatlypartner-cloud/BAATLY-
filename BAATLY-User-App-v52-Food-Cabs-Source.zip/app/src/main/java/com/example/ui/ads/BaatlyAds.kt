package com.example.ui.ads

import android.app.Activity
import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.appopen.AppOpenAdPreloader
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize
import com.google.android.libraries.ads.mobile.sdk.banner.AdView
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import com.google.android.libraries.ads.mobile.sdk.common.PreloadConfiguration
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdEventCallback
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdPreloader
import com.google.android.libraries.ads.mobile.sdk.nativead.MediaView
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAd
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoader
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoaderCallback
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdRequest
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdView
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Centralized BAATLY AdMob IDs, loading pools, refresh and compact rendering. */
object BaatlyAds {
    const val APP_ID = "ca-app-pub-9363095174633972~9323820583"
    const val APP_OPEN = "ca-app-pub-9363095174633972/4795775416"
    const val HOST_LIST = "ca-app-pub-9363095174633972/3291122057"
    const val CHAT_LIST = "ca-app-pub-9363095174633972/2085851599"
    const val REELS = "ca-app-pub-9363095174633972/1485271702"
    const val PANDIT_AI = "ca-app-pub-9363095174633972/3351840962"
    const val SUPER_AI = "ca-app-pub-9363095174633972/9473387024"
    const val ENTERTAINMENT_BANNER = "ca-app-pub-9363095174633972/6354455002"
    const val ENTERTAINMENT_NATIVE = "ca-app-pub-9363095174633972/8980618347"
    const val POST_CALL = "ca-app-pub-9363095174633972/5375369073"

    private const val PREFS = "baatly_ad_frequency"
    private const val KEY_LAST_BACKGROUND = "last_background_at"
    private const val KEY_LAST_APP_OPEN = "last_app_open_shown"
    private const val APP_OPEN_COOLDOWN_MS = 90L * 1000L
    private const val MIN_BACKGROUND_MS = 3_500L
    private const val APP_OPEN_RETRY_DELAY_MS = 1_000L
    private const val APP_OPEN_MAX_RETRIES = 20
    private const val NATIVE_BATCH_SIZE = 5
    private const val MAX_CACHED_NATIVE_ADS_PER_UNIT = 10
    private const val MAX_EMPTY_BATCH_RETRIES = 2
    private val mainHandler = Handler(Looper.getMainLooper())
    private val appOpenAttemptPending = AtomicBoolean(false)
    private val initialized = AtomicBoolean(false)
    @Volatile private var sdkReady = false
    private val _readyState = MutableStateFlow(false)
    val readyState = _readyState.asStateFlow()
    private val _nativeRefreshGeneration = MutableStateFlow(0L)
    val nativeRefreshGeneration = _nativeRefreshGeneration.asStateFlow()

    private class NativePool {
        val cachedAds = ArrayDeque<NativeAd>()
        val waiting = ArrayDeque<(NativeAd?) -> Unit>()
        var loading = false
        var loadedInCurrentBatch = 0
        var emptyBatchRetries = 0
    }

    private val nativePools = ConcurrentHashMap<String, NativePool>()

    fun nativeUnit(productionId: String): String =
        if (BuildConfig.DEBUG) "/21775744923/example/native" else productionId

    fun bannerUnit(productionId: String): String =
        if (BuildConfig.DEBUG) "/21775744923/example/adaptive-banner" else productionId

    /** Called only after UMP has processed consent information. */
    fun initialize(context: Context) {
        if (!initialized.compareAndSet(false, true)) return
        Thread {
            try {
                MobileAds.initialize(
                    context.applicationContext,
                    InitializationConfig.Builder(APP_ID).build()
                ) {
                    sdkReady = true
                    startPreloading()
                    _readyState.value = true
                }
            } catch (t: Throwable) {
                initialized.set(false)
                android.util.Log.e("BaatlyAds", "GMA Next-Gen initialization failed", t)
            }
        }.start()
    }

    private fun startPreloading() {
        try {
            val appOpenId = if (BuildConfig.DEBUG) "/21775744923/example/app-open" else APP_OPEN
            AppOpenAdPreloader.start(
                appOpenId,
                PreloadConfiguration(AdRequest.Builder(appOpenId).build(), 2)
            )

            val interstitialId = if (BuildConfig.DEBUG) "/21775744923/example/interstitial" else POST_CALL
            InterstitialAdPreloader.start(
                interstitialId,
                PreloadConfiguration(AdRequest.Builder(interstitialId).build(), 2)
            )
        } catch (t: Throwable) {
            android.util.Log.w("BaatlyAds", "Ad preloading could not start", t)
        }
    }

    fun recordBackground(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putLong(KEY_LAST_BACKGROUND, System.currentTimeMillis()).apply()
    }

    /** First launch and meaningful returns are eligible; very brief app switches are ignored. */
    fun showAppOpenOnEligibleResume(activity: Activity, shouldBlock: () -> Boolean) {
        if (!sdkReady || shouldBlock() || activity.isFinishing || activity.isDestroyed) return
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val lastBackground = prefs.getLong(KEY_LAST_BACKGROUND, 0L)
        val lastShown = prefs.getLong(KEY_LAST_APP_OPEN, 0L)
        if (lastBackground > 0L && now - lastBackground < MIN_BACKGROUND_MS) return
        if (lastShown > 0L && now - lastShown < APP_OPEN_COOLDOWN_MS) return
        if (!appOpenAttemptPending.compareAndSet(false, true)) return

        val preloadId = if (BuildConfig.DEBUG) "/21775744923/example/app-open" else APP_OPEN
        fun pollAndShow(retriesLeft: Int) {
            if (activity.isFinishing || activity.isDestroyed || shouldBlock()) {
                appOpenAttemptPending.set(false)
                return
            }
            val ad = try {
                AppOpenAdPreloader.pollAd(preloadId)
            } catch (t: Throwable) {
                android.util.Log.w("BaatlyAds", "App-open poll failed: ${t.message}")
                null
            }
            if (ad == null) {
                if (retriesLeft > 0) {
                    mainHandler.postDelayed({ pollAndShow(retriesLeft - 1) }, APP_OPEN_RETRY_DELAY_MS)
                } else {
                    android.util.Log.w("BaatlyAds", "App-open ad was not filled/ready after preload retries")
                    appOpenAttemptPending.set(false)
                }
                return
            }
            try {
                ad.show(activity)
                prefs.edit().putLong(KEY_LAST_APP_OPEN, System.currentTimeMillis()).apply()
            } catch (t: Throwable) {
                android.util.Log.w("BaatlyAds", "App-open ad failed to show: ${t.message}")
            } finally {
                appOpenAttemptPending.set(false)
            }
        }
        mainHandler.post { pollAndShow(APP_OPEN_MAX_RETRIES) }
    }

    fun isReady(): Boolean = sdkReady

    /** Invalidate current screen's native cards; cards reload and the SDK batch pool refills. */
    fun refreshNativeAds() {
        nativePools.values.forEach { pool ->
            synchronized(pool) {
                while (pool.cachedAds.isNotEmpty()) {
                    runCatching { pool.cachedAds.removeFirst().destroy() }
                }
            }
        }
        _nativeRefreshGeneration.value = _nativeRefreshGeneration.value + 1L
    }

    private fun enqueueNativeAd(adUnitId: String, callback: (NativeAd?) -> Unit): () -> Unit {
        val pool = nativePools.getOrPut(adUnitId) { NativePool() }
        var immediateAd: NativeAd? = null
        var startBatch = false
        synchronized(pool) {
            if (pool.cachedAds.isNotEmpty()) {
                immediateAd = pool.cachedAds.removeFirst()
            } else {
                pool.waiting.addLast(callback)
                if (!pool.loading) {
                    pool.loading = true
                    startBatch = true
                }
            }
        }
        if (immediateAd != null) {
            val ad = immediateAd
            mainHandler.post { callback(ad) }
        } else if (startBatch) {
            loadNativeBatch(adUnitId, pool)
        }
        // Compose list items can leave composition during refresh/scroll. Remove stale
        // waiters so they do not consume and immediately destroy ads intended for visible slots.
        return {
            synchronized(pool) { pool.waiting.remove(callback) }
        }
    }

    private fun loadNativeBatch(adUnitId: String, pool: NativePool) {
        try {
            val request = NativeAdRequest.Builder(
                nativeUnit(adUnitId),
                listOf(NativeAd.NativeAdType.NATIVE)
            ).build()
            android.util.Log.d("BaatlyAds", "Loading native batch ($NATIVE_BATCH_SIZE) for $adUnitId")
            NativeAdLoader.load(request, NATIVE_BATCH_SIZE, object : NativeAdLoaderCallback {
                override fun onNativeAdLoaded(nativeAd: NativeAd) {
                    mainHandler.post {
                        var receiver: ((NativeAd?) -> Unit)? = null
                        var shouldCache = false
                        synchronized(pool) {
                            pool.loadedInCurrentBatch += 1
                            receiver = if (pool.waiting.isNotEmpty()) pool.waiting.removeFirst() else null
                            shouldCache = receiver == null && pool.cachedAds.size < MAX_CACHED_NATIVE_ADS_PER_UNIT
                            if (shouldCache) pool.cachedAds.addLast(nativeAd)
                        }
                        if (receiver != null) receiver?.invoke(nativeAd)
                        else if (!shouldCache) nativeAd.destroy()
                    }
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    android.util.Log.w("BaatlyAds", "Native batch item failed for $adUnitId: ${adError.message}")
                }

                override fun onAdLoadingCompleted() {
                    mainHandler.post {
                        var loadAnotherBatch = false
                        val pending = synchronized(pool) {
                            pool.loading = false
                            val batchHadAnyFill = pool.loadedInCurrentBatch > 0
                            pool.loadedInCurrentBatch = 0
                            if (pool.waiting.isNotEmpty() && (batchHadAnyFill || pool.emptyBatchRetries < MAX_EMPTY_BATCH_RETRIES)) {
                                // A batch contains at most five creatives. If more than five
                                // list slots are waiting (e.g. 10 ad positions in 50 hosts),
                                // immediately request another batch instead of failing them.
                                if (batchHadAnyFill) pool.emptyBatchRetries = 0 else pool.emptyBatchRetries += 1
                                pool.loading = true
                                loadAnotherBatch = true
                                emptyList<(NativeAd?) -> Unit>()
                            } else {
                                pool.emptyBatchRetries = 0
                                buildList {
                                    while (pool.waiting.isNotEmpty()) add(pool.waiting.removeFirst())
                                }
                            }
                        }
                        if (loadAnotherBatch) {
                            loadNativeBatch(adUnitId, pool)
                        } else {
                            // Deliver null only after bounded empty batches; each Compose slot
                            // then performs its own backoff retry instead of disappearing silently.
                            pending.forEach { it(null) }
                        }
                    }
                }
            })
        } catch (t: Throwable) {
            android.util.Log.e("BaatlyAds", "Native batch request failed for $adUnitId", t)
            val pending = synchronized(pool) {
                pool.loading = false
                pool.loadedInCurrentBatch = 0
                pool.emptyBatchRetries = 0
                buildList {
                    while (pool.waiting.isNotEmpty()) add(pool.waiting.removeFirst())
                }
            }
            mainHandler.post { pending.forEach { it(null) } }
        }
    }

    suspend fun awaitNativeAd(adUnitId: String): NativeAd? =
        withTimeoutOrNull(15_000L) {
            suspendCancellableCoroutine { continuation ->
                val removeWaiter = enqueueNativeAd(adUnitId) { ad ->
                    if (continuation.isActive) continuation.resume(ad)
                    else ad?.destroy()
                }
                continuation.invokeOnCancellation { removeWaiter() }
            }
        }

    /** Show a preloaded interstitial only after a completed (not cancelled/failed) call. */
    fun showPostCallInterstitial(activity: Activity) {
        if (!sdkReady || activity.isFinishing || activity.isDestroyed) return
        val preloadId = if (BuildConfig.DEBUG) "/21775744923/example/interstitial" else POST_CALL
        val ad = try { InterstitialAdPreloader.pollAd(preloadId) } catch (_: Throwable) { null } ?: return
        try {
            ad.adEventCallback = object : InterstitialAdEventCallback {
                override fun onAdDismissedFullScreenContent() {
                    android.util.Log.d("BaatlyAds", "Post-call ad dismissed")
                }
                override fun onAdFailedToShowFullScreenContent(fullScreenContentError: com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError) {
                    android.util.Log.w("BaatlyAds", "Post-call ad failed: ${fullScreenContentError.message}")
                }
                override fun onAdImpression() {
                    android.util.Log.d("BaatlyAds", "Post-call impression")
                }
            }
            ad.show(activity)
        } catch (t: Throwable) {
            android.util.Log.w("BaatlyAds", "Post-call interstitial could not be shown", t)
        }
    }
}

@Composable
fun BaatlyNativeAdCard(
    adUnitId: String,
    modifier: Modifier = Modifier,
    slotId: String = adUnitId
) {
    val sdkReady by BaatlyAds.readyState.collectAsState()
    val refreshGeneration by BaatlyAds.nativeRefreshGeneration.collectAsState()
    var loadedAd by remember(adUnitId, slotId) { mutableStateOf<NativeAd?>(null) }
    var failed by remember(adUnitId, slotId) { mutableStateOf(false) }
    val currentAd by rememberUpdatedState(loadedAd)

    LaunchedEffect(adUnitId, slotId, sdkReady, refreshGeneration) {
        loadedAd?.destroy()
        loadedAd = null
        failed = false
        if (!sdkReady) return@LaunchedEffect

        var result: NativeAd? = null
        for (attempt in 0 until 3) {
            result = BaatlyAds.awaitNativeAd(adUnitId)
            if (result != null) break
            if (attempt < 2) delay(2_500L * (attempt + 1))
        }
        loadedAd = result
        failed = result == null
        if (failed) android.util.Log.w("BaatlyAds", "No native ad fill after retries for $adUnitId slot=$slotId")
    }

    DisposableEffect(adUnitId, slotId) {
        onDispose { currentAd?.destroy() }
    }

    val ad = loadedAd
    if (ad != null && !failed) {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shape = RoundedCornerShape(13.dp),
            color = Color(0xFF18152D),
            border = BorderStroke(1.dp, Color(0xFF3E365F))
        ) {
            key(ad) {
                AndroidView(
                    modifier = Modifier.fillMaxWidth().heightIn(min = 78.dp, max = 118.dp),
                    factory = { ctx -> createCompactNativeAdView(ctx, ad) }
                )
            }
        }
    }
}

/** Restores the ninth configured placement as a compact 320x50 Entertainment banner. */
@Composable
fun BaatlyBannerAd(adUnitId: String, modifier: Modifier = Modifier, slotId: String = adUnitId) {
    val context = LocalContext.current
    val sdkReady by BaatlyAds.readyState.collectAsState()
    val refreshGeneration by BaatlyAds.nativeRefreshGeneration.collectAsState()
    var loaded by remember(adUnitId, slotId) { mutableStateOf(false) }
    val adView = remember(context, adUnitId, slotId, refreshGeneration) { AdView(context) }

    LaunchedEffect(adView, sdkReady, refreshGeneration) {
        loaded = false
        if (sdkReady) {
            val request = BannerAdRequest.Builder(
                BaatlyAds.bannerUnit(adUnitId),
                AdSize.BANNER
            ).build()
            for (attempt in 0 until 3) {
                val succeeded = withTimeoutOrNull(10_000L) {
                    suspendCancellableCoroutine<Boolean> { continuation ->
                    adView.loadAd(request, object : AdLoadCallback<BannerAd> {
                        override fun onAdLoaded(ad: BannerAd) {
                            android.util.Log.d("BaatlyAds", "Banner loaded for $slotId")
                            if (continuation.isActive) continuation.resume(true)
                        }
                        override fun onAdFailedToLoad(adError: LoadAdError) {
                            android.util.Log.w("BaatlyAds", "Banner attempt ${attempt + 1} failed for $slotId: ${adError.message}")
                            if (continuation.isActive) continuation.resume(false)
                        }
                    })
                    }
                } ?: false
                if (succeeded) {
                    loaded = true
                    break
                }
                if (attempt < 2) delay(2_000L * (attempt + 1))
            }
        }
    }

    DisposableEffect(adView) {
        onDispose { runCatching { adView.destroy() } }
    }

    if (loaded) {
        key(adView) {
            AndroidView(
                modifier = modifier.fillMaxWidth().height(50.dp),
                factory = { adView },
                update = { }
            )
        }
    }
}

private fun createCompactNativeAdView(context: Context, ad: NativeAd): NativeAdView {
    val root = NativeAdView(context).apply {
        setBackgroundColor(AndroidColor.rgb(24, 21, 45))
        setPadding(dp(context, 9), dp(context, 7), dp(context, 9), dp(context, 7))
    }
    val container = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val attributionRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val attribution = TextView(context).apply {
        text = "Ad"
        setTextColor(AndroidColor.rgb(255, 204, 96))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        typeface = Typeface.DEFAULT_BOLD
    }
    val advertiser = TextView(context).apply {
        text = ad.advertiser.orEmpty()
        setTextColor(AndroidColor.rgb(166, 160, 190))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(dp(context, 7), 0, 0, 0)
    }
    attributionRow.addView(attribution, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    attributionRow.addView(advertiser, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

    val contentRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val mediaView = MediaView(context).apply {
        imageScaleType = ImageView.ScaleType.CENTER_CROP
        visibility = if (ad.mediaContent.aspectRatio > 0f) View.VISIBLE else View.GONE
        layoutParams = LinearLayout.LayoutParams(dp(context, 56), dp(context, 56)).apply { rightMargin = dp(context, 8) }
    }
    val iconView = ImageView(context).apply {
        setImageDrawable(ad.icon?.drawable)
        visibility = if (ad.mediaContent.aspectRatio <= 0f && ad.icon?.drawable != null) View.VISIBLE else View.GONE
        scaleType = ImageView.ScaleType.CENTER_CROP
        layoutParams = LinearLayout.LayoutParams(dp(context, 40), dp(context, 40)).apply { rightMargin = dp(context, 8) }
    }
    val textColumn = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val headline = TextView(context).apply {
        text = ad.headline.orEmpty()
        setTextColor(AndroidColor.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = Typeface.DEFAULT_BOLD
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }
    val body = TextView(context).apply {
        text = ad.body.orEmpty()
        setTextColor(AndroidColor.rgb(204, 200, 219))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(0, dp(context, 2), 0, 0)
    }
    val cta = TextView(context).apply {
        text = ad.callToAction.orEmpty()
        setTextColor(AndroidColor.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(context, 8), dp(context, 4), dp(context, 8), dp(context, 4))
        setBackgroundColor(AndroidColor.rgb(112, 61, 183))
        visibility = if (ad.callToAction.isNullOrBlank()) View.GONE else View.VISIBLE
    }

    textColumn.addView(headline)
    if (ad.body?.isNotBlank() == true) textColumn.addView(body)
    if (!ad.callToAction.isNullOrBlank()) {
        textColumn.addView(cta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 3) })
    }
    if (mediaView.visibility == View.VISIBLE) contentRow.addView(mediaView)
    else if (iconView.visibility == View.VISIBLE) contentRow.addView(iconView)
    contentRow.addView(textColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    container.addView(attributionRow)
    container.addView(contentRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 3) })
    root.addView(container, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

    root.headlineView = headline
    root.iconView = iconView
    root.bodyView = body
    root.advertiserView = advertiser
    root.callToActionView = cta
    root.registerNativeAd(ad, mediaView)
    return root
}

private fun dp(context: Context, value: Int): Int =
    (value * context.resources.displayMetrics.density).toInt()
