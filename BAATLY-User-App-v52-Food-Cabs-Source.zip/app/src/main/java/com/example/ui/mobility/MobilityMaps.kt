package com.example.ui.mobility

import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.mobility.MobilityPoint
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val BaatlyMapStart = LatLng(28.6139, 77.2090)

@Composable
fun MobilityMap(
    modifier: Modifier = Modifier,
    pickup: MobilityPoint? = null,
    drop: MobilityPoint? = null,
    driver: LatLng? = null,
    pin: LatLng? = null,
    onMapTap: ((LatLng) -> Unit)? = null,
    showRoute: Boolean = false,
    routePoints: List<LatLng> = emptyList()
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var googleMap by remember { mutableStateOf<GoogleMap?>(null) }
    val mapView = remember(context) { MapView(context).apply { onCreate(Bundle()); onResume() } }

    DisposableEffect(lifecycle, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            runCatching { mapView.onPause(); mapView.onDestroy() }
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { view ->
            mapView.getMapAsync { map ->
                googleMap = map
                map.uiSettings.isMapToolbarEnabled = false
                map.uiSettings.isCompassEnabled = true
                map.uiSettings.isZoomControlsEnabled = false
                map.mapType = GoogleMap.MAP_TYPE_NORMAL
                onMapTap?.let { callback -> map.setOnMapClickListener { callback(it) } }
            }
            mapView
        },
        update = { view ->
            // The map instance is updated below through Compose state.
        }
    )

    LaunchedEffect(googleMap, pickup, drop, driver, pin, showRoute, routePoints) {
        val map = googleMap ?: return@LaunchedEffect
        map.clear()
        val points = mutableListOf<LatLng>()
        pickup?.let {
            val p = LatLng(it.latitude, it.longitude); points += p
            map.addMarker(MarkerOptions().position(p).title("Pickup"))
        }
        drop?.let {
            val p = LatLng(it.latitude, it.longitude); points += p
            map.addMarker(MarkerOptions().position(p).title("Drop"))
        }
        driver?.let {
            points += it
            map.addMarker(MarkerOptions().position(it).title("Your partner"))
        }
        pin?.let {
            points += it
            map.addMarker(MarkerOptions().position(it).draggable(false).title("Selected location"))
        }
        if (showRoute && points.size >= 2) {
            val roadPath = routePoints.ifEmpty { listOf(points[0], points[1]) }
            if (roadPath.size >= 2) map.addPolyline(PolylineOptions().addAll(roadPath).width(7f))
        }
        if (points.isEmpty()) points += BaatlyMapStart
        val update = if (points.size == 1) CameraUpdateFactory.newLatLngZoom(points.first(), 15f)
        else CameraUpdateFactory.newLatLngBounds(
            com.google.android.gms.maps.model.LatLngBounds.Builder().apply { points.forEach(::include) }.build(), 110
        )
        runCatching { map.animateCamera(update) }
    }
}

@Composable
fun LocationPickerDialog(
    title: String,
    initial: MobilityPoint?,
    onDismiss: () -> Unit,
    onConfirm: (MobilityPoint) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var selectedLatLng by remember {
        mutableStateOf(initial?.let { LatLng(it.latitude, it.longitude) } ?: BaatlyMapStart)
    }
    var label by remember { mutableStateOf(initial?.address.orEmpty()) }
    // Delhi is only the fallback camera center; never submit it as a real address
    // unless the user searched, moved the pin, or explicitly chose current location.
    var hasSelection by remember { mutableStateOf(initial != null) }
    var searching by remember { mutableStateOf(false) }
    var locating by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun reverseGeocode(latLng: LatLng, fallback: String = "Pinned location") {
        scope.launch {
            val address = withContext(Dispatchers.IO) {
                runCatching {
                    @Suppress("DEPRECATION")
                    Geocoder(context, Locale.getDefault()).getFromLocation(latLng.latitude, latLng.longitude, 1)
                        ?.firstOrNull()?.getAddressLine(0)
                }.getOrNull()
            }
            label = address?.takeIf { it.isNotBlank() } ?: fallback
        }
    }

    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val allowed = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (allowed) {
            locating = true
            LocationServices.getFusedLocationProviderClient(context).lastLocation
                .addOnSuccessListener { location ->
                    locating = false
                    if (location != null) {
                        selectedLatLng = LatLng(location.latitude, location.longitude)
                        hasSelection = true
                        reverseGeocode(selectedLatLng, "Current location")
                    } else message = "Current location is not available yet. Search or pin it on the map."
                }
                .addOnFailureListener { locating = false; message = "Could not read current location. Please pin it on the map." }
        } else message = "Location permission is needed to use your current location. You can still pin a location manually."
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it }, modifier = Modifier.weight(1f),
                        singleLine = true, label = { Text("Search area, building or landmark") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }
                    )
                    Spacer(Modifier.width(6.dp))
                    FilledTonalButton(enabled = query.isNotBlank() && !searching, onClick = {
                        searching = true; message = null
                        scope.launch {
                            val found = withContext(Dispatchers.IO) {
                                runCatching {
                                    @Suppress("DEPRECATION")
                                    Geocoder(context, Locale.getDefault()).getFromLocationName(query, 1)?.firstOrNull()
                                }.getOrNull()
                            }
                            searching = false
                            if (found != null) {
                                selectedLatLng = LatLng(found.latitude, found.longitude)
                                hasSelection = true
                                label = found.getAddressLine(0) ?: found.featureName ?: query
                            } else message = "No matching place found. Try a nearby landmark."
                        }
                    }) { if (searching) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Go") }
                }
                MobilityMap(
                    modifier = Modifier.fillMaxWidth().height(285.dp),
                    pin = selectedLatLng,
                    onMapTap = { selectedLatLng = it; hasSelection = true; reverseGeocode(it) }
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(label.ifBlank { "Move the pin to set the exact location" }, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = {
                        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (fine || coarse) {
                            locating = true
                            LocationServices.getFusedLocationProviderClient(context).lastLocation
                                .addOnSuccessListener { location ->
                                    locating = false
                                    if (location != null) { selectedLatLng = LatLng(location.latitude, location.longitude); hasSelection = true; reverseGeocode(selectedLatLng, "Current location") }
                                    else message = "Current location is unavailable."
                                }.addOnFailureListener { locating = false; message = "Unable to get location." }
                        } else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    }) {
                        if (locating) CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Default.MyLocation, contentDescription = "Use current location")
                    }
                }
                message?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val point = MobilityPoint(
                    label = title, address = label.ifBlank { "Pinned location" },
                    latitude = selectedLatLng.latitude, longitude = selectedLatLng.longitude
                )
                onConfirm(point)
            }, enabled = hasSelection, shape = RoundedCornerShape(14.dp)) { Text("Confirm location") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        shape = RoundedCornerShape(24.dp)
    )
}
