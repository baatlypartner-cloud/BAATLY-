# BAATLY v51 — Photos, AdMob delivery, refresh and update-gate removal

## Release metadata

- Android `versionCode`: **51**
- Android `versionName`: **1.0.51**
- Deliverable: Android source ZIP. This is not a compiled APK.

## 1. Photo loading and signed media URLs

- Removed the custom Coil storage keyers that stripped the query string from Supabase signed profile-media URLs. The image cache now uses the complete signed URL, including the time-limited token, rather than treating different signed URLs for the same object as the same cache entry.
- `resolveProfileAvatarUrl` now recognizes a Supabase signed Storage URL and re-signs its canonical object key. This helps when a profile record still contains an expired signed URL.
- Signed media URL cache lifetime shortened from 45 minutes to 25 minutes, below the one-hour signed URL expiry used by the app.
- Added bounded profile-image URL resolution retries. An unresolved storage key is no longer passed to Coil as though it were a network URL.
- Added one force-refresh retry on image load failure to common profile/avatar cards, Home host cards, feed creator avatars, the current user's profile, Social Profile, and post thumbnails/detail views.
- Added three bounded initial URL-resolution attempts (first cached/normal URL, then forced re-sign twice with backoff) for Feed posts, Reels, Stories, user/host profile grid and detail media, and Social Profile grid/detail media. Failed image rendering still has a separate forced refresh on `onError`.
- Added the same image-failure refresh path to the Social Feed header avatar and Explore Creators avatars.
- R2-backed post media refresh can now request a new playback URL by content ID when a canonical media path is not available; where a media path is present, the existing canonical-key refresh is used.

## 2. Play Store update-check removal

- Removed the Play In-App Update API flow and mandatory-update dialog from `MainActivity`.
- Removed the `com.google.android.play:app-update` and `app-update-ktx` dependencies.
- Kept UMP consent handling. Consent/privacy handling is separate from Play Store update enforcement and is still required before requesting ads where applicable.

## 3. Native ad loading pool and repeated placements

- Changed the shared native-ad pool to chain multiple SDK batches instead of ending after the first batch of five.
- The pool supports up to 10 cached native ads per unit, serves queued visible slots in order, and starts another batch when there are still waiting slots.
- Added bounded retries for empty batches and retained per-slot retry/backoff in `BaatlyNativeAdCard`.
- Added cancellation cleanup: when a LazyColumn item leaves composition during scroll/refresh, its pending callback is removed so it does not consume an ad and immediately destroy it.
- A screen refresh increments one shared generation. Mounted native cards and the Entertainment banner respond by requesting fresh inventory; unused cached native ads are destroyed.

## 4. Ad placement map

| Ad unit | Placement in v51 |
|---|---|
| App Open | Eligible app launch/resume, after UMP consent and AdMob initialization |
| Host List | After every 5 hosts in Voice Call, Video Call and Love Note lists |
| Chat List | After every 5 conversations |
| Reels | After every 5 feed posts and every 5 reels |
| Pandit Ji | After each assistant reply |
| Super AI | After each assistant reply |
| Entertainment Banner | Compact 320×50 banner after Entertainment filters |
| Entertainment Native | Compact native placement at the top and between catalogue carousel items |
| Post Call | Preloaded interstitial after an eligible completed call |

For a host list containing 50 filtered hosts, the LazyColumn now defines **10 host-list ad slots** (one after each fifth host) in all three modes. Feed and Reels also retain their repeated five-content-item cadence.

## 5. App Open behavior

- App Open preload polling is bounded to 20 attempts at one-second intervals after AdMob initialization.
- App Open ads are eligible on first launch and on a return after the app has been in the background for at least 3.5 seconds.
- A 90-second frequency guard avoids showing an App Open ad repeatedly during rapid app switches.
- App Open remains blocked during an active audio/video call.
- The old Play Store update gate is no longer part of App Open eligibility.

## 6. Refresh behavior

- Home pull-to-refresh and the Home refresh icon refresh native ad inventory and host data.
- Feed pull-to-refresh, recommendation refresh and Feed/Reels tab changes refresh native ad inventory.
- Chat-list pull-to-refresh refreshes native ad inventory and conversations.
- Entertainment catalogue retry refreshes ad inventory as well as catalogue content.
- Re-entering or switching a surface composes its individual slot IDs again; slots use unique IDs for easier request tracing.

## 7. Important AdMob serving limitation

The source creates the requested ad slots and retries failed loads, but client code cannot guarantee an impression for every slot. Google documents that multi-native loading accepts a maximum of five ads per batch and may return fewer than requested; v51 chains batches for additional waiting slots. Actual delivery still depends on consent, network, ad-unit configuration, inventory/no-fill, account status and any mediation configuration. Google also notes that multi-native loading is not supported for ad units configured for mediation. Confirm these production ad units are not configured for mediation before relying on the multi-load path.

## 8. Verification status

- Source inspection confirms the Play update-check code and dependencies are removed.
- Source inspection confirms all nine configured ad-unit IDs are present and referenced by their intended surfaces.
- Source inspection confirms host-list cadence is every 5 items in all Home modes, Feed/Reels cadence is every 5 items, and Chat cadence is every 5 conversations.
- Source inspection confirms the cache-key override is no longer installed and signed URL refresh/retry paths are present.
- **32/32 targeted static checks passed** after the final edits. Checks cover version metadata, removal of Play update flow/dependencies, UMP retention, all nine configured AdMob unit IDs, native batch chaining, refresh generation, placement cadence, signed URL/cache behavior, retry hooks, Android manifest XML and version-catalog TOML parsing.
- A full Gradle compile could not be run in this environment. `./gradlew :app:compileDebugKotlin --offline` still tries to obtain Gradle 9.3.1 and cannot resolve `services.gradle.org` in this environment. No APK or physical-device test is claimed.

## 9. Device test checklist before Play upload

1. Sign in with a profile that has a Supabase profile-media avatar; verify Home, Chat, User Profile and Social Profile images.
2. Verify existing and newly created image posts in Feed, profile grids and post detail; retry with a poor network connection and reopen the screen.
3. Load 50 hosts in each of Voice Call, Video Call and Love Note. Confirm 10 ad positions are inserted after hosts 5, 10, 15 … 50. Count actual filled ads separately from inserted slots.
4. Pull-to-refresh Home and Feed repeatedly. Confirm old native ads are replaced and new requests appear in Logcat for the relevant unit IDs.
5. Scroll Feed and Reels past multiple five-item boundaries; verify distinct slots load as they enter the viewport.
6. Verify Chat, Pandit Ji, Super AI and Entertainment placements, including the 320×50 banner.
7. Cold-launch the app, then background and reopen it after 4 seconds. Confirm App Open eligibility; test that an active call suppresses it.
8. Confirm no Play Store forced-update dialog appears. UMP privacy consent should still behave normally.

Use Logcat tag `BaatlyAds` to distinguish a missing slot/request from an AdMob no-fill response.
