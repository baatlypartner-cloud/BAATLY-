from pathlib import Path
import subprocess, sys, xml.etree.ElementTree as ET, json, tomllib

root = Path(__file__).parent
java_root = root / 'app/src/main/java/com/example'
changed = [
    java_root/'ui/home/HomeScreen.kt',
    java_root/'ui/ads/BaatlyAds.kt',
    java_root/'MainActivity.kt',
    java_root/'ui/social/SocialScreen.kt',
    java_root/'ui/entertainment/EntertainmentScreen.kt',
]

home = changed[0].read_text()
ads = changed[1].read_text()
activity = changed[2].read_text()
social = changed[3].read_text()
ent = changed[4].read_text()

checks = {
    'separate audio host capability filter': 'HomeMode.CALL -> partner.audioEnabled' in home,
    'separate video capability and access filter': 'HomeMode.VIDEO -> partner.videoEnabled && partner.videoCallAccess' in home,
    'separate Love Note capability filter': 'HomeMode.CHAT -> partner.chatEnabled' in home,
    'video quick action changes filter mode': 'viewModel.setHomeMode(HomeMode.VIDEO)' in home,
    'video card uses real video-call request': 'onVideoCall = { viewModel.requestVideoCall(partner) }' in home,
    'mode-specific primary host actions': all(x in home for x in ['Text("Voice Call"', 'Text("Video Call"', 'Text("Send Love Note"']),
    'host ad insertion for video and love-note lists': 'if (homeMode == HomeMode.CALL) 5 else 3' in home,
    'compact native ad height limit': 'heightIn(min = 70.dp, max = 116.dp)' in ads,
    'first-launch skip removed': 'KEY_FIRST_LAUNCH_SEEN' not in ads,
    'app-open cooldown reduced': '10L * 60L * 1000L' in ads,
    'app-open bounded retries': 'APP_OPEN_MAX_RETRIES = 8' in ads,
    'app-open preload begins before ready event': ads.index('startPreloading()\n                    _readyState.value = true') > 0,
    'app-open checks UMP/SDK/update readiness': 'BaatlyAds.readyState.collect' in activity and 'updateGateResolved' in activity,
    'app-open refuses display while activity is paused/call active': 'private fun maybeShowAppOpenAd()' in activity and '!activityResumed || !updateGateResolved || mandatoryUpdateRequired.value || hasActiveCall()' in activity and 'CallState.REQUESTING' in activity and 'viewModel.activeCall.value' in activity and 'viewModel.currentScreen.value == Screen.ACTIVE_CALL' in activity and 'override fun onStop()' in activity and 'adConsentFlowActive' in activity,
    'social feed ad inserted every five posts': '(index + 1) % 5 == 0' in social and 'social-feed-native-ad-' in social,
    'reels ad inserted every five reels': '(index + 1) % 5 == 0' in social and 'BaatlyNativeAdCard(BaatlyAds.REELS)' in social,
    'entertainment screen-level ad slot': 'entertainment-screen-native-ad' in ent,
    'large adaptive banner removed': 'BaatlyEntertainmentBanner' not in ent and 'LargeAnchoredAdaptive' not in ads,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + '  ' + name)

# Parse project metadata and JSON/XML resources.
manifest = ET.parse(root/'app/src/main/AndroidManifest.xml')
with open(root/'gradle/libs.versions.toml', 'rb') as f:
    tomllib.load(f)
for path in root.rglob('*.json'):
    try:
        json.loads(path.read_text())
    except Exception as exc:
        failed.append(f'JSON valid: {path.relative_to(root)} ({exc})')

# Kotlin compiler is used only as a parser in this environment; no Android/Compose classpath is present.
for path in changed:
    proc = subprocess.run(['kotlinc', str(path), '-d', '/tmp/baatly-v50-parse.jar'], text=True, capture_output=True)
    output = proc.stdout + proc.stderr
    syntax_markers = ['expecting', 'unexpected tokens', 'syntax error']
    if any(marker in output.lower() for marker in syntax_markers):
        failed.append(f'Kotlin parser: {path.relative_to(root)}')
    else:
        print('PASS  Kotlin parser: ' + str(path.relative_to(root)))

print(f'\nStatic checks passed: {len(checks) - len(failed)}/{len(checks)} (plus metadata/resource parses)')
if failed:
    print('Failures:')
    for item in failed:
        print(' - ' + item)
    sys.exit(1)
