# BAATLY User App v52 — Food & Cabs update

## Implemented in the User App source
- Removed the AI Astrology screen, navigation route, screen/service source files, and astrology drawable assets.
- Replaced the old navigation slot with **Food & Cabs**.
- Added premium-styled Cab and Food surfaces with service tabs, cab category selection, food filters, restaurant/menu navigation, cart, and COD checkout.
- Added pickup, drop, and food-delivery address selection with place search, map pin placement, and a runtime current-location permission request.
- Added cab fare quote and booking requests against `baatly-mobility-api`.
- Added a custom animated panda search state with the requested partner-search message; it appears while booking is sent and while the booking remains in `searching`.
- Added cab status, customer ride-start code display, cancellation action, live partner map, and Cloudflare tracking snapshot/WebSocket reading.
- Added food order placement/cancellation, delivery-code display, order status and live delivery map. Menu photos use authenticated signed-download URLs from `baatly-mobility-media`.
- Fixed a feed-post media parsing edge case where JSON `media_bucket: null` was being treated as the literal bucket name `null`, preventing the expected legacy bucket fallback. Existing R2 and Supabase Storage paths remain supported.
- Updated Android Maps/Location dependencies, the Android Maps API key resource, location permissions, and app version to `52` / `1.0.52`.

## Scope
- Only the uploaded **User App** source was edited.
- No Partner App source or ZIP was changed.
- No Supabase schema, Edge Function, or Cloudflare Worker was changed during this ZIP update.

## External setup and validation still required
- The connected Supabase project currently has **zero approved, active restaurants**, so the Food catalogue will remain empty until restaurants/branches/menus are onboarded and activated.
- Cab quote, cab booking and food order route calculation require the server-side `GOOGLE_MAPS_API_KEY` secret in the Supabase Edge Function environment. The Android client key supplied for this build is configured for Android Maps rendering; server-side secret availability was not verified and this client key should not be assumed to be a suitable server Routes key.
- A full Gradle build could not be executed in this environment because the Gradle 9.3.1 wrapper distribution could not be downloaded (`services.gradle.org` DNS/network resolution failed). XML/TOML validation passed and the changed Kotlin files had no Kotlin parser/syntax diagnostics, but this is not a successful Android compilation.
- No physical-device or emulator end-to-end test was possible here. The User App still needs real-user testing against an approved restaurant and an assigned Partner App session for booking, code, and live GPS verification.

## Google Maps API key security
The Android Maps key is a client-side value packaged in the APK by design. Restrict it in Google Cloud to the Android application ID `com.aistudio.baatly.app`, the release signing certificate SHA-1, and only the required Maps SDK for Android API. Do not reuse it as a server secret without server-appropriate restrictions.
