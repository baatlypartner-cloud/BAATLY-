package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class UserSession(
    @Json(name = "access_token") val accessToken: String,
    @Json(name = "refresh_token") val refreshToken: String? = null,
    @Json(name = "user") val user: AuthUser? = null,
    @Json(name = "profile") val profile: UserProfile? = null
)

@JsonClass(generateAdapter = true)
data class AuthUser(
    @Json(name = "id") val id: String,
    @Json(name = "email") val email: String? = null,
    @Json(name = "phone") val phone: String? = null
)

@JsonClass(generateAdapter = true)
data class UserProfile(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "username") val username: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "gender") val gender: String? = null,
    @Json(name = "language") val language: String? = null,
    @Json(name = "account_status") val accountStatus: String? = "active",
    @Json(name = "is_online") val isOnline: Boolean? = false,
    @Json(name = "mobile_number") val mobileNumber: String? = null,
    @Json(name = "referral_code") val referralCode: String? = null,
    @Json(name = "referral_code_used") val referralCodeUsed: String? = null,
    @Json(name = "followers_count") val followersCount: Int? = 0,
    @Json(name = "following_count") val followingCount: Int? = 0,
    @Json(name = "rating") val rating: Double? = null,
    @Json(name = "reviews_count") val reviewsCount: Int? = 0,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class PartnerProfile(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "user_id_display") val userIdDisplay: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "hobbies") val hobbies: String? = null,
    @Json(name = "age") val age: Int? = null,
    @Json(name = "gender") val gender: String? = null,
    @Json(name = "language") val language: String? = null,
    @Json(name = "is_partner") val isPartner: Boolean = true,
    @Json(name = "approval_status") val approvalStatus: String = "approved",
    @Json(name = "is_available") val isAvailable: Boolean = true,
    @Json(name = "is_online") val isOnline: Boolean = true,
    @Json(name = "audio_enabled") val audioEnabled: Boolean = true,
    @Json(name = "chat_enabled") val chatEnabled: Boolean = true,
    @Json(name = "account_status") val accountStatus: String = "active",
    @Json(name = "rating") val rating: Double? = null,
    @Json(name = "followers_count") val followersCount: Int = 0,
    @Json(name = "reviews_count") val reviewsCount: Int = 0,
    @Json(name = "is_following") val isFollowing: Boolean = false
) {
    val hobbiesList: List<String>
        get() = if (hobbies.isNullOrBlank()) emptyList()
        else hobbies.split(",", ";").map { it.trim() }.filter { it.isNotBlank() }

    val publicHandle: String
        get() {
            val handle = userIdDisplay?.takeIf { it.isNotBlank() && !isRawUuid(it) }
                ?: userId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
            return handle ?: ""
        }
}

@JsonClass(generateAdapter = true)
data class CallRecord(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "partner_id") val partnerId: String? = null,
    @Json(name = "status") val status: String = "requested", // requested, ringing, accepted, connected, completed
    @Json(name = "requested_at") val requestedAt: String? = null,
    @Json(name = "ringing_at") val ringingAt: String? = null,
    @Json(name = "accepted_at") val acceptedAt: String? = null,
    @Json(name = "connected_at") val connectedAt: String? = null,
    @Json(name = "ended_at") val endedAt: String? = null,
    @Json(name = "duration_seconds") val durationSeconds: Int = 0,
    @Json(name = "user_coins_charged") val userCoinsCharged: Int = 0,
    @Json(name = "partner_earning") val partnerEarning: Double = 0.0,
    @Json(name = "termination_reason") val terminationReason: String? = null,
    @Json(name = "billing_status") val billingStatus: String? = null,
    @Json(name = "agora_channel_id") val agoraChannelId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "max_duration_seconds") val maxDurationSeconds: Int? = null,
    @Json(name = "max_duration_coins") val maxDurationCoins: Int? = null,
    @Json(name = "partner") val partner: PartnerProfile? = null
) {
    val channelName: String? get() = agoraChannelId
    val coinsSpent: Int get() = userCoinsCharged
}

@JsonClass(generateAdapter = true)
data class AgoraTokenResponse(
    @Json(name = "app_id") val appId: String? = null,
    @Json(name = "channel_name") val channelName: String? = null,
    @Json(name = "uid") val uid: Long? = 0,
    @Json(name = "token") val token: String? = null,
    @Json(name = "expires_in") val expiresIn: Long? = null
)

@JsonClass(generateAdapter = true)
data class ConversationSummary(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "partner_id") val partnerId: String? = null,
    @Json(name = "last_message_id") val lastMessageId: String? = null,
    @Json(name = "last_message_at") val lastMessageAt: String? = null,
    @Json(name = "last_message_text") val lastMessageText: String? = null,
    @Json(name = "last_message_type") val lastMessageType: String? = null,
    @Json(name = "unread_count") val unreadCount: Int = 0,
    @Json(name = "user_blocked") val userBlocked: Boolean = false,
    @Json(name = "partner_blocked") val partnerBlocked: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "partner") val partner: PartnerProfile? = null
)

@JsonClass(generateAdapter = true)
data class ChatMessage(
    @Json(name = "id") val id: String,
    @Json(name = "conversation_id") val conversationId: String,
    @Json(name = "sender_id") val senderId: String,
    @Json(name = "receiver_id") val receiverId: String? = null,
    @Json(name = "message_type") val messageType: String = "text", // text, image, voice, gift
    @Json(name = "message_text") val messageText: String? = null,
    @Json(name = "media_url") val mediaUrl: String? = null,
    @Json(name = "media_duration_seconds") val mediaDurationSeconds: Int? = null,
    @Json(name = "gift_id") val giftId: String? = null,
    @Json(name = "reply_to_story_id") val replyToStoryId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "is_read") val isRead: Boolean = false,
    @Json(name = "gift") val gift: GiftItem? = null
) {
    val content: String? get() = messageText
}

@JsonClass(generateAdapter = true)
data class GiftItem(
    @Json(name = "id") val id: String,
    @Json(name = "name") val name: String,
    @Json(name = "category") val category: String? = "general",
    @Json(name = "icon_url") val iconUrl: String? = null,
    @Json(name = "animation_url") val animationUrl: String? = null,
    @Json(name = "coin_price") val coinPrice: Int = 10,
    @Json(name = "partner_earning_percent") val partnerEarningPercent: Double? = 50.0,
    @Json(name = "display_order") val displayOrder: Int? = 0,
    @Json(name = "is_active") val isActive: Boolean = true
)

@JsonClass(generateAdapter = true)
data class GiftTransaction(
    @Json(name = "id") val id: String,
    @Json(name = "sender_id") val senderId: String,
    @Json(name = "receiver_id") val receiverId: String,
    @Json(name = "gift_id") val giftId: String,
    @Json(name = "coins_spent") val coinsSpent: Int,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "gift") val gift: GiftItem? = null
)

@JsonClass(generateAdapter = true)
data class WalletInfo(
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "coin_balance") val coinBalance: Int = 0,
    @Json(name = "cash_balance") val cashBalance: Double = 0.0,
    @Json(name = "updated_at") val updatedAt: String? = null
) {
    val balance: Int get() = coinBalance
}

@JsonClass(generateAdapter = true)
data class CoinPackage(
    @Json(name = "id") val id: String,
    @Json(name = "coins") val coins: Int,
    @Json(name = "price_inr") val priceInr: Double,
    @Json(name = "display_order") val displayOrder: Int = 0,
    @Json(name = "is_active") val isActive: Boolean = true
)

@JsonClass(generateAdapter = true)
data class TransactionItem(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "type") val type: String = "debit",
    @Json(name = "coins") val coins: Int = 0,
    @Json(name = "description") val description: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class UroPayCreateOrderResult(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "reused") val reused: Boolean = false,
    @Json(name = "payment_id") val paymentId: String? = null,
    @Json(name = "order_id") val orderId: String? = null,
    @Json(name = "open_url") val openUrl: String? = null,
    @Json(name = "amount_inr") val amountInr: Double = 0.0,
    @Json(name = "coins") val coins: Int = 0,
    @Json(name = "currency") val currency: String = "INR",
    @Json(name = "status") val status: String = "pending",
    @Json(name = "tenant_order_ref") val tenantOrderRef: String? = null,
    @Json(name = "message") val message: String? = null,
    @Json(name = "error") val error: String? = null
)

@JsonClass(generateAdapter = true)
data class UroPayVerifyPaymentResult(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "status") val status: String = "pending",
    @Json(name = "payment_id") val paymentId: String? = null,
    @Json(name = "order_id") val orderId: String? = null,
    @Json(name = "coins") val coins: Int = 0,
    @Json(name = "amount_inr") val amountInr: Double = 0.0,
    @Json(name = "already_processed") val alreadyProcessed: Boolean = false,
    @Json(name = "message") val message: String? = null,
    @Json(name = "error") val error: String? = null
)

@JsonClass(generateAdapter = true)
data class PendingUroPayPayment(
    @Json(name = "payment_id") val paymentId: String,
    @Json(name = "order_id") val orderId: String? = null,
    @Json(name = "tenant_order_ref") val tenantOrderRef: String,
    @Json(name = "package_id") val packageId: String,
    @Json(name = "coins") val coins: Int,
    @Json(name = "price_inr") val priceInr: Double,
    @Json(name = "open_url") val openUrl: String? = null,
    @Json(name = "created_at") val createdAt: Long = System.currentTimeMillis()
)

sealed class UroPayPaymentUiState {
    object Idle : UroPayPaymentUiState()
    data class CreatingOrder(val pkg: CoinPackage) : UroPayPaymentUiState()
    data class OpeningCheckout(val paymentId: String, val openUrl: String, val coins: Int, val priceInr: Double) : UroPayPaymentUiState()
    data class Verifying(val paymentId: String, val coins: Int, val priceInr: Double, val attempt: Int = 1) : UroPayPaymentUiState()
    data class Success(val paymentId: String, val coinsCredited: Int, val updatedBalance: Int) : UroPayPaymentUiState()
    data class Pending(val paymentId: String, val coins: Int, val priceInr: Double, val message: String) : UroPayPaymentUiState()
    data class Failed(val message: String, val canRetry: Boolean = true) : UroPayPaymentUiState()
    data class Cancelled(val message: String) : UroPayPaymentUiState()
    data class Expired(val message: String) : UroPayPaymentUiState()
}

@JsonClass(generateAdapter = true)
data class AppNotification(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "title") val title: String = "",
    @Json(name = "body") val body: String = "",
    @Json(name = "notification_type") val notificationType: String = "system",
    @Json(name = "is_read") val isRead: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "data") val data: Map<String, String>? = null
)

@JsonClass(generateAdapter = true)
data class SocialProfile(
    @Json(name = "user_id") val userId: String,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "hobbies") val hobbies: String? = null,
    @Json(name = "social_avatar_url") val socialAvatarUrl: String? = null,
    @Json(name = "followers_count") val followersCount: Int = 0,
    @Json(name = "following_count") val followingCount: Int = 0,
    @Json(name = "total_likes") val totalLikes: Int = 0,
    @Json(name = "total_views") val totalViews: Int = 0,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    // Joined / Identity fields
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "signup_user_id") val signupUserId: String? = null,
    @Json(name = "is_host") val isHost: Boolean = false,
    @Json(name = "is_following") val isFollowing: Boolean = false,
    @Json(name = "posts") val posts: List<SocialPost> = emptyList(),
    @Json(name = "stories") val stories: List<SocialStory> = emptyList(),
    @Json(name = "partner") val partner: PartnerProfile? = null
) {
    val hobbiesList: List<String>
        get() = if (hobbies.isNullOrBlank()) emptyList()
        else hobbies.split(",", ";").map { it.trim() }.filter { it.isNotBlank() }

    val hasActiveStories: Boolean
        get() = stories.any { it.isActive && !it.isExpired }

    val publicHandle: String
        get() {
            val handle = signupUserId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
                ?: partner?.userId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
            return handle ?: ""
        }
}

@JsonClass(generateAdapter = true)
data class SocialStory(
    @Json(name = "id") val id: String,
    @Json(name = "owner_id") val ownerId: String,
    @Json(name = "media_path") val mediaPath: String,
    @Json(name = "caption") val caption: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "expires_at") val expiresAt: String? = null,
    @Json(name = "is_active") val isActive: Boolean = true,
    // Extra fields
    @Json(name = "owner_display_name") val ownerDisplayName: String? = null,
    @Json(name = "owner_user_id") val ownerUserId: String? = null,
    @Json(name = "owner_avatar_url") val ownerAvatarUrl: String? = null,
    @Json(name = "is_owner_host") val isOwnerHost: Boolean = false,
    @Json(name = "resolved_media_url") val resolvedMediaUrl: String? = null,
    @Json(name = "likes_count") val likesCount: Int = 0,
    @Json(name = "views_count") val viewsCount: Int = 0,
    @Json(name = "is_liked") val isLiked: Boolean = false,
    @Json(name = "is_viewed") val isViewed: Boolean = false,
    @Json(name = "owner_partner") val ownerPartner: PartnerProfile? = null
) {
    val isExpired: Boolean
        get() {
            if (expiresAt.isNullOrBlank() || expiresAt == "null") return false
            return try {
                val instant = java.time.Instant.parse(expiresAt)
                instant.isBefore(java.time.Instant.now())
            } catch (_: Exception) {
                false
            }
        }

    val publicHandle: String
        get() {
            val handle = ownerUserId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
                ?: ownerPartner?.userId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
            return handle ?: ""
        }
}

@JsonClass(generateAdapter = true)
data class SocialPost(
    @Json(name = "id") val id: String,
    @Json(name = "owner_id") val ownerId: String,
    @Json(name = "media_path") val mediaPath: String,
    @Json(name = "caption") val caption: String? = null,
    @Json(name = "published_at") val publishedAt: String? = null,
    @Json(name = "visible_until") val visibleUntil: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    // Extra fields
    @Json(name = "owner_display_name") val ownerDisplayName: String? = null,
    @Json(name = "owner_user_id") val ownerUserId: String? = null,
    @Json(name = "owner_avatar_url") val ownerAvatarUrl: String? = null,
    @Json(name = "is_owner_host") val isOwnerHost: Boolean = false,
    @Json(name = "resolved_media_url") val resolvedMediaUrl: String? = null,
    @Json(name = "is_unlocked") val isUnlocked: Boolean = false,
    @Json(name = "likes_count") val likesCount: Int = 0,
    @Json(name = "comments_count") val commentsCount: Int = 0,
    @Json(name = "views_count") val viewsCount: Int = 0,
    @Json(name = "is_liked") val isLiked: Boolean = false,
    @Json(name = "is_expired") val isExpired: Boolean = false,
    @Json(name = "owner_partner") val ownerPartner: PartnerProfile? = null
) {
    val isPostExpired: Boolean
        get() {
            if (isExpired) return true
            if (visibleUntil.isNullOrBlank() || visibleUntil == "null") return false
            return try {
                val instant = java.time.Instant.parse(visibleUntil)
                instant.isBefore(java.time.Instant.now())
            } catch (_: Exception) {
                false
            }
        }

    val publicHandle: String
        get() {
            val handle = ownerUserId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
                ?: ownerPartner?.userId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
            return handle ?: ""
        }
}

fun isRawUuid(text: String?): Boolean {
    if (text.isNullOrBlank()) return false
    return text.trim().matches(Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
}

@JsonClass(generateAdapter = true)
data class SocialComment(
    @Json(name = "id") val id: String,
    @Json(name = "content_id") val contentId: String,
    @Json(name = "content_type") val contentType: String = "post", // "post" or "story"
    @Json(name = "user_id") val userId: String,
    @Json(name = "comment") val comment: String,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class SocialSearchResult(
    @Json(name = "user_id") val userId: String,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "signup_user_id") val signupUserId: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "is_host") val isHost: Boolean = false,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "followers_count") val followersCount: Int = 0,
    @Json(name = "is_following") val isFollowing: Boolean = false,
    @Json(name = "partner") val partner: PartnerProfile? = null
) {
    val publicHandle: String
        get() {
            val handle = signupUserId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
                ?: partner?.userId?.takeIf { it.isNotBlank() && !isRawUuid(it) }
            return handle ?: ""
        }
}

@JsonClass(generateAdapter = true)
data class DeleteSocialPostResponse(
    @Json(name = "deleted") val deleted: Boolean = true,
    @Json(name = "post_id") val postId: String,
    @Json(name = "media_path") val mediaPath: String? = null,
    @Json(name = "refund_issued") val refundIssued: Boolean = false
)

