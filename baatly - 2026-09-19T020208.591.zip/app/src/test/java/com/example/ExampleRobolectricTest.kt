package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.network.SupabaseClient
import com.example.domain.BillingEngine
import com.example.ui.payment.UroPayCheckoutLauncher
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun read_app_name_from_context() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Baatly", appName)
    }

    @Test
    fun test_billing_engine_call_calculations() {
        // 0 balance -> 0 max duration
        assertEquals(0, BillingEngine.calculateMaxCallDurationSeconds(0.0, 10.0))
        assertEquals(0, BillingEngine.calculateMaxCallDurationSeconds(0.0, 0.0))

        // Balance ₹30 with rate ₹10/min -> 180s (3 min)
        assertEquals(180, BillingEngine.calculateMaxCallDurationSeconds(30.0, 10.0))

        // Balance ₹5 with rate ₹5/min -> 60s (1 min)
        assertEquals(60, BillingEngine.calculateMaxCallDurationSeconds(5.0, 5.0))

        // Formatter tests
        assertEquals("100", BillingEngine.formatRupees(100.0))
        assertEquals("120.5", BillingEngine.formatRupees(120.5))
        assertEquals("01:30", BillingEngine.formatDuration(90))
    }

    @Test
    fun test_forbidden_number_moderation() {
        assertTrue(BillingEngine.containsForbiddenNumberContent("call me at 9876543210"))
        assertTrue(BillingEngine.containsForbiddenNumberContent("my number is 9 8 7 6 5 4 3 2 1 0"))
        assertTrue(BillingEngine.containsForbiddenNumberContent("reach me on nine eight seven six five four three two one zero"))
        assertFalse(BillingEngine.containsForbiddenNumberContent("Hello, how are you? Let's chat."))
    }

    @Test
    fun test_session_manager_atomic_save_and_rotation() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)

        sessionManager.clearSession()
        assertNull(sessionManager.accessToken.value)
        assertNull(sessionManager.refreshToken.value)
        assertEquals(AuthState.Unauthenticated, sessionManager.authState.value)

        // Save session
        sessionManager.saveSession("token_A", "user_123", refreshToken = "refresh_A")
        assertEquals("token_A", sessionManager.accessToken.value)
        assertEquals("refresh_A", sessionManager.refreshToken.value)
        assertEquals("user_123", sessionManager.userId.value)
        assertTrue(sessionManager.isLoggedIn)

        // Rotate tokens atomically
        sessionManager.saveSession("token_B", "user_123", refreshToken = "refresh_B")
        assertEquals("token_B", sessionManager.accessToken.value)
        assertEquals("refresh_B", sessionManager.refreshToken.value)
    }

    @Test
    fun test_ensure_valid_session_single_flight_simulation() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)
        sessionManager.clearSession()

        val mockValidJwt = "eyJhbGciOiJub25lIn0.eyJleHAiOjI1MzQwMjMwMDc5OSwic3ViIjoidGVzdF91c2VyIn0."
        sessionManager.saveSession(mockValidJwt, "test_user", refreshToken = "valid_refresh_token")

        val client = SupabaseClient(sessionManager)

        val deferredList = (1..10).map {
            async {
                client.ensureValidSession()
            }
        }

        val results = deferredList.awaitAll()
        assertEquals(10, results.size)
        results.forEach { res ->
            assertTrue(res is SessionResult.Valid)
            assertEquals(mockValidJwt, (res as SessionResult.Valid).accessToken)
            assertEquals("test_user", res.userId)
        }
    }

    // 1. Available host returned
    @Test
    fun test_available_host_returned() {
        val partner = PartnerProfile(
            id = "p-123",
            userId = "00000000-0000-0000-0000-000000000002",
            partnerDisplayName = "Neha",
            isOnline = true,
            isAvailable = true
        )
        assertTrue(partner.isOnline)
        assertTrue(partner.isAvailable)
        assertEquals("p-123", partner.id)
        assertEquals("Neha", partner.displayName)
    }

    // 2. Stale host hidden
    @Test
    fun test_stale_host_hidden() {
        val partners = listOf(
            PartnerProfile(id = "p1", partnerDisplayName = "Online Host", isOnline = true),
            PartnerProfile(id = "p2", partnerDisplayName = "Offline Host", isOnline = false)
        )
        val available = partners.filter { it.isOnline }
        assertEquals(1, available.size)
        assertEquals("p1", available[0].id)
    }

    // 3. Audio request returns UUID
    @Test
    fun test_audio_request_returns_uuid() {
        val generatedCallId = UUID.randomUUID().toString()
        val record = CallRecord(
            id = generatedCallId,
            userId = "user_1",
            partnerId = "p_1",
            callType = "audio",
            status = "requested"
        )
        assertNotNull(UUID.fromString(record.id))
        assertEquals("requested", record.status)
        assertEquals("audio", record.callType)
    }

    // 4. User waits for accepted before Agora token
    @Test
    fun test_user_waits_for_accepted_before_agora_token() {
        var agoraTokenRequested = false
        var currentStatus = "requested"

        fun onRealtimeCallUpdate(newStatus: String) {
            currentStatus = newStatus
            if (currentStatus == "accepted") {
                agoraTokenRequested = true
            }
        }

        assertFalse(agoraTokenRequested)
        onRealtimeCallUpdate("requested")
        assertFalse(agoraTokenRequested)

        onRealtimeCallUpdate("accepted")
        assertTrue(agoraTokenRequested)
    }

    // 5. Video request waits for accepted
    @Test
    fun test_video_request_waits_for_accepted() {
        var agoraVideoConnected = false
        var callStatus = "requested"

        fun handleRealtimeStatus(status: String) {
            callStatus = status
            if (callStatus == "accepted") {
                agoraVideoConnected = true
            }
        }

        assertFalse(agoraVideoConnected)
        handleRealtimeStatus("ringing")
        assertFalse(agoraVideoConnected)

        handleRealtimeStatus("accepted")
        assertTrue(agoraVideoConnected)
    }

    // 6. Call balance enforcement
    @Test
    fun test_call_balance_enforcement() {
        val resultAllowed = CallBalanceEnforcementResult(status = "ok", isAllowed = true, remainingSeconds = 120)
        assertTrue(resultAllowed.isAllowed)
        assertEquals(120, resultAllowed.remainingSeconds)

        val resultDepleted = CallBalanceEnforcementResult(status = "depleted", isAllowed = false, remainingSeconds = 0)
        assertFalse(resultDepleted.isAllowed)
        assertEquals(0, resultDepleted.remainingSeconds)
    }

    // 7. Settlement uses backend Rupee fields
    @Test
    fun test_settlement_uses_backend_rupee_fields() {
        val json = """
            {
                "call_id": "call-123",
                "status": "settled",
                "duration_seconds": 180,
                "user_charge_rupees": 15.0,
                "partner_earning_rupees": 7.5
            }
        """.trimIndent()

        val orgJson = org.json.JSONObject(json)
        val userCharge = orgJson.optDouble("user_charge_rupees", 0.0)
        val partnerEarning = orgJson.optDouble("partner_earning_rupees", 0.0)

        assertEquals(15.0, userCharge, 0.001)
        assertEquals(7.5, partnerEarning, 0.001)
    }

    // 8. ₹2 user chat charge
    @Test
    fun test_rupee_2_user_chat_charge() {
        val pricing = EffectiveUserPricing(
            callRateRupeesPerMinute = 5.0,
            videoCallRateRupeesPerMinute = 20.0,
            messageRateRupees = 2.0
        )
        assertEquals(2.0, pricing.messageRateRupees, 0.001)
    }

    // 9. ₹0.50 partner chat earning
    @Test
    fun test_rupee_0_50_partner_chat_earning() {
        val json = """
            {
                "audio_call_rate_rupees": 5.0,
                "video_call_rate_rupees": 20.0,
                "chat_message_rate_rupees": 2.0,
                "partner_chat_earning_rupees": 0.50
            }
        """.trimIndent()

        val orgJson = org.json.JSONObject(json)
        val partnerEarning = orgJson.optDouble("partner_chat_earning_rupees", 0.0)
        assertEquals(0.50, partnerEarning, 0.001)
    }

    // 10. Image message
    @Test
    fun test_image_message() {
        val msg = ChatMessage(
            id = "msg_img_1",
            conversationId = "conv_1",
            senderId = "user_1",
            messageType = "image",
            mediaUrl = "chat-media/user_1/img.jpg"
        )
        assertEquals("image", msg.messageType)
        assertEquals("chat-media/user_1/img.jpg", msg.mediaUrl)
    }

    // 11. Voice message
    @Test
    fun test_voice_message() {
        val msg = ChatMessage(
            id = "msg_voice_1",
            conversationId = "conv_1",
            senderId = "user_1",
            messageType = "voice",
            mediaUrl = "chat-media/user_1/audio.m4a",
            mediaDurationSeconds = 15
        )
        assertEquals("voice", msg.messageType)
        assertEquals(15, msg.mediaDurationSeconds)
    }

    // 12. Mark delivered
    @Test
    fun test_mark_delivered() {
        val msg = ChatMessage(
            id = "msg_1",
            conversationId = "conv_1",
            senderId = "p_1",
            deliveredAt = "2026-09-18T10:00:00Z"
        )
        assertNotNull(msg.deliveredAt)
    }

    // 13. Mark seen
    @Test
    fun test_mark_seen() {
        val msg = ChatMessage(
            id = "msg_1",
            conversationId = "conv_1",
            senderId = "p_1",
            seenAt = "2026-09-18T10:05:00Z"
        )
        assertNotNull(msg.seenAt)
    }

    // 14. Gift using price_rupees
    @Test
    fun test_gift_using_price_rupees() {
        val gift = GiftItem(
            id = "gift_rose",
            name = "Rose",
            iconUrl = "https://example.com/rose.png",
            priceRupees = 10.0
        )
        assertEquals(10.0, gift.priceRupees, 0.001)
    }

    // 15. UroPay verification
    @Test
    fun test_uropay_verification_url_validation() {
        assertTrue(UroPayCheckoutLauncher.isValidCheckoutUrl("https://api.uropai.in/checkout/pay_123456"))
        assertTrue(UroPayCheckoutLauncher.isValidCheckoutUrl("https://checkout.uropay.me/pay/order_123"))
        assertFalse(UroPayCheckoutLauncher.isValidCheckoutUrl("http://insecure-http.com/pay"))
        assertFalse(UroPayCheckoutLauncher.isValidCheckoutUrl("https://malicious-domain.com"))
    }

    // 16. Notification_type parsing
    @Test
    fun test_notification_type_parsing() {
        val notif = AppNotification(
            id = "notif_1",
            userId = "user_1",
            title = "Incoming Call",
            body = "Host is calling you",
            type = "incoming_call"
        )
        assertEquals("incoming_call", notif.notificationType)
    }

    // 17. No social notification routing
    @Test
    fun test_no_social_notification_routing() {
        val notifTypes = listOf("incoming_call", "chat_message", "gift_received", "system")
        val socialTypes = listOf("story_reply", "post_like", "post_comment", "follow")

        socialTypes.forEach { st ->
            assertFalse(notifTypes.contains(st))
        }
    }

    // 18. Pending UroPay Payment uses Rupee fields
    @Test
    fun test_pending_uropay_payment_rupee_persistence() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val sessionManager = SessionManager(context)
        sessionManager.clearPendingPayment()

        val pending = PendingUroPayPayment(
            paymentId = "pay_test_999",
            orderId = "ord_test_999",
            tenantOrderRef = "BAATLY-REF-999",
            packageId = "pkg_120",
            amountRupees = 120.0,
            openUrl = "https://checkout.uropay.me/pay_test_999"
        )

        sessionManager.savePendingPayment(pending)
        val loaded = sessionManager.getPendingPayment()
        assertNotNull(loaded)
        assertEquals("pay_test_999", loaded?.paymentId)
        assertEquals(120.0, loaded?.amountRupees ?: 0.0, 0.001)

        sessionManager.clearPendingPayment()
        assertNull(sessionManager.getPendingPayment())
    }
}
