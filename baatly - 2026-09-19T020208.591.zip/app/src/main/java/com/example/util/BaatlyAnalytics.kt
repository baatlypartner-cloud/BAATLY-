package com.example.util

import android.util.Log

object BaatlyAnalytics {
    private const val TAG = "BaatlyAnalytics"

    fun logEvent(eventName: String, params: Map<String, Any?> = emptyMap()) {
        val safeParams = params.filterKeys { key ->
            val lower = key.lowercase()
            !lower.contains("secret") && !lower.contains("key") && !lower.contains("token") && !lower.contains("password")
        }
        Log.i(TAG, "Event: $eventName | Params: $safeParams")
    }
}
