package com.example.ui.payment

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import androidx.browser.customtabs.CustomTabsClient
import androidx.browser.customtabs.CustomTabsIntent

/**
 * UroPayCheckoutLauncher coordinates launching the UroPay checkout URL
 * following this strict fallback order:
 *
 * UroPay open_url
 *         ↓
 * Validate URL
 *         ↓
 * Try Custom Tabs
 *         ↓
 * If unavailable → ACTION_VIEW
 *         ↓
 * If unavailable → In-App WebView fallback
 *         ↓
 * Open UroPay checkout
 */
object UroPayCheckoutLauncher {
    private const val TAG = "UroPayCheckoutLauncher"

    const val USER_FACING_LAUNCH_ERROR =
        "Unable to open payment page. Please install or enable a browser and try again."

    private val ALLOWED_CHECKOUT_HOSTS = setOf(
        "api.uropai.in",
        "uropai.in",
        "checkout.uropai.in",
        "checkout.uropay.me",
        "uropay.me",
        "api.uropay.me",
        "baatly.app",
        "www.baatly.app",
        "baatly.com"
    )

    /**
     * Validates that the checkout URL is safe and valid for UroPay:
     * - Parseable URI
     * - HTTPS scheme
     * - Host matches expected UroPay domain (including live api.uropai.in) or Baatly return domain
     *
     * Does NOT replace or alter the checkout URL.
     */
    fun isValidCheckoutUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = try {
            Uri.parse(url)
        } catch (_: Exception) {
            return false
        }
        val scheme = uri.scheme?.lowercase() ?: return false
        val host = uri.host?.lowercase() ?: return false
        if (scheme != "https") return false
        if (host.isBlank()) return false

        // Exact allowlist match or specific subdomain suffixes
        val isExpectedHost = ALLOWED_CHECKOUT_HOSTS.contains(host) ||
                host.endsWith(".uropai.in") ||
                host.endsWith(".uropay.me") ||
                host.endsWith(".baatly.app")
        return isExpectedHost
    }

    /**
     * Checks if Android Custom Tabs service is available on this device.
     */
    fun isCustomTabsAvailable(context: Context): Boolean {
        return try {
            // First check standard CustomTabsClient package resolution
            val packageName = CustomTabsClient.getPackageName(context, null)
            if (!packageName.isNullOrBlank()) {
                return true
            }
            // Secondary check: queryIntentServices for CustomTabsService action
            val pm = context.packageManager
            val serviceIntent = Intent("android.support.customtabs.action.CustomTabsService")
            val resolveInfos = pm.queryIntentServices(serviceIntent, 0)
            resolveInfos.isNotEmpty()
        } catch (e: Exception) {
            Log.w(TAG, "Error checking Custom Tabs availability: ${e.message}")
            false
        }
    }

    /**
     * Checks if an Activity exists on the device to handle ACTION_VIEW for the given URI.
     */
    fun isBrowserActivityAvailable(context: Context, uri: Uri): Boolean {
        return try {
            val viewIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                if (context !is Activity) {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            val pm = context.packageManager
            val resolveActivity = viewIntent.resolveActivity(pm)
            if (resolveActivity != null) {
                return true
            }
            val activities = pm.queryIntentActivities(viewIntent, PackageManager.MATCH_DEFAULT_ONLY)
            activities.isNotEmpty()
        } catch (e: Exception) {
            Log.w(TAG, "Error checking browser activity availability: ${e.message}")
            false
        }
    }

    /**
     * Launches the checkout URL following the required fallback chain:
     * 1. Validate URL
     * 2. Try Custom Tabs if supported
     * 3. Try ACTION_VIEW if an activity can handle it
     * 4. If everything fails, report user-friendly error message
     */
    fun launch(
        context: Context,
        openUrl: String,
        onError: (userMessage: String) -> Unit
    ) {
        val uri = try {
            Uri.parse(openUrl)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse checkout URL: $openUrl, error: ${e.message}")
            onError(USER_FACING_LAUNCH_ERROR)
            return
        }

        val host = uri.host?.lowercase() ?: ""
        val scheme = uri.scheme?.lowercase() ?: ""
        val contextClass = context.javaClass.name

        Log.d(
            TAG,
            "UroPay checkout launch requested:\n" +
            "open_url=$openUrl\n" +
            "host=$host\n" +
            "scheme=$scheme\n" +
            "context=$contextClass"
        )

        // 1. Validate UroPay checkout URL
        if (!isValidCheckoutUrl(openUrl)) {
            Log.e(TAG, "Invalid or unverified checkout URL rejected: host=$host, scheme=$scheme, url=$openUrl")
            onError(USER_FACING_LAUNCH_ERROR)
            return
        }

        // 2. Custom Tabs first
        if (isCustomTabsAvailable(context)) {
            try {
                Log.d(TAG, "Custom Tabs provider found. Launching via CustomTabsIntent for: $openUrl")
                val customTabsIntent = CustomTabsIntent.Builder()
                    .setShowTitle(true)
                    .build().apply {
                        if (context !is Activity) {
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    }
                customTabsIntent.launchUrl(context, uri)
                Log.d(TAG, "CustomTabs launched successfully.")
                return
            } catch (e: Exception) {
                Log.w(TAG, "CustomTabs launchUrl failed: ${e.message}. Proceeding to ACTION_VIEW fallback...", e)
            }
        } else {
            Log.d(TAG, "Custom Tabs not available on this device. Proceeding to ACTION_VIEW check...")
        }

        // 3. ACTION_VIEW Fallback
        val isBrowserAvailable = isBrowserActivityAvailable(context, uri)
        Log.d(TAG, "ACTION_VIEW browser activity resolvable: $isBrowserAvailable")
        if (isBrowserAvailable) {
            try {
                Log.d(TAG, "Browser Activity found for ACTION_VIEW. Launching...")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    if (context !is Activity) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                context.startActivity(intent)
                Log.d(TAG, "ACTION_VIEW launched successfully.")
                return
            } catch (e: Exception) {
                Log.w(TAG, "ACTION_VIEW startActivity failed: ${e.message}.", e)
            }
        } else {
            Log.d(TAG, "No browser Activity found for ACTION_VIEW.")
        }

        // 4. Report error instead of using WebView
        Log.e(TAG, "No browser/Custom Tabs is available to open $openUrl")
        onError(USER_FACING_LAUNCH_ERROR)
    }
}
