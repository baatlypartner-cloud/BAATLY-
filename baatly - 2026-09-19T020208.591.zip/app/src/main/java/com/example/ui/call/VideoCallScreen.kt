package com.example.ui.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.view.SurfaceView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.ui.BaatlyViewModel
import com.example.ui.CallState
import com.example.ui.theme.*

@Composable
fun VideoCallScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val partner by viewModel.activeCallPartner.collectAsState()
    val callState by viewModel.callState.collectAsState()
    val remainingSeconds by viewModel.callRemainingSeconds.collectAsState()
    val elapsedSeconds by viewModel.callElapsedSeconds.collectAsState()
    val isMuted by viewModel.agoraCallManager.isMuted.collectAsState()
    val remoteUid by viewModel.agoraCallManager.remoteUid.collectAsState()
    val isRemoteVideoMuted by viewModel.agoraCallManager.isRemoteVideoMuted.collectAsState()

    val host = partner
    val resolvedHostAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(host?.avatarUrl, viewModel.dataService)

    // Permission check for Camera and Microphone
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasCameraPermission = permissions[Manifest.permission.CAMERA] ?: false
        hasMicPermission = permissions[Manifest.permission.RECORD_AUDIO] ?: false
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission || !hasMicPermission) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO
                )
            )
        }
    }

    Surface(
        color = Color.Black,
        modifier = Modifier.fillMaxSize()
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // 1. Full Screen Remote Video Stream
            if (remoteUid != null && !isRemoteVideoMuted) {
                val currentUid = remoteUid!!
                AndroidView(
                    factory = { ctx ->
                        SurfaceView(ctx).apply {
                            viewModel.agoraCallManager.setupRemoteVideo(this, currentUid)
                        }
                    },
                    update = { view ->
                        viewModel.agoraCallManager.setupRemoteVideo(view, currentUid)
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("remote_video_view")
                )
            } else {
                // Placeholder when remote video is not yet attached or muted
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DarkBackground),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(HostAvatarGradient)
                                .border(3.dp, PrimaryLavender, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!resolvedHostAvatarUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = resolvedHostAvatarUrl,
                                    contentDescription = host?.displayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text(
                                    text = (host?.displayName?.take(1) ?: "H").uppercase(),
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = when (callState) {
                                CallState.REQUESTING -> "Requesting video call..."
                                CallState.RINGING -> "Ringing..."
                                CallState.CONNECTED -> "Waiting for video feed..."
                                else -> "Connecting video..."
                            },
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )

                        if (callState == CallState.CONNECTED) {
                            Spacer(modifier = Modifier.height(8.dp))
                            CircularProgressIndicator(
                                color = PrimaryLavender,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            // 2. Local Preview Window (Floating Box in top right)
            if (hasCameraPermission) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 16.dp, end = 16.dp)
                        .size(width = 110.dp, height = 160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.DarkGray)
                        .border(2.dp, PrimaryLavender, RoundedCornerShape(16.dp))
                        .testTag("local_video_preview")
                ) {
                    AndroidView(
                        factory = { ctx ->
                            SurfaceView(ctx).apply {
                                viewModel.agoraCallManager.setupLocalVideo(this)
                            }
                        },
                        update = { view ->
                            viewModel.agoraCallManager.setupLocalVideo(view)
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Camera Switch Button overlay on local preview
                    IconButton(
                        onClick = { viewModel.agoraCallManager.switchCamera() },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .size(28.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Cameraswitch,
                            contentDescription = "Switch Camera",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // 3. Top Call Details Overlay
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .statusBarsPadding()
                    .padding(top = 16.dp, start = 16.dp)
            ) {
                Text(
                    text = host?.displayName ?: "Baatly Host",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Connection status & Timer
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (callState == CallState.CONNECTED) OnlineGreen else SecondaryAmber)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (callState == CallState.CONNECTED) {
                            val mins = elapsedSeconds / 60
                            val secs = elapsedSeconds % 60
                            String.format("%02d:%02d", mins, secs)
                        } else {
                            "Connecting..."
                        },
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    )
                }

                if (callState == CallState.CONNECTED && remainingSeconds > 0) {
                    val remMins = remainingSeconds / 60
                    val remSecs = remainingSeconds % 60
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Remaining: ${String.format("%02d:%02d", remMins, remSecs)}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (remainingSeconds < 30) DangerRed else PrimaryLavender,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // 4. Bottom Control Bar (RECHARGE, GIFT, MUTE, CUT)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. RECHARGE
                    VideoButtonControl(
                        icon = Icons.Filled.AddCard,
                        label = "Recharge",
                        bgColor = OnlineGreen.copy(alpha = 0.9f),
                        iconColor = Color.White,
                        testTag = "btn_video_recharge",
                        onClick = { viewModel.showRechargeModal() }
                    )

                    // 2. GIFT
                    VideoButtonControl(
                        icon = Icons.Filled.CardGiftcard,
                        label = "Gift",
                        bgColor = SecondaryAmber.copy(alpha = 0.9f),
                        iconColor = Color.Black,
                        testTag = "btn_video_gift",
                        onClick = { viewModel.toggleGiftSheet(true) }
                    )

                    // 3. MUTE
                    VideoButtonControl(
                        icon = if (isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        label = if (isMuted) "Unmute" else "Mute",
                        bgColor = if (isMuted) DangerRed else Color.White.copy(alpha = 0.25f),
                        iconColor = Color.White,
                        testTag = "btn_video_mute",
                        onClick = { viewModel.agoraCallManager.toggleMute() }
                    )

                    // 4. CUT (End Call)
                    VideoButtonControl(
                        icon = Icons.Filled.CallEnd,
                        label = "Cut",
                        bgColor = DangerRed,
                        iconColor = Color.White,
                        testTag = "btn_video_cut",
                        onClick = { viewModel.endCall() }
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoButtonControl(
    icon: ImageVector,
    label: String,
    bgColor: Color,
    iconColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.testTag(testTag)
    ) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(bgColor)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconColor,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )
        )
    }
}
