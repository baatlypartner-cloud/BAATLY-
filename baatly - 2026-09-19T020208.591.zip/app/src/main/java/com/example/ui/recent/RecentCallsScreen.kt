package com.example.ui.recent

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PhoneCallback
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CallRecord
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.BaatlyTopBar
import com.example.ui.theme.*

@Composable
fun RecentCallsScreen(viewModel: BaatlyViewModel) {
    val recentCalls by viewModel.recentCalls.collectAsState()
    val wallet by viewModel.walletSummary.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    Scaffold(
        topBar = {
            BaatlyTopBar(
                walletBalanceRupees = wallet.balanceRupees,
                onWalletClick = { viewModel.setScreen(Screen.WALLET) },
                onNotificationClick = { viewModel.setScreen(Screen.NOTIFICATIONS) },
                unreadNotifications = notifications.count { !it.isRead }
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Text(
                text = "Recent Calls",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                ),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
            )

            if (recentCalls.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Call,
                            contentDescription = null,
                            tint = TextTertiary,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No recent calls found.",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Text(
                            text = "Your voice call history will appear here.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recentCalls, key = { it.id }) { call ->
                        RecentCallItem(
                            call = call,
                            viewModel = viewModel,
                            onCallBack = {
                                call.partner?.let { partner ->
                                    viewModel.requestCall(partner)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RecentCallItem(
    call: CallRecord,
    viewModel: BaatlyViewModel,
    onCallBack: () -> Unit
) {
    val partner = call.partner
    val displayName = partner?.displayName?.takeIf { it.isNotBlank() && it != "Baatly Host" }
        ?: partner?.displayName?.takeIf { it.isNotBlank() }
        ?: "Host"

    val resolvedAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(partner?.avatarUrl, viewModel.dataService)
    val isResolvingAvatar = !partner?.avatarUrl.isNullOrBlank() && partner?.avatarUrl != "null" && resolvedAvatarUrl == null

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Partner Avatar
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(HostAvatarGradient)
                    .border(1.dp, DarkBorderSubtle, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (!resolvedAvatarUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = resolvedAvatarUrl,
                        contentDescription = displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (isResolvingAvatar) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = PrimaryLavender,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        text = (displayName.take(1)).uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 20.sp
                        )
                    )
                }
            }

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = displayName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(3.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CallMade,
                        contentDescription = "Outgoing",
                        tint = OnlineGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${call.durationSeconds}s duration",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "₹",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SecondaryAmber,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "₹${com.example.domain.BillingEngine.formatRupees(call.rupeesSpent)}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SecondaryAmber,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                Text(
                    text = call.createdAt ?: "",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary, fontSize = 10.sp)
                )
            }

            // Call Back button
            if (partner != null) {
                IconButton(
                    onClick = onCallBack,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(PrimaryLavender)
                        .testTag("btn_call_back_${call.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Call,
                        contentDescription = "Call Back",
                        tint = Color(0xFF1C1C22),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
