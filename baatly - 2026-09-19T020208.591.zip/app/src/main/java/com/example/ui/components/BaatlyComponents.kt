package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.EffectiveUserPricing
import com.example.data.model.GiftItem
import com.example.data.model.PartnerProfile
import com.example.data.model.PublicUserRating
import com.example.domain.BillingEngine
import com.example.ui.HomeMode
import com.example.ui.Screen
import com.example.ui.theme.*

@Composable
fun BaatlyTopBar(
    walletBalanceRupees: Double = 0.0,
    onWalletClick: () -> Unit = {},
    onNotificationClick: () -> Unit,
    unreadNotifications: Int = 0,
    onRefreshClick: (() -> Unit)? = null
) {
    Surface(
        color = DarkBackground,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Logo & Title
            Column {
                Text(
                    text = "BAATLY",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = TextPrimary,
                        fontSize = 22.sp
                    )
                )
                Text(
                    text = "USER APP",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.5.sp,
                        color = PrimaryLavender,
                        fontSize = 9.sp
                    )
                )
            }

            // Right side: Refresh, Rupee Wallet Pill & Notifications
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Top-bar Refresh Button if provided
                if (onRefreshClick != null) {
                    IconButton(
                        onClick = onRefreshClick,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceVariant)
                            .border(1.dp, DarkBorderSubtle, CircleShape)
                            .testTag("btn_topbar_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh",
                            tint = PrimaryLavender,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Vibrant Rupee Wallet Badge
                Surface(
                    shape = CircleShape,
                    color = DarkSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                    modifier = Modifier
                        .testTag("wallet_balance_badge")
                        .clickable { onWalletClick() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(start = 6.dp, end = 12.dp, top = 5.dp, bottom = 5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(GoldGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "₹",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B1402),
                                    fontSize = 13.sp
                                )
                            )
                        }
                        Text(
                            text = "₹${BillingEngine.formatRupees(walletBalanceRupees)}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SecondaryAmber,
                                fontSize = 13.sp
                            )
                        )
                    }
                }

                // Notification Bell
                IconButton(
                    onClick = onNotificationClick,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .border(1.dp, DarkBorderSubtle, CircleShape)
                        .testTag("btn_topbar_notifications")
                ) {
                    Box {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        if (unreadNotifications > 0) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(VibrantPink)
                                    .align(Alignment.TopEnd)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BaatlyBottomNavBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    Surface(
        color = DarkNavBackground,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(top = 10.dp, bottom = 12.dp, start = 4.dp, end = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                title = "HOME",
                icon = Icons.Filled.Home,
                selected = currentScreen == Screen.HOME,
                testTag = "nav_home",
                onClick = { onNavigate(Screen.HOME) }
            )
            BottomNavItem(
                title = "CHAT",
                icon = Icons.AutoMirrored.Filled.Chat,
                selected = currentScreen == Screen.DIRECT_CHAT || currentScreen == Screen.CHAT_LIST,
                testTag = "nav_chat",
                onClick = { onNavigate(Screen.CHAT_LIST) }
            )
            BottomNavItem(
                title = "RECENT",
                icon = Icons.Filled.Call,
                selected = currentScreen == Screen.RECENT_CALLS,
                testTag = "nav_recent_calls",
                onClick = { onNavigate(Screen.RECENT_CALLS) }
            )
            BottomNavItem(
                title = "PROFILE",
                icon = Icons.Filled.Person,
                selected = currentScreen == Screen.PROFILE,
                testTag = "nav_profile",
                onClick = { onNavigate(Screen.PROFILE) }
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (selected) VibrantPink else TextMuted,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) VibrantPink else TextMuted,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp
            )
        )
    }
}

// =========================================================================
// Centralized Profile Avatar & Authenticated Media Resolvers
// =========================================================================
@Composable
fun rememberResolvedProfileImageUrl(
    rawPathOrUrl: String?,
    dataService: com.example.data.network.SupabaseDataService?
): State<String?> {
    val resolvedState = remember(rawPathOrUrl) { mutableStateOf<String?>(null) }
    LaunchedEffect(rawPathOrUrl, dataService) {
        if (rawPathOrUrl.isNullOrBlank() || rawPathOrUrl == "null") {
            resolvedState.value = null
        } else if (dataService != null) {
            val resolved = dataService.resolveProfileAvatarUrl(rawPathOrUrl)
            resolvedState.value = resolved.takeIf { it.isNotBlank() } ?: rawPathOrUrl
        } else {
            resolvedState.value = rawPathOrUrl
        }
    }
    return resolvedState
}

@Composable
fun ProfileAvatar(
    rawPathOrUrl: String?,
    displayName: String?,
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = CircleShape,
    fallbackGradient: Brush = HostAvatarGradient,
    fontSize: androidx.compose.ui.unit.TextUnit = 20.sp,
    dataService: com.example.data.network.SupabaseDataService? = null,
    onClick: (() -> Unit)? = null
) {
    val resolvedUrl by rememberResolvedProfileImageUrl(rawPathOrUrl, dataService)
    val isResolving = !rawPathOrUrl.isNullOrBlank() && rawPathOrUrl != "null" && resolvedUrl == null && dataService != null

    Box(
        modifier = modifier
            .clip(shape)
            .background(fallbackGradient)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        contentAlignment = Alignment.Center
    ) {
        if (!resolvedUrl.isNullOrBlank()) {
            AsyncImage(
                model = resolvedUrl,
                contentDescription = displayName ?: "Avatar",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else if (isResolving) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                color = PrimaryLavender,
                strokeWidth = 2.dp
            )
        } else {
            val initial = (displayName?.trim()?.take(1) ?: "P").uppercase()
            Text(
                text = initial,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = fontSize
                )
            )
        }
    }
}

@Composable
fun HostCard(
    partner: PartnerProfile,
    homeMode: HomeMode,
    onCardClick: () -> Unit,
    onActionClick: () -> Unit,
    dataService: com.example.data.network.SupabaseDataService? = null,
    effectivePricing: EffectiveUserPricing = EffectiveUserPricing.DEFAULT,
    publicRating: PublicUserRating? = null
) {
    val resolvedAvatarUrl by rememberResolvedProfileImageUrl(partner.avatarUrl, dataService)
    val isResolving = !partner.avatarUrl.isNullOrBlank() && partner.avatarUrl != "null" && resolvedAvatarUrl == null && dataService != null

    Card(
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Host Avatar (Squircle 72dp) with online badge
            Box(
                modifier = Modifier.size(72.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(HostAvatarGradient),
                    contentAlignment = Alignment.Center
                ) {
                    if (!resolvedAvatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAvatarUrl,
                            contentDescription = partner.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (isResolving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = PrimaryLavender,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Text(
                            text = (partner.displayName.take(1)).uppercase(),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 28.sp
                            )
                        )
                    }
                }

                if (partner.isOnline) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(DarkBackground)
                            .align(Alignment.BottomEnd),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(OnlineGreen)
                        )
                    }
                }
            }

            // Info Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                // Name & Rating Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = partner.displayName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 16.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    val ratingVal = publicRating?.averageRating ?: partner.rating
                    val reviewsCount = publicRating?.totalReviews ?: partner.reviewsCount
                    val ratingDisplay = if (ratingVal > 0.0) {
                        if (reviewsCount > 0) "★ ${String.format(java.util.Locale.US, "%.1f", ratingVal)} ($reviewsCount)" else "★ ${String.format(java.util.Locale.US, "%.1f", ratingVal)}"
                    } else {
                        "★ 5.0"
                    }

                    Surface(
                        shape = CircleShape,
                        color = SecondaryAmber.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SecondaryAmber.copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = ratingDisplay,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = SecondaryAmber,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }
                }

                // Bio
                if (!partner.bio.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = partner.bio,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontSize = 12.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Stats: Age & Total Calls
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (partner.age > 0) {
                        Column {
                            Text(
                                text = "AGE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    color = TextTertiary
                                )
                            )
                            Text(
                                text = "${partner.age}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    fontSize = 13.sp
                                )
                            )
                        }
                    }

                    if (partner.totalCalls > 0) {
                        Column {
                            Text(
                                text = "CALLS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    color = TextTertiary
                                )
                            )
                            Text(
                                text = "${partner.totalCalls}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    fontSize = 13.sp
                                )
                            )
                        }
                    }
                }
            }

            // Quick Call/Video/Chat Action CTA Button + Rate
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onActionClick,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(PrimaryGradient)
                        .testTag("btn_host_action_${partner.id}")
                ) {
                    val icon = when (homeMode) {
                        HomeMode.CALL -> Icons.Filled.Call
                        HomeMode.VIDEO -> Icons.Filled.Videocam
                        HomeMode.CHAT -> Icons.AutoMirrored.Filled.Chat
                    }
                    val desc = when (homeMode) {
                        HomeMode.CALL -> "Call Partner"
                        HomeMode.VIDEO -> "Video Call Partner"
                        HomeMode.CHAT -> "Chat Partner"
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = desc,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                val rateText = when (homeMode) {
                    HomeMode.CALL -> if (effectivePricing.callRateRupeesPerMinute > 0.0) "₹${effectivePricing.callRateRupeesPerMinute.toInt()}/min" else ""
                    HomeMode.VIDEO -> if (effectivePricing.videoCallRateRupeesPerMinute > 0.0) "₹${effectivePricing.videoCallRateRupeesPerMinute.toInt()}/min" else ""
                    HomeMode.CHAT -> if (effectivePricing.messageRateRupees > 0.0) "₹${effectivePricing.messageRateRupees.toInt()}/msg" else ""
                }
                if (rateText.isNotBlank()) {
                    Text(
                        text = rateText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun GiftAnimationOverlay(gift: GiftItem) {
    val infiniteTransition = rememberInfiniteTransition(label = "gift_anim")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.scale(scale)
        ) {
            Surface(
                shape = CircleShape,
                color = DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(3.dp, SecondaryAmber),
                modifier = Modifier.size(120.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (!gift.iconUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = gift.iconUrl,
                            contentDescription = gift.name,
                            modifier = Modifier.size(80.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.CardGiftcard,
                            contentDescription = gift.name,
                            tint = SecondaryAmber,
                            modifier = Modifier.size(60.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Sent ${gift.name}!",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = SecondaryAmberLight
                )
            )
        }
    }
}
