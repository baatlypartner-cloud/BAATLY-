package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.WalletRechargePackage
import com.example.data.model.UroPayPaymentUiState
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*

@Composable
fun RechargePopup(
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit
) {
    val rechargePackages by viewModel.rechargePackages.collectAsState()
    val paymentState by viewModel.uropayPaymentState.collectAsState()
    val isProcessingPayment = paymentState is UroPayPaymentUiState.CreatingOrder ||
            paymentState is UroPayPaymentUiState.Verifying ||
            paymentState is UroPayPaymentUiState.OpeningCheckout

    val activePackages = rechargePackages.filter { it.isActive }.sortedBy { it.sortOrder }

    Dialog(
        onDismissRequest = {
            if (!isProcessingPayment) onDismiss()
        },
        properties = DialogProperties(
            dismissOnBackPress = !isProcessingPayment,
            dismissOnClickOutside = !isProcessingPayment
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = DarkCard,
            border = BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .testTag("dialog_recharge_popup")
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Header Row with Close Icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VibrantPink.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AccountBalanceWallet,
                                contentDescription = null,
                                tint = VibrantPink,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = "Low Balance",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 18.sp
                            )
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isProcessingPayment,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("btn_close_recharge_popup")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "You need more balance to continue. Choose a quick recharge to proceed:",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    ),
                    textAlign = TextAlign.Start,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (activePackages.isEmpty()) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(32.dp),
                        color = VibrantPink
                    )
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        activePackages.take(3).forEachIndexed { index, pkg ->
                            val isRecommended = index == 1 || (activePackages.size == 1)
                            val price = pkg.amountRupees
                            RechargeOptionCard(
                                priceLabel = "₹${price.toInt()}",
                                isRecommended = isRecommended,
                                isLoading = isProcessingPayment,
                                onClick = {
                                    onDismiss()
                                    viewModel.startUroPayRecharge(
                                        pkg = pkg,
                                        targetCallId = viewModel.activeCall.value?.id,
                                        isCallRecharge = (viewModel.activeCall.value != null)
                                    )
                                },
                                testTag = "btn_recharge_${pkg.id}"
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.FlashOn,
                        contentDescription = null,
                        tint = SecondaryAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Instant 100% secure recharge via UroPay",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextTertiary,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun RechargeOptionCard(
    priceLabel: String,
    isRecommended: Boolean,
    isLoading: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isRecommended) DarkSurfaceVariant else DarkSurface,
        border = BorderStroke(
            1.5.dp,
            if (isRecommended) VibrantPink else DarkCardBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isLoading) { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = priceLabel,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        fontSize = 22.sp
                    )
                )
                if (isRecommended) {
                    Text(
                        text = "Most Popular",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = SecondaryAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Button(
                onClick = onClick,
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRecommended) VibrantPink else PrimaryLavenderContainer
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Recharge",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isRecommended) Color.White else PrimaryLavenderDark
                    )
                )
            }
        }
    }
}
