package com.example.ui.host

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HostProfileScreen(viewModel: BaatlyViewModel) {
    val partner by viewModel.selectedPartner.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()
    val hostPublicRatings by viewModel.hostPublicRatings.collectAsState()
    val scrollState = rememberScrollState()

    if (partner == null) {
        viewModel.setScreen(Screen.HOME)
        return
    }

    val host = partner!!
    val hostUserId = host.userId?.takeIf { it.isNotBlank() } ?: host.id
    val publicRating = hostPublicRatings[hostUserId]

    LaunchedEffect(hostUserId) {
        viewModel.loadPublicRatingForUser(hostUserId)
    }

    val resolvedAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(host.avatarUrl, viewModel.dataService)
    val isResolvingAvatar = !host.avatarUrl.isNullOrBlank() && host.avatarUrl != "null" && resolvedAvatarUrl == null

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(host.displayName ?: "Host Profile", color = TextPrimary) },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.setScreen(Screen.HOME) },
                        modifier = Modifier.testTag("btn_back_host_profile")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.openReportDialog(
                                reportedUserId = hostUserId,
                                targetDisplayName = host.displayName ?: "Host"
                            )
                        },
                        modifier = Modifier.testTag("btn_report_host")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Flag,
                            contentDescription = "Report Host",
                            tint = DangerRed.copy(alpha = 0.85f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Large Avatar with status ring
            Box {
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(RoundedCornerShape(36.dp))
                        .background(HostAvatarGradient)
                        .border(2.dp, DarkBorderSubtle, RoundedCornerShape(36.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!resolvedAvatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAvatarUrl,
                            contentDescription = host.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (isResolvingAvatar) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(32.dp),
                            color = PrimaryLavender,
                            strokeWidth = 3.dp
                        )
                    } else {
                        Text(
                            text = (host.displayName?.take(1) ?: "H").uppercase(),
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White.copy(alpha = 0.4f),
                                fontSize = 48.sp
                            )
                        )
                    }
                }
                if (host.isOnline) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(DarkBackground)
                            .align(Alignment.BottomEnd),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(OnlineGreen)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Display Name & Age
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = host.displayName ?: "Host",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                if (host.age != null && host.age > 0) {
                    Surface(
                        shape = CircleShape,
                        color = DarkSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle)
                    ) {
                        Text(
                            text = "${host.age} yrs",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Public handle / User ID
            val publicHandle = host.publicHandle
            if (publicHandle.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "@$publicHandle",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = PrimaryLavender,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bio
            if (!host.bio.isNullOrBlank()) {
                Text(
                    text = host.bio,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Hobbies chips if available
            val hobbies = host.hobbiesList
            if (hobbies.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    hobbies.take(4).forEach { hobby ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = hobby,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Medium
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Stats Card (Rating, Language)
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Real Authoritative Public Rating
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val hasRating = publicRating != null && publicRating.hasRatings && publicRating.rating != null
                        val legacyHostRating = host.rating ?: 0.0
                        val ratingText = if (hasRating) {
                            val score = String.format(java.util.Locale.US, "%.1f", publicRating!!.rating)
                            if (publicRating.totalRatings > 0) {
                                "★ $score (${publicRating.totalRatings})"
                            } else {
                                "★ $score"
                            }
                        } else if (legacyHostRating > 0.0) {
                            "★ ${String.format(java.util.Locale.US, "%.1f", legacyHostRating)}"
                        } else {
                            "No ratings yet"
                        }

                        Surface(
                            shape = CircleShape,
                            color = if (hasRating || legacyHostRating > 0.0) SecondaryAmber.copy(alpha = 0.15f) else DarkSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (hasRating || legacyHostRating > 0.0) SecondaryAmber.copy(alpha = 0.35f) else DarkBorderSubtle
                            )
                        ) {
                            Text(
                                text = ratingText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (hasRating || legacyHostRating > 0.0) SecondaryAmber else TextSecondary,
                                    fontSize = 11.sp
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "RATING",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextTertiary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }

                    // Language
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = host.language ?: "Hindi",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "LANGUAGE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextTertiary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons: CALL, VIDEO & CHAT
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Audio Call Button
                    Button(
                        onClick = { viewModel.requestCall(host) },
                        enabled = host.audioEnabled,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryLavender,
                            contentColor = Color(0xFF1C1C22)
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("btn_host_call")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Call,
                            contentDescription = "Audio Call",
                            tint = Color(0xFF1C1C22),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "AUDIO CALL",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1C1C22),
                                    fontSize = 11.sp
                                )
                            )
                            val rateStr = if (effectivePricing.callRateRupeesPerMinute > 0.0) "₹${effectivePricing.callRateRupeesPerMinute.toInt()}/min" else ""
                            if (rateStr.isNotBlank()) {
                                Text(
                                    text = rateStr,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF1C1C22).copy(alpha = 0.75f),
                                        fontSize = 9.sp
                                    )
                                )
                            }
                        }
                    }

                    // Video Call Button
                    Button(
                        onClick = { viewModel.requestVideoCall(host) },
                        enabled = host.videoCallAccess && host.videoEnabled && host.isOnline && host.isAvailable,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VibrantPink,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("btn_host_video_call")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Videocam,
                            contentDescription = "Video Call",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "VIDEO CALL",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 11.sp
                                )
                            )
                            val vRateStr = if (effectivePricing.videoCallRateRupeesPerMinute > 0.0) "₹${effectivePricing.videoCallRateRupeesPerMinute.toInt()}/min" else ""
                            if (vRateStr.isNotBlank()) {
                                Text(
                                    text = vRateStr,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 9.sp
                                    )
                                )
                            }
                        }
                    }
                }

                // Chat Button
                Button(
                    onClick = { viewModel.openChatWithHost(host) },
                    enabled = host.chatEnabled,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryLavenderContainer,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_host_chat")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Chat,
                        contentDescription = "Chat",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val chatText = if (effectivePricing.messageRateRupees > 0.0) "START CHAT (₹${effectivePricing.messageRateRupees.toInt()}/msg)" else "START CHAT"
                    Text(
                        text = chatText,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))
            OutlinedButton(
                onClick = {
                    viewModel.openReportDialog(
                        reportedUserId = hostUserId,
                        targetDisplayName = host.displayName ?: "Host"
                    )
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_report_host_bottom")
            ) {
                Icon(
                    imageVector = Icons.Filled.Flag,
                    contentDescription = "Report Host",
                    tint = DangerRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Report Host",
                    color = DangerRed,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
