package com.example.ui.legal

object LegalContentData {

    const val SUPPORT_EMAIL = "baatly672@gmail.com"
    const val LAST_UPDATED_DATE = "08/08/2026"

    fun getContent(page: LegalPage): LegalPageContent {
        return when (page) {
            LegalPage.ABOUT_BAATLY -> aboutBaatlyContent
            LegalPage.SAFETY_SECURITY -> safetySecurityContent
            LegalPage.REFUND_CANCELLATION -> refundCancellationContent
            LegalPage.TERMS_CONDITIONS -> termsConditionsContent
            LegalPage.PRIVACY_POLICY -> privacyPolicyContent
        }
    }

    private val aboutBaatlyContent = LegalPageContent(
        page = LegalPage.ABOUT_BAATLY,
        openingText = "Baatly is a 1-to-1 communication platform created to make it easier for people to discover verified partners, enjoy authentic audio & video conversations and share moments in a safe and respectful environment.",
        sections = listOf(
            LegalSection(
                heading = "Talk & Connect",
                intro = "Discover available Partners and start one-to-one conversations through Baatly's supported chat, voice and video calling features."
            ),
            LegalSection(
                heading = "Voice & Video Conversations",
                intro = "Connect with Partners through real-time audio and video calling features with transparent per-minute rates."
            ),
            LegalSection(
                heading = "Virtual Gifting",
                intro = "Users can send supported virtual gifts to Partners using their in-app wallet balance during eligible interactions."
            ),
            LegalSection(
                heading = "Rupee Wallet & Recharges",
                intro = "Baatly uses a direct Indian Rupee (₹) wallet for paid communication services and virtual gifts. Recharge packages are processed securely via authorized payment gateways."
            ),
            LegalSection(
                heading = "Safety First",
                intro = "Baatly works continuously to maintain a respectful and safe platform through:",
                bullets = listOf(
                    "Content moderation",
                    "User reporting",
                    "Blocking tools",
                    "Fraud and abuse prevention",
                    "Account security measures",
                    "Community Guidelines",
                    "Investigation of reported violations"
                )
            ),
            LegalSection(
                heading = "What We Don't Allow",
                intro = "Baatly does not permit:",
                bullets = listOf(
                    "Sexual or pornographic content",
                    "Exploitation",
                    "Fraud or scams",
                    "Harassment",
                    "Impersonation",
                    "Illegal activities",
                    "Abuse",
                    "Malicious activity",
                    "Attempts to misuse the payment system"
                )
            ),
            LegalSection(
                heading = "Our Mission",
                intro = "Our mission is simple:\n\nMake conversations easier, connections better and online interactions safer.\n\nBaatly is built for people who want authentic, respectful 1-on-1 conversations."
            )
        ),
        closingText = "Baatly\nBetter conversations. Better connections."
    )

    private val safetySecurityContent = LegalPageContent(
        page = LegalPage.SAFETY_SECURITY,
        openingText = "Safety comes first at Baatly.\n\nEvery person using Baatly is expected to behave respectfully and follow these guidelines.",
        sections = listOf(
            LegalSection(
                heading = "1. Sexual & Explicit Content",
                intro = "Baatly does not allow:",
                bullets = listOf(
                    "Pornographic content",
                    "Sexually explicit images or videos",
                    "Sexual exploitation",
                    "Explicit sexual solicitation",
                    "Content involving sexual abuse",
                    "Sexual content involving minors"
                ),
                outro = "Any content involving the sexual exploitation of minors is strictly prohibited and reported to appropriate law enforcement authorities."
            ),
            LegalSection(
                heading = "2. Fraud & Scams",
                intro = "Do not use Baatly to:",
                bullets = listOf(
                    "Scam another user",
                    "Request money through deception",
                    "Promote fake investments",
                    "Send fraudulent payment requests",
                    "Pretend to be a Baatly employee",
                    "Manipulate users into making unauthorized payments",
                    "Collect money outside approved Baatly payment methods for Baatly services"
                )
            ),
            LegalSection(
                heading = "Payment Safety",
                intro = "Baatly will never ask you for:",
                bullets = listOf(
                    "OTP",
                    "UPI PIN",
                    "ATM PIN",
                    "Card PIN",
                    "Password"
                ),
                outro = "Never share these with another person."
            ),
            LegalSection(
                heading = "3. Harassment & Abuse",
                intro = "Do not:",
                bullets = listOf(
                    "Threaten another person",
                    "Bully or intimidate users",
                    "Repeatedly contact someone who does not want contact",
                    "Send abusive messages",
                    "Stalk another user",
                    "Encourage violence or harm"
                )
            ),
            LegalSection(
                heading = "4. Impersonation",
                intro = "Do not pretend to be:",
                bullets = listOf(
                    "Another user",
                    "A Partner / Host",
                    "A Baatly employee",
                    "A Baatly administrator",
                    "Another public or private individual"
                )
            ),
            LegalSection(
                heading = "5. Illegal & Harmful Activities",
                intro = "Baatly cannot be used to facilitate illegal activities or distribute content that violates applicable law."
            ),
            LegalSection(
                heading = "6. Fake or Misleading Information",
                intro = "Do not deliberately create misleading profiles or provide false information for the purpose of fraud or deception."
            ),
            LegalSection(
                heading = "7. Report & Block",
                intro = "If you see something that violates Baatly's rules:\n\nReport → Select a reason → Submit\n\nUsers may also use the available Block feature to prevent unwanted interaction."
            ),
            LegalSection(
                heading = "8. Enforcement",
                intro = "Depending on the violation, Baatly may:",
                bullets = listOf(
                    "Remove content",
                    "Restrict chat",
                    "Restrict calls",
                    "Suspend an account",
                    "Permanently terminate an account",
                    "Take other appropriate safety or legal action"
                ),
                outro = "Serious violations may result in immediate action."
            ),
            LegalSection(
                heading = "9. Account Security",
                intro = "Keep your account credentials secure.\n\nIf you believe someone has accessed your account without permission, contact Baatly Support immediately."
            )
        ),
        closingText = "Be respectful. Stay safe. Never share sensitive information."
    )

    private val refundCancellationContent = LegalPageContent(
        page = LegalPage.REFUND_CANCELLATION,
        openingText = null,
        sections = listOf(
            LegalSection(
                heading = "Please read before recharging your Wallet",
                intro = "Baatly uses direct Rupee (₹) wallet balances for in-app paid communication features and gifting.\n\nBefore completing a recharge, users should review the amount and terms shown in the payment flow."
            ),
            LegalSection(
                heading = "1. Wallet Recharges",
                intro = "Once a wallet recharge has been successfully completed and credited to the user's account, it is non-refundable, except where a refund is required by applicable law or approved by Baatly under its dispute resolution policies."
            ),
            LegalSection(
                heading = "2. Payment Deducted but Balance Not Updated",
                intro = "If money is deducted from your payment method but wallet balance is not updated:\n\nDo not recharge the same amount repeatedly.\n\nContact Baatly Support with:",
                bullets = listOf(
                    "User ID",
                    "Transaction / Order ID (UroPay / Gateway reference)",
                    "Payment amount",
                    "Date and time",
                    "Screenshot / transaction receipt, if available"
                ),
                outro = "Baatly will verify payment settlement with the payment gateway and credit the wallet balance."
            ),
            LegalSection(
                heading = "3. Duplicate Payment",
                intro = "If the same recharge order was charged more than once, contact Support.\n\nAfter verification, Baatly will process the appropriate gateway refund for the duplicate transaction."
            ),
            LegalSection(
                heading = "4. Balances Already Used",
                intro = "Wallet funds already consumed for completed calls, messages or virtual gifts are not refundable."
            ),
            LegalSection(
                heading = "5. Technical Failure During Calls",
                intro = "If a paid call fails or drops prematurely due to server-side technical issues, Support may investigate call records and issue an appropriate wallet credit adjustment."
            ),
            LegalSection(
                heading = "6. Account Suspension",
                intro = "If an account is suspended or terminated because of fraud, abuse or violation of Community Guidelines, the suspension itself does not automatically create a refund entitlement."
            ),
            LegalSection(
                heading = "7. Refund & Payment Support",
                intro = "Support Email: $SUPPORT_EMAIL\n\nInclude your User ID and transaction reference."
            )
        ),
        closingText = "Nothing in this policy is intended to remove any consumer right or legal remedy that cannot lawfully be excluded."
    )

    private val termsConditionsContent = LegalPageContent(
        page = LegalPage.TERMS_CONDITIONS,
        openingText = "By creating an account or using Baatly, you agree to these Terms & Conditions, Privacy Policy, Refund & Cancellation Policy and Community Guidelines.",
        sections = listOf(
            LegalSection(
                heading = "1. Using Baatly",
                intro = "Baatly provides 1-to-1 communication services. Depending on availability, Baatly provides:",
                bullets = listOf(
                    "One-to-one text, photo, and voice chat",
                    "1-to-1 voice calls",
                    "1-to-1 video calls",
                    "Virtual gifting",
                    "Wallet recharges in Indian Rupees (₹)"
                )
            ),
            LegalSection(
                heading = "2. Account Responsibility",
                intro = "You are responsible for your account and activity.\n\nYou must:",
                bullets = listOf(
                    "Provide accurate information",
                    "Keep your account secure",
                    "Protect your login credentials",
                    "Use the platform lawfully",
                    "Follow Baatly's rules"
                )
            ),
            LegalSection(
                heading = "3. Users & Partners",
                intro = "Baatly connects Users with independent Partners. Baatly does not guarantee the continuous availability of any particular Partner."
            ),
            LegalSection(
                heading = "4. Wallet & Payments",
                intro = "Wallet recharges are in INR (₹) and must be made through Baatly's supported checkout flow. Call rates and chat charges are calculated automatically per minute or per message."
            ),
            LegalSection(
                heading = "5. Virtual Gifts",
                intro = "Users may send virtual gifts to Partners using their wallet balance. Virtual gifts are digital items and do not represent physical goods."
            ),
            LegalSection(
                heading = "6. Prohibited Activities",
                intro = "Users must not use Baatly for fraud, scams, harassment, pornography, exploitation, impersonation, or illegal activities."
            ),
            LegalSection(
                heading = "7. Safety & Moderation",
                intro = "Baatly may use automated systems and human review to enforce platform safety and protect users from abuse."
            ),
            LegalSection(
                heading = "8. Contact",
                intro = "Baatly Support:\n$SUPPORT_EMAIL"
            )
        ),
        closingText = null
    )

    private val privacyPolicyContent = LegalPageContent(
        page = LegalPage.PRIVACY_POLICY,
        openingText = "This Privacy Policy explains how Baatly collects, uses, and protects information when you use the Baatly application.",
        sections = listOf(
            LegalSection(
                heading = "1. Information We Collect",
                intro = "Baatly processes:",
                bullets = listOf(
                    "Account Information: Name/Display Name, Mobile number, User ID",
                    "Profile Information: Profile photo, Bio, Gender, Age, Languages",
                    "Communication Information: Metadata necessary to establish 1-to-1 audio/video calls and deliver messages",
                    "Payment Information: Transaction ID, recharge amounts, and wallet balances (we never store banking passwords or UPI PINs)",
                    "Device & Security: Device model, app version, push token, and diagnostic logs"
                )
            ),
            LegalSection(
                heading = "2. How We Use Information",
                intro = "Information is used to operate the communication service, process wallet transactions, enforce safety guidelines, prevent fraud, and provide customer support."
            ),
            LegalSection(
                heading = "3. Account Deletion",
                intro = "Users may request deletion of their Baatly account directly within the app under Profile > Delete Account."
            ),
            LegalSection(
                heading = "4. Contact",
                intro = "Privacy Contact:\n$SUPPORT_EMAIL"
            )
        ),
        closingText = null
    )
}
