package com.example.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PartnerProfile
import com.example.ui.BaatlyViewModel
import com.example.ui.HomeMode
import com.example.ui.Screen
import com.example.ui.components.BaatlyTopBar
import com.example.ui.components.HostCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(viewModel: BaatlyViewModel) {
    val homeMode by viewModel.homeMode.collectAsState()
    val availablePartners by viewModel.availablePartners.collectAsState()
    val isLoadingPartners by viewModel.isLoadingPartners.collectAsState()
    val wallet by viewModel.walletSummary.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()
    val hostPublicRatings by viewModel.hostPublicRatings.collectAsState()

    // Filter hosts per selected mode
    val displayedPartners = remember(availablePartners, homeMode) {
        when (homeMode) {
            HomeMode.CALL -> availablePartners.filter { it.audioEnabled }
            HomeMode.VIDEO -> availablePartners.filter { it.videoEnabled }
            HomeMode.CHAT -> availablePartners.filter { it.chatEnabled }
        }
    }

    Scaffold(
        topBar = {
            BaatlyTopBar(
                walletBalanceRupees = wallet.balanceRupees,
                onWalletClick = { viewModel.setScreen(Screen.WALLET) },
                onNotificationClick = { viewModel.setScreen(Screen.NOTIFICATIONS) },
                unreadNotifications = notifications.count { !it.isRead },
                onRefreshClick = {
                    viewModel.refreshPartners()
                    viewModel.refreshWallet()
                }
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Segmented Primary Choice: [ CALL | VIDEO | CHAT ]
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp)
                ) {
                    SegmentButton(
                        title = "CALL",
                        icon = Icons.Filled.Call,
                        selected = homeMode == HomeMode.CALL,
                        modifier = Modifier.weight(1f),
                        testTag = "tab_call_mode",
                        selectedColor = VibrantPink,
                        onClick = { viewModel.setHomeMode(HomeMode.CALL) }
                    )
                    SegmentButton(
                        title = "VIDEO",
                        icon = Icons.Filled.Videocam,
                        selected = homeMode == HomeMode.VIDEO,
                        modifier = Modifier.weight(1f),
                        testTag = "tab_video_mode",
                        selectedColor = VibrantPink,
                        onClick = { viewModel.setHomeMode(HomeMode.VIDEO) }
                    )
                    SegmentButton(
                        title = "CHAT",
                        icon = Icons.AutoMirrored.Filled.Chat,
                        selected = homeMode == HomeMode.CHAT,
                        modifier = Modifier.weight(1f),
                        testTag = "tab_chat_mode",
                        selectedColor = VibrantPink,
                        onClick = { viewModel.setHomeMode(HomeMode.CHAT) }
                    )
                }
            }

            // Available Hosts List
            if (isLoadingPartners && displayedPartners.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PrimaryLavender)
                }
            } else if (displayedPartners.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        val emptyText = when (homeMode) {
                            HomeMode.CALL -> "No hosts available for audio calls right now"
                            HomeMode.VIDEO -> "No hosts available for video calls right now"
                            HomeMode.CHAT -> "No hosts available for chat right now"
                        }
                        Text(
                            text = emptyText,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedButton(
                            onClick = { viewModel.refreshPartners() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryLavender),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = PrimaryLavender)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Refresh", color = PrimaryLavender)
                        }
                    }
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    if (isLoadingPartners) {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp),
                            color = PrimaryLavender,
                            trackColor = Color.Transparent
                        )
                    }
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 20.dp)
                    ) {
                        items(displayedPartners, key = { it.id }) { partner ->
                        val hostUserId = partner.userId?.takeIf { it.isNotBlank() } ?: partner.id
                        val publicRating = hostPublicRatings[hostUserId]
                        HostCard(
                            partner = partner,
                            homeMode = homeMode,
                            onCardClick = { viewModel.openHostProfile(partner) },
                            onActionClick = {
                                when (homeMode) {
                                    HomeMode.CALL -> viewModel.requestCall(partner)
                                    HomeMode.VIDEO -> viewModel.requestVideoCall(partner)
                                    HomeMode.CHAT -> viewModel.openChatWithHost(partner)
                                }
                            },
                            dataService = viewModel.dataService,
                            effectivePricing = effectivePricing,
                            publicRating = publicRating
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
private fun SegmentButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    testTag: String,
    selectedColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) selectedColor else Color.Transparent,
        modifier = modifier
            .testTag(testTag)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) Color.White else TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontSize = 14.sp,
                    color = if (selected) Color.White else TextSecondary
                )
            )
        }
    }
}
