package com.example.ui.call

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.BaatlyViewModel
import com.example.ui.CallState
import com.example.ui.Screen
import com.example.ui.theme.*

@Composable
fun ActiveCallScreen(viewModel: BaatlyViewModel) {
    val partner by viewModel.activeCallPartner.collectAsState()
    val callState by viewModel.callState.collectAsState()
    val remainingSeconds by viewModel.callRemainingSeconds.collectAsState()
    val elapsedSeconds by viewModel.callElapsedSeconds.collectAsState()
    val isMuted by viewModel.agoraCallManager.isMuted.collectAsState()
    val isSpeakerOn by viewModel.agoraCallManager.isSpeakerOn.collectAsState()

    val host = partner
    val resolvedHostAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(host?.avatarUrl, viewModel.dataService)
    val isResolvingHostAvatar = !host?.avatarUrl.isNullOrBlank() && host?.avatarUrl != "null" && resolvedHostAvatarUrl == null

    // Pulse Animation for Call Visualizer
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (callState == CallState.CONNECTED) 1.15f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Surface(
        color = DarkBackground,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header: Call Status & Host Name
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 24.dp)
            ) {
                Text(
                    text = host?.displayName ?: "Baatly Host",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = when (callState) {
                        CallState.REQUESTING -> "Requesting..."
                        CallState.RINGING -> "Ringing..."
                        CallState.CONNECTED -> "Connected"
                        CallState.ENDED -> "Call Ended"
                        else -> "Connecting..."
                    },
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = if (callState == CallState.CONNECTED) OnlineGreen else TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Timer Pill (Counts down from locked maximum duration)
                if (callState == CallState.CONNECTED) {
                    val minutes = remainingSeconds / 60
                    val seconds = remainingSeconds % 60
                    val timeString = String.format("%02d:%02d", minutes, seconds)

                    Surface(
                        shape = CircleShape,
                        color = DarkSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (remainingSeconds < 30) DangerRed else PrimaryLavender)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Timer,
                                contentDescription = "Timer",
                                tint = if (remainingSeconds < 30) DangerRed else PrimaryLavender,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Remaining: $timeString",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (remainingSeconds < 30) DangerRed else TextPrimary
                                )
                            )
                        }
                    }
                }
            }

            // Center Avatar with pulsating audio circles
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(240.dp)
            ) {
                // Outer Pulse Ring
                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(PrimaryLavender.copy(alpha = 0.15f))
                )

                // Mid Pulse Ring
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .scale(pulseScale * 0.95f)
                        .clip(CircleShape)
                        .background(PrimaryLavender.copy(alpha = 0.25f))
                )

                // Host Avatar
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .clip(CircleShape)
                        .background(HostAvatarGradient)
                        .border(3.dp, PrimaryLavender, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (!resolvedHostAvatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedHostAvatarUrl,
                            contentDescription = host?.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (isResolvingHostAvatar) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(36.dp),
                            color = PrimaryLavender,
                            strokeWidth = 3.dp
                        )
                    } else {
                        Text(
                            text = (host?.displayName?.take(1) ?: "H").uppercase(),
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        )
                    }
                }
            }

            // Bottom Controls
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.padding(bottom = 20.dp)
            ) {
                // Secondary Controls: MUTE, SPEAKER, RECHARGE, GIFT, FULL CHAT
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Mute Button
                    CallControlButton(
                        icon = if (isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        label = if (isMuted) "Unmute" else "Mute",
                        isActive = isMuted,
                        testTag = "btn_call_mute",
                        onClick = { viewModel.agoraCallManager.toggleMute() }
                    )

                    // Speaker Button
                    CallControlButton(
                        icon = if (isSpeakerOn) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                        label = "Speaker",
                        isActive = isSpeakerOn,
                        testTag = "btn_call_speaker",
                        onClick = { viewModel.agoraCallManager.toggleSpeaker() }
                    )

                    // Recharge Button (In-Call Wallet Extension)
                    CallControlButton(
                        icon = Icons.Filled.AddCard,
                        label = "Recharge",
                        isActive = false,
                        accentColor = OnlineGreen,
                        testTag = "btn_call_recharge",
                        onClick = { viewModel.showRechargeModal() }
                    )

                    // Gift Button
                    CallControlButton(
                        icon = Icons.Filled.CardGiftcard,
                        label = "Gift",
                        isActive = false,
                        accentColor = SecondaryAmber,
                        testTag = "btn_call_gift",
                        onClick = { viewModel.toggleGiftSheet(true) }
                    )

                    // Open Main Chat Screen (Without interrupting call)
                    CallControlButton(
                        icon = Icons.AutoMirrored.Filled.Chat,
                        label = "Chat",
                        isActive = false,
                        testTag = "btn_call_chat",
                        onClick = {
                            viewModel.setScreen(Screen.CHAT_LIST)
                        }
                    )
                }

                // Primary Hang Up Button
                FloatingActionButton(
                    onClick = { viewModel.endCall() },
                    containerColor = DangerRed,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(68.dp)
                        .testTag("btn_end_call")
                ) {
                    Icon(
                        imageVector = Icons.Filled.CallEnd,
                        contentDescription = "End Call",
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CallControlButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    accentColor: Color = TextPrimary,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.testTag(testTag)
    ) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(if (isActive) PrimaryLavender else DarkSurfaceVariant)
                .border(1.dp, if (isActive) PrimaryLavenderDark else DarkCardBorder, CircleShape)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) Color(0xFF1C1C22) else accentColor,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextSecondary,
                fontSize = 11.sp
            )
        )
    }
}
