package com.example.data.network

import com.example.data.local.SessionManager
import com.example.data.model.UserProfile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class SupabaseAuthService(
    private val client: SupabaseClient,
    private val sessionManager: SessionManager
) {

    suspend fun checkUserIdAvailable(userId: String): Boolean {
        val normalized = userId.trim().lowercase()
        return try {
            val response = client.rpc("check_user_id_available", mapOf("p_user_id" to normalized))
            val trimmed = response.trim()
            if (trimmed == "true" || trimmed == "1" || trimmed == "\"true\"") {
                true
            } else if (trimmed == "false" || trimmed == "0" || trimmed == "\"false\"") {
                false
            } else {
                val queryUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?user_id=eq.$normalized&select=id"
                val queryRes = client.get(queryUrl)
                val array = JSONArray(queryRes)
                array.length() == 0
            }
        } catch (e: Exception) {
            try {
                val queryUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?user_id=eq.$normalized&select=id"
                val queryRes = client.get(queryUrl)
                val array = JSONArray(queryRes)
                array.length() == 0
            } catch (_: Exception) {
                true
            }
        }
    }

    suspend fun signUp(
        userId: String,
        password: String,
        displayName: String,
        mobileNumber: String,
        avatarFile: File? = null,
        referralCode: String? = null
    ): Result<UserProfile> {
        val normalizedUserId = userId.trim().lowercase()
        val normalizedMobile = mobileNumber.filter { it.isDigit() }
        val cleanDisplayName = displayName.trim()
        val cleanReferral = referralCode?.trim()?.takeIf { it.isNotBlank() }
        val internalEmail = SupabaseConfig.getInternalAuthEmail(normalizedUserId)

        return try {
            var sessionToken: String? = null
            var authUserId: String? = null
            var refreshToken: String? = null

            // STEP 1: Attempt Supabase Auth signup
            val signupUrl = "${SupabaseConfig.supabaseUrl}/auth/v1/signup"
            val signupBody = JSONObject().apply {
                put("email", internalEmail)
                put("password", password)
                put("data", JSONObject().apply {
                    put("user_id", normalizedUserId)
                    put("display_name", cleanDisplayName)
                    put("mobile_number", normalizedMobile)
                })
            }

            try {
                val signupRes = client.post(signupUrl, signupBody.toString())
                val signupJson = JSONObject(signupRes)
                sessionToken = signupJson.optString("access_token")
                refreshToken = signupJson.optString("refresh_token")
                authUserId = signupJson.optJSONObject("user")?.optString("id")
                    ?: signupJson.optString("id")
            } catch (e: Exception) {
                val errMsg = e.message?.lowercase() ?: ""
                // Orphan recovery: If user is already registered in Auth but profile incomplete, attempt sign in
                if (errMsg.contains("already registered") || errMsg.contains("user already exists") || errMsg.contains("email address already")) {
                    val tokenUrl = "${SupabaseConfig.supabaseUrl}/auth/v1/token?grant_type=password"
                    val tokenBody = JSONObject().apply {
                        put("email", internalEmail)
                        put("password", password)
                    }
                    val tokenRes = client.post(tokenUrl, tokenBody.toString())
                    val tokenJson = JSONObject(tokenRes)
                    sessionToken = tokenJson.optString("access_token")
                    refreshToken = tokenJson.optString("refresh_token")
                    authUserId = tokenJson.optJSONObject("user")?.optString("id") ?: tokenJson.optString("id")
                } else {
                    throw e
                }
            }

            // If token wasn't directly returned, obtain via token endpoint
            if (sessionToken.isNullOrBlank() || authUserId.isNullOrBlank()) {
                val tokenUrl = "${SupabaseConfig.supabaseUrl}/auth/v1/token?grant_type=password"
                val tokenBody = JSONObject().apply {
                    put("email", internalEmail)
                    put("password", password)
                }
                val tokenRes = client.post(tokenUrl, tokenBody.toString())
                val tokenJson = JSONObject(tokenRes)
                sessionToken = tokenJson.optString("access_token")
                refreshToken = tokenJson.optString("refresh_token")
                authUserId = tokenJson.optJSONObject("user")?.optString("id") ?: tokenJson.optString("id")
            }

            if (sessionToken.isNullOrBlank() || authUserId.isNullOrBlank()) {
                throw SupabaseException("Could not authenticate session. Please try again.", 400, "")
            }

            // Save temporary token in session so subsequent authenticated calls succeed
            sessionManager.saveSession(sessionToken, authUserId, refreshToken = refreshToken)

            // STEP 2: If profile photo selected, upload to private profile-media bucket
            var avatarPath: String? = null
            if (avatarFile != null) {
                val ext = avatarFile.extension.ifBlank { "jpg" }
                val relativePath = "$authUserId/${UUID.randomUUID()}.$ext"
                avatarPath = client.uploadFile(
                    SupabaseConfig.BUCKET_PROFILE_MEDIA,
                    relativePath,
                    avatarFile,
                    "image/jpeg"
                )
            }

            // STEP 3: Complete user registration via authoritative RPC
            val rpcParams = mutableMapOf<String, Any?>(
                "p_user_id" to normalizedUserId,
                "p_display_name" to cleanDisplayName,
                "p_mobile_number" to normalizedMobile,
                "p_avatar_url" to avatarPath
            )
            if (cleanReferral != null) {
                rpcParams["p_referral_code"] = cleanReferral
            }

            try {
                client.rpc("complete_user_signup", rpcParams)
            } catch (e: Exception) {
                val rpcErr = e.message ?: ""
                if (cleanReferral != null && rpcErr.contains("referral", ignoreCase = true)) {
                    throw SupabaseException("Invalid referral code", 400, "invalid_referral")
                } else {
                    throw e
                }
            }

            // STEP 4: Authoritatively verify profile from backend
            val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=eq.$authUserId&select=*"
            val profileRes = client.get(profileUrl)
            val profileArray = JSONArray(profileRes)
            if (profileArray.length() == 0) {
                throw SupabaseException("Profile could not be verified after registration.", 500, "")
            }

            val profile = parseUserProfile(profileArray.getJSONObject(0))
            if (profile.userId.isBlank() || profile.mobileNumber.isBlank()) {
                throw SupabaseException("Incomplete user profile data. Please try again.", 500, "")
            }

            sessionManager.saveSession(sessionToken, authUserId, profile, refreshToken = refreshToken)
            Result.success(profile)
        } catch (e: Exception) {
            sessionManager.clearSession()
            Result.failure(e)
        }
    }

    suspend fun signIn(userId: String, password: String): Result<UserProfile> {
        val normalizedUserId = userId.trim().lowercase()
        val internalEmail = SupabaseConfig.getInternalAuthEmail(normalizedUserId)

        return try {
            val tokenUrl = "${SupabaseConfig.supabaseUrl}/auth/v1/token?grant_type=password"
            val authBody = JSONObject().apply {
                put("email", internalEmail)
                put("password", password)
            }
            val authRes = client.post(tokenUrl, authBody.toString())
            val authJson = JSONObject(authRes)
            val sessionToken = authJson.optString("access_token")
            val refreshToken = authJson.optString("refresh_token")
            val authUserId = authJson.optJSONObject("user")?.optString("id")
                ?: authJson.optString("id")

            if (sessionToken.isNullOrBlank() || authUserId.isNullOrBlank()) {
                throw SupabaseException("Invalid User ID or Password.", 401, "unauthorized")
            }

            sessionManager.saveSession(sessionToken, authUserId, refreshToken = refreshToken)

            // Fetch profile
            val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=eq.$authUserId&select=*"
            val profileRes = client.get(profileUrl)
            val profileArray = JSONArray(profileRes)
            if (profileArray.length() == 0) {
                throw SupabaseException("User profile not found. Please contact support.", 404, "")
            }

            val profile = parseUserProfile(profileArray.getJSONObject(0))
            if (profile.accountStatus == "deleted" || profile.accountStatus == "banned" || profile.accountStatus == "suspended") {
                sessionManager.clearSession()
                throw SupabaseException("Your account is ${profile.accountStatus}. Please contact support.", 403, "")
            }

            sessionManager.saveSession(sessionToken, authUserId, profile, refreshToken = refreshToken)
            Result.success(profile)
        } catch (e: Exception) {
            sessionManager.clearSession()
            Result.failure(e)
        }
    }

    suspend fun restoreOrRefreshSession(): Boolean {
        if (!sessionManager.hasPersistedSessionCredentials) {
            sessionManager.clearSession()
            return false
        }

        val sessionResult = client.ensureValidSession()
        return when (sessionResult) {
            is com.example.data.model.SessionResult.Valid -> {
                true
            }
            is com.example.data.model.SessionResult.AuthRequired -> {
                sessionManager.clearSession()
                false
            }
            is com.example.data.model.SessionResult.NetworkError,
            is com.example.data.model.SessionResult.ServerError -> {
                val hasCachedUser = sessionManager.currentUser.value != null && !sessionManager.userId.value.isNullOrBlank()
                hasCachedUser || sessionManager.hasPersistedSessionCredentials
            }
        }
    }

    suspend fun fetchCurrentUserProfile(): Result<UserProfile> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=eq.$userId&select=*"
            val profileRes = client.get(profileUrl)
            val profileArray = JSONArray(profileRes)
            if (profileArray.length() > 0) {
                val profile = parseUserProfile(profileArray.getJSONObject(0))
                sessionManager.updateProfile(profile)
                Result.success(profile)
            } else {
                Result.failure(Exception("Profile not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateProfile(displayName: String, bio: String?, avatarFile: File? = null): Result<UserProfile> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            var avatarPath: String? = null
            if (avatarFile != null) {
                val ext = avatarFile.extension.ifBlank { "jpg" }
                val relativePath = "$userId/${UUID.randomUUID()}.$ext"
                avatarPath = client.uploadFile(
                    SupabaseConfig.BUCKET_PROFILE_MEDIA,
                    relativePath,
                    avatarFile,
                    "image/jpeg"
                )
            }

            try {
                val rpcParams = mutableMapOf<String, Any?>(
                    "p_display_name" to displayName
                )
                if (bio != null) rpcParams["p_bio"] = bio
                if (avatarPath != null) rpcParams["p_avatar_url"] = avatarPath
                client.rpc("update_my_profile", rpcParams)
            } catch (_: Exception) {
                // Fallback to update_my_profile_avatar if avatar updated or direct patch
                if (avatarPath != null) {
                    try {
                        client.rpc("update_my_profile_avatar", mapOf("p_avatar_url" to avatarPath))
                    } catch (_: Exception) {}
                }
                val patchUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=eq.$userId"
                val updateJson = JSONObject().apply {
                    put("display_name", displayName)
                    if (bio != null) put("bio", bio)
                    if (avatarPath != null) put("avatar_url", avatarPath)
                }
                client.patch(patchUrl, updateJson.toString())
            }

            fetchCurrentUserProfile()
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun signOut() {
        sessionManager.clearSession()
    }

    suspend fun requestAccountDeletion(): Result<Unit> {
        val currentUserId = sessionManager.userId.value
        if (currentUserId.isNullOrBlank()) {
            return Result.failure(IllegalStateException("User is not authenticated"))
        }
        return try {
            val response = client.rpc("request_account_deletion")
            android.util.Log.d("SupabaseAuthService", "request_account_deletion response: $response")
            Result.success(Unit)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseAuthService", "request_account_deletion failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun parseUserProfile(json: JSONObject): UserProfile {
        return UserProfile(
            id = json.optString("id"),
            userId = json.optString("user_id"),
            username = json.optString("username"),
            displayName = json.optString("display_name"),
            avatarUrl = json.optString("avatar_url").takeIf { it.isNotBlank() },
            bio = json.optString("bio").takeIf { it.isNotBlank() },
            gender = json.optString("gender"),
            language = json.optString("language"),
            accountStatus = json.optString("account_status", "active"),
            isOnline = json.optBoolean("is_online", false),
            mobileNumber = json.optString("mobile_number"),
            referralCode = json.optString("referral_code"),
            referralCodeUsed = json.optString("referral_code_used"),
            rating = json.optDouble("rating", 5.0),
            reviewsCount = json.optInt("reviews_count", 0),
            totalCalls = json.optInt("total_calls", 0),
            createdAt = json.optString("created_at")
        )
    }
}
