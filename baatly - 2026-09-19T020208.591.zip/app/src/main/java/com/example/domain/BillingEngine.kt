package com.example.domain

import java.text.DecimalFormat
import java.util.Locale

/**
 * Coordinates backend state and UI presentation.
 * Note: Contains NO hardcoded financial numbers, coin conversions, or pricing rules.
 * All authoritative pricing and balances are fetched directly from the backend.
 */
object BillingEngine {

    private val currencyFormat = DecimalFormat("#,##0.##")

    /**
     * Calculates maximum call duration in seconds given balance and rate per minute.
     * All values passed in must originate from backend pricing/wallet responses.
     */
    fun calculateMaxCallDurationSeconds(balanceRupees: Double, rateRupeesPerMinute: Double): Int {
        if (rateRupeesPerMinute <= 0.0 || balanceRupees <= 0.0) return 0
        val minutes = balanceRupees / rateRupeesPerMinute
        return (minutes * 60).toInt()
    }

    fun calculateMaxCallDurationSeconds(balance: Int, ratePerMinute: Int): Int {
        return calculateMaxCallDurationSeconds(balance.toDouble(), ratePerMinute.toDouble())
    }

    /**
     * Formats rupee amounts dynamically for presentation.
     */
    fun formatRupees(amount: Double?): String {
        if (amount == null) return "0"
        return currencyFormat.format(amount)
    }

    /**
     * Formats duration in seconds to mm:ss format.
     */
    fun formatDuration(seconds: Int): String {
        val safeSec = maxOf(0, seconds)
        val m = safeSec / 60
        val s = safeSec % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }

    /**
     * Checks whether text content contains contact or number-sharing attempts.
     * Matches 4+ digit numeric sequences or English/Hindi number words.
     */
    fun containsForbiddenNumberContent(text: String): Boolean {
        if (text.isBlank()) return false
        val clean = text.lowercase(Locale.ROOT)

        // Match 4+ digits even if separated by spaces or dots/hyphens
        val digitsOnly = clean.filter { it.isDigit() }
        if (digitsOnly.length >= 4) {
            val consecutiveDigitsRegex = Regex("""\b\d{4,}\b|\d[\s\-_.,]*\d[\s\-_.,]*\d[\s\-_.,]*\d""")
            if (consecutiveDigitsRegex.find(clean) != null) {
                return true
            }
        }

        // Check for common Indian 10-digit mobile number patterns
        val phoneRegex = Regex("""(?:\+?91)?[6-9]\d{9}""")
        if (phoneRegex.find(digitsOnly) != null) {
            return true
        }

        // Check for number words in sequence
        val numberWords = listOf(
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
            "shunya", "ek", "do", "teen", "chaar", "char", "paanch", "panch", "chheh", "chhe", "saat", "aath", "ath", "nau", "das"
        )

        val words = clean.split(Regex("""[\s,.\-_/]+"""))
        var consecutiveWordNumberCount = 0
        for (w in words) {
            if (numberWords.contains(w) || (w.isNotEmpty() && w.all { it.isDigit() })) {
                consecutiveWordNumberCount++
                if (consecutiveWordNumberCount >= 4) {
                    return true
                }
            } else {
                consecutiveWordNumberCount = 0
            }
        }

        return false
    }
}
