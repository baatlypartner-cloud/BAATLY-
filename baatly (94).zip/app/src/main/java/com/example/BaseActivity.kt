package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity

/**
 * BaseActivity provides a centralized Activity layer ensuring that
 * screenshots and screen recordings are fully permitted for testing.
 */
abstract class BaseActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        super.onCreate(savedInstanceState)
        BaatlyApplication.ensureWindowCaptureAllowed(this)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        BaatlyApplication.ensureWindowCaptureAllowed(this)
    }

    override fun onResume() {
        super.onResume()
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        BaatlyApplication.ensureWindowCaptureAllowed(this)
    }
}
