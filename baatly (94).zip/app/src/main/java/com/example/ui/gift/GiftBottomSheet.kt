package com.example.ui.gift

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.SecureFlagPolicy
import coil.compose.AsyncImage
import com.example.data.model.GiftItem
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GiftBottomSheet(viewModel: BaatlyViewModel) {
    val gifts by viewModel.gifts.collectAsState()
    val wallet by viewModel.wallet.collectAsState()
    var selectedGift by remember { mutableStateOf<GiftItem?>(null) }

    ModalBottomSheet(
        onDismissRequest = { viewModel.toggleGiftSheet(false) },
        properties = ModalBottomSheetDefaults.properties(securePolicy = SecureFlagPolicy.SecureOff),
        containerColor = DarkSurface,
        dragHandle = { BottomSheetDefaults.DragHandle(color = DarkCardBorder) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Send a Gift",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "Your Balance: ${wallet?.balance ?: 0} Coins",
                        style = MaterialTheme.typography.bodySmall.copy(color = PrimaryLavender)
                    )
                }

                // Top Up shortcut
                TextButton(
                    onClick = {
                        viewModel.toggleGiftSheet(false)
                        viewModel.setScreen(Screen.WALLET)
                    }
                ) {
                    Text("Top Up", color = PrimaryLavender, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Gift Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(gifts, key = { it.id }) { gift ->
                    val isSelected = selectedGift?.id == gift.id
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) DarkSurfaceVariant else Color.Transparent)
                            .border(1.dp, if (isSelected) PrimaryLavender else DarkCardBorder, RoundedCornerShape(16.dp))
                            .clickable { selectedGift = gift }
                            .padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(DarkBackground),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!gift.iconUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = gift.iconUrl,
                                    contentDescription = gift.name,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.size(36.dp)
                                )
                            } else {
                                Text(
                                    text = "🎁",
                                    fontSize = 24.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = gift.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MonetizationOn,
                                contentDescription = null,
                                tint = PrimaryLavender,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "${gift.coinPrice}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = PrimaryLavender,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Send Button
            Button(
                onClick = {
                    selectedGift?.let { gift ->
                        viewModel.sendGift(gift)
                    }
                },
                enabled = selectedGift != null && (wallet?.balance ?: 0) >= (selectedGift?.coinPrice ?: Int.MAX_VALUE),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryLavender,
                    contentColor = Color(0xFF1C1C22)
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_send_gift_confirm")
            ) {
                Text(
                    text = if (selectedGift != null) "SEND ${selectedGift!!.name.uppercase()} (${selectedGift!!.coinPrice} COINS)" else "SELECT A GIFT",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1C1C22)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
