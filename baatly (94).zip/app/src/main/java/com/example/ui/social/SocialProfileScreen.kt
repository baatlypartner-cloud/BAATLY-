package com.example.ui.social

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import android.util.Log
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.SocialPost
import com.example.data.model.SocialProfile
import com.example.data.model.SocialStory
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialProfileScreen(
    viewModel: BaatlyViewModel,
    profile: SocialProfile?
) {
    val context = LocalContext.current
    val currentUserId by viewModel.sessionManager.userId.collectAsState()
    val isMyProfile = profile?.userId == currentUserId
    val isRenewingPost by viewModel.isRenewingPost.collectAsState()
    val followingInProgress by viewModel.followingInProgress.collectAsState()
    val activeStoryViewer by viewModel.activeStoryViewer.collectAsState()
    val activePostViewer by viewModel.activePostViewer.collectAsState()
    val activeCommentsPost by viewModel.activeCommentsPost.collectAsState()
    val socialComments by viewModel.socialComments.collectAsState()
    val isLoadingComments by viewModel.isLoadingComments.collectAsState()
    val wallet by viewModel.wallet.collectAsState()
    val userCoins = wallet?.balance ?: 0

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Posts, 1: Stories
    var showEditDialog by remember { mutableStateOf(false) }
    var postToDelete by remember { mutableStateOf<SocialPost?>(null) }

    // Edit Profile State
    var editBio by remember(profile) { mutableStateOf(profile?.bio ?: "") }
    var editHobbies by remember(profile) { mutableStateOf(profile?.hobbies ?: "") }
    var editAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var isSavingProfile by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            editAvatarUri = uri
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isMyProfile) "My Social Profile" else (profile?.displayName ?: "Profile"),
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.closeSocialProfile() },
                        modifier = Modifier.testTag("btn_back_social_profile")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    if (isMyProfile) {
                        IconButton(
                            onClick = { showEditDialog = true },
                            modifier = Modifier.testTag("btn_open_edit_social_profile")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = "Edit Profile",
                                tint = VibrantPink
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkNavBackground,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        if (profile == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = VibrantPink)
            }
            return@Scaffold
        }

        val activeStories = profile.stories.filter { it.isActive && !it.isExpired }
        val hasActiveStories = profile.hasActiveStories

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Profile Header Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Avatar with Gradient Ring (Ring highlights active stories)
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .clip(CircleShape)
                        .background(
                            if (hasActiveStories) Brush.sweepGradient(listOf(VibrantPink, DarkPink, CoinGold, VibrantPink))
                            else Brush.linearGradient(listOf(VibrantPink, DarkPink))
                        )
                        .padding(if (hasActiveStories) 3.5.dp else 2.5.dp)
                        .clickable(enabled = hasActiveStories) {
                            val firstStory = activeStories.firstOrNull()
                            if (firstStory != null) {
                                viewModel.openStoryViewer(firstStory)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(DarkSurfaceVariant)
                    ) {
                        if (!profile.socialAvatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = profile.socialAvatarUrl,
                                contentDescription = profile.displayName,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (profile.displayName ?: "U").take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 32.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Display Name & Handle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = profile.displayName ?: if (profile.isHost) "Host" else "User",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 18.sp
                        )
                    )
                    if (profile.isHost) {
                        Surface(
                            color = VibrantPink,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "HOST",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                val handle = profile.publicHandle
                if (handle.isNotBlank()) {
                    Text(
                        text = "@$handle",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }

                // Bio
                if (!profile.bio.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = profile.bio,
                        color = TextPrimary.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Hobbies Chips
                if (profile.hobbiesList.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        profile.hobbiesList.take(4).forEach { hobby ->
                            Surface(
                                color = DarkSurfaceVariant,
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                            ) {
                                Text(
                                    text = hobby,
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Stats Row: Followers | Following | Likes | Views
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkSurfaceVariant)
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatColumn(label = "Followers", count = profile.followersCount)
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(DarkCardBorder))
                    StatColumn(label = "Following", count = profile.followingCount)
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(DarkCardBorder))
                    StatColumn(label = "Likes", count = profile.totalLikes)
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(DarkCardBorder))
                    StatColumn(label = "Views", count = profile.totalViews)
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Buttons Row
                if (isMyProfile) {
                    Button(
                        onClick = { showEditDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("btn_edit_social_profile"),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VibrantPink.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "Edit",
                            tint = VibrantPink,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Edit Social Profile",
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                } else if (profile.isHost) {
                    val isFollowInProgress = followingInProgress.contains(profile.userId) ||
                            followingInProgress.contains(profile.canonicalAuthUserId) ||
                            (profile.partner != null && (followingInProgress.contains(profile.partner.id) || (profile.partner.userId != null && followingInProgress.contains(profile.partner.userId))))
                    // Host Profile Action Row: Follow, Chat & Call Now
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Follow Button
                        Button(
                            onClick = {
                                val targetId = profile.canonicalAuthUserId
                                viewModel.toggleSocialFollow(targetId, profile.partner)
                            },
                            enabled = !isFollowInProgress,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_social_follow_host"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (profile.isFollowing) DarkSurfaceVariant else VibrantPink,
                                disabledContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isFollowInProgress) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = Color.White
                                )
                            } else {
                                Text(
                                    text = if (profile.isFollowing) "Following" else "Follow",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        // Chat Button
                        val partnerToChat = profile.partner ?: com.example.data.model.PartnerProfile(
                            id = profile.userId,
                            userId = profile.signupUserId ?: profile.userId,
                            displayName = profile.displayName ?: "Host",
                            avatarUrl = profile.socialAvatarUrl,
                            bio = profile.bio,
                            isOnline = true
                        )
                        Button(
                            onClick = { viewModel.openChatWithHost(partnerToChat) },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_social_chat_host"),
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Chat,
                                contentDescription = "Chat with Host",
                                tint = TextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Chat",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        // Call Now Button (Allowed ONLY when viewed profile is a Host)
                        val partnerToCall = profile.partner ?: com.example.data.model.PartnerProfile(
                            id = profile.userId,
                            userId = profile.signupUserId ?: profile.userId,
                            displayName = profile.displayName ?: "Host",
                            avatarUrl = profile.socialAvatarUrl,
                            bio = profile.bio,
                            isOnline = true
                        )
                        Button(
                            onClick = { viewModel.startCallFromSocial(partnerToCall) },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_social_call_host"),
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Call,
                                contentDescription = "Call Host",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Call Now",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    // Regular User Profile Action Row: Follow / Following
                    val isFollowInProgress = followingInProgress.contains(profile.userId) ||
                            followingInProgress.contains(profile.canonicalAuthUserId)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Button(
                            onClick = {
                                viewModel.toggleSocialFollow(profile.canonicalAuthUserId)
                            },
                            enabled = !isFollowInProgress,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("btn_social_follow_user"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (profile.isFollowing) DarkSurfaceVariant else VibrantPink,
                                disabledContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isFollowInProgress) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = Color.White
                                )
                            } else {
                                Text(
                                    text = if (profile.isFollowing) "Following" else "Follow",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            // Tabs for Posts & Stories
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkNavBackground,
                contentColor = VibrantPink,
                indicator = { tabPositions ->
                    if (selectedTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = VibrantPink
                        )
                    }
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "Posts (${profile.posts.size})",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == 0) VibrantPink else TextSecondary
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "Stories (${activeStories.size})",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == 1) VibrantPink else TextSecondary
                        )
                    }
                )
            }

            // Content Grid
            if (selectedTab == 0) {
                if (profile.posts.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No posts published yet",
                            color = TextTertiary,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(profile.posts, key = { it.id }) { post ->
                            PostGridItem(
                                post = post,
                                onClick = {
                                    if (!post.isUnlocked && post.isOwnerHost) {
                                        viewModel.unlockPost(post)
                                    } else {
                                        viewModel.openPostViewer(post)
                                    }
                                }
                            )
                        }
                    }
                }
            } else {
                if (activeStories.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No active stories",
                            color = TextTertiary,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(activeStories, key = { it.id }) { story ->
                            StoryGridItem(
                                story = story,
                                onClick = { viewModel.openStoryViewer(story) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Edit Profile Modal Dialog
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSavingProfile) showEditDialog = false },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOff),
            title = {
                Text("Edit Social Profile", fontWeight = FontWeight.Bold, color = TextPrimary)
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Avatar Picker
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceVariant)
                            .clickable { photoPickerLauncher.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        if (editAvatarUri != null) {
                            AsyncImage(
                                model = editAvatarUri,
                                contentDescription = "New avatar",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else if (!profile?.socialAvatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = profile?.socialAvatarUrl,
                                contentDescription = "Current avatar",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.AddAPhoto,
                                contentDescription = "Upload avatar",
                                tint = VibrantPink,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                    Text(
                        text = "Tap to change photo",
                        fontSize = 11.sp,
                        color = TextTertiary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text("Bio") },
                        placeholder = { Text("Tell something about yourself") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VibrantPink,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = editHobbies,
                        onValueChange = { editHobbies = it },
                        label = { Text("Hobbies / Interests") },
                        placeholder = { Text("Music, Travel, Gaming") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VibrantPink,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isSavingProfile = true
                        var file: File? = null
                        if (editAvatarUri != null) {
                            try {
                                val inputStream = context.contentResolver.openInputStream(editAvatarUri!!)
                                val tempFile = File(context.cacheDir, "avatar_${System.currentTimeMillis()}.jpg")
                                val outputStream = FileOutputStream(tempFile)
                                val bitmap = BitmapFactory.decodeStream(inputStream)
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
                                outputStream.flush()
                                outputStream.close()
                                inputStream?.close()
                                file = tempFile
                            } catch (_: Exception) {}
                        }

                        viewModel.updateMySocialProfile(editBio, editHobbies, file) { success, _ ->
                            isSavingProfile = false
                            if (success) {
                                showEditDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VibrantPink),
                    enabled = !isSavingProfile
                ) {
                    if (isSavingProfile) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                    } else {
                        Text("Save", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showEditDialog = false },
                    enabled = !isSavingProfile
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkCardBackground
        )
    }

    // Active Comments Sheet
    if (activeCommentsPost != null) {
        SocialCommentsSheet(
            title = "Comments (${activeCommentsPost?.commentsCount ?: 0})",
            comments = socialComments,
            isLoading = isLoadingComments,
            userCoinBalance = userCoins,
            onDismiss = { viewModel.closeComments() },
            onSendComment = { text -> viewModel.addCommentToActivePost(text) }
        )
    }

    // Full Screen Story Viewer
    if (activeStoryViewer != null) {
        StoryViewerModal(
            story = activeStoryViewer!!,
            onClose = { viewModel.closeStoryViewer() },
            onLikeStory = { viewModel.toggleLikeStory(activeStoryViewer!!) },
            onReplyStory = { text -> viewModel.addCommentToActiveStory(text) },
            onCallHost = { partner -> viewModel.startCallFromSocial(partner) }
        )
    }

    // Full Screen Post Viewer
    if (activePostViewer != null) {
        PostImageViewerModal(
            post = activePostViewer!!,
            currentUserId = currentUserId ?: "",
            onClose = { viewModel.closePostViewer() },
            onLikePost = { viewModel.toggleLikePost(activePostViewer!!) },
            onOpenComments = {
                val currentPost = activePostViewer!!
                viewModel.openCommentsForPost(currentPost)
            },
            onAuthorClick = null,
            onCallHost = { partner -> viewModel.startCallFromSocial(partner) },
            onDeletePost = {
                postToDelete = activePostViewer
            },
            onRenewPost = {
                val currentPost = activePostViewer
                if (currentPost != null) {
                    viewModel.renewPost(currentPost)
                }
            },
            isRenewing = isRenewingPost == activePostViewer?.id
        )
    }

    // Post Deletion Confirmation Dialog
    if (postToDelete != null) {
        val targetPost = postToDelete!!
        AlertDialog(
            onDismissRequest = { postToDelete = null },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOff),
            containerColor = DarkSurface,
            title = {
                Text(
                    text = "Delete post?",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "This post will be permanently deleted. Coins already spent by other users will not be refunded.",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val toDelete = targetPost
                        postToDelete = null
                        viewModel.deleteSocialPost(toDelete)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("btn_confirm_delete_post")
                ) {
                    Text(
                        text = "Delete",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { postToDelete = null },
                    modifier = Modifier.testTag("btn_cancel_delete_post")
                ) {
                    Text(
                        text = "Cancel",
                        color = TextTertiary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        )
    }
}

@Composable
private fun StatColumn(label: String, count: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count.toString(),
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            fontSize = 16.sp
        )
        Text(
            text = label,
            color = TextTertiary,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun PostGridItem(
    post: SocialPost,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceVariant)
            .clickable { onClick() }
    ) {
        if (!post.resolvedMediaUrl.isNullOrBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(post.resolvedMediaUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Post thumbnail",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                onError = { state ->
                    Log.e("PostGridItem", "Failed to load thumbnail for post ${post.id}: ${state.result.throwable.message}")
                }
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.BrokenImage,
                    contentDescription = "Image unavailable",
                    tint = TextTertiary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        if (!post.isUnlocked && post.isOwnerHost) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = "Locked post",
                    tint = VibrantPink,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Renewal badge if post is in grace period
        if (post.isInRenewalGracePeriod) {
            Surface(
                color = WarningYellow,
                shape = RoundedCornerShape(bottomStart = 6.dp),
                modifier = Modifier.align(Alignment.TopEnd)
            ) {
                Text(
                    text = "RENEW",
                    color = Color.Black,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun StoryGridItem(
    story: SocialStory,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceVariant)
            .clickable { onClick() }
    ) {
        if (!story.resolvedMediaUrl.isNullOrBlank()) {
            AsyncImage(
                model = story.resolvedMediaUrl,
                contentDescription = "Story thumbnail",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.BrokenImage,
                    contentDescription = "Story thumbnail unavailable",
                    tint = TextTertiary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
