package com.example.ui.payment

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.NeonPink
import com.example.ui.theme.PrimaryLavender
import com.example.ui.theme.TextMuted

private const val TAG = "UroPayCheckoutWebView"

/**
 * Dedicated In-App WebView fallback for UroPay checkout.
 *
 * Requirements:
 * - HTTPS, JavaScript, DOM storage, cookies, redirects
 * - Handles payment gateway navigation and external intents (e.g. UPI) safely
 * - Normal back navigation
 * - Loading indicator & network error retry
 * - Does NOT apply FLAG_SECURE (allows screenshots and screen recordings for testing)
 * - Deep link return interception to trigger existing backend verification
 * - Does NOT mark payment successful client-side
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun UroPayCheckoutWebViewModal(
    checkoutUrl: String,
    onDismiss: () -> Unit,
    onPaymentReturn: (Uri) -> Unit
) {
    val context = LocalContext.current
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var loadProgress by remember { mutableFloatStateOf(0f) }
    var hasError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showExitConfirmDialog by remember { mutableStateOf(false) }

    val displayHost = remember(checkoutUrl) {
        try {
            Uri.parse(checkoutUrl).host ?: "api.uropai.in"
        } catch (_: Exception) {
            "api.uropai.in"
        }
    }

    // Handle back button: go back in web history if possible, else confirm exit
    BackHandler(enabled = true) {
        if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            showExitConfirmDialog = true
        }
    }

    Dialog(
        onDismissRequest = { showExitConfirmDialog = true },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
            securePolicy = SecureFlagPolicy.SecureOff // Screenshot/recording friendly for testing
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("uropay_checkout_modal"),
            color = DarkBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                // Top App Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = DarkCard,
                    shadowElevation = 4.dp
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                IconButton(
                                    onClick = {
                                        if (webViewInstance?.canGoBack() == true) {
                                            webViewInstance?.goBack()
                                        } else {
                                            showExitConfirmDialog = true
                                        }
                                    },
                                    modifier = Modifier.testTag("btn_checkout_back")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Back",
                                        tint = Color.White
                                    )
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Secure Checkout",
                                    tint = PrimaryLavender,
                                    modifier = Modifier.size(16.dp)
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                Column {
                                    Text(
                                        text = "UroPay Checkout",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    )
                                    Text(
                                        text = displayHost,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontSize = 11.sp,
                                            color = TextMuted
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        hasError = false
                                        webViewInstance?.reload()
                                    },
                                    modifier = Modifier.testTag("btn_checkout_reload")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Refresh",
                                        tint = Color.White
                                    )
                                }

                                IconButton(
                                    onClick = { showExitConfirmDialog = true },
                                    modifier = Modifier.testTag("btn_checkout_close")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Close",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        // Progress Indicator
                        if (isLoading) {
                            LinearProgressIndicator(
                                progress = { loadProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(2.dp),
                                color = PrimaryLavender,
                                trackColor = Color.Transparent
                            )
                        }
                    }
                }

                // WebView Container with Error & Loading overlays
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )

                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    databaseEnabled = true
                                    useWideViewPort = true
                                    loadWithOverviewMode = true
                                    cacheMode = WebSettings.LOAD_DEFAULT
                                    mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW // Enforce HTTPS
                                    allowFileAccess = false
                                    allowContentAccess = false
                                    setSupportMultipleWindows(false)
                                    javaScriptCanOpenWindowsAutomatically = true
                                }

                                val cookieManager = CookieManager.getInstance()
                                cookieManager.setAcceptCookie(true)
                                cookieManager.setAcceptThirdPartyCookies(this, true)

                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(
                                        view: WebView?,
                                        request: WebResourceRequest?
                                    ): Boolean {
                                        val reqUri = request?.url ?: return false
                                        val reqUrl = reqUri.toString()
                                        val scheme = reqUri.scheme?.lowercase() ?: ""
                                        val host = reqUri.host?.lowercase() ?: ""
                                        val path = reqUri.path?.lowercase() ?: ""

                                        Log.d(TAG, "Navigating to: $reqUrl (scheme=$scheme, host=$host, path=$path)")

                                        // 1. Intercept Baatly UroPay payment return deep links
                                        val isPaymentReturn = (scheme == "baatly" && host == "payment") ||
                                                (scheme == "https" && (path.startsWith("/payment/uropay/return") ||
                                                        path.startsWith("/payment/return") ||
                                                        path.contains("uropay-return") ||
                                                        path.contains("uropai-return") ||
                                                        (path.contains("uropay") && path.contains("return")) ||
                                                        (path.contains("uropai") && path.contains("return"))))

                                        if (isPaymentReturn) {
                                            Log.d(TAG, "Intercepted payment return deep link: $reqUri")
                                            onPaymentReturn(reqUri)
                                            return true
                                        }

                                        // 2. Handle external payment intents (e.g. UPI, PhonePe, Paytm, GooglePay, intent://)
                                        if (scheme != "http" && scheme != "https") {
                                            try {
                                                val externalIntent = if (reqUrl.startsWith("intent://")) {
                                                    Intent.parseUri(reqUrl, Intent.URI_INTENT_SCHEME)
                                                } else {
                                                    Intent(Intent.ACTION_VIEW, reqUri)
                                                }.apply {
                                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                }

                                                // Safe resolution: check if an Activity can handle the intent before launching
                                                if (externalIntent.resolveActivity(ctx.packageManager) != null) {
                                                    ctx.startActivity(externalIntent)
                                                } else {
                                                    // Check if fallback URL is provided in intent:// uri
                                                    val fallbackUrl = externalIntent.getStringExtra("browser_fallback_url")
                                                    if (!fallbackUrl.isNullOrBlank()) {
                                                        view?.loadUrl(fallbackUrl)
                                                    } else {
                                                        Toast.makeText(
                                                            ctx,
                                                            "No installed app found to handle payment method ($scheme)",
                                                            Toast.LENGTH_SHORT
                                                        ).show()
                                                    }
                                                }
                                            } catch (e: Exception) {
                                                Log.w(TAG, "Failed to launch external intent for: $reqUrl, error: ${e.message}", e)
                                            }
                                            return true
                                        }

                                        // Standard HTTPS navigation: allow WebView to load normally
                                        return false
                                    }

                                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                        super.onPageStarted(view, url, favicon)
                                        isLoading = true
                                        hasError = false
                                        errorMessage = null
                                    }

                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        super.onPageFinished(view, url)
                                        isLoading = false
                                    }

                                    override fun onReceivedError(
                                        view: WebView?,
                                        request: WebResourceRequest?,
                                        error: WebResourceError?
                                    ) {
                                        super.onReceivedError(view, request, error)
                                        // Only handle main frame errors
                                        if (request?.isForMainFrame == true) {
                                            hasError = true
                                            isLoading = false
                                            errorMessage = error?.description?.toString()
                                                ?: "Failed to load checkout page."
                                            Log.e(TAG, "WebView error: $errorMessage")
                                        }
                                    }
                                }

                                webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                        super.onProgressChanged(view, newProgress)
                                        loadProgress = (newProgress / 100f).coerceIn(0f, 1f)
                                        if (newProgress >= 100) {
                                            isLoading = false
                                        }
                                    }
                                }

                                loadUrl(checkoutUrl)
                                webViewInstance = this
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("checkout_webview_content")
                    )

                    // Network Error Overlay with Retry
                    if (hasError) {
                        Surface(
                            modifier = Modifier.fillMaxSize(),
                            color = DarkBackground
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WarningAmber,
                                    contentDescription = null,
                                    tint = NeonPink,
                                    modifier = Modifier.size(56.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "Unable to Load Checkout",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = errorMessage
                                        ?: "Please check your internet connection and try again.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextMuted,
                                        textAlign = TextAlign.Center
                                    )
                                )
                                Spacer(modifier = Modifier.height(24.dp))
                                Button(
                                    onClick = {
                                        hasError = false
                                        isLoading = true
                                        webViewInstance?.reload()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("btn_checkout_error_retry")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = null,
                                        tint = Color(0xFF1C1C22)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Retry",
                                        color = Color(0xFF1C1C22),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = onDismiss,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Close Checkout", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Exit Confirmation Dialog
    if (showExitConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showExitConfirmDialog = false },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOff),
            containerColor = DarkCard,
            title = {
                Text(
                    text = "Exit Checkout?",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            },
            text = {
                Text(
                    text = "If you have completed your payment, you can verify it in the Wallet screen. If not, your transaction will remain pending.",
                    color = TextMuted,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExitConfirmDialog = false
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Exit", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitConfirmDialog = false }) {
                    Text("Continue Payment", color = PrimaryLavender)
                }
            }
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewInstance?.stopLoading()
            webViewInstance?.destroy()
            webViewInstance = null
        }
    }
}
