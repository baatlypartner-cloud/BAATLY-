package com.example

import android.app.Activity
import android.app.Application
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager

/**
 * BaatlyApplication configuration.
 *
 * All screenshot and screen recording blocking mechanisms (FLAG_SECURE, recents preview disabling)
 * have been completely removed from the User App for testing so that screenshots, screen recordings,
 * and test captures function normally across all screens, activities, dialogs, and components.
 */
class BaatlyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        setupGlobalWindowPolicy()
    }

    /**
     * Registers ActivityLifecycleCallbacks to ensure no Activity retains screenshot or
     * screen recording restrictions.
     */
    private fun setupGlobalWindowPolicy() {
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                ensureWindowCaptureAllowed(activity)
            }

            override fun onActivityStarted(activity: Activity) {
                ensureWindowCaptureAllowed(activity)
            }

            override fun onActivityResumed(activity: Activity) {
                ensureWindowCaptureAllowed(activity)
            }

            override fun onActivityPaused(activity: Activity) {
                ensureWindowCaptureAllowed(activity)
            }

            override fun onActivityStopped(activity: Activity) {}

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {}
        })
    }

    companion object {
        private const val TAG = "BaatlySecurity"

        /**
         * Ensures that the given Activity does NOT block screenshots or screen recordings:
         * - Clears WindowManager.LayoutParams.FLAG_SECURE if present.
         * - On Android 14+ (API 34+), ensures recents screenshot preview is enabled.
         */
        fun ensureWindowCaptureAllowed(activity: Activity) {
            try {
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    activity.setRecentsScreenshotEnabled(true)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to ensure window capture is allowed: ${e.message}")
            }
        }

        // Backward compatibility alias for any callers
        fun applyWindowProtection(activity: Activity) {
            ensureWindowCaptureAllowed(activity)
        }
    }
}
