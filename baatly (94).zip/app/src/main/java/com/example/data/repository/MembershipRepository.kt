package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.network.SupabaseDataService
import com.example.ui.payment.UroPayCheckoutLauncher
import com.example.util.BaatlyAnalytics
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MembershipRepository(
    private val dataService: SupabaseDataService,
    private val sessionManager: SessionManager,
    private val repositoryScope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {
    private val _membershipState = MutableStateFlow<MembershipState>(MembershipState.Loading)
    val membershipState: StateFlow<MembershipState> = _membershipState.asStateFlow()

    private val _effectivePricing = MutableStateFlow(EffectiveUserPricing.DEFAULT_NON_MEMBER)
    val effectivePricing: StateFlow<EffectiveUserPricing> = _effectivePricing.asStateFlow()

    private val _activePlanState = MutableStateFlow<ActivePlanState>(ActivePlanState.Loading)
    val activePlanState: StateFlow<ActivePlanState> = _activePlanState.asStateFlow()

    private val _activePlan = MutableStateFlow<MembershipPlan?>(null)
    val activePlan: StateFlow<MembershipPlan?> = _activePlan.asStateFlow()

    private val _purchaseUiState = MutableStateFlow<MembershipPurchaseUiState>(MembershipPurchaseUiState.Idle)
    val purchaseUiState: StateFlow<MembershipPurchaseUiState> = _purchaseUiState.asStateFlow()

    private var countdownJob: Job? = null

    init {
        startCountdownTimer()
    }

    private fun startCountdownTimer() {
        countdownJob?.cancel()
        countdownJob = repositoryScope.launch {
            while (isActive) {
                delay(1000)
                val current = _membershipState.value
                if (current is MembershipState.Active) {
                    val now = System.currentTimeMillis()
                    val remaining = current.expiresAtEpochMs - now
                    if (remaining <= 0) {
                        Log.i(TAG, "Membership countdown reached 0. Transitioning to Expired state.")
                        BaatlyAnalytics.logMembershipExpired(sessionManager.userId.value)
                        _membershipState.value = MembershipState.Expired(current.membership)
                        _effectivePricing.value = EffectiveUserPricing.DEFAULT_NON_MEMBER
                        // Authoritatively sync with server
                        repositoryScope.launch {
                            dataService.expireMemberships()
                            refreshMembership()
                        }
                    } else {
                        _membershipState.value = current.copy(remainingMillis = remaining)
                    }
                }
            }
        }
    }

    suspend fun refreshMembership() {
        val userId = sessionManager.userId.value
        if (userId.isNullOrBlank()) {
            _membershipState.value = MembershipState.Inactive
            _effectivePricing.value = EffectiveUserPricing.DEFAULT_NON_MEMBER
            _activePlan.value = null
            _activePlanState.value = ActivePlanState.NoActivePlan
            return
        }

        try {
            // 1. Fetch active plan strictly from Supabase
            val planRes = dataService.fetchActiveMembershipPlan()
            if (planRes.isSuccess) {
                val plan = planRes.getOrNull()
                _activePlan.value = plan
                if (plan != null) {
                    _activePlanState.value = ActivePlanState.ActivePlan(plan)
                    Log.d(TAG, "Active membership plan found: ${plan.name} (₹${plan.priceInr})")
                } else {
                    _activePlanState.value = ActivePlanState.NoActivePlan
                    Log.d(TAG, "No active membership plan found in backend")
                }
            } else {
                _activePlan.value = null
                val err = planRes.exceptionOrNull()?.message ?: "Failed to fetch active membership plan"
                _activePlanState.value = ActivePlanState.Error(err)
                Log.e(TAG, "Error fetching active membership plan: $err")
            }

            // 2. Fetch user's membership record
            val memRes = dataService.fetchUserMembership(userId)
            val membership = memRes.getOrNull()

            val now = System.currentTimeMillis()
            var isActiveMembership = false

            if (membership != null && membership.status.equals("active", ignoreCase = true)) {
                val expiresMs = parseIsoTimestamp(membership.expiresAt)
                if (expiresMs != null && expiresMs > now) {
                    isActiveMembership = true
                    val remaining = expiresMs - now
                    _membershipState.value = MembershipState.Active(
                        membership = membership,
                        expiresAtEpochMs = expiresMs,
                        remainingMillis = remaining
                    )
                } else {
                    _membershipState.value = MembershipState.Expired(membership)
                }
            } else if (membership != null && membership.status.equals("expired", ignoreCase = true)) {
                _membershipState.value = MembershipState.Expired(membership)
            } else {
                _membershipState.value = MembershipState.Inactive
            }

            // 3. Fetch authoritative effective pricing
            val pricingRes = dataService.getEffectiveUserPricing(userId, isMemberFallback = isActiveMembership)
            val pricing = pricingRes.getOrNull() ?: if (isActiveMembership) EffectiveUserPricing.DEFAULT_MEMBER else EffectiveUserPricing.DEFAULT_NON_MEMBER
            _effectivePricing.value = pricing

            Log.d(TAG, "Membership refreshed: state=${_membershipState.value::class.simpleName}, isMember=${pricing.isMember}")
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing membership: ${e.message}", e)
        }
    }

    fun resetPurchaseUiState() {
        _purchaseUiState.value = MembershipPurchaseUiState.Idle
    }

    suspend fun startMembershipPurchase(
        context: Context,
        onLaunchInAppWebView: ((String) -> Unit)? = null
    ) {
        val userId = sessionManager.userId.value
        if (userId.isNullOrBlank()) {
            _purchaseUiState.value = MembershipPurchaseUiState.Failed("Please sign in to get membership.")
            return
        }

        // Validate if already active
        val current = _membershipState.value
        if (current is MembershipState.Active) {
            _purchaseUiState.value = MembershipPurchaseUiState.Failed("You already have an active membership!", canRetry = false)
            return
        }

        val plan = _activePlan.value
        if (plan == null) {
            _purchaseUiState.value = MembershipPurchaseUiState.Failed("No membership plan exists currently", canRetry = false)
            return
        }

        BaatlyAnalytics.logMembershipPurchaseStarted(userId, plan.id, plan.priceInr)
        _purchaseUiState.value = MembershipPurchaseUiState.CreatingPayment

        try {
            // 1. Call Supabase RPC create_membership_payment
            val paymentRes = dataService.createMembershipPayment(plan.id)
            if (paymentRes.isFailure) {
                val err = paymentRes.exceptionOrNull()?.message ?: "Failed to initiate membership payment."
                BaatlyAnalytics.logMembershipPaymentFailed(null, err)
                _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                return
            }

            val paymentId = paymentRes.getOrThrow()
            val tenantOrderRef = "MB_${System.currentTimeMillis()}_${(1000..9999).random()}"
            BaatlyAnalytics.logMembershipPaymentCreated(paymentId, tenantOrderRef)

            // 2. Call create-uropay-order Edge Function (UroPay only)
            val orderRes = dataService.createMembershipUroPayOrder(paymentId, plan.id, tenantOrderRef)
            if (orderRes.isFailure) {
                val err = orderRes.exceptionOrNull()?.message ?: "Failed to open UroPay payment checkout."
                BaatlyAnalytics.logMembershipPaymentFailed(paymentId, err)
                _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                return
            }

            val orderResult = orderRes.getOrThrow()
            val openUrl = orderResult.openUrl
            if (openUrl.isNullOrBlank()) {
                val err = "Invalid payment checkout link received."
                BaatlyAnalytics.logMembershipPaymentFailed(paymentId, err)
                _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                return
            }

            // 3. Save pending payment in SessionManager
            sessionManager.savePendingPayment(
                PendingUroPayPayment(
                    paymentId = paymentId,
                    orderId = orderResult.orderId,
                    tenantOrderRef = tenantOrderRef,
                    packageId = plan.id,
                    coins = 0,
                    priceInr = plan.priceInr,
                    openUrl = openUrl,
                    createdAt = System.currentTimeMillis(),
                    isMembership = true
                )
            )

            // 4. Update UI State & open checkout
            _purchaseUiState.value = MembershipPurchaseUiState.OpeningCheckout(paymentId, openUrl)
            BaatlyAnalytics.logMembershipCheckoutOpened(paymentId)

            val parsedUri = try { Uri.parse(openUrl) } catch (_: Exception) { null }
            Log.d(
                "BaatlyPayment",
                "Membership checkout:\n" +
                "payment_id=$paymentId\n" +
                "plan_id=${plan.id}\n" +
                "tenant_order_ref=$tenantOrderRef\n" +
                "order_id=${orderResult.orderId ?: "N/A"}\n" +
                "open_url=$openUrl\n" +
                "host=${parsedUri?.host ?: "unknown"}\n" +
                "scheme=${parsedUri?.scheme ?: "unknown"}\n" +
                "context=${context.javaClass.name}"
            )

            withContext(Dispatchers.Main) {
                UroPayCheckoutLauncher.launch(
                    context = context,
                    openUrl = openUrl,
                    onLaunchInAppWebView = { url ->
                        onLaunchInAppWebView?.invoke(url)
                    },
                    onError = { userMsg ->
                        _purchaseUiState.value = MembershipPurchaseUiState.Failed(userMsg)
                    }
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "startMembershipPurchase error: ${e.message}", e)
            BaatlyAnalytics.logMembershipPaymentFailed(null, e.message ?: "Unknown error")
            _purchaseUiState.value = MembershipPurchaseUiState.Failed(e.message ?: "Could not complete payment setup.")
        }
    }

    suspend fun verifyMembershipPayment(paymentId: String): Boolean {
        _purchaseUiState.value = MembershipPurchaseUiState.Verifying(paymentId)
        val res = dataService.verifyUroPayPayment(paymentId)
        if (res.isSuccess) {
            val result = res.getOrThrow()
            BaatlyAnalytics.logMembershipPaymentVerified(paymentId, result.success, result.status)

            if (result.success || result.status == "success") {
                // Finalize payment in backend RPC
                val finalizeRes = dataService.finalizeUroPayPayment(
                    paymentRowId = paymentId,
                    providerPaymentId = result.orderId
                )
                if (finalizeRes.isFailure) {
                    val err = finalizeRes.exceptionOrNull()?.message ?: "Failed to finalize membership payment."
                    Log.e(TAG, "finalizeUroPayPayment failed: $err", finalizeRes.exceptionOrNull())
                    BaatlyAnalytics.logMembershipPaymentFailed(paymentId, err)
                    _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                    return false
                }

                // Refresh membership from Supabase immediately so user gets benefits without waiting
                refreshMembership()

                val currentMem = (_membershipState.value as? MembershipState.Active)?.membership
                    ?: UserMembership(status = "active", planId = _activePlan.value?.id)

                BaatlyAnalytics.logMembershipActivated(
                    userId = sessionManager.userId.value,
                    planId = currentMem.planId,
                    expiresAt = currentMem.expiresAt
                )

                sessionManager.clearPendingPayment()
                _purchaseUiState.value = MembershipPurchaseUiState.Success(currentMem)
                return true
            } else if (result.status == "pending" || result.status == "created" || result.status == "in_progress") {
                _purchaseUiState.value = MembershipPurchaseUiState.Pending(
                    paymentId,
                    "Payment is being verified. Your membership will activate automatically once confirmed."
                )
                return false
            } else if (result.status == "cancelled") {
                sessionManager.clearPendingPayment()
                _purchaseUiState.value = MembershipPurchaseUiState.Cancelled("Payment was cancelled. No amount was charged.")
                return false
            } else {
                sessionManager.clearPendingPayment()
                _purchaseUiState.value = MembershipPurchaseUiState.Failed(
                    result.error ?: result.message ?: "Payment verification failed (${result.status})."
                )
                return false
            }
        } else {
            val err = res.exceptionOrNull()?.message ?: "Network error verifying payment."
            _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
            return false
        }
    }

    fun handlePaymentCancelled() {
        sessionManager.clearPendingPayment()
        _purchaseUiState.value = MembershipPurchaseUiState.Cancelled("Payment cancelled. No amount was added as membership.")
    }

    companion object {
        private const val TAG = "MembershipRepository"
    }
}
