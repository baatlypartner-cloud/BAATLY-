package com.example.ui.ads

import android.app.Activity
import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.appopen.AppOpenAdPreloader
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import com.google.android.libraries.ads.mobile.sdk.common.PreloadConfiguration
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdPreloader
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdEventCallback
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAd
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoader
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoaderCallback
import com.google.android.libraries.ads.mobile.sdk.nativead.MediaView
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdRequest
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdView
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Centralized BAATLY AdMob IDs, SDK initialization, frequency rules and ad rendering. */
object BaatlyAds {
    const val APP_ID = "ca-app-pub-9363095174633972~9323820583"
    const val APP_OPEN = "ca-app-pub-9363095174633972/4795775416"
    const val HOST_LIST = "ca-app-pub-9363095174633972/3291122057"
    const val CHAT_LIST = "ca-app-pub-9363095174633972/2085851599"
    const val REELS = "ca-app-pub-9363095174633972/1485271702"
    const val PANDIT_AI = "ca-app-pub-9363095174633972/3351840962"
    const val SUPER_AI = "ca-app-pub-9363095174633972/9473387024"
    const val ENTERTAINMENT_NATIVE = "ca-app-pub-9363095174633972/8980618347"
    const val POST_CALL = "ca-app-pub-9363095174633972/5375369073"

    private const val PREFS = "baatly_ad_frequency"
    private const val KEY_LAST_BACKGROUND = "last_background_at"
    private const val KEY_LAST_APP_OPEN = "last_app_open_shown"
    // Allow a launch ad on the first open and after a meaningful return, but avoid repeats
    // when users briefly switch apps or dismiss an app-open ad.
    private const val APP_OPEN_COOLDOWN_MS = 10L * 60L * 1000L
    private const val APP_OPEN_RETRY_DELAY_MS = 900L
    private const val APP_OPEN_MAX_RETRIES = 8
    private val mainHandler = Handler(Looper.getMainLooper())
    private val appOpenAttemptPending = AtomicBoolean(false)
    private val initialized = AtomicBoolean(false)
    @Volatile private var sdkReady = false
    private val _readyState = MutableStateFlow(false)
    val readyState = _readyState.asStateFlow()

    fun nativeUnit(productionId: String): String = if (BuildConfig.DEBUG) "/21775744923/example/native" else productionId

    /** Call only after UMP has processed the user's consent information. */
    fun initialize(context: Context) {
        if (!initialized.compareAndSet(false, true)) return
        Thread {
            try {
                MobileAds.initialize(
                    context.applicationContext,
                    InitializationConfig.Builder(APP_ID).build()
                ) {
                    sdkReady = true
                    // Start the preloaders before notifying UI/lifecycle observers that ads are ready.
                    startPreloading()
                    _readyState.value = true
                }
            } catch (t: Throwable) {
                initialized.set(false)
                android.util.Log.e("BaatlyAds", "GMA Next-Gen initialization failed", t)
            }
        }.start()
    }

    private fun startPreloading() {
        try {
            val appOpenId = if (BuildConfig.DEBUG) "/21775744923/example/app-open" else APP_OPEN
            val appOpenRequest = AdRequest.Builder(appOpenId).build()
            AppOpenAdPreloader.start(appOpenId, PreloadConfiguration(appOpenRequest))

            val interstitialId = if (BuildConfig.DEBUG) "/21775744923/example/interstitial" else POST_CALL
            val interstitialRequest = AdRequest.Builder(interstitialId).build()
            InterstitialAdPreloader.start(interstitialId, PreloadConfiguration(interstitialRequest))
        } catch (t: Throwable) {
            android.util.Log.w("BaatlyAds", "Ad preloading could not start", t)
        }
    }

    fun recordBackground(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putLong(KEY_LAST_BACKGROUND, System.currentTimeMillis()).apply()
    }

    /**
     * Attempts an app-open ad after consent, SDK initialization and the update gate are complete.
     * The preloader can still be warming up, so retry briefly instead of silently losing the launch.
     */
    fun showAppOpenOnEligibleResume(activity: Activity, shouldBlock: () -> Boolean) {
        if (!sdkReady || shouldBlock() || activity.isFinishing || activity.isDestroyed) return
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val lastBackground = prefs.getLong(KEY_LAST_BACKGROUND, 0L)
        val lastShown = prefs.getLong(KEY_LAST_APP_OPEN, 0L)
        if (lastBackground > 0L && now - lastBackground < APP_OPEN_COOLDOWN_MS) return
        if (lastShown > 0L && now - lastShown < APP_OPEN_COOLDOWN_MS) return
        if (!appOpenAttemptPending.compareAndSet(false, true)) return

        val preloadId = if (BuildConfig.DEBUG) "/21775744923/example/app-open" else APP_OPEN
        fun pollAndShow(retriesLeft: Int) {
            if (activity.isFinishing || activity.isDestroyed || shouldBlock()) {
                appOpenAttemptPending.set(false)
                return
            }
            val ad = try { AppOpenAdPreloader.pollAd(preloadId) } catch (t: Throwable) {
                android.util.Log.w("BaatlyAds", "App-open poll failed: ${t.message}")
                null
            }
            if (ad == null) {
                if (retriesLeft > 0) {
                    mainHandler.postDelayed({ pollAndShow(retriesLeft - 1) }, APP_OPEN_RETRY_DELAY_MS)
                } else {
                    android.util.Log.d("BaatlyAds", "App-open ad not ready after preload retries")
                    appOpenAttemptPending.set(false)
                }
                return
            }
            try {
                ad.show(activity)
                prefs.edit().putLong(KEY_LAST_APP_OPEN, System.currentTimeMillis()).apply()
            } catch (t: Throwable) {
                android.util.Log.w("BaatlyAds", "App-open ad failed to show: ${t.message}")
            } finally {
                appOpenAttemptPending.set(false)
            }
        }
        mainHandler.post { pollAndShow(APP_OPEN_MAX_RETRIES) }
    }

    /** Show a preloaded interstitial only after a completed (not cancelled/failed) call. */
    fun isReady(): Boolean = sdkReady

    fun showPostCallInterstitial(activity: Activity) {
        if (!sdkReady || activity.isFinishing || activity.isDestroyed) return
        val preloadId = if (BuildConfig.DEBUG) "/21775744923/example/interstitial" else POST_CALL
        val ad = try { InterstitialAdPreloader.pollAd(preloadId) } catch (_: Throwable) { null } ?: return
        try {
            ad.adEventCallback = object : InterstitialAdEventCallback {
                override fun onAdDismissedFullScreenContent() { android.util.Log.d("BaatlyAds", "Post-call ad dismissed") }
                override fun onAdFailedToShowFullScreenContent(fullScreenContentError: com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError) {
                    android.util.Log.w("BaatlyAds", "Post-call ad failed: ${fullScreenContentError.message}")
                }
                override fun onAdImpression() { android.util.Log.d("BaatlyAds", "Post-call impression") }
            }
            ad.show(activity)
        } catch (t: Throwable) {
            android.util.Log.w("BaatlyAds", "Post-call interstitial could not be shown", t)
        }
    }
}

@Composable
fun BaatlyNativeAdCard(adUnitId: String, modifier: Modifier = Modifier) {
    val sdkReady by BaatlyAds.readyState.collectAsState()
    var loadedAd by remember(adUnitId) { mutableStateOf<NativeAd?>(null) }
    var failed by remember(adUnitId) { mutableStateOf(false) }

    DisposableEffect(adUnitId, sdkReady) {
        var isActive = true
        var ownedAd: NativeAd? = null
        if (sdkReady) {
            try {
                val request = NativeAdRequest.Builder(
                    BaatlyAds.nativeUnit(adUnitId),
                    listOf(NativeAd.NativeAdType.NATIVE)
                ).build()
                NativeAdLoader.load(request, object : NativeAdLoaderCallback {
                    override fun onNativeAdLoaded(nativeAd: NativeAd) {
                        Handler(Looper.getMainLooper()).post {
                            if (isActive) {
                                ownedAd = nativeAd
                                loadedAd?.takeIf { it !== nativeAd }?.destroy()
                                loadedAd = nativeAd
                                failed = false
                            } else {
                                nativeAd.destroy()
                            }
                        }
                    }

                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        android.util.Log.w("BaatlyAds", "Native ad failed for $adUnitId: ${adError.message}")
                        Handler(Looper.getMainLooper()).post { if (isActive) failed = true }
                    }
                })
            } catch (t: Throwable) {
                android.util.Log.w("BaatlyAds", "Native ad request failed for $adUnitId: ${t.message}")
                failed = true
            }
        }
        onDispose {
            isActive = false
            ownedAd?.destroy()
            if (loadedAd === ownedAd) loadedAd = null
        }
    }

    val ad = loadedAd
    if (ad != null && !failed) {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shape = RoundedCornerShape(13.dp),
            color = androidx.compose.ui.graphics.Color(0xFF18152D),
            border = androidx.compose.foundation.BorderStroke(1.dp, androidx.compose.ui.graphics.Color(0xFF3E365F))
        ) {
            key(ad) {
                AndroidView(
                    modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp, max = 116.dp),
                    factory = { ctx -> createCompactNativeAdView(ctx, ad) }
                )
            }
        }
    }
}

private fun createCompactNativeAdView(context: Context, ad: NativeAd): NativeAdView {
    val root = NativeAdView(context).apply {
        setBackgroundColor(AndroidColor.rgb(24, 21, 45))
        setPadding(dp(context, 9), dp(context, 7), dp(context, 9), dp(context, 7))
    }
    val container = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val attributionRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val attribution = TextView(context).apply {
        text = "Ad"
        setTextColor(AndroidColor.rgb(255, 204, 96))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        typeface = Typeface.DEFAULT_BOLD
    }
    val advertiser = TextView(context).apply {
        text = ad.advertiser.orEmpty()
        setTextColor(AndroidColor.rgb(166, 160, 190))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(dp(context, 7), 0, 0, 0)
    }
    attributionRow.addView(attribution, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    attributionRow.addView(advertiser, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

    val contentRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val mediaView = MediaView(context).apply {
        imageScaleType = ImageView.ScaleType.CENTER_CROP
        visibility = if (ad.mediaContent.aspectRatio > 0f) View.VISIBLE else View.GONE
        layoutParams = LinearLayout.LayoutParams(dp(context, 62), dp(context, 62)).apply { rightMargin = dp(context, 9) }
    }
    val iconView = ImageView(context).apply {
        setImageDrawable(ad.icon?.drawable)
        visibility = if (ad.mediaContent.aspectRatio <= 0f && ad.icon?.drawable != null) View.VISIBLE else View.GONE
        scaleType = ImageView.ScaleType.CENTER_CROP
        layoutParams = LinearLayout.LayoutParams(dp(context, 42), dp(context, 42)).apply { rightMargin = dp(context, 9) }
    }
    val textColumn = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val headline = TextView(context).apply {
        text = ad.headline.orEmpty()
        setTextColor(AndroidColor.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        typeface = Typeface.DEFAULT_BOLD
        maxLines = 2
        ellipsize = android.text.TextUtils.TruncateAt.END
    }
    val body = TextView(context).apply {
        text = ad.body.orEmpty()
        setTextColor(AndroidColor.rgb(204, 200, 219))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        maxLines = 2
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(0, dp(context, 2), 0, 0)
    }
    val cta = TextView(context).apply {
        text = ad.callToAction.orEmpty()
        setTextColor(AndroidColor.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(context, 9), dp(context, 5), dp(context, 9), dp(context, 5))
        setBackgroundColor(AndroidColor.rgb(112, 61, 183))
        visibility = if (ad.callToAction.isNullOrBlank()) View.GONE else View.VISIBLE
        setPadding(dp(context, 10), dp(context, 5), dp(context, 10), dp(context, 5))
    }

    textColumn.addView(headline)
    if (ad.body?.isNotBlank() == true) textColumn.addView(body)
    if (!ad.callToAction.isNullOrBlank()) {
        textColumn.addView(cta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 4) })
    }
    if (mediaView.visibility == View.VISIBLE) contentRow.addView(mediaView)
    else if (iconView.visibility == View.VISIBLE) contentRow.addView(iconView)
    contentRow.addView(textColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    container.addView(attributionRow)
    container.addView(contentRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 3) })
    root.addView(container, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

    root.headlineView = headline
    root.iconView = iconView
    root.bodyView = body
    root.advertiserView = advertiser
    root.callToActionView = cta
    root.registerNativeAd(ad, mediaView)
    return root
}

private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
