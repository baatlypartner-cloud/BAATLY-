# BAATLY Super AI Web Search Fix — Worker v1.7.1

## What was wrong

The app did call the `web_search` tool, but the Worker relied on scraping a couple of search engine HTML pages. Bot blocks and changing markup could produce an empty result array. The agent then paraphrased that empty result as “no information found,” which was a false conclusion. The separate `/v1/web/search` route also had a DuckDuckGo-only parser, so it was less resilient than the agent route.

## Changes deployed

- Extended the search provider chain: DuckDuckGo HTML, Bing HTML, Google web results, Google News RSS (English/India), and Google News RSS (Hindi/India).
- Added flexible Google-result and RSS parsing while retaining URL safety checks.
- For Manoj/Bubli + Karora queries, adds spelling/query variants including “Manoj Babli” and a 2007 case variant.
- Routed the authenticated `/v1/web/search` endpoint through the same shared provider chain instead of a separate DDG-only parser.
- Marked a tool search as successful only when a non-empty results array is returned.
- If all search providers fail, the agent now gives a transparent service-failure response; it must not say that no information exists.
- Updated `cloudflare/baatly-ai-gateway/index.js` in this source bundle to Worker version 1.7.1.

## Live status and test limitation

Cloudflare confirmed a successful upload/deployment of Worker `baatly-ai-gateway` version 1.7.1. The Worker source passes `node --check` locally. This editing environment cannot resolve public DNS (`curl` to Google News, Bing, and DuckDuckGo fails with `Could not resolve host`), so provider fetches could not be exercised from this environment. Please validate from the installed BAATLY app after the live deployment.

## Expected behavior

When source results are returned, Super AI should summarize them and include source names/links. If the providers are unavailable or blocked, Super AI should say the search service could not retrieve results and invite a retry; it should not pretend it proved that no web information exists.
