# BAATLY Cloudflare AI Gateway

This Worker is deployed in the connected Cloudflare account as `baatly-ai-gateway` at `https://baatly-ai-gateway.baatly-ai.workers.dev`. Live Worker version at the time of this bundle: **1.6.4**.

## Runtime bindings

- `AI`: Cloudflare Workers AI binding.
- `BAATLY_MEDIA`: existing R2 bucket `baatly-media` for private user files, conversation archives, selected memory facts, generated images, and project workspaces.
- `SUPABASE_URL`: `https://qewhxsbrnlgunygghpez.supabase.co`.
- `SUPABASE_ANON_KEY`: the project's public Supabase publishable key, configured as a plain-text Worker binding in the live deployment.

All user routes require a valid Supabase access token in `Authorization: Bearer <access-token>`. No Agora Conversational AI endpoint or service token is configured in this Worker. The Worker does not contain the Supabase service-role key.

## Deployed endpoints

| Route | Purpose |
|---|---|
| `GET /health` | Worker, model, binding and version metadata; not an end-to-end authentication test. |
| `POST /v1/agent/chat` | Super AI agent chat; the model chooses between `web_search`, `web_read`, and explicit `save_memory` tools. Saves conversation turns to R2. |
| `POST /v1/chat/completions` | Standard chat completions for the AI Host Edge Functions; supports streamed output. |
| `POST /v1/chat/vision` | Prompt + image analysis using Llama 4 Scout; saves conversation turns to R2. |
| `POST /v1/audio/transcriptions` | Cloudflare Whisper Large v3 Turbo speech-to-text. |
| `POST /v1/images/generations` | Native Workers AI FLUX image generation; stores generated PNGs in R2. |
| `POST /v1/video/generations` | Video-generation request via the Cloudflare AI Gateway provider catalog. This route needs prepaid AI Gateway credits/model access; current account balance was $0 during audit. No credit top-up was made. |
| `POST /v1/astrology/readings` | Astrology-style interpretive/entertainment reading; it does not calculate exact astronomical charts. |
| `POST /v1/web/search` | Authenticated web search (also callable by the agent tool router). |
| `POST /v1/web/read` | Authenticated HTML/text page reader; redirects are rejected to reduce SSRF risk. |
| `GET/POST /v1/memory` | Private R2 memory facts, with basic secret/sensitive-data filtering. |
| `GET /v1/conversations` | List the current user's archived conversations. |
| `GET /v1/conversations/messages?conversation_id=...` | Retrieve a conversation archive owned by the current user. |
| `POST /v1/attachments` | Store an attachment in the current user's R2 prefix. Current limit: 5 MB per attachment. |
| `GET/POST /v1/workspaces` | Create/list persistent project workspaces in R2. |
| `GET/POST /v1/workspaces/files` | List/upload source files while preserving relative paths. |
| `GET /v1/workspaces/file?object_key=...` / `PUT /v1/workspaces/file` | Download or update a file within the current user's workspace prefix. |
| `POST /v1/workspaces/file/read` | Read a text source file from a saved workspace. |
| `POST /v1/workspaces/ask` | Ask AI to edit saved text source files; prior versions are copied to R2 before overwriting. |
| `POST /v1/workspaces/preview/html` | Build an in-app static HTML preview from a saved `index.html`, inlining supported local CSS/JS/images. It does not run npm/Vite/React builds. |

## Billing and safety notes

- Cloudflare AI Gateway rate limiting is set to 30 requests/minute; gateway log collection is off.
- A $2/24-hour spend limit is configured for AI Gateway traffic. This does **not** cap native `env.AI.run()` Workers AI calls that bypass the AI Gateway. Review normal Workers AI account usage separately.
- External video generation is not end-to-end tested because the AI Gateway prepaid balance was $0. Do not assume video generation will succeed until the account has credits and model access.
- The Support Agent Edge Functions `partner-ai-chat` and `partner-ai-chat-v2` intentionally remain on Groq.
- Sarvam remains in the AI audio speech path for Hindi/realtime STT and TTS. AI audio calls use the Supabase WebSocket plus Cloudflare LLM pipeline and do not start Agora Conversational AI agents. Normal non-AI user/partner Agora RTC calling is unchanged.
- Static HTML preview is available inside the app with local resources inlined and external navigation/network blocked. This Worker does not yet provide an isolated arbitrary-code execution sandbox, live npm/Vite/React web-app preview server, Android emulator, Gradle build runner or APK packaging. The app saves/edits sources and downloads ZIPs. An APK build must remain opt-in and requires a secure sandbox runner before it can be enabled.
- Web search/page reads can fail due to provider access or a site's bot/redirect controls. Tool output reports failure rather than pretending the content was fetched.

## Local deployment

1. Install Node.js and Wrangler, then run `npx wrangler login`.
2. Configure the `SUPABASE_ANON_KEY` Worker secret.
3. Run `npx wrangler deploy`.
4. Test `GET /health`, then authenticated text chat, image understanding, R2 workspace upload/read/export, web tools, and provider-dependent image/video routes.

Do not add service-role keys, Agora private tokens or provider secrets to Android resources, Git, ZIP manifests, or report files.


## Conversation response guard (v1.6.4)

The `/v1/agent/chat` endpoint responds to simple greetings with ordinary chat inference (without tool selection), adds an explicit user-facing response contract, and detects/retries internal tool-routing commentary before returning a response. This prevents the model from showing text such as “I do not have a specific function to call” to users.


## Natural-language photo editing from Super AI

Authenticated endpoint: `POST /v1/images/edits`

Body JSON fields: `prompt`, `image_base64`, optional `mime_type`, `width`, `height`, and `conversation_id`. The Android chat detects common English/Roman-Hindi editing requests when a photo is attached, scales the input image to below 512x512 (required for FLUX.2 Klein reference inputs), sends it to the backend, and renders the returned edited image with a Save image action. Source and edited image objects are stored in the user's private R2 prefix.

Model: `@cf/black-forest-labs/flux-2-klein-4b` via the native Workers AI binding. This is an image-to-image model, unlike the existing FLUX.1 Schnell text-to-image generator. See Cloudflare's model docs: https://developers.cloudflare.com/workers-ai/models/flux-2-klein-4b/
