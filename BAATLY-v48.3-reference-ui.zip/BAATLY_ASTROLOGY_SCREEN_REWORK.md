# BAATLY Astrology Screen Rework

## What changed

- Replaced the previous astrology/horoscope screen with a focused screen containing only:
  1. **Kundli Banaye** — asks for name, birth date, birth time and place, then shows the generated report.
  2. **Online AI Astrologers** — fetched dynamically from the dedicated `public.ai_astrologers` registry. Only rows with `is_active = true` and `is_online = true` are shown. Each row has **Chat Now**.
- Added a dedicated `AiAstrologerService` Android client for the `ai-astrologer` Supabase Edge Function.
- Chat history and messages are stored separately in `ai_astrologer_conversations` and `ai_astrologer_messages`.
- Seeded **Pandit Ji** in `public.ai_astrologers`. The accidentally-added `pandit-ji` row was removed from `public.ai_hosts`; Meera remains in the companion/host registry.
- Reworked `ai-chat` to remain companion-only and deployed as version 47.
- Deployed the separate `ai-astrologer` Edge Function (version 4) with actions `list`, `history`, `chat` and `kundli`.
- Astrologer chat currently reuses BAATLY's existing ₹2-per-message wallet charge/refund RPC. Failed AI provider calls trigger a refund.
- Kundli calculation uses the public endpoint `https://panchang.tantragurukul.org/v1/vedic/kundali` and asks the AI only to interpret the returned chart fields; it must not invent missing planetary positions. Reports are saved to `public.ai_kundli_reports`. A per-user limit of 5 Kundli reports in 24 hours is applied.
- The screen tells users that their birth details are sent to the calculation service and that the generated report is saved to their BAATLY account.

## Verification / limitations

- Confirmed in Supabase that `Pandit Ji` exists as an active/online row in `public.ai_astrologers` and does not exist in `public.ai_hosts`.
- Confirmed the four new tables exist and the `ai-astrologer` Edge Function deployed successfully at version 4.
- Cloudflare Worker source syntax check passed and the base ZIP archive is verified before repackaging.
- Android Gradle compilation could not run because this environment cannot resolve `services.gradle.org` while trying to download Gradle 9.3.1 (`UnknownHostException`). Thus the updated Kotlin source has **not** been proven by a successful APK build in this environment.
- The external Kundli calculation endpoint could not be live-invoked from this environment. Runtime connectivity and the provider's current response schema still need an authenticated app/device test. The backend returns an explicit error if the provider is unavailable or returns an error payload; it does not silently fabricate a chart.
