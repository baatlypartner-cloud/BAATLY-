# BAATLY v47 — Locked redesign and Roleplay integration

## Applied from the 15 supplied visual references
- Switched the shared app palette and Material scheme to the neon-night navy / violet / pink system used by the locked screens.
- Updated Social feed/profile/Reels, Relationship discovery, Entertainment, Messages and search presentation.
- Search stays a light surface as shown in the supplied Search BAATLY reference; Creator Studio media editor keeps its light story-editor canvas.
- Reels now suppresses the Social header and bottom navigation while active, uses the existing vertical pager/player, and Android Back returns to Feeds.
- Existing Supabase-backed catalogue, feed, reels, profile, stories, hashtags, messages, wallets and discovery actions remain connected. No demo catalogue/creator/chat records were inserted.

## Roleplay feature
- Added Relationship > Roleplay entry.
- Added a Roleplay screen with Characters and Chats tabs, character cards from the live `ai_roleplay_characters` table, stored conversation history, and live message composer.
- Wired through the existing authenticated `ai-roleplay-chat` Supabase Edge Function using the signed-in Supabase session.
- Uses the configured Aion Labs provider/model in Supabase; no local mock reply or seeded character content was added.

## Build verification
- Tried `./gradlew :app:compileDebugKotlin --no-daemon`. The environment could not resolve `services.gradle.org` (UnknownHostException), so the Gradle distribution could not be downloaded and a compile result could not be produced here.
- Source files and routing were manually inspected after edits. Run the build in Android Studio or a network-enabled CI runner before release.
