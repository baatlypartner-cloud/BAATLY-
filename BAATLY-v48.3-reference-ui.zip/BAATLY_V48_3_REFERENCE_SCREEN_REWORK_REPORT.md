# BAATLY v48.3 — Reference Screen UI Rework

This update applies the nine supplied BAATLY screen references to the existing Android source project. It is a source-project update, not a compiled APK.

## Screens and flows covered

1. **Social Feeds** — dark navy surface, pink/purple accents, BAATLY header, Feeds/Reels switch, For You/Following/Personalized controls, live story row, live trending hashtags, Camera/Video/Create Post entry cards, feed cards and the four primary Like/Comment/Share/Save actions.
2. **Reels** — full-screen vertical reel pager, Back to Feeds, Reels/Feeds switch, search, right-rail interactions, creator identity and Follow action. The normal bottom navigation remains visible as in the reference.
3. **Creator Studio / Story Editor** — light pink/white editor, selected-media preview, editor mode, look categories, filter cards, strength slider, text overlay, caption/hashtags and media-specific editing controls. Filter thumbnails are generated from the user's selected media rather than sample photos.
4. **Create Story** — photo gallery, video gallery, camera capture and Create with AI entry points.
5. **Super AI home** — dark AI landing screen, image/video/code/file/workspace entry points, quick tools, prompt shortcuts and history/projects backed by the existing service.
6. **Image Generator** — prompt, reference image, generation modes, style selection, aspect/quality/count/model settings, actual generation and current-session creations.
7. **Android App Builder** — ZIP upload, project workspace, source file browsing/editing, project chat and ZIP export using the existing Cloudflare workspace routes.
8. **Web App Builder** — same workspace capabilities with a restricted static HTML preview where supported.
9. **Video Generator** — text-to-video form with duration, aspect ratio, resolution and style controls, generation and current-session video results.

## Data integrity and existing integrations

- Feed posts, reel items, stories, creator details, engagement counts, hashtags, comments, follows and music-library entries continue to come from the existing BAATLY/Supabase data flows. The reference screenshot's sample names, counters, sample photographs and sample posts are not inserted as app data.
- Like, comment, follow and publishing actions remain connected to the existing social flows.
- Share opens Android's native share sheet with the real post text and resolved media URL when available.
- Saved posts use account-scoped local persistence. They are not represented as server-synced bookmarks; server bookmark sync would require a dedicated backend contract.
- The editor uses the user's chosen photo/video for the preview and preset thumbnails. It does not populate fake photo assets.
- AI generation and workspace operations use the existing Cloudflare Worker endpoints in the project. The app reports persistence only when the API response confirms it.

## Explicitly unavailable capabilities

Some controls shown in the reference depend on services that the current worker does not expose. They are visibly disabled or return a clear availability message rather than pretending to work:

- Video reference-image/video input, multi-scene storyboard, camera-motion controls, generated audio, and negative-prompt/seed controls are not supported by the current `/v1/video/generations` contract. Text-to-video with prompt, duration, resolution and aspect ratio is supported by the current contract.
- Remove Background is not available as a dedicated operation from the current image worker contract.
- Previous-generation library listing is not exposed by the current API. Image/video creations shown in the AI screen are the actual results generated during the current screen session.
- Screen sharing and video calling are not connected. The BAATLY calling implementation is audio-only; these options therefore show an unavailable state rather than starting a fake session.
- Android workspace supports real source ZIP upload, file inspection/editing and ZIP export. This repository does not include an isolated Gradle/Android SDK build runner or emulator, so the Android workspace cannot truthfully claim to compile or run an APK.
- Web preview is restricted to safe static HTML. A React/Vite/npm build requires a sandbox runner that is not configured in this project.

## Validation performed

- Checked the edited Kotlin files for Compose icon/import consistency; full Kotlin type-checking requires the Android/Compose dependency classpath. A fresh parser-only compiler run timed out in this environment, so parser validation is not claimed.
- Parsed the project's XML resources, JSON resources/configuration files and Gradle version catalog.
- Checked that referenced Compose icons have corresponding imports in the edited screens.
- Verified the source ZIP archive structure and contents after packaging.
- Attempted the Gradle compile task, but Gradle 9.3.1 could not be downloaded because this environment could not resolve `services.gradle.org`; no local Android SDK was configured. Therefore a successful Android build is **not verified** and no APK is included.
