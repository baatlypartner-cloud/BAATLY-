import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const out = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
const str = (value: unknown) => typeof value === "string" ? value.trim() : "";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return out({ error: "Method not allowed" }, 405);

  try {
    const authorization = req.headers.get("Authorization") || "";
    if (!authorization.startsWith("Bearer ")) return out({ error: "Missing authorization" }, 401);
    const jwt = authorization.slice(7).trim();

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    if (!supabaseUrl || !serviceRoleKey || !anonKey) {
      return out({ error: "Server configuration is incomplete" }, 500);
    }

    const adminDb = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const userDb = createClient(supabaseUrl, anonKey, {
      auth: { autoRefreshToken: false, persistSession: false },
      global: { headers: { Authorization: "Bearer " + jwt } },
    });

    const { data: authData, error: authError } = await adminDb.auth.getUser(jwt);
    if (authError || !authData.user) return out({ error: "Invalid authentication" }, 401);

    const body = await req.json().catch(() => ({}));
    const hostId = str(body?.host_id);
    if (!hostId) return out({ error: "host_id is required" }, 400);

    const { data: host, error: hostError } = await adminDb
      .from("ai_hosts")
      .select("id,name,voice_id,language,is_active,is_demo")
      .eq("id", hostId)
      .eq("is_active", true)
      .eq("is_demo", true)
      .maybeSingle();
    if (hostError) throw hostError;
    if (!host) return out({ error: "AI host not available" }, 404);

    // Direct Supabase WebSocket + Sarvam speech + Cloudflare LLM; no Agora AI agent is created.
    const { data: sessionId, error: reserveError } = await userDb.rpc("reserve_ai_audio_call", {
      p_ai_host_id: hostId,
      p_rate: 5,
    });
    if (reserveError || !sessionId) {
      return out({ error: reserveError?.message || "Unable to reserve AI audio call" }, 409);
    }

    const sid = String(sessionId);
    const websocketUrl = supabaseUrl.replace(/^https:/i, "wss:").replace(/^http:/i, "ws:")
      + "/functions/v1/ai-voice-stream?session_id=" + encodeURIComponent(sid);
    const now = new Date().toISOString();
    const { data: savedSession, error: updateError } = await adminDb
      .from("ai_call_sessions")
      .update({
        provider: "cloudflare_sarvam_websocket",
        provider_session_id: null,
        provider_conversation_url: websocketUrl,
        agora_channel_id: null,
        agora_user_uid: null,
        agora_agent_uid: null,
        started_at: now,
        updated_at: now,
        error_message: null,
      })
      .eq("id", sid)
      .eq("user_id", authData.user.id)
      .select("reserved_call_rupees,max_duration_seconds")
      .maybeSingle();

    if (updateError || !savedSession) {
      await userDb.rpc("release_ai_audio_call_reservation", {
        p_session_id: sid,
        p_final_status: "failed",
        p_reason: "AI audio session could not be saved",
      });
      return out({ error: "AI audio session could not be saved" }, 500);
    }

    return out({
      success: true,
      session_id: sid,
      host_id: host.id,
      host_name: host.name,
      provider: "cloudflare_sarvam_websocket",
      stream_url: websocketUrl,
      stream_auth: "Send the user's Supabase access token as Authorization: Bearer <token>",
      status: "active",
      billing_status: "reserved",
      rate_rupees_per_minute: 5,
      reserved_call_rupees: Number(savedSession.reserved_call_rupees || 0),
      max_duration_seconds: Number(savedSession.max_duration_seconds || 0),
      transport: "direct_websocket",
      ai_pipeline: {
        stt: "sarvam_saaras_v3_realtime",
        llm: "@cf/meta/llama-3.3-70b-instruct-fp8-fast",
        tts: "sarvam_bulbul_v3_streaming",
      },
    });
  } catch (error) {
    console.error("ai-call-start", error);
    return out({ error: "Unexpected server error" }, 500);
  }
});
