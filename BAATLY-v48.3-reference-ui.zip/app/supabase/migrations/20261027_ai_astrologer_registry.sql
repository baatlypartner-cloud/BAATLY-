-- Keep AI astrologers separate from AI companion hosts (for example, Meera).
create table if not exists public.ai_astrologers (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  display_name text not null,
  avatar_url text,
  intro text not null default '',
  language text not null default 'hi-Hinglish',
  personality text not null default '',
  conversation_style text not null default '',
  system_instructions text not null default '',
  is_online boolean not null default false,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ai_astrologer_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  astrologer_id uuid not null references public.ai_astrologers(id) on delete restrict,
  status text not null default 'active' check (status in ('active','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ai_astrologer_conversations_user_idx
  on public.ai_astrologer_conversations(user_id, updated_at desc);
create index if not exists ai_astrologer_conversations_astrologer_idx
  on public.ai_astrologer_conversations(astrologer_id, updated_at desc);

create table if not exists public.ai_astrologer_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.ai_astrologer_conversations(id) on delete cascade,
  sender_type text not null check (sender_type in ('user','astrologer')),
  content text not null,
  sequence_no integer not null check (sequence_no > 0),
  created_at timestamptz not null default now(),
  unique (conversation_id, sequence_no)
);
create index if not exists ai_astrologer_messages_conversation_idx
  on public.ai_astrologer_messages(conversation_id, sequence_no);

create table if not exists public.ai_kundli_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  full_name text not null,
  birth_date date not null,
  birth_time time not null,
  birth_place text not null,
  timezone text not null default 'Asia/Kolkata',
  chart_data jsonb not null default '{}'::jsonb,
  interpretation text not null default '',
  calculation_provider text not null default 'interpretive-ai-only',
  created_at timestamptz not null default now()
);
create index if not exists ai_kundli_reports_user_idx
  on public.ai_kundli_reports(user_id, created_at desc);

alter table public.ai_astrologers enable row level security;
alter table public.ai_astrologer_conversations enable row level security;
alter table public.ai_astrologer_messages enable row level security;
alter table public.ai_kundli_reports enable row level security;

drop policy if exists "active online astrologers readable" on public.ai_astrologers;
create policy "active online astrologers readable"
  on public.ai_astrologers for select to authenticated
  using (is_active = true and is_online = true);

drop policy if exists "users read own astrologer conversations" on public.ai_astrologer_conversations;
create policy "users read own astrologer conversations"
  on public.ai_astrologer_conversations for select to authenticated
  using (auth.uid() = user_id);

drop policy if exists "users read own astrologer messages" on public.ai_astrologer_messages;
create policy "users read own astrologer messages"
  on public.ai_astrologer_messages for select to authenticated
  using (exists (
    select 1 from public.ai_astrologer_conversations c
    where c.id = ai_astrologer_messages.conversation_id
      and c.user_id = auth.uid()
  ));

drop policy if exists "users read own kundli reports" on public.ai_kundli_reports;
create policy "users read own kundli reports"
  on public.ai_kundli_reports for select to authenticated
  using (auth.uid() = user_id);

-- Do not keep Pandit Ji in the companion/host registry.
delete from public.ai_hosts where slug = 'pandit-ji';
alter table public.ai_hosts
  drop constraint if exists ai_hosts_host_category_check;
alter table public.ai_hosts
  drop column if exists host_category,
  drop column if exists is_online;

insert into public.ai_astrologers (
  slug, display_name, avatar_url, intro, language, personality, conversation_style,
  system_instructions, is_online, is_active, sort_order
) values (
  'pandit-ji', 'Pandit Ji', null,
  'AI Vedic astrologer • Janam kundli, grah-nakshatra aur jeevan ke sawalon par shaant, sammanjanak margdarshan.',
  'hi-Hinglish',
  'Shaant, samajhdaar, vinamra, dhairya se sunne wale traditional-style Vedic AI astrologer. Roman Hindi mein natural baat karte hain.',
  'Warm and respectful Roman Hindi / Roman Hinglish. Ask relevant follow-up questions if birth details are missing. Explain traditional astrology in plain language.',
  'IDENTITY: You are Pandit Ji, BAATLY AI astrologer. Be transparent that you are an AI assistant, not a human priest.\nPERSONA: Calm, respectful, thoughtful, patient and kind. Speak naturally in Roman Hindi / Roman Hinglish by default. Address the user respectfully as aap. Do not sound like a customer-service bot.\nSCOPE: Help users understand traditional Vedic astrology concepts, kundli terminology, zodiac signs, houses, planets, nakshatras, muhurat and reflective interpretations. Ask for missing relevant details instead of guessing.\nHONESTY: Distinguish traditional beliefs from scientifically established facts. Do not invent exact chart placements unless verified calculation data is supplied. Avoid fearmongering, deterministic predictions and expensive-remedy pressure. Do not make medical, legal or financial decisions for users.\nLANGUAGE: Natural Roman Hindi/Hinglish. Keep answers conversational and helpful, not overly formal.\nSAFETY: Never ask for passwords, payment credentials or outside contact details. Never manipulate the user into paying or continuing chat.',
  true, true, 1
)
on conflict (slug) do update set
  display_name = excluded.display_name,
  avatar_url = excluded.avatar_url,
  intro = excluded.intro,
  language = excluded.language,
  personality = excluded.personality,
  conversation_style = excluded.conversation_style,
  system_instructions = excluded.system_instructions,
  is_online = excluded.is_online,
  is_active = excluded.is_active,
  sort_order = excluded.sort_order,
  updated_at = now();
