package com.example.ui.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BaatlyFilterCatalogTest {
    @Test fun catalogHasUniqueNamesAndOriginalPreset() {
        val names = BaatlyFilterCatalog.presets.map { it.name }
        assertEquals(names.size, names.toSet().size)
        assertTrue(names.size >= 25)
        assertEquals("Original", BaatlyFilterCatalog.get("Original").name)
        assertEquals("", BaatlyFilterCatalog.get("Original").cgeRule)
    }

    @Test fun filterCategoriesArePopulated() {
        BaatlyFilterCatalog.categories.filter { it != "All" }.forEach { category ->
            assertFalse("Category $category should contain filters", BaatlyFilterCatalog.visible(category).isEmpty())
        }
    }

    @Test fun videoListExcludesPhotoOnlyArtisticEffects() {
        val videoNames = BaatlyFilterCatalog.visible("All", videoOnly = true).map { it.name }.toSet()
        assertTrue("Cinematic should be usable on video", "Cinematic" in videoNames)
        assertFalse("Sketch is currently a photo-only GPU preset", "Sketch" in videoNames)
    }

    @Test fun unknownPresetFallsBackToOriginal() {
        assertNotNull(BaatlyFilterCatalog.get("not-a-real-filter"))
        assertEquals("Original", BaatlyFilterCatalog.get("not-a-real-filter").name)
    }
}
