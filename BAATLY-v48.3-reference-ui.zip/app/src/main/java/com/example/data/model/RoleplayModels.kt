package com.example.data.model

data class RoleplayCharacter(
    val id: String, val slug: String, val name: String, val fullName: String = "",
    val tagline: String = "", val bio: String = "", val greeting: String = "",
    val ageYears: Int = 0, val gender: String = "", val hometown: String = "",
    val occupation: String = "", val interests: List<String> = emptyList(),
    val avatarUrl: String? = null, val model: String = "aion-labs/aion-2.0"
)

data class RoleplayConversation(
    val id: String, val title: String, val status: String, val preview: String = "",
    val updatedAt: String = "", val characterName: String = "", val characterSlug: String = ""
)

data class RoleplayMessage(
    val id: String, val role: String, val content: String, val inputTokens: Int = 0,
    val outputTokens: Int = 0, val createdAt: String = ""
)
