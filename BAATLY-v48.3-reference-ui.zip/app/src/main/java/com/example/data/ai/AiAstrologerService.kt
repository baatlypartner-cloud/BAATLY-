package com.example.data.ai

import com.example.data.local.SessionManager
import com.example.data.network.SupabaseConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class AiAstrologer(
    val id: String,
    val slug: String,
    val displayName: String,
    val avatarUrl: String?,
    val intro: String,
    val language: String,
    val isOnline: Boolean
)

data class AiAstrologerMessage(
    val id: String,
    val senderType: String,
    val content: String,
    val createdAt: String = ""
)

data class AiAstrologerHistory(
    val conversationId: String?,
    val messages: List<AiAstrologerMessage>
)

data class AiAstrologerReply(
    val conversationId: String,
    val displayName: String,
    val reply: String,
    val chargeRupees: Double
)

data class KundliReport(
    val reportId: String,
    val fullName: String,
    val birthDate: String,
    val birthTime: String,
    val birthPlace: String,
    val interpretation: String,
    val chartData: JSONObject
)

/** Authenticated client for BAATLY's separate AI astrologer backend. */
class AiAstrologerService(private val sessionManager: SessionManager) {
    private val endpoint = SupabaseConfig.supabaseUrl.trimEnd('/') + "/functions/v1/ai-astrologer"
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .callTimeout(240, TimeUnit.SECONDS)
        .build()

    private suspend fun postAction(body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val token = sessionManager.accessToken.value?.takeIf { it.isNotBlank() }
            ?: throw IOException("Please sign in to use Astrology.")
        val request = Request.Builder()
            .url(endpoint)
            .header("Authorization", "Bearer $token")
            .header("apikey", SupabaseConfig.publishableKey)
            .header("Accept", "application/json")
            .post(body.toString().toRequestBody(jsonType))
            .build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val payload = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (!response.isSuccessful) {
                val message = payload.optString("error").takeIf { it.isNotBlank() }
                    ?: "Astrology request failed (${response.code})."
                throw IOException(message)
            }
            payload
        }
    }

    suspend fun listOnlineAstrologers(): List<AiAstrologer> {
        val response = postAction(JSONObject().put("action", "list"))
        val array = response.optJSONArray("astrologers") ?: JSONArray()
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val id = item.optString("id").takeIf { it.isNotBlank() && it != "null" } ?: continue
                add(
                    AiAstrologer(
                        id = id,
                        slug = item.optString("slug"),
                        displayName = item.optString("display_name").ifBlank { "AI Astrologer" },
                        avatarUrl = item.optString("avatar_url").takeIf { it.isNotBlank() && it != "null" },
                        intro = item.optString("intro"),
                        language = item.optString("language", "hi-Hinglish"),
                        isOnline = item.optBoolean("is_online", false)
                    )
                )
            }
        }
    }

    suspend fun loadHistory(astrologerId: String): AiAstrologerHistory {
        val response = postAction(JSONObject().put("action", "history").put("astrologer_id", astrologerId))
        val array = response.optJSONArray("messages") ?: JSONArray()
        val messages = buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                add(
                    AiAstrologerMessage(
                        id = item.optString("id", index.toString()),
                        senderType = item.optString("sender_type", "user"),
                        content = item.optString("content"),
                        createdAt = item.optString("created_at")
                    )
                )
            }
        }
        return AiAstrologerHistory(response.optString("conversation_id").takeIf { it.isNotBlank() && it != "null" }, messages)
    }

    suspend fun sendMessage(astrologerId: String, conversationId: String?, message: String): AiAstrologerReply {
        val body = JSONObject()
            .put("action", "chat")
            .put("astrologer_id", astrologerId)
            .put("message", message)
        conversationId?.takeIf { it.isNotBlank() }?.let { body.put("conversation_id", it) }
        val response = postAction(body)
        return AiAstrologerReply(
            conversationId = response.optString("conversation_id"),
            displayName = response.optString("display_name", "Pandit Ji"),
            reply = response.optString("reply").ifBlank { "Maaf kijiye, abhi jawab nahi mil paya. Dobara try karein." },
            chargeRupees = response.optDouble("charge_rupees", 2.0)
        )
    }

    suspend fun generateKundli(
        fullName: String,
        birthDate: String,
        birthTime: String,
        birthPlace: String
    ): KundliReport {
        val response = postAction(
            JSONObject()
                .put("action", "kundli")
                .put("full_name", fullName.trim())
                .put("birth_date", birthDate.trim())
                .put("birth_time", birthTime.trim())
                .put("birth_place", birthPlace.trim())
        )
        return KundliReport(
            reportId = response.optString("report_id"),
            fullName = response.optString("full_name", fullName),
            birthDate = response.optString("birth_date", birthDate),
            birthTime = response.optString("birth_time", birthTime),
            birthPlace = response.optString("birth_place", birthPlace),
            interpretation = response.optString("interpretation").ifBlank { "Kundli report abhi available nahi hai." },
            chartData = response.optJSONObject("chart_data") ?: JSONObject()
        )
    }
}
