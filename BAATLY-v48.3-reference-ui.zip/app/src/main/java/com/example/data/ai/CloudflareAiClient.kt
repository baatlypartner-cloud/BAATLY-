package com.example.data.ai

import com.example.data.local.SessionManager
import com.example.data.network.SupabaseConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Authenticated client for BAATLY's Cloudflare Worker. Never put provider secrets in the Android app. */
class CloudflareAiClient(private val sessionManager: SessionManager) {
    private val baseUrl = "https://baatly-ai-gateway.baatly-ai.workers.dev"
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .callTimeout(240, TimeUnit.SECONDS)
        .build()

    suspend fun post(path: String, body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val token = sessionManager.accessToken.value?.takeIf { it.isNotBlank() }
            ?: throw IOException("Please sign in to use Super AI.")
        val request = Request.Builder()
            .url(baseUrl + path)
            .header("Authorization", "Bearer $token")
            .header("apikey", SupabaseConfig.publishableKey)
            .header("Accept", "application/json")
            .post(body.toString().toRequestBody(jsonType))
            .build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = try { JSONObject(text).optString("error").ifBlank { "Request failed (${response.code})." } }
                catch (_: Exception) { "Request failed (${response.code})." }
                throw IOException(message)
            }
            JSONObject(text)
        }
    }

    suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        val token = sessionManager.accessToken.value?.takeIf { it.isNotBlank() }
            ?: throw IOException("Please sign in to use Super AI.")
        val request = Request.Builder()
            .url(baseUrl + path)
            .header("Authorization", "Bearer $token")
            .header("apikey", SupabaseConfig.publishableKey)
            .header("Accept", "application/json")
            .get()
            .build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = try { JSONObject(text).optString("error").ifBlank { "Request failed (${response.code})." } }
                catch (_: Exception) { "Request failed (${response.code})." }
                throw IOException(message)
            }
            JSONObject(text)
        }
    }

    suspend fun getBytes(path: String): ByteArray = withContext(Dispatchers.IO) {
        val token = sessionManager.accessToken.value?.takeIf { it.isNotBlank() }
            ?: throw IOException("Please sign in to use Super AI.")
        val request = Request.Builder()
            .url(baseUrl + path)
            .header("Authorization", "Bearer $token")
            .header("apikey", SupabaseConfig.publishableKey)
            .header("Accept", "application/octet-stream")
            .get()
            .build()
        http.newCall(request).execute().use { response ->
            val bytes = response.body?.bytes() ?: byteArrayOf()
            if (!response.isSuccessful) {
                val message = try { JSONObject(bytes.toString(Charsets.UTF_8)).optString("error").ifBlank { "Request failed (${response.code})." } }
                catch (_: Exception) { "Request failed (${response.code})." }
                throw IOException(message)
            }
            bytes
        }
    }

    fun query(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())
}
