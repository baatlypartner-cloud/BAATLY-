package com.example.ui.roleplay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RoleplayCharacter
import com.example.data.model.RoleplayConversation
import com.example.data.model.RoleplayMessage
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

private val RoleplayInk = Color(0xFF09091B)
private val RoleplaySurface = Color(0xFF15152F)
private val RoleplaySurface2 = Color(0xFF211A42)
private val RoleplayMuted = Color(0xFFB8B0D0)

@Composable
fun RoleplayScreen(viewModel: BaatlyViewModel, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var characters by remember { mutableStateOf<List<RoleplayCharacter>>(emptyList()) }
    var conversations by remember { mutableStateOf<List<RoleplayConversation>>(emptyList()) }
    var messages by remember { mutableStateOf<List<RoleplayMessage>>(emptyList()) }
    var selectedCharacter by remember { mutableStateOf<RoleplayCharacter?>(null) }
    var conversationId by remember { mutableStateOf<String?>(null) }
    var draft by remember { mutableStateOf("") }
    var activeTab by remember { mutableStateOf("Characters") }
    var loading by remember { mutableStateOf(true) }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    fun loadHome() {
        loading = true
        error = null
        scope.launch {
            val c = viewModel.dataService.getRoleplayCharacters()
            val h = viewModel.dataService.getRoleplayConversations()
            c.onSuccess { characters = it }.onFailure { error = it.message ?: "Couldn't load Roleplay characters" }
            h.onSuccess { conversations = it }
            loading = false
        }
    }

    LaunchedEffect(Unit) { loadHome() }

    fun openConversation(id: String, character: RoleplayCharacter? = null) {
        loading = true
        error = null
        scope.launch {
            viewModel.dataService.getRoleplayMessages(id).onSuccess { messages = it }.onFailure {
                error = it.message ?: "Couldn't load conversation"
            }
            conversationId = id
            if (character != null) selectedCharacter = character
            loading = false
            activeTab = "Chat"
        }
    }

    fun startChat(character: RoleplayCharacter) {
        if (loading) return
        loading = true
        error = null
        scope.launch {
            viewModel.dataService.startRoleplayConversation(character.slug).onSuccess { (id, returnedCharacter) ->
                selectedCharacter = returnedCharacter
                conversationId = id
                messages = listOf(RoleplayMessage("opening-$id", "assistant", returnedCharacter.greeting))
                activeTab = "Chat"
            }.onFailure { error = it.message ?: "Couldn't start this chat" }
            loading = false
        }
    }

    fun sendMessage() {
        val id = conversationId ?: return
        val text = draft.trim()
        if (text.isBlank() || sending) return
        draft = ""
        sending = true
        val optimistic = RoleplayMessage("pending-${System.nanoTime()}", "user", text)
        messages = messages + optimistic
        scope.launch {
            viewModel.dataService.sendRoleplayMessage(id, text).onSuccess { reply ->
                messages = messages + reply
                conversations = viewModel.dataService.getRoleplayConversations().getOrDefault(conversations)
            }.onFailure { e ->
                messages = messages.filterNot { it.id == optimistic.id }
                draft = text
                error = e.message ?: "Message could not be sent"
            }
            sending = false
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().background(RoleplayInk)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconButton(onClick = { if (activeTab == "Chat") { activeTab = "Characters"; conversationId = null; selectedCharacter = null; messages = emptyList(); loadHome() } else onBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("BAATLY ROLEPLAY", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = .6.sp)
                Text(if (activeTab == "Chat") selectedCharacter?.name ?: "Your conversation" else "Meet a character. Start your story.", color = RoleplayMuted, fontSize = 10.sp)
            }
            if (activeTab != "Chat") {
                IconButton(onClick = { loadHome() }) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh", tint = RoleplayMuted) }
            }
        }

        if (activeTab == "Chat") {
            val character = selectedCharacter
            Surface(color = RoleplaySurface, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    CharacterAvatar(character, Modifier.size(46.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(character?.name ?: "Roleplay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(character?.tagline.orEmpty(), color = RoleplayMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Surface(color = Color(0xFF1F3C36), shape = RoundedCornerShape(14.dp)) {
                        Text("AI CHARACTER", color = Color(0xFF76E2B2), fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                    }
                }
            }
            if (loading && messages.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = VibrantPink) }
            } else {
                LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages, key = { it.id }) { message ->
                        val isUser = message.role == "user"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                            Box(
                                Modifier.widthIn(max = 310.dp).clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (isUser) 18.dp else 5.dp, bottomEnd = if (isUser) 5.dp else 18.dp))
                                    .background(if (isUser) Brush.linearGradient(listOf(Color(0xFFE6009D), Color(0xFF6D39D8))) else Brush.linearGradient(listOf(RoleplaySurface2, RoleplaySurface)))
                                    .padding(horizontal = 14.dp, vertical = 11.dp)
                            ) {
                                Text(message.content, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
                            }
                        }
                    }
                    if (sending) item { Text("Typing…", color = RoleplayMuted, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp)) }
                }
            }
            if (!error.isNullOrBlank()) Text(error.orEmpty(), color = Color(0xFFFF8D9E), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp).clip(RoundedCornerShape(28.dp)).background(RoleplaySurface).border(1.dp, Color(0xFF49366C), RoundedCornerShape(28.dp)).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = draft, onValueChange = { if (it.length <= 4000) draft = it }, modifier = Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), cursorBrush = Brush.verticalGradient(listOf(VibrantPink, PrimaryLavender)), decorationBox = { inner -> Box { if (draft.isBlank()) Text("Message ${character?.name ?: "character"}…", color = RoleplayMuted, fontSize = 14.sp); inner() } })
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { sendMessage() }, enabled = draft.isNotBlank() && !sending, modifier = Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(VibrantPink, PrimaryLavender)))) {
                    if (sending) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clip(RoundedCornerShape(24.dp)).background(RoleplaySurface).padding(4.dp)) {
                listOf("Characters", "Chats").forEach { tab ->
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(if (activeTab == tab) Brush.linearGradient(listOf(VibrantPink, PrimaryLavender)) else Brush.linearGradient(listOf(RoleplaySurface, RoleplaySurface))).clickable { activeTab = tab }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
                        Text(tab, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
            if (loading) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = VibrantPink) }
            } else if (!error.isNullOrBlank() && characters.isEmpty() && conversations.isEmpty()) {
                Column(Modifier.fillMaxWidth().weight(1f).padding(26.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error.orEmpty(), color = RoleplayMuted, textAlign = TextAlign.Center)
                    TextButton(onClick = { loadHome() }) { Text("Try again", color = VibrantPink) }
                }
            } else if (activeTab == "Characters") {
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (characters.isEmpty()) item { EmptyRoleplay("No roleplay characters are published yet.") }
                    items(characters, key = { it.id }) { character ->
                        CharacterCard(character, onClick = { startChat(character) })
                    }
                }
            } else {
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (conversations.isEmpty()) item { EmptyRoleplay("Your roleplay chats will appear here after you start one.") }
                    items(conversations, key = { it.id }) { conversation ->
                        ConversationCard(conversation) {
                            val c = characters.firstOrNull { it.slug == conversation.characterSlug }
                            openConversation(conversation.id, c)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CharacterCard(character: RoleplayCharacter, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(RoleplaySurface).border(1.dp, Color(0xFF3D2D62), RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
        CharacterAvatar(character, Modifier.size(76.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(character.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(character.tagline, color = Color(0xFFE8A8E4), fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(character.bio, color = RoleplayMuted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (character.interests.isNotEmpty()) Text(character.interests.take(3).joinToString(" · "), color = RoleplayMuted, fontSize = 9.sp, maxLines = 1)
        }
        Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF4C1C66)) { Icon(Icons.Filled.ChatBubbleOutline, contentDescription = "Start chat", tint = Color.White, modifier = Modifier.padding(11.dp).size(19.dp)) }
    }
}

@Composable
private fun ConversationCard(conversation: RoleplayConversation, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(RoleplaySurface).border(1.dp, Color(0xFF342950), RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(VibrantPink, PrimaryLavender))), contentAlignment = Alignment.Center) { Icon(Icons.Filled.Favorite, contentDescription = null, tint = Color.White) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(conversation.characterName.ifBlank { conversation.title }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(conversation.preview.ifBlank { "Open conversation" }, color = RoleplayMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("›", color = VibrantPink, fontSize = 28.sp)
    }
}

@Composable
private fun CharacterAvatar(character: RoleplayCharacter?, modifier: Modifier = Modifier) {
    Box(modifier.clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFFFA2EAD), Color(0xFF5638D8), Color(0xFF148BC7)))).padding(2.dp)) {
        Box(Modifier.fillMaxSize().clip(CircleShape).background(RoleplaySurface2), contentAlignment = Alignment.Center) {
            if (!character?.avatarUrl.isNullOrBlank()) coil.compose.AsyncImage(model = character?.avatarUrl, contentDescription = character?.name, contentScale = androidx.compose.ui.layout.ContentScale.Crop, modifier = Modifier.fillMaxSize())
            else Icon(Icons.Filled.SmartToy, contentDescription = null, tint = Color(0xFFFF83DC), modifier = Modifier.size(29.dp))
        }
    }
}

@Composable
private fun EmptyRoleplay(message: String) {
    Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Filled.SmartToy, contentDescription = null, tint = Color(0xFFB38BFF), modifier = Modifier.size(42.dp))
        Text(message, color = RoleplayMuted, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}
