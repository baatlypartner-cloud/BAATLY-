package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// BAATLY locked neon-night palette
val LightCreamBackground = Color(0xFF05091F)
val LightCardBackground = Color(0xFF0D1538)
val LightSurfaceVariant = Color(0xFF151F49)
val LightNavBackground = Color(0xFF070D28)
val LightCardBorder = Color(0xFF47377B)
val LightBorderSubtle = Color(0xFF2C2A60)
val DarkBackground = LightCreamBackground
val DarkSurface = LightCardBackground
val DarkSurfaceVariant = LightSurfaceVariant
val DarkNavBackground = LightNavBackground
val DarkCardBorder = LightCardBorder
val DarkBorderSubtle = LightBorderSubtle
val DarkCard = LightCardBackground
val DarkCardBackground = LightCardBackground
val DarkBorder = LightCardBorder

// Exact Brand Colors
val VibrantPink = Color(0xFFFF0AA8)       // Exact Primary: #FF2D68
val PrimaryLavender = Color(0xFF793BFF)   // Exact Secondary: #7C3AED
val VibrantViolet = Color(0xFF793BFF)
val ElectricIndigo = Color(0xFF6366F1)
val NeonCyan = Color(0xFF20BFFF)
val VibrantAmber = Color(0xFFFFB703)
val VibrantOrange = Color(0xFFFB8500)

val PrimaryLavenderContainer = Color(0xFFEDE9FE)
val PrimaryLavenderDark = Color(0xFF5B21B6)

val PrimaryCoral = Color(0xFFFF0AA8)
val PrimaryCoralLight = Color(0xFFFF7A9E)
val PrimaryCoralDark = Color(0xFFBE123C)

val SecondaryAmber = Color(0xFFF59E0B)
val SecondaryAmberLight = Color(0xFFFEF3C7)

val AccentPurple = Color(0xFF793BFF)
val AccentPurpleLight = Color(0xFFDDD6FE)

// Near-Black High-Contrast Text Hierarchy
val TextPrimary = Color(0xFFFAF7FF)       // Exact Text: #171717
val TextSecondary = Color(0xFFC1BDD8)     // Exact Secondary Text: #777777
val TextMuted = Color(0xFF9692B5)
val TextTertiary = Color(0xFF9692B5)

// Status & Action Colors
val OnlineGreen = Color(0xFF10B981)
val OfflineGray = Color(0xFF9CA3AF)
val BusyAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)
val WarningYellow = Color(0xFFF59E0B)

val NeonPink = Color(0xFFFF0AA8)
val DarkPink = Color(0xFFDB168F)
val ErrorRed = DangerRed
val SuccessGreen = OnlineGreen

// Chat Bubbles (Light green for outgoing, crisp white for incoming)
val ChatBubbleOutgoing = Color(0xFF49206C)
val ChatBubbleIncoming = Color(0xFF121B3B)
val WhatsAppOutgoingBubble = Color(0xFF49206C)
val WhatsAppIncomingBubble = Color(0xFF121B3B)
val WhatsAppChatTextDark = Color(0xFFFAF7FF)
val WhatsAppChatBackground = Color(0xFF05091F)
val WhatsAppTickGrey = Color(0xFF8696A0)
val WhatsAppTickBlue = Color(0xFF34B7F1)

// Modern Light Gradients
val PrimaryGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFF0AA8), Color(0xFF793BFF))
)

val AccentGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF8B5CF6), Color(0xFF20BFFF))
)

val GoldGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFFFD166), Color(0xFFFB8500))
)

val CardGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF171831), Color(0xFF0A1230))
)

val HeroHeaderGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFF21134C), Color(0xFF0D1538))
)

val HostAvatarGradient = Brush.linearGradient(
    colors = listOf(Color(0xFFFF3366), Color(0xFFFFB703))
)
