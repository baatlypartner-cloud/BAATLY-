package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BaatlyColorScheme = darkColorScheme(
    primary = VibrantPink,
    onPrimary = Color.White,
    primaryContainer = PrimaryLavenderContainer,
    onPrimaryContainer = PrimaryLavenderDark,
    secondary = SecondaryAmber,
    onSecondary = Color.White,
    secondaryContainer = SecondaryAmberLight,
    onSecondaryContainer = Color(0xFF78350F),
    tertiary = NeonCyan,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = LightCardBorder,
    outlineVariant = LightBorderSubtle,
    error = DangerRed,
    onError = Color.White
)

@Composable
fun BaatlyTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = BaatlyColorScheme,
        typography = Typography,
        content = content
    )
}
