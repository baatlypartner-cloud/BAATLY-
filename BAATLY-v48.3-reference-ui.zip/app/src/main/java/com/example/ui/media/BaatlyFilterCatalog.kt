package com.example.ui.media

/**
 * Single source of truth for BAATLY's creator filters.
 * Photo processing uses Android GPUImage Plus (CGE rule strings); video preview/export
 * uses AndroidX Media3 effects. Some artistic effects are intentionally photo-only.
 */
data class BaatlyFilterPreset(
    val name: String,
    val category: String,
    val cgeRule: String = "",
    val supportsVideo: Boolean = true,
    val description: String = ""
)

object BaatlyFilterCatalog {
    val categories = listOf("All", "Trending", "Portrait", "Film", "Color", "Creative")

    val presets: List<BaatlyFilterPreset> = listOf(
        BaatlyFilterPreset("Original", "All", description = "Keep the original look"),
        BaatlyFilterPreset("Warm", "Trending", "@adjust whitebalance 0.22 1.04 @adjust hsl 0.025 0.06 0.02", description = "Warm skin tones"),
        BaatlyFilterPreset("Vivid", "Trending", "@adjust saturation 1.32 @adjust contrast 1.08", description = "Punchy colours"),
        BaatlyFilterPreset("Golden Hour", "Trending", "@adjust whitebalance 0.32 1.05 @adjust hsl 0.04 0.12 0.035 @adjust contrast 1.04", description = "Golden highlights"),
        BaatlyFilterPreset("Cinematic", "Film", "@adjust hsl -0.015 -0.10 -0.035 @adjust contrast 1.14 @vignette 0.12 0.88", description = "Deep cinematic tones"),
        BaatlyFilterPreset("Teal & Orange", "Film", "@adjust colorbalance 0.13 0.015 -0.12 @adjust saturation 1.12 @adjust contrast 1.08", description = "Movie-style colour"),
        BaatlyFilterPreset("Film Fade", "Film", "@curve RGB (0, 18) (64, 73) (128, 132) (200, 198) (255, 242) @adjust saturation 0.82", description = "Soft faded film"),
        BaatlyFilterPreset("Moody", "Film", "@adjust brightness -0.035 @adjust contrast 1.18 @adjust saturation 0.86 @vignette 0.15 0.83", description = "Dark and dramatic"),
        BaatlyFilterPreset("Soft Glow", "Portrait", "@adjust brightness 0.045 @adjust contrast 0.94 @adjust saturation 0.96", description = "Soft bright finish"),
        BaatlyFilterPreset("Matte", "Film", "@curve RGB (0, 22) (64, 76) (128, 134) (200, 198) (255, 238) @adjust saturation 0.90", description = "Lifted matte blacks"),
        BaatlyFilterPreset("Cool Night", "Color", "@adjust whitebalance -0.32 1.02 @adjust saturation 0.84 @adjust brightness -0.025", description = "Cool blue shadows"),
        BaatlyFilterPreset("Sunset", "Color", "@adjust whitebalance 0.28 1.00 @adjust hsl 0.045 0.17 0.02", description = "Warm sunset colour"),
        BaatlyFilterPreset("Portrait", "Portrait", "@adjust brightness 0.025 @adjust contrast 1.025 @adjust saturation 1.035", description = "Natural portrait"),
        BaatlyFilterPreset("Beauty", "Portrait", "@beautify face 0.45", supportsVideo = false, description = "Soft face enhancement"),
        BaatlyFilterPreset("Rose", "Portrait", "@adjust colorbalance 0.075 0.015 0.045 @adjust saturation 1.04", description = "Subtle rosy tint"),
        BaatlyFilterPreset("Dream", "Portrait", "@adjust brightness 0.045 @adjust contrast 0.91 @adjust saturation 0.88", description = "Dreamy pastel look"),
        BaatlyFilterPreset("Retro", "Film", "@lomo 0.20 0.82 0.12 0.24 0.88 0", description = "Retro camera feel"),
        BaatlyFilterPreset("Noir", "Film", "@adjust saturation 0 @adjust contrast 1.22 @vignette 0.15 0.82", description = "High-contrast monochrome"),
        BaatlyFilterPreset("Mono", "Color", "@adjust saturation 0", description = "Black and white"),
        BaatlyFilterPreset("Sepia", "Film", "@colormul mat 0.393 0.349 0.272 0.769 0.686 0.534 0.189 0.168 0.131", description = "Classic sepia"),
        BaatlyFilterPreset("Haze", "Creative", "@style haze 0.13 0.025 0.88 0.84 0.80", supportsVideo = false, description = "Airy haze"),
        BaatlyFilterPreset("Lomo", "Creative", "@lomo 0.18 0.78 0.10 0.22 0.94 0", supportsVideo = false, description = "Lomography vignette"),
        BaatlyFilterPreset("Sketch", "Creative", "@style sketch 0.68", supportsVideo = false, description = "Pencil sketch"),
        BaatlyFilterPreset("Crosshatch", "Creative", "@style crosshatch 0.028 0.0025", supportsVideo = false, description = "Illustrated hatch lines"),
        BaatlyFilterPreset("Sharpen", "Creative", "@adjust sharpen 1.25", supportsVideo = false, description = "Crisp detail"),
        BaatlyFilterPreset("Pop", "Color", "@adjust saturation 1.45 @adjust contrast 1.12", description = "Extra colour pop"),
        BaatlyFilterPreset("Invert", "Creative", "", description = "Inverted colours")
    )

    fun get(name: String): BaatlyFilterPreset = presets.firstOrNull { it.name == name } ?: presets.first()

    fun visible(category: String, videoOnly: Boolean = false): List<BaatlyFilterPreset> = presets.filter { preset ->
        (category == "All" || preset.category == category || (category == "Trending" && preset.name in setOf("Original", "Warm", "Vivid", "Golden Hour", "Cinematic"))) &&
            (!videoOnly || preset.supportsVideo)
    }
}
