package com.example.ui.media

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.TextUtils
import android.util.Log
import org.wysaid.nativePort.CGENativeLibrary
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.log10

object MediaEditorExporter {
    data class PhotoResult(val uri: Uri, val file: File)

    suspend fun exportPhoto(
        context: Context,
        sourceUri: Uri,
        filter: String,
        rotationDegrees: Int,
        overlayText: String,
        filterIntensity: Float = 1f
    ): Uri = withContext(Dispatchers.IO) {
        val decoded = decodeScaledBitmap(context, sourceUri, maxDimension = 5200)
            ?: throw IllegalArgumentException("This image format is not supported. Use JPG, PNG or WebP.")
        var rotated = decoded
        if (rotationDegrees % 360 != 0) {
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
            if (rotated !== decoded) decoded.recycle()
        }

        val filtered = applyFilterBitmap(rotated, filter, filterIntensity)
        if (filtered !== rotated) rotated.recycle()
        val cleanOverlay = overlayText.trim().take(80)
        if (cleanOverlay.isNotBlank()) drawTextOverlay(filtered, cleanOverlay)
        val output = File(context.cacheDir, "baatly_edit_${System.currentTimeMillis()}.jpg")
        try {
            FileOutputStream(output).use { stream ->
                if (!filtered.compress(Bitmap.CompressFormat.JPEG, 93, stream)) throw IllegalStateException("Could not encode edited photo")
                stream.flush()
            }
            Uri.fromFile(output)
        } finally {
            filtered.recycle()
        }
    }

    /** Creates a smaller preview with the same native filter pipeline used for final photo export. */
    fun createPhotoPreviewBitmap(context: Context, sourceUri: Uri, filter: String, intensity: Float): Bitmap? = runCatching {
        val decoded = decodeScaledBitmap(context, sourceUri, maxDimension = 1100) ?: return null
        applyFilterBitmap(decoded, filter, intensity).also { result ->
            if (result !== decoded) decoded.recycle()
        }
    }.onFailure { Log.w("BaatlyEditor", "Could not render filter preview; showing source image", it) }.getOrNull()

    private fun decodeScaledBitmap(context: Context, sourceUri: Uri, maxDimension: Int): Bitmap? {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = openSourceStream(context, sourceUri) ?: return null
        boundsStream.use { BitmapFactory.decodeStream(it, null, options) }
        if (options.outWidth <= 0 || options.outHeight <= 0) return null
        val longest = max(options.outWidth, options.outHeight)
        var sample = 1
        while (longest / sample > maxDimension * 1.6f && sample < 16) sample *= 2
        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return openSourceStream(context, sourceUri)?.use { BitmapFactory.decodeStream(it, null, decodeOptions) }
    }

    private fun applyFilterBitmap(source: Bitmap, filter: String, intensity: Float): Bitmap {
        val strength = intensity.coerceIn(0f, 1f)
        if (filter == "Original" || strength <= 0f) return source
        val preset = BaatlyFilterCatalog.get(filter)
        if (filter != "Invert" && preset.cgeRule.isNotBlank()) {
            try {
                val nativeResult = CGENativeLibrary.filterImage_MultipleEffects(source, preset.cgeRule, strength)
                if (nativeResult != null && nativeResult !== source && !nativeResult.isRecycled) return nativeResult
            } catch (error: Throwable) {
                // A native ABI/device mismatch must not break Creator Studio publishing. Fall back
                // to the Android bitmap pipeline below, and report the issue for diagnostics.
                Log.w("BaatlyEditor", "GPUImage Plus filter '${preset.name}' failed; using bitmap fallback", error)
            }
        }
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(androidColorMatrix(filter, strength))
        }
        Canvas(output).drawBitmap(source, 0f, 0f, paint)
        return output
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    suspend fun exportVideo(
        context: Context,
        sourceUri: Uri,
        musicUri: Uri?,
        filter: String,
        rotationDegrees: Int,
        trimStartMs: Long,
        trimEndMs: Long,
        overlayText: String,
        originalAudioVolume: Float = 0.35f,
        musicVolume: Float = 0.82f,
        filterIntensity: Float = 1f
    ): Uri {
        val outputFile = File(context.cacheDir, "baatly_edit_${System.currentTimeMillis()}.mp4")
        val overlayBitmap = if (overlayText.isNotBlank()) withContext(Dispatchers.IO) {
            makeVideoTextOverlay(context, sourceUri, overlayText.trim().take(80))
        } else null
        val editedMediaItem = withContext(Dispatchers.Main.immediate) {
            val clippingBuilder = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(trimStartMs.coerceAtLeast(0L))
            if (trimEndMs > trimStartMs && trimEndMs > 0L) clippingBuilder.setEndPositionMs(trimEndMs)
            val mediaItem = MediaItem.Builder().setUri(sourceUri).setClippingConfiguration(clippingBuilder.build()).build()
            val effects = videoFilterEffects(filter, filterIntensity).toMutableList()
            if (rotationDegrees % 360 != 0) effects.add(ScaleAndRotateTransformation.Builder().setRotationDegrees(rotationDegrees.toFloat()).build())
            if (overlayBitmap != null) effects.add(OverlayEffect(listOf(BitmapOverlay.createStaticBitmapOverlay(overlayBitmap))))
            val sourceAudioProcessors = if (musicUri != null) {
                listOf(GainProcessor(DefaultGainProvider.Builder(volumeToDecibels(originalAudioVolume)).build()))
            } else emptyList()
            EditedMediaItem.Builder(mediaItem).setEffects(Effects(sourceAudioProcessors, effects)).build()
        }
        val videoSequence = EditedMediaItemSequence.withAudioAndVideoFrom(listOf(editedMediaItem))
        val composition = if (musicUri != null) {
            val musicGain = GainProcessor(DefaultGainProvider.Builder(volumeToDecibels(musicVolume)).build())
            val musicItem = EditedMediaItem.Builder(MediaItem.fromUri(musicUri))
                .setEffects(Effects(listOf(musicGain), emptyList()))
                .build()
            val musicSequence = EditedMediaItemSequence.withAudioFrom(listOf(musicItem)).buildUpon().setIsLooping(true).build()
            Composition.Builder(videoSequence, musicSequence).build()
        } else {
            Composition.Builder(videoSequence).build()
        }
        return try {
            withContext(Dispatchers.Main.immediate) {
                suspendCancellableCoroutine<Unit> { continuation ->
                    val transformer = Transformer.Builder(context.applicationContext)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setAudioMimeType(MimeTypes.AUDIO_AAC)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                if (continuation.isActive) continuation.resume(Unit)
                            }
                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                if (continuation.isActive) continuation.resumeWithException(exportException)
                            }
                        }).build()
                    continuation.invokeOnCancellation { runCatching { transformer.cancel() }; outputFile.delete() }
                    transformer.start(composition, outputFile.absolutePath)
                }
            }
            if (!outputFile.exists() || outputFile.length() <= 0L) throw IllegalStateException("Edited video export returned an empty file")
            Uri.fromFile(outputFile)
        } catch (error: Exception) {
            outputFile.delete()
            throw error
        } finally {
            overlayBitmap?.recycle()
        }
    }


    @androidx.annotation.OptIn(UnstableApi::class)
    fun videoFilterEffects(filter: String, intensity: Float = 1f): List<androidx.media3.common.Effect> {
        val amount = intensity.coerceIn(0f, 1f)
        if (filter == "Original" || amount <= 0f) return emptyList()
        fun scale(target: Float) = 1f + (target - 1f) * amount
        fun saturation(delta: Float) = HslAdjustment.Builder().adjustSaturation(delta * amount).build()
        fun hue(degrees: Float) = HslAdjustment.Builder().adjustHue(degrees * amount).build()
        fun rgb(red: Float, green: Float, blue: Float) = RgbAdjustment.Builder()
            .setRedScale(scale(red)).setGreenScale(scale(green)).setBlueScale(scale(blue)).build()
        return when (filter) {
            "Mono" -> listOf(saturation(-100f))
            "Noir" -> listOf(saturation(-100f), Contrast(0.22f * amount))
            "Invert" -> if (amount >= 0.98f) listOf(RgbFilter.createInvertedFilter()) else listOf(Contrast(0.08f * amount), Brightness(0.01f * amount))
            "Warm" -> listOf(rgb(1.10f, 1.025f, 0.89f))
            "Vivid" -> listOf(saturation(32f), Contrast(0.16f * amount), Brightness(0.035f * amount), rgb(1.04f, 1.04f, 1.04f))
            "Golden Hour", "Sunset" -> listOf(hue(3f), saturation(12f), rgb(1.12f, 1.035f, 0.88f), Brightness(0.025f * amount), Contrast(0.035f * amount))
            "Cinematic" -> listOf(rgb(1.035f, 1.015f, 0.965f), Contrast(0.14f * amount), Brightness(-0.025f * amount))
            "Teal & Orange" -> listOf(hue(-5f), saturation(12f), rgb(1.10f, 1.015f, 0.93f), Contrast(0.08f * amount))
            "Film Fade", "Matte" -> listOf(rgb(1.025f, 1.01f, 0.99f), Contrast(-0.08f * amount), Brightness(0.025f * amount))
            "Moody" -> listOf(rgb(0.97f, 0.985f, 1.03f), Contrast(0.16f * amount), Brightness(-0.04f * amount))
            "Soft Glow", "Dream" -> listOf(Brightness(0.045f * amount), Contrast(-0.06f * amount), rgb(1.025f, 1.01f, 1.025f))
            "Cool Night" -> listOf(rgb(0.89f, 0.98f, 1.12f), Brightness(-0.025f * amount))
            "Portrait", "Beauty" -> listOf(saturation(4f), Brightness(0.02f * amount), Contrast(0.025f * amount), rgb(1.02f, 1.01f, 1.0f))
            "Rose" -> listOf(rgb(1.07f, 1.005f, 1.04f))
            "Retro" -> listOf(hue(4f), saturation(-12f), rgb(1.08f, 1.0f, 0.87f), Contrast(-0.06f * amount), Brightness(0.02f * amount))
            "Sepia" -> listOf(saturation(-42f), rgb(1.10f, 1.0f, 0.82f), Contrast(-0.025f * amount))
            "Pop" -> listOf(saturation(38f), Contrast(0.2f * amount), rgb(1.07f, 1.07f, 1.07f))
            "Haze" -> listOf(Brightness(0.04f * amount), Contrast(-0.10f * amount))
            else -> emptyList()
        }
    }

    private fun volumeToDecibels(volume: Float): Float {
        val safe = volume.coerceIn(0f, 1f)
        return if (safe <= 0.0001f) -80f else (20f * log10(safe)).coerceIn(-80f, 6f)
    }

    fun getDurationMs(context: Context, uri: Uri): Long = runCatching {
        MediaMetadataRetriever().use { retriever ->
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        }
    }.getOrDefault(0L)

    private fun openSourceStream(context: Context, uri: Uri): java.io.InputStream? {
        if (uri.scheme.equals("file", ignoreCase = true)) {
            val path = uri.path ?: return null
            return File(path).takeIf { it.isFile && it.length() > 0L }?.inputStream()
        }
        return context.contentResolver.openInputStream(uri)
    }

    fun isVideo(context: Context, uri: Uri): Boolean {
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        return mime.startsWith("video/") || uri.toString().substringBefore('?').substringAfterLast('.', "").lowercase() in setOf("mp4", "m4v", "mov", "webm", "3gp", "m3u8")
    }

    fun composeFilter(filter: String, intensity: Float = 1f): androidx.compose.ui.graphics.ColorFilter? {
        if (filter == "Original" || intensity <= 0f) return null
        return androidx.compose.ui.graphics.ColorFilter.colorMatrix(
            androidx.compose.ui.graphics.ColorMatrix(androidColorMatrix(filter, intensity).array)
        )
    }

    /** A lightweight color-matrix approximation for the camera preview surface. */
    fun androidPreviewColorFilter(filter: String, intensity: Float = 1f): android.graphics.ColorFilter? {
        if (filter == "Original" || intensity <= 0f) return null
        return ColorMatrixColorFilter(androidColorMatrix(filter, intensity))
    }

    private fun androidColorMatrix(filter: String, intensity: Float = 1f): ColorMatrix {
        val target = when (filter) {
            "Mono", "Noir" -> ColorMatrix().apply { setSaturation(0f) }
            "Warm", "Golden Hour", "Sunset" -> ColorMatrix(floatArrayOf(
                1.10f, 0f, 0f, 0f, 5f,
                0f, 1.02f, 0f, 0f, 1f,
                0f, 0f, 0.88f, 0f, -1f,
                0f, 0f, 0f, 1f, 0f
            ))
            "Vivid", "Pop" -> ColorMatrix().apply { setSaturation(if (filter == "Pop") 1.52f else 1.34f) }
            "Vintage", "Retro", "Sepia", "Lomo" -> ColorMatrix(floatArrayOf(
                1.05f, 0.10f, 0.03f, 0f, 5f,
                0.06f, 0.98f, 0.02f, 0f, 2f,
                0.02f, 0.08f, 0.80f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
            "Cinematic", "Moody" -> ColorMatrix(floatArrayOf(
                1.10f, 0f, 0f, 0f, -3f,
                0f, 1.04f, 0f, 0f, -2f,
                0f, 0f, 0.96f, 0f, 1f,
                0f, 0f, 0f, 1f, 0f
            ))
            "Teal & Orange" -> ColorMatrix(floatArrayOf(
                1.08f, 0f, 0f, 0f, 4f,
                0f, 1.01f, 0f, 0f, 0f,
                0f, 0f, 0.90f, 0f, 3f,
                0f, 0f, 0f, 1f, 0f
            ))
            "Cool Night" -> ColorMatrix(floatArrayOf(
                0.90f, 0f, 0f, 0f, -1f,
                0f, 1.00f, 0f, 0f, 0f,
                0f, 0f, 1.12f, 0f, 3f,
                0f, 0f, 0f, 1f, 0f
            ))
            "Rose" -> ColorMatrix(floatArrayOf(
                1.06f, 0f, 0f, 0f, 4f,
                0f, 0.99f, 0f, 0f, 1f,
                0f, 0f, 1.03f, 0f, 2f,
                0f, 0f, 0f, 1f, 0f
            ))
            "Soft Glow", "Dream", "Film Fade", "Matte", "Haze" -> ColorMatrix(floatArrayOf(
                0.96f, 0.02f, 0.02f, 0f, 8f,
                0.02f, 0.96f, 0.02f, 0f, 8f,
                0.02f, 0.02f, 0.96f, 0f, 8f,
                0f, 0f, 0f, 1f, 0f
            ))
            "Invert" -> ColorMatrix(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            ))
            else -> ColorMatrix()
        }
        val amount = intensity.coerceIn(0f, 1f)
        if (amount >= 0.999f) return target
        val base = ColorMatrix().array
        val effect = target.array
        return ColorMatrix(FloatArray(20) { index -> base[index] + (effect[index] - base[index]) * amount })
    }

    private fun drawTextOverlay(bitmap: Bitmap, text: String) {
        val canvas = Canvas(bitmap)
        val stripHeight = (bitmap.height * 0.16f).coerceAtLeast(88f)
        val top = bitmap.height - stripHeight
        val backdrop = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AndroidColor.argb(88, 12, 8, 24) }
        canvas.drawRoundRect(RectF(0f, top, bitmap.width.toFloat(), bitmap.height.toFloat()), 0f, 0f, backdrop)
        val fontSize = (bitmap.width * 0.055f).coerceIn(24f, 72f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.WHITE
            textSize = fontSize
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            setShadowLayer(fontSize * 0.15f, 1f, 2f, AndroidColor.BLACK)
        }
        val maxTextWidth = bitmap.width * 0.88f
        val label = TextUtils.ellipsize(text, android.text.TextPaint(paint), maxTextWidth, TextUtils.TruncateAt.END).toString()
        canvas.drawText(label, bitmap.width * 0.06f, top + stripHeight * 0.62f, paint)
    }

    private fun makeVideoTextOverlay(context: Context, uri: Uri, text: String): Bitmap = MediaMetadataRetriever().use { retriever ->
        retriever.setDataSource(context, uri)
        val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()?.coerceIn(320, 1920) ?: 720
        val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()?.coerceIn(320, 1920) ?: 1280
        val overlay = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        drawTextOverlay(overlay, text)
        overlay
    }
}
