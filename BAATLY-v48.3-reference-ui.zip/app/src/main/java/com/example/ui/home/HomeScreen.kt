package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.HomeMode
import com.example.ui.Screen
import com.example.ui.components.HostCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: BaatlyViewModel) {
    val homeMode by viewModel.homeMode.collectAsState()
    val availablePartners by viewModel.availablePartners.collectAsState()
    val isLoadingPartners by viewModel.isLoadingPartners.collectAsState()
    val wallet by viewModel.walletSummary.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()
    val hostPublicRatings by viewModel.hostPublicRatings.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val displayedPartners = remember(availablePartners, homeMode) {
        when (homeMode) {
            HomeMode.CALL -> availablePartners.filter { it.audioEnabled }
            HomeMode.VIDEO -> availablePartners.filter { it.videoEnabled }
            HomeMode.CHAT -> availablePartners.filter { it.chatEnabled }
        }
    }
    val filteredPartners = remember(displayedPartners, searchQuery) {
        if (searchQuery.isBlank()) displayedPartners
        else displayedPartners.filter {
            it.displayName.contains(searchQuery, ignoreCase = true) ||
                (it.bio?.contains(searchQuery, ignoreCase = true) == true)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
        RelationshipHeader(
            balance = wallet.availableBalanceRupees,
            onWalletClick = { viewModel.setScreen(Screen.WALLET) },
            onMessagesClick = { viewModel.setScreen(Screen.CHAT_LIST) }
        )

        PullToRefreshBox(
            isRefreshing = isLoadingPartners && availablePartners.isNotEmpty(),
            onRefresh = {
                viewModel.refreshPartners()
                viewModel.refreshWallet()
            },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "relationship_hero") {
                    RelationshipHeroBanner(
                        greeting = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
                            in 4..11 -> "Good morning"
                            in 12..16 -> "Good afternoon"
                            else -> "Good evening"
                        }
                    )
                }
                item(key = "relationship_search") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search hosts by name, mood or interest…", color = TextTertiary, fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search hosts", tint = VibrantPink) },
                            shape = RoundedCornerShape(24.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VibrantPink,
                                unfocusedBorderColor = DarkCardBorder,
                                focusedContainerColor = DarkSurface,
                                unfocusedContainerColor = DarkSurface,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                cursorColor = VibrantPink
                            ),
                            modifier = Modifier.weight(1f).testTag("input_search_hosts")
                        )
                        Surface(
                            modifier = Modifier.size(52.dp).clickable { viewModel.refreshPartners() },
                            shape = RoundedCornerShape(17.dp),
                            color = DarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Tune, contentDescription = "Refresh host list", tint = VibrantPink)
                            }
                        }
                    }
                }
                item(key = "relationship_modes") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        RelationshipQuickAction("Voice Call", "Talk now", Icons.Filled.Call, listOf(Color(0xFFFF0AA8), Color(0xFF8B35FF)), Modifier.weight(1f)) {
                            viewModel.setHomeMode(HomeMode.CALL)
                        }
                        RelationshipQuickAction("Video Call", "Face to face", Icons.Filled.Videocam, listOf(Color(0xFF803BFF), Color(0xFF326BFF)), Modifier.weight(1f)) {
                            viewModel.setHomeMode(HomeMode.VIDEO)
                        }
                        RelationshipQuickAction("Love Note", "Send a message", Icons.Filled.Email, listOf(Color(0xFFFF7956), Color(0xFFDB278F)), Modifier.weight(1f)) {
                            viewModel.setHomeMode(HomeMode.CHAT)
                        }
                        RelationshipQuickAction("Roleplay", "AI characters", Icons.Filled.FavoriteBorder, listOf(Color(0xFF3157FF), Color(0xFF7B36FF)), Modifier.weight(1f)) {
                            viewModel.setScreen(Screen.ROLEPLAY)
                        }
                    }
                }
                item(key = "relationship_available_title") {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Available now", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(OnlineGreen))
                            Text("${filteredPartners.size} online", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                        }
                    }
                }
                if (isLoadingPartners && filteredPartners.isEmpty()) {
                    item(key = "relationship_loading") {
                        Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = VibrantPink)
                        }
                    }
                } else if (filteredPartners.isEmpty()) {
                    item(key = "relationship_empty") {
                        Box(Modifier.fillMaxWidth().height(300.dp).padding(28.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(42.dp))
                                Text(
                                    text = when (homeMode) {
                                        HomeMode.CALL -> "No hosts available for voice calls right now"
                                        HomeMode.VIDEO -> "No hosts available for video calls right now"
                                        HomeMode.CHAT -> "No hosts available for Love Notes right now"
                                    },
                                    style = MaterialTheme.typography.bodyLarge.copy(color = TextSecondary, fontWeight = FontWeight.Medium)
                                )
                                Text("Pull down to refresh", style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                            }
                        }
                    }
                } else {
                    items(filteredPartners, key = { it.id }) { partner ->
                        val hostUserId = partner.userId?.takeIf { it.isNotBlank() } ?: partner.id
                        Box(Modifier.padding(horizontal = 16.dp)) {
                            HostCard(
                                partner = partner,
                                homeMode = homeMode,
                                onCardClick = { viewModel.openHostProfile(partner) },
                                onActionClick = {
                                    when (homeMode) {
                                        HomeMode.CALL -> viewModel.requestCall(partner)
                                        HomeMode.VIDEO -> viewModel.requestVideoCall(partner)
                                        HomeMode.CHAT -> viewModel.openChatWithHost(partner)
                                    }
                                },
                                dataService = viewModel.dataService,
                                effectivePricing = effectivePricing,
                                publicRating = hostPublicRatings[hostUserId]
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RelationshipHeroBanner(greeting: String) {
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .height(132.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF26104A), Color(0xFF4B145C), Color(0xFF101A45))))
    ) {
        Image(
            painter = painterResource(id = com.example.R.drawable.img_onboard_chat),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF170C32).copy(alpha = 0.94f), Color(0xFF231144).copy(alpha = 0.75f), Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(start = 17.dp, end = 112.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("$greeting  👋", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text("Connect, talk, share and build meaningful relationships on BAATLY.", color = Color(0xFFE5DDFB), fontSize = 11.sp, lineHeight = 16.sp)
        }
        Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = Color(0xFFFF72CF), modifier = Modifier.align(Alignment.TopEnd).padding(14.dp).size(23.dp))
    }
}

@Composable
private fun RelationshipQuickAction(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.height(84.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        color = DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, colors.first().copy(alpha = 0.8f))
    ) {
        Column(
            Modifier.fillMaxSize().background(Brush.linearGradient(colors)).padding(horizontal = 3.dp, vertical = 9.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(5.dp))
            Text(title, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(subtitle, color = Color.White.copy(alpha = 0.84f), fontSize = 7.sp, maxLines = 1)
        }
    }
}

@Composable
private fun RelationshipHeader(balance: Double, onWalletClick: () -> Unit, onMessagesClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(DarkBackground).statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(VibrantPink, PrimaryLavender))), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = Color.White, modifier = Modifier.size(23.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                Text("BAATLY", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 0.4.sp))
                Text("R E L A T I O N S H I P", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = VibrantPink, fontSize = 9.sp))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(
                shape = CircleShape,
                color = DarkSurfaceVariant,
                modifier = Modifier.clickable(onClick = onWalletClick).testTag("relationship_wallet_badge")
            ) {
                Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Box(Modifier.size(25.dp).clip(CircleShape).background(Color(0xFFFFB703)), contentAlignment = Alignment.Center) {
                        Text("₹", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    }
                    Text("₹${"%.0f".format(balance)}", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
            IconButton(onClick = onMessagesClick, modifier = Modifier.size(42.dp).testTag("btn_relationship_messages")) {
                Icon(Icons.Filled.Email, contentDescription = "Messages", tint = Color.White, modifier = Modifier.size(25.dp))
            }
        }
    }
}

@Composable
private fun SegmentButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    testTag: String,
    selectedColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) selectedColor else Color.Transparent,
        modifier = modifier.testTag(testTag).clickable(onClick = onClick)
    ) {
        Row(modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(icon, contentDescription = null, tint = if (selected) Color.White else TextSecondary, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Text(title, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (selected) Color.White else TextSecondary))
        }
    }
}
