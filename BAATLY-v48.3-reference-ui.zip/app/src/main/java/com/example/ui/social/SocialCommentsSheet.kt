package com.example.ui.social

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.launch

/** Instagram-style comment sheet backed by the real social_get_comments/social_add_comment RPCs. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SocialCommentsSheet(
    viewModel: BaatlyViewModel,
    contentType: String,
    contentId: String,
    creatorName: String,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var comments by remember(contentType, contentId) { mutableStateOf(emptyList<com.example.data.model.SocialComment>()) }
    var commentText by remember(contentType, contentId) { mutableStateOf("") }
    var loading by remember(contentType, contentId) { mutableStateOf(true) }
    var posting by remember(contentType, contentId) { mutableStateOf(false) }
    var errorText by remember(contentType, contentId) { mutableStateOf<String?>(null) }

    fun reload() {
        scope.launch {
            loading = true
            viewModel.dataService.getSocialComments(contentType, contentId).onSuccess {
                comments = it
                errorText = null
            }.onFailure {
                errorText = it.message ?: "Could not load comments"
            }
            loading = false
        }
    }
    LaunchedEffect(contentType, contentId) { reload() }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = DarkSurface) {
        Column(
            Modifier.fillMaxWidth().heightIn(min = 280.dp, max = 620.dp).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Comments", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("${comments.size} comments · ${creatorName.ifBlank { "this post" }}", color = TextSecondary, fontSize = 12.sp)
            Divider(color = DarkCardBorder)
            when {
                loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = VibrantPink)
                }
                comments.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("Be the first to comment", color = TextSecondary, fontSize = 13.sp)
                }
                else -> LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(comments, key = { it.id }) { comment ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top) {
                            AsyncImage(
                                model = comment.avatarUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(34.dp).clip(CircleShape).background(DarkSurfaceVariant)
                            )
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(comment.displayName.ifBlank { "BAATLY member" }, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                Text(comment.commentText, color = TextPrimary, fontSize = 13.sp)
                                if (comment.createdAt.isNotBlank()) Text(comment.createdAt.take(16).replace('T', ' '), color = TextSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
            if (!errorText.isNullOrBlank()) Text(errorText.orEmpty(), color = Color(0xFFB42318), fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it.take(1000) },
                    placeholder = { Text("Write a comment…") },
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    shape = RoundedCornerShape(22.dp)
                )
                IconButton(
                    enabled = commentText.trim().isNotEmpty() && !posting,
                    onClick = {
                        val body = commentText.trim()
                        if (body.isNotEmpty() && !posting) scope.launch {
                            posting = true
                            viewModel.dataService.addSocialComment(contentType, contentId, body).onSuccess {
                                if (contentType == "post") viewModel.recordSocialRecommendationEvent(contentId, "comment")
                                commentText = ""
                                reload()
                            }.onFailure { errorText = it.message ?: "Could not post comment" }
                            posting = false
                        }
                    }
                ) {
                    if (posting) CircularProgressIndicator(Modifier.size(20.dp), color = VibrantPink, strokeWidth = 2.dp)
                    else Icon(Icons.Filled.Send, contentDescription = "Post comment", tint = VibrantPink)
                }
            }
        }
    }
}
