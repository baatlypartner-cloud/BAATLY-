# BAATLY v44 — Super AI Photo Editing Fix

## What was wrong

The Android chat always routed an attached photo to `/v1/chat/vision`. That endpoint asks a vision-language model to describe or analyse an image, so an edit request such as “remove this watch and send a new photo” was being treated as a text-only question. The chat UI also rendered text messages only, so even if the backend returned an edited image it would not appear in the conversation.

## Changes included

- Added the authenticated Cloudflare Worker endpoint `POST /v1/images/edits` using `@cf/black-forest-labs/flux-2-klein-4b`, a model that supports image editing from reference images.
- The Android chat detects common English and Roman-Hindi photo-edit commands when a photo is attached and routes them to the image-edit endpoint; ordinary photo questions still use `/v1/chat/vision`.
- The source image is scaled to a maximum side of 479 px before it is sent to FLUX.2 Klein, which documents reference inputs as smaller than 512 x 512.
- The edited image is returned in the chat, can be saved to the phone, and is archived in the user's private R2 prefix.
- The image-edit endpoint is authenticated using the same Supabase session as the other Worker endpoints; no provider keys are added to the APK.
- The Worker source in this bundle contains the search helper fix as well as the image-edit route.

## Live backend

Cloudflare Worker `baatly-ai-gateway` was deployed as version 1.8.1. The route is `/v1/images/edits`; the existing `/v1/images/generations` text-to-image route was not repurposed.

## Verification and limitations

- `node --check cloudflare/baatly-ai-gateway/index.js`: passed.
- ZIP integrity is checked after packaging.
- A full Android Gradle build could not be completed in this environment because the Gradle wrapper cannot resolve `services.gradle.org` (`UnknownHostException`). Therefore APK compilation and on-device image-edit inference are not yet confirmed here.
- FLUX.2 Klein supports input images smaller than 512 x 512. The app prepares the input to meet that constraint.
