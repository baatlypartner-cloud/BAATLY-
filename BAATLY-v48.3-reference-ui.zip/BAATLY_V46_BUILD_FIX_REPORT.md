# BAATLY v46 — Build Fix Report

## Fixes applied

1. Removed the compiler-triggering `BaatlyFilterCatalog.get(selectedFilter).description` access from `MediaEditorScreen.kt`; the editor now displays a stable helper caption for the effect-strength slider.
2. Added explicit `BaatlyFilterCatalog` imports to `MediaEditorScreen.kt` and `BaatlyCameraScreen.kt`, which use the catalog from the `com.example.ui.media` package.
3. Incremented Android app version to `versionCode = 46` and `versionName = "1.0.46"`.
4. Kept the existing Supabase/Cloudflare R2 upload flow and upload/service files unchanged.
5. Kept the existing GPUImage Plus dependency at `org.wysaid:gpuimage-plus:3.2.0-16k-min` and its documented Maven repository.

## Checks completed

- Original v45 ZIP extraction and integrity test: PASS.
- Standalone Kotlin compilation of `BaatlyFilterCatalog.kt`: PASS.
- Filter catalog smoke check: PASS — 27 unique presets, original preset/description exists in the catalog, and video-only filtering excludes photo-only presets.
- Android manifest and source assets: reviewed with static project checks.
- ZIP re-creation and post-creation integrity test: PASS.

## Important build limitation

A full Android Gradle compile/release build could not run in this environment because the Gradle wrapper distribution download failed with `UnknownHostException: services.gradle.org`; there is no preinstalled Gradle distribution or Android SDK available here. Therefore this report does **not** claim a verified APK or a successful full-project compile. Run `./gradlew :app:compileReleaseKotlin` or the release workflow in an environment with network access and the Android SDK to verify the complete build.

## Preserved flow

No R2 upload code, presigned-upload request handling, media bucket naming, Supabase service logic, or publishing callback was modified for this fix.
