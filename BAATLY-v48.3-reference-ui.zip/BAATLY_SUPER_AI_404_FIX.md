# BAATLY Super AI 404 fix

Date: 2026-10-27

## Root cause

The Android Cloudflare client used `https://baatly-ai.baatly-ai.workers.dev`, but the deployed Cloudflare Worker script name is `baatly-ai-gateway` and the account's `workers.dev` subdomain is `baatly-ai`. Cloudflare worker URLs use the form `<worker-name>.<account-subdomain>.workers.dev`, so the client was targeting the wrong hostname and the API returned 404 before the Super AI route could run.

## Fix

Changed the shared Android Cloudflare AI client's base URL to:

`https://baatly-ai-gateway.baatly-ai.workers.dev`

This single shared client is used by Super AI and the astrologer screen, and its `post`, `get`, and `getBytes` operations now all target the deployed Worker. The Cloudflare Worker script itself was not changed by this hostname correction. Supabase functions `ai-call-turn` and `ai-voice-stream` were inspected and already point to the correct host.

## Validation

- Confirmed live Cloudflare script name: `baatly-ai-gateway`.
- Confirmed account `workers.dev` subdomain: `baatly-ai`.
- Confirmed Worker `workers.dev` routing is enabled.
- Confirmed deployed Worker code includes `POST /v1/agent/chat` and standard chat routes.
- Scanned the packaged project for the incorrect hostname; no occurrences should remain.
- Full runtime request from this sandbox could not be performed because outbound DNS/network access is restricted in this execution environment. Please rebuild/install this ZIP and test `hello` on the device.
