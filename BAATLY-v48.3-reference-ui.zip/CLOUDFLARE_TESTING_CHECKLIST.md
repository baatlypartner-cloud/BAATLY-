# BAATLY Cloudflare testing checklist

Use a signed-in test BAATLY account. Do not test with production partner/user balances unless the test is approved and monitored.

1. Open Super AI and send: `Namaste, apna introduction do.` Confirm a normal reply and archived conversation.
2. Send: `India ka latest CPI inflation rate batao sources ke sath.` Check that the tool router chooses web search and the answer includes source URLs. Also test `Manoj Bubli Karora gaon Haryana ghatna`; the Worker should try the Babli spelling variant and give source-backed results, or clearly say the search provider failed instead of saying no information exists.
3. Send a public HTTPS page URL with `Is page ka summary do: <url>`. Confirm the read tool succeeds or reports a transparent failure.
4. Ask: `Yaad rakhna, mujhe short answers pasand hain.` Confirm the agent explicitly saves a non-sensitive memory. Then inspect conversation behavior in a later prompt.
5. Upload a small image and ask a visual question. Confirm the attachment is stored in the authenticated user's R2 prefix and Llama 4 Scout returns an answer.
6. Generate a single low-cost test image. Confirm the image returns, is saved under the user's R2 prefix, and the phone Save action works.
7. Create a Web or Android workspace. Upload a small source ZIP, reopen the saved workspace, ask for a one-file edit, and export the updated ZIP. Check a prior revision remains in the `revisions/` prefix. For a static Web project with `index.html`, tap **Preview static HTML page**; Vite/React builds still require the runner.
8. Open Astrology and request a daily interpretation. Confirm the response includes reflective/entertainment framing rather than claiming exact planetary calculations.
9. For AI audio, check `ai-call-start` returns `provider=cloudflare_sarvam_websocket` and a direct Supabase WebSocket URL. Verify the client sends the JWT in the Authorization header, Cloudflare LLM replies, Sarvam audio is audible, and `ai-call-end` settles at ₹5/min. No Agora Conversational AI agent should start; ordinary user/partner Agora RTC calls should remain unaffected. The provided Kotlin source currently has no client-side references to these AI audio endpoints, so complete device testing requires that native WebSocket microphone/audio playback wiring be integrated.
10. Video-generation currently requires AI Gateway credits/model access; the verified account balance was $0. Do not interpret a 503 from that route as an app code regression until billing access is resolved.

## Known test gates

- A full Android Gradle compile could not run in this environment because Gradle 9.3.1 could not be downloaded (`services.gradle.org` DNS failure).
- Full mobile end-to-end tests require installing the APK on a test device and an authenticated Supabase session. This bundle does not currently include the native client wiring for `ai-call-start` / `ai-voice-stream`; backend routing alone does not make AI voice calls callable from the app UI.
- Isolated project runtime, dynamic Web App preview server, Android emulator, Gradle worker, and APK pipeline are not deployed in this bundle. The restricted static HTML preview endpoint is implemented for a saved `index.html` and locally inlined assets only. Android requests must not trigger automatic APK builds; source ZIP export is the default.


## Photo edit flow (new in Worker v1.8.2)

1. In Super AI, attach a photo and send `Is photo se watch remove karo, baaki sab same rakhna.`
2. Verify that the chat shows an edited image, not a refusal or a text-only description.
3. Tap **Save image** and confirm it appears in Pictures/BAATLY.
4. Check R2 under the signed-in user's `generated/edits/` prefix.
5. Separately attach a photo and ask what is in it; verify that ordinary image analysis still uses `/v1/chat/vision`.
6. Repeat with a different object-removal request and inspect face, hands, clothing, and background for unintended changes.
