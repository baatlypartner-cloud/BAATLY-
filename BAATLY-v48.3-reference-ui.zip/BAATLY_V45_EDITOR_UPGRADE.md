# BAATLY v45 — Creator / Photo & Video Editor Upgrade

## Implemented in source

- Raised Android app version to `versionCode 45` / `versionName 1.0.45`.
- Added the open-source `org.wysaid:gpuimage-plus:3.2.0-16k-min` dependency and its official Maven repository. No API key is required for local bitmap filtering.
- Added one shared filter catalog with 27 named presets and six category chips: All, Trending, Portrait, Film, Color and Creative.
- Added filter descriptions, adjustable intensity and selection UI in Creator Studio.
- Photo editor preview and final JPG export now use GPUImage Plus native filter rules where available, with an Android color-matrix fallback if a native filter cannot run.
- Added video-filter mappings using AndroidX Media3 effects for supported presets, and wired filter intensity into video preview and export.
- Updated the in-app camera screen with category and preset selection. On Android 12+ the camera preview uses a lightweight Android RenderEffect colour-matrix approximation; the chosen filter is passed to Creator Studio, where the final still photo is rendered with GPUImage Plus. On Android 7–11 this camera preview approximation is not available, but the selected preset is still applied in Creator Studio.
- Added unit tests for catalog uniqueness, category coverage, video-compatible filters and unknown-preset fallback.
- Kept Story/Post/Reel publish callback and the existing Supabase `baatly-r2-media` presigned-upload flow untouched. Edited media continues through the existing publication callback and R2 upload service.

## Current scope / not yet implemented

- This change does **not** include real face-landmark tracking, Snapchat-style 3D masks or a complete AR lens runtime. The `Beauty` preset is the GPUImage Plus face beautification filter, not a general-purpose face tracker.
- The camera preview currently uses an Android colour-matrix approximation rather than the same GPUImage Plus shader pipeline used for final photo rendering.
- GPUImage Plus native integration, Media3 rendering, actual playback/export and R2 uploads still require an Android device/runtime smoke test after a successful build.

## Validation performed

- `BaatlyFilterCatalog.kt` compiled successfully with the available standalone Kotlin compiler.
- Compared the working tree to the provided v44 ZIP: changes are confined to the editor/filter files, Gradle dependency/version declarations, and new filter catalog test/report files. `SupabaseDataService.kt` and the R2 upload edge-function wiring are unchanged.
- Attempted `./gradlew :app:assembleDebug --no-daemon`, but the wrapper could not download Gradle 9.3.1 because this environment could not resolve `services.gradle.org` (`UnknownHostException`). Android SDK environment variables and `android.jar` were not available in this runtime. Therefore a full Android build and device test could not be verified here; this ZIP is updated source, not a verified APK.
