# BAATLY Super AI conversation fix (Worker v1.6.3)

## Issue
For a simple greeting such as `hi`, the LLM returned an internal tool-routing explanation (for example, saying there was no function to call) instead of a natural user-facing reply.

## Live backend fix
- Deployed Cloudflare Worker `baatly-ai-gateway` version `1.6.3`.
- Added a user-facing response contract to the agent route: never expose tool selection or internal routing, and answer in the user's language.
- Simple greetings bypass tool-selection inference and use normal chat inference.
- Added detection for known tool-router leakage. Such output is retried through normal chat inference; if it still leaks, a short safe fallback is returned instead of internal commentary.
- Existing web search, URL reading, and explicit memory-save tools remain available for non-greeting requests.
- The response continues to use the expected OpenAI-compatible `choices[0].message.content` shape.

## App bundle
`SuperAiScreen.kt` has the same user-facing instruction for the next APK build, and status text no longer says it is choosing tools. The current installed APK already targets the corrected Worker host, so this backend response fix should be picked up by new messages without rebuilding the APK. Starting a fresh chat / force-closing and reopening BAATLY helps avoid carrying the previous bad response in visible chat history.

## Verification / limitations
- Cloudflare API accepted the Worker upload and automatically deployed the new version.
- JavaScript source `node --check` passed on the bundled Worker source.
- A direct public `/health` fetch could not be made from the build container because its DNS/network cannot resolve the `workers.dev` hostname. An authenticated end-to-end response from the user's handset is therefore not claimed as independently tested.
