# BAATLY User App v40 — Social, Upload Audio, Highlights and Artwork Fixes

## Live Supabase repair
- Removed the stale global `private.baatly_api_pre_request()` rule that returned HTTP 402 for Social/Story/Follow RPC and table requests.
- Corrected the remaining maintenance-only PostgREST error details to include the required `headers` object.
- Verified `social_search_profiles('ruhi', 10)` executes and returns a JSON array; the rollback-only post/story creation checks passed without leaving test content behind.
- Confirmed `social_media_enabled` is `true`, and the active `social_highlights`, `social_highlight_items`, and `streaming_catalog` tables exist.
- Deployed `baatly-r2-media` Edge Function v10. It now supports `complete_highlight_upload` so an authenticated user can upload a photo/video and save a named Highlight without needing an active Story first. The cleanup action allows deletion only beneath that user's own generated media prefixes.

## Android source changes
- Astrology is a native Compose animated solar system: moving planets, orbit rings and stars on a darker plum/navy background with pink and gold accents. No photo is used for the Astrology artwork.
- Super AI has a darker plum background, animated native orbit/ribbon artwork, and concise copy; the former poster-image layout is removed from this screen.
- Reels and Story autoplay used to call `MediaPlayer.setVolume(0f, 0f)`. It now sets volume to `1f` so the video’s original audio can play. Full-screen video detection also recognizes `.3gp`.
- Post, Story and Reel selection now streams directly from the content URI into a short-lived R2 signed PUT URL instead of first copying the complete video to cache. R2 PUT uses a longer timeout suitable for large files; providers without a known content length still use a safe temp-file fallback.
- The profile Highlight dialog supports both saving an active Story and uploading a photo/video directly under a required Highlight name. The Edge Function stores the named Highlight and its media item in `social_highlights` / `social_highlight_items`.
- Existing follow/follower counts remain backed by actual database relationships; zero counts are real when there are no rows.
- `versionCode` remains **40**.

## Verification limitations
- ZIP integrity is checked.
- The live Supabase function deploy returned `ACTIVE`, version 11. Database/search and rollback-only content-creation checks were verified.
- Android compilation could not run here because `services.gradle.org` failed DNS resolution (`UnknownHostException`). The APK build is **not** claimed as verified. After uploading the ZIP to GitHub Actions, run the Release APK workflow and review any new compiler output.
- Actual audio playback, long-video throughput and a full authenticated R2 upload/Highlights round-trip still need verification on a device because this environment cannot run the Android app with a live session.
