# BAATLY User App — v41 Social Media & Creator Studio Fixes

## App changes

- Fixed photo export's bounds decode handling. `BitmapFactory` intentionally returns `null` when `inJustDecodeBounds` is enabled; that normal result was being interpreted as an unreadable photo. The exporter now checks whether the source stream opened, then checks the decoded dimensions, and supports both cache-file URIs and content URIs.
- Stabilized media selection by copying selected photos/videos into the app cache before opening Creator Studio. This avoids many provider-URI lifetime issues and keeps the file extension/MIME aligned for upload.
- Replaced the Android system audio-file picker with a BAATLY Music Library dialog backed by the existing `baatly-r2-media` `list_music_library` action. Only published, licensed catalog entries are returned.
- Combined each user's stories into a single story bubble. Tapping it plays that user's stories sequentially in chronological order with progress segments and tap-to-advance navigation.
- Added cached poster-frame extraction for video/reel tiles in profile grids and the feed, so videos have a visible preview before opening the player.
- Simplified the camera to CameraX still capture and removed CameraX Media3 GL camera effects from the preview/capture path. Chosen filter is passed into Creator Studio for processing after capture, reducing the risk of device-specific camera crashes.
- Bumped Android `versionCode` from 40 to 41.

## Backend/R2 audit

The source is configured for Supabase project `qewhxsbrnlgunygghpez`. Its `baatly-r2-media` Edge Function is active (v13) and already has R2 upload, signed playback URL, story/feed, and licensed music-library actions. Existing SQL schema supports video `media_type` for posts/stories, so no schema migration was needed for these UI fixes.

Read-only counts from the connected backend at the time of this patch:

- `social_posts`: 12 rows, 1 identified video row.
- `social_stories`: 3 rows, 2 identified video rows.
- `baatly_music_tracks`: 0 rows (no tracks currently published in the licensed music catalog).

The app music selector is now wired to the server catalog, but it will correctly show an empty state until an admin uploads and publishes tracks for which BAATLY has distribution rights. No dummy songs were inserted, and no R2 secrets, user data, or production rows were changed.

## Build validation

A Gradle Kotlin compile was attempted, but the environment could not download the configured Gradle 9.3.1 distribution because `services.gradle.org` was unreachable (`UnknownHostException`). Please build the included project in an environment with Gradle/network dependencies available and test camera, photo export, R2 playback, and music export on a physical Android device before release.
