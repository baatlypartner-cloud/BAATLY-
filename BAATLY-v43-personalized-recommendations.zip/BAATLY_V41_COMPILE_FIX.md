# BAATLY User App v41 — Kotlin Compile Fix

## Fix applied

The `:app:compileReleaseKotlin` failure shown in the reported build was caused by `MediaEditorScreen.kt` calling `Modifier.heightIn(...)` without importing `androidx.compose.foundation.layout.heightIn`.

Added the missing import:

`import androidx.compose.foundation.layout.heightIn`

No app version or backend configuration was changed for this compile fix; versionCode remains 41.

## Validation status

The source was checked to confirm that the new import is present and that the `heightIn` call sites are in the same file. A Gradle compile was attempted locally, but the wrapper could not download Gradle 9.3.1 because `services.gradle.org` was unreachable (`UnknownHostException`). Therefore a successful full APK build has not been verified in this environment. Re-run the existing GitHub Actions Release APK workflow to verify compilation.
