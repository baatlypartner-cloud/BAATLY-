# BAATLY User App — v43 Personalized Recommendations

## User-facing additions

- Added **For You / Following** selectors to the Feed and Reels surfaces.
- Reels use a separate backend query that ranks **video-only content**, rather than filtering videos out of the first page of mixed photo/video posts.
- Reels viewing duration now generates `impression`, `skip`, `watch`, or `complete` events. Under 2 seconds is classified as a quick skip; 8 seconds or more is classified as a completed/long watch signal. These are heuristic signals, not proof that a particular video reached its end.
- Successful likes and comments add positive recommendation feedback events.
- Added a Reel **More → Not interested** action. It removes the Reel from the current local list immediately, stores negative feedback, and the backend excludes that post from For You for 14 days.
- Added a trending hashtag strip on the feed, hashtag suggestions/autocomplete in Search and Creator Studio, and a hashtag detail header with posts/Reels counts and recent-post counts.
- Added curated starter tags (such as travel, nature, funny, dance, food and fashion) so autocomplete is useful before the community has published many tagged posts. These starter suggestions are labeled **Explore hashtags**, not falsely presented as trending.
- Incremented `versionCode` to **43** and `versionName` to **1.0.43**.

## Backend changes already applied to the connected BAATLY project

- Added `social_recommendation_events` to store event kind, watch duration, owner and hashtag snapshot. The table has RLS enabled, direct API table privileges are revoked, and it is written through an authenticated security-definer RPC. The RPC verifies that `like`, `comment`, and `follow` feedback corresponds to actual recent/active records before accepting it.
- `social_get_feed` now ranks candidates using recent watched/completed/skipped/liked/commented events, overlap with hashtags on previously liked content, prior creator views, follows, engagement and exponential time decay. `not_interested` feedback removes that same post from For You for 14 days.
- The ranking is a transparent heuristic recommender, **not a trained machine-learning model**. It can adapt from user behaviour after events accumulate; a new account will rely more on broad/current content and followed creators.
- Added `social_get_trending_hashtags`, `social_suggest_hashtags` and `social_get_hashtag_details`. Trending results are based on real tagged content from approved visible Posts/Reels; when there are no hashtags published yet, autocomplete uses the curated catalog with zero counts.
- Added `social_hashtag_catalog` starter rows, server-side caption hashtag extraction/backfill, and a GIN index for hashtag arrays.
- Updated `social_get_feed` to support `reels_for_you` and `reels_following` modes and return only video content for those modes.
- Deployed `baatly-r2-media` Edge Function **version 16** so it passes the new Reels feed-mode values to the recommendation RPC.
- Backend functions enforce authenticated access. Search/trending respects content visibility and block relationships.

## Current data note

At the time of the backend check, there were **0 existing Posts with hashtags** in the connected project. Therefore the app will show “Explore hashtags” starter suggestions until users publish real tagged content; genuine trending counts and tag pages will populate from actual Posts/Reels. No fake engagement or trend counts are inserted.

## Validation status

- Verified the backend suggestion RPC returns starter tags.
- Verified the `social_get_feed(..., 'reels_for_you')` RPC returned video-only content (no non-video rows) for the test user context.
- Verified new social recommendation RPCs are executable by `authenticated` and not by `anon`.
- ZIP/source structure checks passed, and a syntax-diagnostic scan found no parser-level Kotlin errors. Full Gradle compilation **could not be run** because the configured Gradle 9.3.1 distribution host (`services.gradle.org`) was unreachable from this environment; Kotlin type-checking is therefore not confirmed. A GitHub Actions release build and real-device check remain required before publishing.

## Device tests

1. Search → Hashtags while the catalogue is empty; confirm “Explore hashtags” appears and a tap opens the tag results/details.
2. In Creator Studio, type `#tr` in a Post/Reel caption; select a suggestion and confirm it replaces the active hashtag token.
3. Publish tagged Posts/Reels, then confirm real trending counts and hashtag pages update.
4. Switch Feed between For You and Following.
5. Switch Reels between For You and Following; confirm every card is a video and the feed isn't limited to videos that happen to be in the first mixed-content page.
6. Watch a Reel for a few seconds, quickly skip another, and tap More → Not interested on a third; confirm the last disappears and isn't recommended in For You after a refresh.
7. Like/comment on content, browse more content, and verify the ranking gradually uses these signals. New users will not have a fully personalised order until enough behavioural events have accumulated.
