package com.example.ui.media

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File

/**
 * Shared disk-cached video player for Reels, Stories and full-screen media.
 * R2 signed URLs contain short-lived query parameters; using the stable object path as the
 * cache key lets later signed URLs reuse already-buffered bytes for that same private object.
 */
private object BaatlyPlaybackCache {
    @Volatile private var instance: Cache? = null

    fun get(context: android.content.Context): Cache = instance ?: synchronized(this) {
        instance ?: SimpleCache(
            File(context.applicationContext.cacheDir, "baatly_media_playback_cache"),
            LeastRecentlyUsedCacheEvictor(192L * 1024L * 1024L),
            StandaloneDatabaseProvider(context.applicationContext)
        ).also { instance = it }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun BaatlyVideoPlayer(
    url: String,
    shouldPlay: Boolean,
    modifier: Modifier = Modifier,
    loop: Boolean = true,
    soundEnabled: Boolean = true,
    cropToFill: Boolean = true,
    showControls: Boolean = false,
    filterName: String = "Original"
) {
    val context = LocalContext.current
    var buffering by remember(url) { mutableStateOf(true) }
    var failed by remember(url) { mutableStateOf(false) }

    val player = remember(url) {
        val cache = BaatlyPlaybackCache.get(context)
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("BAATLY-Android")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(20_000)
        val upstream = DefaultDataSource.Factory(context, httpFactory)
        val cacheFactory = CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(upstream)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(1_500, 18_000, 250, 750)
            .build()
        ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(cacheFactory))
            .build()
            .apply {
                repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                volume = if (soundEnabled) 1f else 0f
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                        .build(),
                    true
                )
                setHandleAudioBecomingNoisy(true)
                val stableCacheKey = url.substringBefore('?')
                val itemBuilder = MediaItem.Builder().setUri(url)
                if (stableCacheKey.startsWith("http")) itemBuilder.setCustomCacheKey(stableCacheKey)
                setMediaItem(itemBuilder.build())
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        buffering = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
                        if (playbackState == Player.STATE_READY) failed = false
                    }
                    override fun onPlayerError(error: PlaybackException) {
                        failed = true
                        buffering = false
                    }
                })
                // Prepare paused neighbours too: the Compose pager keeps one adjacent page composed,
                // allowing ExoPlayer's shared disk cache to warm up before the user swipes to it.
                prepare()
                playWhenReady = shouldPlay
                setVideoEffects(com.example.ui.media.MediaEditorExporter.videoFilterEffects(filterName))
            }
    }

    LaunchedEffect(player, shouldPlay, soundEnabled, loop, filterName) {
        player.playWhenReady = shouldPlay
        player.volume = if (soundEnabled) 1f else 0f
        player.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.setVideoEffects(com.example.ui.media.MediaEditorExporter.videoFilterEffects(filterName))
        if (shouldPlay && player.playbackState == Player.STATE_IDLE) player.prepare()
    }

    Box(modifier.background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = showControls
                    resizeMode = if (cropToFill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = player
                    setKeepContentOnPlayerReset(true)
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                    keepScreenOn = shouldPlay
                }
            },
            update = { view ->
                view.player = player
                view.resizeMode = if (cropToFill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
                view.keepScreenOn = shouldPlay
            }
        )
        if (buffering && shouldPlay && !failed) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = Color.White)
        }
        if (failed) {
            androidx.compose.material3.Text(
                text = "Video couldn't load. Swipe to retry or check your connection.",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }

    DisposableEffect(player) {
        onDispose {
            player.playWhenReady = false
            player.release()
        }
    }
}
