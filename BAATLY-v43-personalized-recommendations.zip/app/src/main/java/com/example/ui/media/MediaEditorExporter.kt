package com.example.ui.media

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.TextUtils
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Contrast
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.log10

object MediaEditorExporter {
    data class PhotoResult(val uri: Uri, val file: File)

    suspend fun exportPhoto(
        context: Context,
        sourceUri: Uri,
        filter: String,
        rotationDegrees: Int,
        overlayText: String
    ): Uri = withContext(Dispatchers.IO) {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = openSourceStream(context, sourceUri)
            ?: throw IllegalStateException("Could not read the selected photo. Please select it again.")
        // With inJustDecodeBounds=true BitmapFactory intentionally returns null after filling options.
        boundsStream.use { BitmapFactory.decodeStream(it, null, options) }
        if (options.outWidth <= 0 || options.outHeight <= 0) {
            throw IllegalArgumentException("This image format is not supported. Use JPG, PNG or WebP.")
        }
        val longest = max(options.outWidth, options.outHeight)
        val sample = when {
            longest > 6000 -> 4
            longest > 3600 -> 2
            else -> 1
        }
        val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val decoded = openSourceStream(context, sourceUri)?.use { BitmapFactory.decodeStream(it, null, decodeOptions) }
            ?: throw IllegalStateException("Could not decode the selected photo. Try saving it as JPG or PNG and select it again.")
        var rotated = decoded
        if (rotationDegrees % 360 != 0) {
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
            if (rotated !== decoded) decoded.recycle()
        }
        val filtered = Bitmap.createBitmap(rotated.width, rotated.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(androidColorMatrix(filter))
        }
        Canvas(filtered).drawBitmap(rotated, 0f, 0f, paint)
        if (rotated !== decoded) rotated.recycle() else decoded.recycle()
        val cleanOverlay = overlayText.trim().take(80)
        if (cleanOverlay.isNotBlank()) drawTextOverlay(filtered, cleanOverlay)
        val output = File(context.cacheDir, "baatly_edit_${System.currentTimeMillis()}.jpg")
        FileOutputStream(output).use { stream ->
            if (!filtered.compress(Bitmap.CompressFormat.JPEG, 91, stream)) throw IllegalStateException("Could not encode edited photo")
            stream.flush()
        }
        filtered.recycle()
        Uri.fromFile(output)
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    suspend fun exportVideo(
        context: Context,
        sourceUri: Uri,
        musicUri: Uri?,
        filter: String,
        rotationDegrees: Int,
        trimStartMs: Long,
        trimEndMs: Long,
        overlayText: String,
        originalAudioVolume: Float = 0.35f,
        musicVolume: Float = 0.82f
    ): Uri {
        val outputFile = File(context.cacheDir, "baatly_edit_${System.currentTimeMillis()}.mp4")
        val overlayBitmap = if (overlayText.isNotBlank()) withContext(Dispatchers.IO) {
            makeVideoTextOverlay(context, sourceUri, overlayText.trim().take(80))
        } else null
        val editedMediaItem = withContext(Dispatchers.Main.immediate) {
            val clippingBuilder = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(trimStartMs.coerceAtLeast(0L))
            if (trimEndMs > trimStartMs && trimEndMs > 0L) clippingBuilder.setEndPositionMs(trimEndMs)
            val mediaItem = MediaItem.Builder().setUri(sourceUri).setClippingConfiguration(clippingBuilder.build()).build()
            val effects = videoFilterEffects(filter).toMutableList()
            if (rotationDegrees % 360 != 0) effects.add(ScaleAndRotateTransformation.Builder().setRotationDegrees(rotationDegrees.toFloat()).build())
            if (overlayBitmap != null) effects.add(OverlayEffect(listOf(BitmapOverlay.createStaticBitmapOverlay(overlayBitmap))))
            val sourceAudioProcessors = if (musicUri != null) {
                listOf(GainProcessor(DefaultGainProvider.Builder(volumeToDecibels(originalAudioVolume)).build()))
            } else emptyList()
            EditedMediaItem.Builder(mediaItem).setEffects(Effects(sourceAudioProcessors, effects)).build()
        }
        val videoSequence = EditedMediaItemSequence.withAudioAndVideoFrom(listOf(editedMediaItem))
        val composition = if (musicUri != null) {
            val musicGain = GainProcessor(DefaultGainProvider.Builder(volumeToDecibels(musicVolume)).build())
            val musicItem = EditedMediaItem.Builder(MediaItem.fromUri(musicUri))
                .setEffects(Effects(listOf(musicGain), emptyList()))
                .build()
            val musicSequence = EditedMediaItemSequence.withAudioFrom(listOf(musicItem)).buildUpon().setIsLooping(true).build()
            Composition.Builder(videoSequence, musicSequence).build()
        } else {
            Composition.Builder(videoSequence).build()
        }
        return try {
            withContext(Dispatchers.Main.immediate) {
                suspendCancellableCoroutine<Unit> { continuation ->
                    val transformer = Transformer.Builder(context.applicationContext)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setAudioMimeType(MimeTypes.AUDIO_AAC)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                if (continuation.isActive) continuation.resume(Unit)
                            }
                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                if (continuation.isActive) continuation.resumeWithException(exportException)
                            }
                        }).build()
                    continuation.invokeOnCancellation { runCatching { transformer.cancel() }; outputFile.delete() }
                    transformer.start(composition, outputFile.absolutePath)
                }
            }
            if (!outputFile.exists() || outputFile.length() <= 0L) throw IllegalStateException("Edited video export returned an empty file")
            Uri.fromFile(outputFile)
        } catch (error: Exception) {
            outputFile.delete()
            throw error
        } finally {
            overlayBitmap?.recycle()
        }
    }


    @androidx.annotation.OptIn(UnstableApi::class)
    fun videoFilterEffects(filter: String): List<androidx.media3.common.Effect> = when (filter) {
        "Mono" -> listOf(RgbFilter.createGrayscaleFilter())
        "Invert" -> listOf(RgbFilter.createInvertedFilter())
        "Warm" -> listOf(RgbAdjustment.Builder().setRedScale(1.10f).setGreenScale(1.02f).setBlueScale(0.89f).build())
        "Vivid" -> listOf(Contrast(0.16f), Brightness(0.035f))
        "Vintage" -> listOf(RgbAdjustment.Builder().setRedScale(1.08f).setGreenScale(0.99f).setBlueScale(0.86f).build(), Contrast(-0.06f))
        else -> emptyList()
    }

    private fun volumeToDecibels(volume: Float): Float {
        val safe = volume.coerceIn(0f, 1f)
        return if (safe <= 0.0001f) -80f else (20f * log10(safe)).coerceIn(-80f, 6f)
    }

    fun getDurationMs(context: Context, uri: Uri): Long = runCatching {
        MediaMetadataRetriever().use { retriever ->
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        }
    }.getOrDefault(0L)

    private fun openSourceStream(context: Context, uri: Uri): java.io.InputStream? {
        if (uri.scheme.equals("file", ignoreCase = true)) {
            val path = uri.path ?: return null
            return File(path).takeIf { it.isFile && it.length() > 0L }?.inputStream()
        }
        return context.contentResolver.openInputStream(uri)
    }

    fun isVideo(context: Context, uri: Uri): Boolean {
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        return mime.startsWith("video/") || uri.toString().substringBefore('?').substringAfterLast('.', "").lowercase() in setOf("mp4", "m4v", "mov", "webm", "3gp", "m3u8")
    }

    fun composeFilter(filter: String): androidx.compose.ui.graphics.ColorFilter? {
        val values = when (filter) {
            "Mono" -> floatArrayOf(
                0.213f, 0.715f, 0.072f, 0f, 0f,
                0.213f, 0.715f, 0.072f, 0f, 0f,
                0.213f, 0.715f, 0.072f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            "Warm", "Vintage" -> floatArrayOf(
                1.08f, 0f, 0f, 0f, if (filter == "Vintage") 5f else 3f,
                0f, 1.01f, 0f, 0f, 0f,
                0f, 0f, if (filter == "Vintage") 0.84f else 0.90f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            "Vivid" -> floatArrayOf(
                1.15f, 0f, 0f, 0f, 0f,
                0f, 1.15f, 0f, 0f, 0f,
                0f, 0f, 1.15f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            "Invert" -> floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
            else -> return null
        }
        return androidx.compose.ui.graphics.ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(values))
    }

    private fun androidColorMatrix(filter: String): ColorMatrix = when (filter) {
        "Mono" -> ColorMatrix().apply { setSaturation(0f) }
        "Warm" -> ColorMatrix(floatArrayOf(
            1.08f, 0f, 0f, 0f, 3f,
            0f, 1.01f, 0f, 0f, 0f,
            0f, 0f, 0.90f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
        "Vintage" -> ColorMatrix(floatArrayOf(
            0.95f, 0.18f, 0.08f, 0f, 5f,
            0.10f, 0.93f, 0.05f, 0f, 1f,
            0.04f, 0.12f, 0.78f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
        "Vivid" -> ColorMatrix().apply { setSaturation(1.35f) }
        "Invert" -> ColorMatrix(floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        ))
        else -> ColorMatrix()
    }

    private fun drawTextOverlay(bitmap: Bitmap, text: String) {
        val canvas = Canvas(bitmap)
        val stripHeight = (bitmap.height * 0.16f).coerceAtLeast(88f)
        val top = bitmap.height - stripHeight
        val backdrop = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AndroidColor.argb(88, 12, 8, 24) }
        canvas.drawRoundRect(RectF(0f, top, bitmap.width.toFloat(), bitmap.height.toFloat()), 0f, 0f, backdrop)
        val fontSize = (bitmap.width * 0.055f).coerceIn(24f, 72f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.WHITE
            textSize = fontSize
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            setShadowLayer(fontSize * 0.15f, 1f, 2f, AndroidColor.BLACK)
        }
        val maxTextWidth = bitmap.width * 0.88f
        val label = TextUtils.ellipsize(text, android.text.TextPaint(paint), maxTextWidth, TextUtils.TruncateAt.END).toString()
        canvas.drawText(label, bitmap.width * 0.06f, top + stripHeight * 0.62f, paint)
    }

    private fun makeVideoTextOverlay(context: Context, uri: Uri, text: String): Bitmap = MediaMetadataRetriever().use { retriever ->
        retriever.setDataSource(context, uri)
        val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()?.coerceIn(320, 1920) ?: 720
        val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()?.coerceIn(320, 1920) ?: 1280
        val overlay = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        drawTextOverlay(overlay, text)
        overlay
    }
}
