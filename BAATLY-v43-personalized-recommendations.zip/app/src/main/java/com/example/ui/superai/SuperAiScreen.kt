package com.example.ui.superai

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private val AiInk = Color(0xFFF9F1FF)
private val AiMuted = Color(0xFFD1BEDD)
private val AiPink = Color(0xFFFF3D91)
private val AiGold = Color(0xFFFFC875)

@Composable
fun SuperAiScreen(onBackToSocial: () -> Unit) {
    val motion = rememberInfiniteTransition(label = "super-ai-orb-motion")
    val rotation by motion.animateFloat(0f, 360f, infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart), label = "orb-rotation")
    val pulse by motion.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "orb-pulse")
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF050817), Color(0xFF0B1030), Color(0xFF20104D), Color(0xFF080A1C)))
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.5f, size.height * 0.39f)
            val radius = size.minDimension * 0.26f * pulse
            drawCircle(Brush.radialGradient(listOf(Color(0x995B36D8), Color(0x5530268C), Color.Transparent), center, radius * 2.1f), radius * 2.1f, center)
            for (i in 0 until 56) {
                val x = ((i * 89 + 13) % 997) / 997f * size.width
                val y = ((i * 151 + 7) % 991) / 991f * size.height
                drawCircle(if (i % 6 == 0) AiGold.copy(alpha = 0.82f) else Color.White.copy(alpha = 0.30f), (if (i % 6 == 0) 1.7f else 0.9f).dp.toPx(), Offset(x, y))
            }
            // Animated orbit ribbons: artwork is part of the screen theme, not a poster image.
            for (i in 0..2) {
                val angle = Math.toRadians((rotation + i * 60f).toDouble())
                val rx = radius * (1.18f + i * 0.2f)
                val ry = radius * (0.54f + i * 0.12f)
                rotate(degrees = (rotation + i * 60f) % 360f, pivot = center) {
                    drawOval(
                        color = listOf(AiPink, Color(0xFFB77BFF), AiGold)[i].copy(alpha = 0.64f),
                        topLeft = Offset(center.x - rx, center.y - ry), size = Size(rx * 2f, ry * 2f),
                        style = Stroke(width = 2.0f.dp.toPx())
                    )
                }
            }
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF2FF), Color(0xFFFF72CD), Color(0xFFB92DDF), Color(0xFF5320A2), Color(0xFF15153F)), center, radius), radius * 0.77f, center)
            drawCircle(Color.White.copy(alpha = 0.46f), radius * 0.12f, Offset(center.x - radius * 0.22f, center.y - radius * 0.30f))
            val ribbon = (rotation * Math.PI / 180.0)
            val p1 = Offset(center.x + (radius * 0.9f * cos(ribbon)).toFloat(), center.y + (radius * 0.35f * sin(ribbon)).toFloat())
            drawCircle(AiGold, radius * 0.055f, p1)
        }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("BAATLY", color = AiInk, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
                    Text("S U P E R  A I", color = AiPink, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.5.sp)
                }
                Icon(Icons.Filled.AutoAwesome, contentDescription = "Super AI", tint = AiGold, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.weight(1.22f))
            Text("BAATLY SUPER AI", color = AiInk, fontSize = 27.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, letterSpacing = 0.2.sp)
            Spacer(Modifier.height(7.dp))
            Text("Your AI companion", color = AiMuted, fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(22.dp))
            Surface(
                color = Color(0xFF811858),
                shape = RoundedCornerShape(28.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                shadowElevation = 12.dp
            ) {
                Row(Modifier.padding(horizontal = 25.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
                    Text("COMING SOON", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.8.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("A smarter way to connect.", color = AiMuted.copy(alpha = 0.88f), fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1f))
        }
    }
}
