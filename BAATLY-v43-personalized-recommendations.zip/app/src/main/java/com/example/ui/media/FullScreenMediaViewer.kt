package com.example.ui.media

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage

@Composable
fun FullScreenMediaViewer(
    mediaUrl: String,
    mediaType: String = "image",
    onDismiss: () -> Unit
) {
    BackHandler { onDismiss() }
    val isVideo = mediaType.equals("video", ignoreCase = true) || mediaUrl.substringBefore('?').substringAfterLast('.', "").lowercase() in setOf("mp4", "mov", "m4v", "webm", "m3u8", "3gp")
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Box(Modifier.fillMaxSize().background(Color.Black).testTag("fullscreen_media_viewer")) {
        if (isVideo) {
            BaatlyVideoPlayer(
                url = mediaUrl,
                shouldPlay = true,
                loop = false,
                soundEnabled = true,
                cropToFill = false,
                showControls = true,
                modifier = Modifier.fillMaxSize().align(Alignment.Center)
            )
        } else {
            SubcomposeAsyncImage(
                model = mediaUrl,
                contentDescription = "Full Screen Media",
                contentScale = ContentScale.Fit,
                loading = { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) } },
                error = { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Could not load photo", color = Color.White) } },
                modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        if (scale > 1f) { offsetX += pan.x; offsetY += pan.y } else { offsetX = 0f; offsetY = 0f }
                    }
                }.graphicsLayer(scaleX = scale, scaleY = scale, translationX = offsetX, translationY = offsetY)
            )
        }
        IconButton(
            onClick = onDismiss,
            modifier = Modifier.statusBarsPadding().padding(16.dp).size(44.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.6f)).align(Alignment.TopStart).testTag("btn_close_fullscreen_media")
        ) { Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(24.dp)) }
    }
}
