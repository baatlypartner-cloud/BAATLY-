package com.example.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.HomeMode
import com.example.ui.Screen
import com.example.ui.components.HostCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: BaatlyViewModel) {
    val homeMode by viewModel.homeMode.collectAsState()
    val availablePartners by viewModel.availablePartners.collectAsState()
    val isLoadingPartners by viewModel.isLoadingPartners.collectAsState()
    val wallet by viewModel.walletSummary.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()
    val hostPublicRatings by viewModel.hostPublicRatings.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val displayedPartners = remember(availablePartners, homeMode) {
        when (homeMode) {
            HomeMode.CALL -> availablePartners.filter { it.audioEnabled }
            HomeMode.VIDEO -> availablePartners.filter { it.videoEnabled }
            HomeMode.CHAT -> availablePartners.filter { it.chatEnabled }
        }
    }
    val filteredPartners = remember(displayedPartners, searchQuery) {
        if (searchQuery.isBlank()) displayedPartners
        else displayedPartners.filter {
            it.displayName.contains(searchQuery, ignoreCase = true) ||
                (it.bio?.contains(searchQuery, ignoreCase = true) == true)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
        RelationshipHeader(
            balance = wallet.availableBalanceRupees,
            onWalletClick = { viewModel.setScreen(Screen.WALLET) },
            onMessagesClick = { viewModel.setScreen(Screen.CHAT_LIST) }
        )

        PullToRefreshBox(
            isRefreshing = isLoadingPartners && availablePartners.isNotEmpty(),
            onRefresh = {
                viewModel.refreshPartners()
                viewModel.refreshWallet()
            },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "relationship_greeting") {
                    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
                    val greeting = when (hour) {
                        in 4..11 -> "Good morning 👋"
                        in 12..16 -> "Good afternoon 👋"
                        else -> "Good evening 👋"
                    }
                    Text(
                        text = greeting,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2B163D),
                            fontSize = 25.sp
                        ),
                        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 2.dp)
                    )
                }
                item(key = "relationship_search") {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search hosts", color = TextTertiary) },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search hosts", tint = TextTertiary) },
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VibrantPink,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface
                        ),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).testTag("input_search_hosts")
                    )
                }
                item(key = "relationship_modes") {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xFFFFF0F3),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(4.dp)) {
                            SegmentButton("Voice", Icons.Filled.Call, homeMode == HomeMode.CALL, Modifier.weight(1f), "tab_call_mode", VibrantPink) {
                                viewModel.setHomeMode(HomeMode.CALL)
                            }
                            SegmentButton("Video", Icons.Filled.Videocam, homeMode == HomeMode.VIDEO, Modifier.weight(1f), "tab_video_mode", VibrantPink) {
                                viewModel.setHomeMode(HomeMode.VIDEO)
                            }
                            SegmentButton("Love Note", Icons.Filled.Email, homeMode == HomeMode.CHAT, Modifier.weight(1.2f), "tab_chat_mode", VibrantPink) {
                                viewModel.setHomeMode(HomeMode.CHAT)
                            }
                        }
                    }
                }
                item(key = "relationship_available_title") {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Available now", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color(0xFF2B163D)))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(OnlineGreen))
                            Text("${filteredPartners.size} online", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                        }
                    }
                }
                if (isLoadingPartners && filteredPartners.isEmpty()) {
                    item(key = "relationship_loading") {
                        Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = VibrantPink)
                        }
                    }
                } else if (filteredPartners.isEmpty()) {
                    item(key = "relationship_empty") {
                        Box(Modifier.fillMaxWidth().height(300.dp).padding(28.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(42.dp))
                                Text(
                                    text = when (homeMode) {
                                        HomeMode.CALL -> "No hosts available for voice calls right now"
                                        HomeMode.VIDEO -> "No hosts available for video calls right now"
                                        HomeMode.CHAT -> "No hosts available for Love Notes right now"
                                    },
                                    style = MaterialTheme.typography.bodyLarge.copy(color = TextSecondary, fontWeight = FontWeight.Medium)
                                )
                                Text("Pull down to refresh", style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                            }
                        }
                    }
                } else {
                    items(filteredPartners, key = { it.id }) { partner ->
                        val hostUserId = partner.userId?.takeIf { it.isNotBlank() } ?: partner.id
                        Box(Modifier.padding(horizontal = 16.dp)) {
                            HostCard(
                                partner = partner,
                                homeMode = homeMode,
                                onCardClick = { viewModel.openHostProfile(partner) },
                                onActionClick = {
                                    when (homeMode) {
                                        HomeMode.CALL -> viewModel.requestCall(partner)
                                        HomeMode.VIDEO -> viewModel.requestVideoCall(partner)
                                        HomeMode.CHAT -> viewModel.openChatWithHost(partner)
                                    }
                                },
                                dataService = viewModel.dataService,
                                effectivePricing = effectivePricing,
                                publicRating = hostPublicRatings[hostUserId]
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RelationshipHeader(balance: Double, onWalletClick: () -> Unit, onMessagesClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(DarkBackground).statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("BAATLY", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, color = Color(0xFF2B163D), letterSpacing = 0.4.sp))
            Text("R E L A T I O N S H I P", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = VibrantPink, fontSize = 9.sp))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(
                shape = CircleShape,
                color = Color(0xFFFFEFF2),
                modifier = Modifier.clickable(onClick = onWalletClick).testTag("relationship_wallet_badge")
            ) {
                Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Box(Modifier.size(25.dp).clip(CircleShape).background(Color(0xFFFFB703)), contentAlignment = Alignment.Center) {
                        Text("₹", color = Color(0xFF2B163D), fontWeight = FontWeight.Black, fontSize = 15.sp)
                    }
                    Text("₹${"%.0f".format(balance)}", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
            IconButton(onClick = onMessagesClick, modifier = Modifier.size(42.dp).testTag("btn_relationship_messages")) {
                Icon(Icons.Filled.Email, contentDescription = "Messages", tint = Color(0xFF2B163D), modifier = Modifier.size(25.dp))
            }
        }
    }
}

@Composable
private fun SegmentButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    testTag: String,
    selectedColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) selectedColor else Color.Transparent,
        modifier = modifier.testTag(testTag).clickable(onClick = onClick)
    ) {
        Row(modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(icon, contentDescription = null, tint = if (selected) Color.White else TextSecondary, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Text(title, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (selected) Color.White else TextSecondary))
        }
    }
}
