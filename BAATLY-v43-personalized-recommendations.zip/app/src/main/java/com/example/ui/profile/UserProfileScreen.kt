package com.example.ui.profile

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import coil.compose.AsyncImage
import com.example.data.model.SocialPost
import com.example.domain.BillingEngine
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.BaatlyTopBar
import com.example.ui.legal.LegalPage
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    // Collect Authoritative State from ViewModel
    val currentUser by viewModel.currentUser.collectAsState()
    val wallet by viewModel.walletSummary.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val mySocialProfile by viewModel.mySocialProfile.collectAsState()
    val mySocialPosts by viewModel.mySocialPosts.collectAsState()
    val isMySocialLoading by viewModel.isMySocialLoading.collectAsState()

    // Dialog & Post Management State
    var showEditDialog by remember { mutableStateOf(false) }
    var editDisplayName by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var editBio by remember { mutableStateOf(currentUser?.bio ?: "") }
    var editAvatarFile by remember { mutableStateOf<File?>(null) }
    var editAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var isUpdatingProfile by remember { mutableStateOf(false) }
    var editProfileError by remember { mutableStateOf<String?>(null) }

    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var isSubmittingAccountDeletion by remember { mutableStateOf(false) }
    var accountDeletionErrorMessage by remember { mutableStateOf<String?>(null) }
    var showAccountDeletionSuccessDialog by remember { mutableStateOf(false) }

    // Selected Post for Preview / Deletion
    var selectedPostForDetail by remember { mutableStateOf<SocialPost?>(null) }
    var postPendingDeletion by remember { mutableStateOf<SocialPost?>(null) }
    var isDeletingPost by remember { mutableStateOf(false) }

    // Image Picker for Edit Profile
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            editAvatarUri = uri
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val tempFile = File(context.cacheDir, "profile_edit_${System.currentTimeMillis()}.jpg")
                tempFile.outputStream().use { output ->
                    inputStream?.copyTo(output)
                }
                editAvatarFile = tempFile
            } catch (e: Exception) {
                editProfileError = "Failed to load image: ${e.message}"
            }
        }
    }

    // Auto-fetch profile on initial display
    LaunchedEffect(Unit) {
        viewModel.loadMySocialProfile()
    }

    // Handle Back Press when Drawer is open
    BackHandler(enabled = drawerState.isOpen) {
        coroutineScope.launch { drawerState.close() }
    }

    val rawAvatarUrl = mySocialProfile?.avatarUrl ?: currentUser?.avatarUrl
    val resolvedAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(rawAvatarUrl, viewModel.dataService)
    val isResolvingAvatar = !rawAvatarUrl.isNullOrBlank() && rawAvatarUrl != "null" && resolvedAvatarUrl == null

    val effectiveDisplayName = mySocialProfile?.displayName?.takeIf { it.isNotBlank() }
        ?: currentUser?.displayName?.takeIf { it.isNotBlank() }
        ?: "Baatly User"

    val effectiveUsername = mySocialProfile?.username?.takeIf { it.isNotBlank() }
        ?: currentUser?.username?.takeIf { it.isNotBlank() }
        ?: currentUser?.userId
        ?: "user"

    val effectiveBio = mySocialProfile?.bio?.takeIf { !it.isNullOrBlank() }
        ?: currentUser?.bio?.takeIf { !it.isNullOrBlank() }
        ?: ""

    val postsCount = mySocialProfile?.postsCount ?: mySocialPosts.size
    val followersCount = mySocialProfile?.followersCount ?: 0
    val followingCount = mySocialProfile?.followingCount ?: 0

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        scrimColor = Color.Black.copy(alpha = 0.65f),
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DarkBackground,
                drawerContentColor = TextPrimary,
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .fillMaxHeight()
                    .testTag("profile_sliding_drawer")
            ) {
                ProfileDrawerContent(
                    currentUser = currentUser,
                    walletBalanceRupees = wallet?.balanceRupees ?: 0.0,
                    onNavigate = { screen ->
                        coroutineScope.launch { drawerState.close() }
                        viewModel.setScreen(screen)
                    },
                    onOpenLegal = { page ->
                        coroutineScope.launch { drawerState.close() }
                        viewModel.openLegalPage(page)
                    },
                    onSupportEmail = {
                        coroutineScope.launch { drawerState.close() }
                        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:support.baatly672@gmail.com")
                            putExtra(Intent.EXTRA_SUBJECT, "Baatly Help & Support Request")
                        }
                        try {
                            context.startActivity(emailIntent)
                        } catch (_: Exception) {
                            val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("mailto:support.baatly672@gmail.com"))
                            try {
                                context.startActivity(fallbackIntent)
                            } catch (_: Exception) {
                                viewModel.showUserMessage("Support email: support.baatly672@gmail.com")
                            }
                        }
                    },
                    onSignOut = {
                        coroutineScope.launch { drawerState.close() }
                        viewModel.signOut()
                    },
                    onDeleteAccount = {
                        coroutineScope.launch { drawerState.close() }
                        accountDeletionErrorMessage = null
                        showDeleteAccountDialog = true
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                BaatlyTopBar(
                    walletBalanceRupees = wallet?.balanceRupees ?: 0.0,
                    onWalletClick = { viewModel.setScreen(Screen.WALLET) },
                    onNotificationClick = { viewModel.setScreen(Screen.NOTIFICATIONS) },
                    unreadNotifications = notifications.count { !it.isRead },
                    onRefreshClick = { viewModel.loadMySocialProfile() },
                    onMenuClick = {
                        coroutineScope.launch {
                            if (drawerState.isClosed) drawerState.open() else drawerState.close()
                        }
                    }
                )
            },
            containerColor = DarkBackground
        ) { innerPadding ->
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .testTag("my_profile_grid"),
                contentPadding = PaddingValues(bottom = 80.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // Header (Spans all 3 columns)
                item(span = { GridItemSpan(3) }) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp)
                    ) {
                        // Avatar and Counts Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Avatar
                            Box(
                                modifier = Modifier
                                    .size(86.dp)
                                    .clip(CircleShape)
                                    .background(HostAvatarGradient)
                                    .border(2.5.dp, PrimaryGradient, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (!resolvedAvatarUrl.isNullOrBlank()) {
                                    AsyncImage(
                                        model = resolvedAvatarUrl,
                                        contentDescription = effectiveDisplayName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else if (isResolvingAvatar) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(24.dp),
                                        color = PrimaryLavender,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Text(
                                        text = effectiveDisplayName.take(1).uppercase(),
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontWeight = FontWeight.Black,
                                            color = Color.White.copy(alpha = 0.85f)
                                        )
                                    )
                                }
                            }

                            // Counts: Posts, Followers, Following
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(start = 18.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatCountColumn(count = postsCount.toString(), label = "Posts")
                                StatCountColumn(count = followersCount.toString(), label = "Followers")
                                StatCountColumn(count = followingCount.toString(), label = "Following")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Name & Username
                        Text(
                            text = effectiveDisplayName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "@$effectiveUsername",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = PrimaryLavender,
                                fontWeight = FontWeight.SemiBold
                            )
                        )

                        // Bio
                        if (effectiveBio.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = effectiveBio,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Edit Profile Button (directly visible on main screen)
                        Button(
                            onClick = {
                                editDisplayName = effectiveDisplayName
                                editBio = effectiveBio
                                editAvatarFile = null
                                editAvatarUri = null
                                editProfileError = null
                                isUpdatingProfile = false
                                showEditDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("btn_edit_profile")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Edit,
                                contentDescription = null,
                                tint = TextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Edit Profile",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Grid Section Divider
                        HorizontalDivider(color = DarkBorderSubtle)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.GridOn,
                                contentDescription = "Posts",
                                tint = PrimaryLavender,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "POSTS",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryLavender,
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                    }
                }

                // Empty / Loading State handling
                if (isMySocialLoading && mySocialPosts.isEmpty()) {
                    item(span = { GridItemSpan(3) }) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = PrimaryLavender)
                        }
                    }
                } else if (mySocialPosts.isEmpty()) {
                    item(span = { GridItemSpan(3) }) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp, horizontal = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = DarkSurfaceVariant,
                                modifier = Modifier.size(64.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.PhotoCamera,
                                        contentDescription = null,
                                        tint = TextSecondary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No posts yet",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Share photos and updates on Baatly Social to start building your profile.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.setScreen(Screen.SOCIAL) },
                                colors = ButtonDefaults.buttonColors(containerColor = VibrantPink),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Create Post on Social", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    // 3-Column Image Grid
                    items(mySocialPosts, key = { it.id }) { post ->
                        ProfilePostGridThumbnail(
                            post = post,
                            dataService = viewModel.dataService,
                            onClick = { selectedPostForDetail = post }
                        )
                    }
                }
            }
        }
    }

    // Post Detail / Deletion Dialog
    selectedPostForDetail?.let { post ->
        PostDetailDialog(
            post = post,
            viewModel = viewModel,
            onDismiss = { selectedPostForDetail = null },
            onDeleteClick = {
                postPendingDeletion = post
            }
        )
    }

    // Delete Post Confirmation Dialog
    postPendingDeletion?.let { post ->
        AlertDialog(
            onDismissRequest = {
                if (!isDeletingPost) postPendingDeletion = null
            },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOn),
            title = {
                Text("Delete Post?", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Are you sure you want to delete this post? This action cannot be undone and the media will be removed from Baatly.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        isDeletingPost = true
                        viewModel.deleteSocialPost(post.id) { success, err ->
                            isDeletingPost = false
                            if (success) {
                                postPendingDeletion = null
                                selectedPostForDetail = null
                            }
                        }
                    },
                    enabled = !isDeletingPost,
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    modifier = Modifier.testTag("btn_confirm_delete_post")
                ) {
                    Text(if (isDeletingPost) "Deleting..." else "Delete Post")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { postPendingDeletion = null },
                    enabled = !isDeletingPost,
                    modifier = Modifier.testTag("btn_cancel_delete_post")
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Edit Profile Modal
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isUpdatingProfile) showEditDialog = false
            },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOn),
            containerColor = DarkSurface,
            title = {
                Text("Edit Profile", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Profile Photo preview & picker
                    Box(
                        contentAlignment = Alignment.BottomEnd,
                        modifier = Modifier.clickable(enabled = !isUpdatingProfile) {
                            photoPickerLauncher.launch("image/*")
                        }
                    ) {
                        AsyncImage(
                            model = editAvatarUri ?: resolvedAvatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300",
                            contentDescription = "Profile Photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .border(2.dp, VibrantPink, CircleShape)
                        )
                        Surface(
                            shape = CircleShape,
                            color = VibrantPink,
                            modifier = Modifier.size(26.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.PhotoCamera,
                                    contentDescription = "Change Photo",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    if (!editProfileError.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DangerRed.copy(alpha = 0.15f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = editProfileError ?: "",
                                color = DangerRed,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editDisplayName,
                        onValueChange = { editDisplayName = it },
                        label = { Text("Display Name") },
                        enabled = !isUpdatingProfile,
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryLavender,
                            unfocusedBorderColor = DarkBorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_edit_display_name")
                    )

                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text("Bio") },
                        enabled = !isUpdatingProfile,
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryLavender,
                            unfocusedBorderColor = DarkBorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_edit_bio")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editDisplayName.isBlank()) {
                            editProfileError = "Display name cannot be empty"
                            return@Button
                        }
                        isUpdatingProfile = true
                        editProfileError = null
                        viewModel.updateUserProfile(
                            displayName = editDisplayName.trim(),
                            bio = editBio.trim().takeIf { it.isNotBlank() },
                            avatarFile = editAvatarFile
                        ) { success, errorMsg ->
                            isUpdatingProfile = false
                            if (success) {
                                showEditDialog = false
                                viewModel.loadMySocialProfile()
                            } else {
                                editProfileError = errorMsg ?: "Update failed. Please try again."
                            }
                        }
                    },
                    enabled = !isUpdatingProfile,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender),
                    modifier = Modifier.testTag("btn_save_edit_profile")
                ) {
                    if (isUpdatingProfile) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text("Save Changes")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showEditDialog = false },
                    enabled = !isUpdatingProfile
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Delete Account Dialog
    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isSubmittingAccountDeletion) showDeleteAccountDialog = false
            },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOn),
            containerColor = DarkSurface,
            title = {
                Text("Delete Baatly Account?", color = DangerRed, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Are you sure you want to permanently delete your account?",
                        color = TextPrimary,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        text = "This action is immediate and cannot be undone. All your profile data, active chats, call history, and wallet balances will be deleted.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!accountDeletionErrorMessage.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DangerRed.copy(alpha = 0.15f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = accountDeletionErrorMessage ?: "",
                                color = DangerRed,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isSubmittingAccountDeletion = true
                        accountDeletionErrorMessage = null
                        viewModel.requestAccountDeletion { success, errorMsg ->
                            isSubmittingAccountDeletion = false
                            if (success) {
                                showDeleteAccountDialog = false
                                showAccountDeletionSuccessDialog = true
                            } else {
                                accountDeletionErrorMessage = errorMsg ?: "Account deletion failed. Please try again."
                            }
                        }
                    },
                    enabled = !isSubmittingAccountDeletion,
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    modifier = Modifier.testTag("btn_confirm_delete_account")
                ) {
                    if (isSubmittingAccountDeletion) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text("Delete My Account", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteAccountDialog = false },
                    enabled = !isSubmittingAccountDeletion
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    if (showAccountDeletionSuccessDialog) {
        AlertDialog(
            onDismissRequest = {
                showAccountDeletionSuccessDialog = false
                viewModel.signOut()
            },
            properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOn),
            containerColor = DarkSurface,
            title = {
                Text("Account Deleted", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "Your account and all associated data have been deleted successfully. You have been logged out.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAccountDeletionSuccessDialog = false
                        viewModel.signOut()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryLavender),
                    modifier = Modifier.testTag("btn_dismiss_deletion_success")
                ) {
                    Text("OK")
                }
            }
        )
    }
}

@Composable
private fun StatCountColumn(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextSecondary
            )
        )
    }
}

@Composable
private fun ProfilePostGridThumbnail(
    post: SocialPost,
    dataService: com.example.data.network.SupabaseDataService,
    onClick: () -> Unit
) {
    var resolvedMediaUrl by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(post.mediaPath, post.mediaUrl) {
        val raw = post.mediaUrl?.takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        resolvedMediaUrl = dataService.resolveSocialMediaUrl(raw, isStory = false, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id)
    }

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .background(DarkSurfaceVariant)
            .clickable(onClick = onClick)
            .testTag("post_grid_item_${post.id}")
    ) {
        if (!resolvedMediaUrl.isNullOrBlank()) {
            AsyncImage(
                model = resolvedMediaUrl,
                contentDescription = post.caption.takeIf { it.isNotBlank() } ?: "Post image",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Outlined.Image,
                    contentDescription = null,
                    tint = TextTertiary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
private fun PostDetailDialog(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var resolvedMediaUrl by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(post.mediaPath, post.mediaUrl) {
        val raw = post.mediaUrl?.takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        resolvedMediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, isStory = false, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOn)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = DarkSurface,
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header: Creator name & overflow menu
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = post.creatorName,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        if (post.createdAt.isNotBlank()) {
                            Text(
                                text = post.createdAt.take(10),
                                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                            )
                        }
                    }
                    val currentUserId = viewModel.sessionManager.userId.value.orEmpty()
                    val isOwner = post.isOwner || (currentUserId.isNotBlank() && post.userId == currentUserId)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isOwner) {
                            var showPostMenu by remember { mutableStateOf(false) }
                            Box {
                                IconButton(
                                    onClick = { showPostMenu = true },
                                    modifier = Modifier.testTag("btn_post_menu_${post.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MoreVert,
                                        contentDescription = "Post Options",
                                        tint = TextSecondary
                                    )
                                }
                                DropdownMenu(
                                    expanded = showPostMenu,
                                    onDismissRequest = { showPostMenu = false },
                                    containerColor = DarkSurfaceVariant
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Delete Post", color = DangerRed, fontWeight = FontWeight.Bold) },
                                        leadingIcon = {
                                            Icon(Icons.Outlined.Delete, contentDescription = null, tint = DangerRed)
                                        },
                                        onClick = {
                                            showPostMenu = false
                                            onDeleteClick()
                                        },
                                        modifier = Modifier.testTag("menu_delete_post_${post.id}")
                                    )
                                }
                            }
                            IconButton(
                                onClick = onDeleteClick,
                                modifier = Modifier.testTag("btn_delete_post_${post.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Delete,
                                    contentDescription = "Delete Post",
                                    tint = DangerRed
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextSecondary)
                        }
                    }
                }

                // Image
                if (!resolvedMediaUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = resolvedMediaUrl,
                        contentDescription = post.caption,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 300.dp)
                    )
                }

                // Caption
                if (post.caption.isNotBlank()) {
                    Text(
                        text = post.caption,
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                        modifier = Modifier.padding(14.dp)
                    )
                }

                // Stats footer
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Favorite,
                            contentDescription = "Likes",
                            tint = VibrantPink,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${post.likesCount} likes",
                            style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Mail,
                            contentDescription = "Love Notes",
                            tint = PrimaryLavender,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${post.loveNotesCount} love notes",
                            style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileDrawerContent(
    currentUser: com.example.data.model.UserProfile?,
    walletBalanceRupees: Double,
    onNavigate: (Screen) -> Unit,
    onOpenLegal: (LegalPage) -> Unit,
    onSupportEmail: () -> Unit,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(scrollState)
            .padding(20.dp)
    ) {
        Text(
            text = "Settings & Options",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Wallet Balance Item
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigate(Screen.WALLET) }
                .testTag("drawer_menu_wallet")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(GoldGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "₹",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B1402)
                            )
                        )
                    }
                    Column {
                        Text(
                            text = "Wallet Balance",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "₹${BillingEngine.formatRupees(walletBalanceRupees)} available",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = SecondaryAmber
                            )
                        )
                    }
                }
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Navigation: Recent Activity & Love Notes
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                DrawerNavigationRow(
                    icon = Icons.Filled.Call,
                    label = "Recent Activity",
                    tint = VibrantPink,
                    testTag = "drawer_menu_recent_activity",
                    onClick = { onNavigate(Screen.RECENT_CALLS) }
                )
                HorizontalDivider(color = DarkBorderSubtle, modifier = Modifier.padding(vertical = 8.dp))
                DrawerNavigationRow(
                    icon = Icons.Filled.Mail,
                    label = "My Love Notes",
                    tint = PrimaryLavender,
                    testTag = "drawer_menu_my_love_notes",
                    onClick = { onNavigate(Screen.CHAT_LIST) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Account Details Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                DrawerInfoRow(
                    icon = Icons.Outlined.Phone,
                    label = "Mobile Number",
                    value = if (!currentUser?.mobileNumber.isNullOrBlank()) "+91 ${currentUser?.mobileNumber}" else "Not specified"
                )
                HorizontalDivider(color = DarkBorderSubtle, modifier = Modifier.padding(vertical = 8.dp))
                DrawerInfoRow(
                    icon = Icons.Outlined.CardGiftcard,
                    label = "Referral Code",
                    value = currentUser?.referralCode ?: "BAATLYUSER"
                )
                HorizontalDivider(color = DarkBorderSubtle, modifier = Modifier.padding(vertical = 8.dp))
                DrawerInfoRow(
                    icon = Icons.Outlined.Shield,
                    label = "Account Security",
                    value = "Protected"
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Help & Support
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onSupportEmail)
                .testTag("drawer_btn_help_support_email")
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Outlined.Email, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(20.dp))
                    Column {
                        Text(
                            text = "Help & Support",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                        )
                        Text(
                            text = "support.baatly672@gmail.com",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                        )
                    }
                }
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Legal Information
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Legal & Policies",
                    style = MaterialTheme.typography.labelMedium.copy(color = TextTertiary, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                DrawerNavigationRow(icon = Icons.Outlined.Info, label = "About Baatly", tint = PrimaryLavender, testTag = "drawer_legal_about") {
                    onOpenLegal(LegalPage.ABOUT_BAATLY)
                }
                HorizontalDivider(color = DarkBorderSubtle, modifier = Modifier.padding(vertical = 6.dp))
                DrawerNavigationRow(icon = Icons.Outlined.Shield, label = "Safety & Security", tint = PrimaryLavender, testTag = "drawer_legal_safety") {
                    onOpenLegal(LegalPage.SAFETY_SECURITY)
                }
                HorizontalDivider(color = DarkBorderSubtle, modifier = Modifier.padding(vertical = 6.dp))
                DrawerNavigationRow(icon = Icons.Outlined.ReceiptLong, label = "Refund & Cancellation", tint = PrimaryLavender, testTag = "drawer_legal_refund") {
                    onOpenLegal(LegalPage.REFUND_CANCELLATION)
                }
                HorizontalDivider(color = DarkBorderSubtle, modifier = Modifier.padding(vertical = 6.dp))
                DrawerNavigationRow(icon = Icons.Outlined.Description, label = "Terms & Conditions", tint = PrimaryLavender, testTag = "drawer_legal_terms") {
                    onOpenLegal(LegalPage.TERMS_CONDITIONS)
                }
                HorizontalDivider(color = DarkBorderSubtle, modifier = Modifier.padding(vertical = 6.dp))
                DrawerNavigationRow(icon = Icons.Outlined.Lock, label = "Privacy Policy", tint = PrimaryLavender, testTag = "drawer_legal_privacy") {
                    onOpenLegal(LegalPage.PRIVACY_POLICY)
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Sign Out Button
        OutlinedButton(
            onClick = onSignOut,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("drawer_btn_logout")
        ) {
            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = DangerRed, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("SIGN OUT", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Delete Account Button
        OutlinedButton(
            onClick = onDeleteAccount,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed.copy(alpha = 0.5f)),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = DangerRed,
                containerColor = DangerRed.copy(alpha = 0.08f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("drawer_btn_delete_account")
        ) {
            Icon(Icons.Outlined.DeleteForever, contentDescription = null, tint = DangerRed, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("DELETE ACCOUNT", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = DangerRed))
        }
    }
}

@Composable
private fun DrawerNavigationRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
            Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold))
        }
        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(14.dp))
    }
}

@Composable
private fun DrawerInfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(18.dp))
            Text(text = label, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
        }
        Text(text = value, style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontWeight = FontWeight.Bold))
    }
}
