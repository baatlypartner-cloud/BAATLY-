package com.example.ui.auth

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.PhoneAuthStep
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*
import java.io.File

@Composable
fun AuthScreen(viewModel: BaatlyViewModel) {
    val phoneAuthStep by viewModel.phoneAuthStep.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()
    val isExistingUserSignIn by viewModel.isExistingUserSignIn.collectAsState()
    val countdownSeconds by viewModel.otpCountdownSeconds.collectAsState()

    Surface(
        color = DarkBackground,
        modifier = Modifier.fillMaxSize()
    ) {
        when (val step = phoneAuthStep) {
            is PhoneAuthStep.EnterPhone -> {
                PhoneInputScreen(
                    viewModel = viewModel,
                    isSignInMode = isExistingUserSignIn,
                    isAuthLoading = isAuthLoading,
                    authError = authError,
                    onModeChange = { signInMode ->
                        viewModel.setExistingUserSignIn(signInMode)
                        viewModel.clearAuthError()
                    },
                    onSubmitPhone = { phone, isSignIn ->
                        viewModel.sendPhoneOtp(phone, isSignIn)
                    }
                )
            }
            is PhoneAuthStep.EnterOtp -> {
                BackHandler {
                    viewModel.setPhoneAuthStep(PhoneAuthStep.EnterPhone)
                }
                OtpVerificationScreen(
                    phone = step.phone,
                    isSignInOnly = step.isSignInOnly,
                    isAuthLoading = isAuthLoading,
                    authError = authError,
                    countdownSeconds = countdownSeconds,
                    onVerifyOtp = { otp ->
                        viewModel.verifyPhoneOtp(otp)
                    },
                    onResendOtp = {
                        viewModel.resendPhoneOtp()
                    },
                    onEditPhone = {
                        viewModel.setPhoneAuthStep(PhoneAuthStep.EnterPhone)
                    }
                )
            }
            is PhoneAuthStep.ProfileCompletion -> {
                BackHandler {
                    viewModel.abandonPhoneAuth()
                }
                ProfileCompletionScreen(
                    verifiedPhone = step.verifiedPhone,
                    isAuthLoading = isAuthLoading,
                    authError = authError,
                    onCompleteProfile = { displayName, bio, avatarFile, referralCode ->
                        viewModel.completePhoneProfile(displayName, bio, avatarFile, referralCode)
                    }
                )
            }
        }
    }
}

// ====================================================================
// STEP A: MAIN PHONE INPUT SCREEN
// ====================================================================
@Composable
private fun PhoneInputScreen(
    viewModel: BaatlyViewModel,
    isSignInMode: Boolean,
    isAuthLoading: Boolean,
    authError: String?,
    onModeChange: (Boolean) -> Unit,
    onSubmitPhone: (String, Boolean) -> Unit
) {
    var rawPhone by remember { mutableStateOf(viewModel.phoneAuthNumber.value) }
    var isAgeConfirmed by remember { mutableStateOf(false) }
    var ageError by remember { mutableStateOf<String?>(null) }
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val cleanDigits = rawPhone.filter { it.isDigit() }
    val isPhoneValid = cleanDigits.length == 10 && cleanDigits[0] in listOf('6', '7', '8', '9')

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // App Branding Logo
        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(PrimaryGradient),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Chat,
                contentDescription = "Baatly",
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "BAATLY",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 4.sp,
                color = TextPrimary
            )
        )

        Text(
            text = "Real Conversations • Instant Audio Calls",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextSecondary
            )
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Mode Switcher: "Continue with Phone" vs "Sign In"
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurfaceVariant,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (!isSignInMode) VibrantPink else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_continue_phone")
                        .clickable { onModeChange(false) }
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CONTINUE",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (!isSignInMode) Color.White else TextSecondary
                            )
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSignInMode) VibrantPink else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tab_existing_sign_in")
                        .clickable { onModeChange(true) }
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "SIGN IN",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSignInMode) Color.White else TextSecondary
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Headline
        Text(
            text = if (isSignInMode) "Sign In to Existing Account" else "Welcome to Baatly",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        )
        Text(
            text = if (isSignInMode)
                "Enter your registered Indian mobile number to log in via OTP."
            else
                "Enter your Indian mobile number. We'll send a 6-digit OTP.",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextTertiary,
                textAlign = TextAlign.Center
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Error Display
        if (!authError.isNullOrBlank()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DangerRed.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ErrorOutline,
                        contentDescription = "Error",
                        tint = DangerRed,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = authError,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = DangerRed,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        // Mobile Number Input
        OutlinedTextField(
            value = rawPhone,
            onValueChange = {
                if (it.length <= 10) {
                    rawPhone = it.filter { char -> char.isDigit() }
                    viewModel.setPhoneAuthNumber(rawPhone)
                }
            },
            label = { Text("Mobile Number") },
            prefix = {
                Text(
                    text = "+91 ",
                    fontWeight = FontWeight.Bold,
                    color = VibrantPink
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Phone,
                    contentDescription = null,
                    tint = TextSecondary
                )
            },
            trailingIcon = {
                if (cleanDigits.length == 10) {
                    if (isPhoneValid) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = "Valid", tint = OnlineGreen)
                    } else {
                        Icon(Icons.Filled.Cancel, contentDescription = "Invalid", tint = DangerRed)
                    }
                }
            },
            supportingText = {
                Text(
                    text = if (cleanDigits.isNotEmpty() && !isPhoneValid && cleanDigits.length == 10)
                        "Must start with 6, 7, 8, or 9"
                    else
                        "10-digit Indian mobile number",
                    color = if (cleanDigits.isNotEmpty() && !isPhoneValid && cleanDigits.length == 10) DangerRed else TextTertiary
                )
            },
            colors = authTextFieldColors(),
            shape = RoundedCornerShape(16.dp),
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Phone,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(onDone = {
                focusManager.clearFocus()
                if (isPhoneValid && (isSignInMode || isAgeConfirmed)) {
                    onSubmitPhone(cleanDigits, isSignInMode)
                }
            }),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_mobile_number")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 18+ Age Checkbox
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isAgeConfirmed,
                onCheckedChange = {
                    isAgeConfirmed = it
                    if (it) ageError = null
                },
                colors = CheckboxDefaults.colors(
                    checkedColor = VibrantPink,
                    uncheckedColor = TextSecondary,
                    checkmarkColor = Color.White
                ),
                modifier = Modifier.testTag("checkbox_18_plus")
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "By continuing, you agree that you are 18 years old",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextSecondary,
                    fontSize = 13.sp
                ),
                modifier = Modifier.clickable {
                    isAgeConfirmed = !isAgeConfirmed
                    if (isAgeConfirmed) ageError = null
                }
            )
        }

        if (ageError != null) {
            Text(
                text = ageError ?: "",
                color = DangerRed,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp)
                    .testTag("error_18_plus")
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Action Button: "Continue with Phone" / "Sign In with Phone"
        val canSubmit = !isAuthLoading && isPhoneValid
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (canSubmit) PrimaryGradient
                    else androidx.compose.ui.graphics.SolidColor(DarkSurfaceVariant)
                )
                .clickable(enabled = canSubmit) {
                    focusManager.clearFocus()
                    if (!isAgeConfirmed) {
                        ageError = "Please confirm that you are 18 years old to continue."
                    } else {
                        ageError = null
                        onSubmitPhone(cleanDigits, isSignInMode)
                    }
                }
                .testTag(if (isSignInMode) "btn_existing_sign_in" else "btn_continue_phone"),
            contentAlignment = Alignment.Center
        ) {
            if (isAuthLoading) {
                CircularProgressIndicator(
                    color = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            } else {
                Text(
                    text = if (isSignInMode) "SIGN IN WITH OTP" else "CONTINUE WITH PHONE",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (canSubmit) Color.White else TextTertiary
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Secondary text link to toggle sign-in / new-user
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    onModeChange(!isSignInMode)
                }
                .padding(8.dp)
        ) {
            Text(
                text = if (isSignInMode) "New to BAATLY? " else "Already have a BAATLY account? ",
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
            )
            Text(
                text = if (isSignInMode) "Continue with Phone" else "Sign In",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = VibrantPink,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

// ====================================================================
// STEP B: OTP VERIFICATION SCREEN
// ====================================================================
@Composable
private fun OtpVerificationScreen(
    phone: String,
    isSignInOnly: Boolean,
    isAuthLoading: Boolean,
    authError: String?,
    countdownSeconds: Int,
    onVerifyOtp: (String) -> Unit,
    onResendOtp: () -> Unit,
    onEditPhone: () -> Unit
) {
    var otpInput by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val canVerify = !isAuthLoading && otpInput.trim().length == 6 && otpInput.trim().all { it.isDigit() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Back / Edit phone top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onEditPhone,
                modifier = Modifier.testTag("btn_back_phone")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Edit phone number",
                    tint = TextPrimary
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            TextButton(
                onClick = onEditPhone,
                modifier = Modifier.testTag("btn_edit_mobile")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Edit,
                    contentDescription = null,
                    tint = VibrantPink,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Edit Number",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = VibrantPink,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Security / Verification Icon
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(VibrantPink.copy(alpha = 0.15f))
                .border(1.dp, VibrantPink.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.MarkEmailRead,
                contentDescription = "Verification Code",
                tint = VibrantPink,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Verify Phone Number",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "We sent a 6-digit OTP code to +91 $phone",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Error display (incorrect or expired OTP)
        if (!authError.isNullOrBlank()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DangerRed.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ErrorOutline,
                        contentDescription = "Error",
                        tint = DangerRed,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = authError,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = DangerRed,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        // Six-digit OTP Input
        OutlinedTextField(
            value = otpInput,
            onValueChange = {
                if (it.length <= 6) {
                    otpInput = it.filter { char -> char.isDigit() }
                    if (otpInput.length == 6) {
                        focusManager.clearFocus()
                        onVerifyOtp(otpInput)
                    }
                }
            },
            label = { Text("6-Digit OTP") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Lock,
                    contentDescription = null,
                    tint = TextSecondary
                )
            },
            colors = authTextFieldColors(),
            shape = RoundedCornerShape(16.dp),
            singleLine = true,
            textStyle = MaterialTheme.typography.headlineSmall.copy(
                letterSpacing = 8.sp,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(onDone = {
                focusManager.clearFocus()
                if (canVerify) {
                    onVerifyOtp(otpInput)
                }
            }),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_otp")
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Verify OTP Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (canVerify) PrimaryGradient
                    else androidx.compose.ui.graphics.SolidColor(DarkSurfaceVariant)
                )
                .clickable(enabled = canVerify) {
                    focusManager.clearFocus()
                    onVerifyOtp(otpInput)
                }
                .testTag("btn_verify_otp"),
            contentAlignment = Alignment.Center
        ) {
            if (isAuthLoading) {
                CircularProgressIndicator(
                    color = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            } else {
                Text(
                    text = "VERIFY OTP",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (canVerify) Color.White else TextTertiary
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Resend OTP Countdown
        if (countdownSeconds > 0) {
            Text(
                text = "Resend OTP in ${countdownSeconds}s",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextTertiary,
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier.testTag("text_countdown_resend")
            )
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(enabled = !isAuthLoading) {
                        onResendOtp()
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .testTag("btn_resend_otp")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Refresh,
                    contentDescription = null,
                    tint = VibrantPink,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Didn't receive code? Resend OTP",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = VibrantPink,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }
}

// ====================================================================
// STEP C: NEW USER PROFILE SCREEN
// ====================================================================
@Composable
private fun ProfileCompletionScreen(
    verifiedPhone: String,
    isAuthLoading: Boolean,
    authError: String?,
    onCompleteProfile: (String, String?, File?, String?) -> Unit
) {
    var displayName by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var referralCode by remember { mutableStateOf("") }
    var selectedAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var selectedAvatarFile by remember { mutableStateOf<File?>(null) }

    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedAvatarUri = uri
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val tempFile = File(context.cacheDir, "avatar_upload_${System.currentTimeMillis()}.jpg")
                tempFile.outputStream().use { output ->
                    inputStream?.copyTo(output)
                }
                selectedAvatarFile = tempFile
            } catch (_: Exception) {}
        }
    }

    val canContinue = !isAuthLoading && displayName.trim().isNotBlank()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Complete Your Profile",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Verified mobile: +91 $verifiedPhone",
            style = MaterialTheme.typography.bodySmall.copy(
                color = OnlineGreen,
                fontWeight = FontWeight.Medium
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Avatar Picker
        Box(
            contentAlignment = Alignment.BottomEnd,
            modifier = Modifier
                .clickable(enabled = !isAuthLoading) {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                }
                .testTag("btn_pick_avatar")
        ) {
            if (selectedAvatarUri != null) {
                AsyncImage(
                    model = selectedAvatarUri,
                    contentDescription = "Profile Photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .border(2.dp, VibrantPink, CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .border(2.dp, DarkCardBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Person,
                        contentDescription = "Default Avatar",
                        tint = TextTertiary,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            Surface(
                shape = CircleShape,
                color = VibrantPink,
                modifier = Modifier.size(30.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.PhotoCamera,
                        contentDescription = "Upload Photo",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Profile Photo (Optional)",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Error display
        if (!authError.isNullOrBlank()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DangerRed.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ErrorOutline,
                        contentDescription = "Error",
                        tint = DangerRed,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = authError,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = DangerRed,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        // Display Name (Required)
        OutlinedTextField(
            value = displayName,
            onValueChange = { displayName = it },
            label = { Text("Display Name *") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Person,
                    contentDescription = null,
                    tint = TextSecondary
                )
            },
            colors = authTextFieldColors(),
            shape = RoundedCornerShape(16.dp),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_profile_name")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Bio (Optional)
        OutlinedTextField(
            value = bio,
            onValueChange = { if (it.length <= 160) bio = it },
            label = { Text("Bio (Optional)") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = null,
                    tint = TextSecondary
                )
            },
            supportingText = {
                Text(
                    text = "${bio.length}/160",
                    color = TextTertiary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End
                )
            },
            colors = authTextFieldColors(),
            shape = RoundedCornerShape(16.dp),
            maxLines = 3,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_profile_bio")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Referral Code (Optional)
        OutlinedTextField(
            value = referralCode,
            onValueChange = { referralCode = it.uppercase() },
            label = { Text("Referral Code (Optional)") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.CardGiftcard,
                    contentDescription = null,
                    tint = SecondaryAmber
                )
            },
            colors = authTextFieldColors(),
            shape = RoundedCornerShape(16.dp),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_profile_referral")
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Continue Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (canContinue) PrimaryGradient
                    else androidx.compose.ui.graphics.SolidColor(DarkSurfaceVariant)
                )
                .clickable(enabled = canContinue) {
                    focusManager.clearFocus()
                    onCompleteProfile(
                        displayName.trim(),
                        bio.trim().takeIf { it.isNotBlank() },
                        selectedAvatarFile,
                        referralCode.trim().takeIf { it.isNotBlank() }
                    )
                }
                .testTag("btn_complete_profile"),
            contentAlignment = Alignment.Center
        ) {
            if (isAuthLoading) {
                CircularProgressIndicator(
                    color = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            } else {
                Text(
                    text = "CONTINUE",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (canContinue) Color.White else TextTertiary
                )
            }
        }
    }
}

@Composable
private fun authTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = VibrantPink,
    unfocusedBorderColor = DarkCardBorder,
    focusedLabelColor = VibrantPink,
    unfocusedLabelColor = TextSecondary,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    cursorColor = VibrantPink,
    focusedContainerColor = DarkSurface,
    unfocusedContainerColor = DarkSurface
)
