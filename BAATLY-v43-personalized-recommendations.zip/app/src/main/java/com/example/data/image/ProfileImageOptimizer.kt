package com.example.data.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Creates a reasonably sized JPEG for profile avatars before upload.
 * Returns null when an existing JPEG is already small enough or decoding fails; callers
 * preserve the original upload in that fallback case to avoid blocking profile updates.
 */
object ProfileImageOptimizer {
    private const val MAX_DIMENSION = 1024
    private const val MAX_SOURCE_BYTES = 450 * 1024L
    private const val JPEG_QUALITY = 84

    fun optimize(source: File): File? {
        if (!source.isFile || source.length() <= 0L) return null

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(source.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        // Existing small JPEGs can be uploaded unchanged. Other formats (for example PNG)
        // must still be transcoded because avatar upload paths use a .jpg suffix and JPEG MIME.
        val isJpeg = source.inputStream().use { input ->
            val header = ByteArray(3)
            input.read(header) == 3 && header[0] == 0xFF.toByte() &&
                header[1] == 0xD8.toByte() && header[2] == 0xFF.toByte()
        }
        if (isJpeg && maxOf(bounds.outWidth, bounds.outHeight) <= MAX_DIMENSION && source.length() <= MAX_SOURCE_BYTES) {
            return null
        }

        val options = BitmapFactory.Options()
        var sample = 1
        while (maxOf(bounds.outWidth / (sample * 2), bounds.outHeight / (sample * 2)) >= MAX_DIMENSION * 1.5) {
            sample *= 2
        }
        options.inSampleSize = sample
        val decoded = BitmapFactory.decodeFile(source.absolutePath, options) ?: return null

        var oriented: Bitmap = decoded
        try {
            val orientation = try {
                ExifInterface(source.absolutePath).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } catch (_: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
            }
            if (!matrix.isIdentity) {
                oriented = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                if (oriented !== decoded) decoded.recycle()
            }

            val largest = maxOf(oriented.width, oriented.height)
            val scaled = if (largest > MAX_DIMENSION) {
                val factor = MAX_DIMENSION.toFloat() / largest.toFloat()
                Bitmap.createScaledBitmap(
                    oriented,
                    (oriented.width * factor).toInt().coerceAtLeast(1),
                    (oriented.height * factor).toInt().coerceAtLeast(1),
                    true
                )
            } else oriented

            val parent = source.parentFile ?: return null
            val output = File(parent, "${source.nameWithoutExtension}_optimized_${System.currentTimeMillis()}.jpg")
            try {
                val encoded = ByteArrayOutputStream()
                var encodedSuccessfully = false
                for (quality in intArrayOf(JPEG_QUALITY, 80, 76, 72, 68, 64)) {
                    encoded.reset()
                    if (!scaled.compress(Bitmap.CompressFormat.JPEG, quality, encoded)) continue
                    encodedSuccessfully = true
                    if (encoded.size().toLong() <= MAX_SOURCE_BYTES) break
                }
                if (!encodedSuccessfully || encoded.size() <= 0) {
                    output.delete()
                    return null
                }
                FileOutputStream(output).use { stream ->
                    encoded.writeTo(stream)
                    stream.flush()
                }
                // Return converted files even if a tiny source PNG becomes slightly larger;
                // matching the stored .jpg path and MIME is more important than that edge case.
                if (output.length() <= 0L) {
                    output.delete()
                    return null
                }
                return output
            } finally {
                if (scaled !== oriented) scaled.recycle()
            }
        } catch (_: Exception) {
            return null
        } finally {
            if (!decoded.isRecycled) decoded.recycle()
            if (oriented !== decoded && !oriented.isRecycled) oriented.recycle()
        }
    }
}
