package com.example

import org.junit.Assert.*
import org.junit.Test

class PhoneOtpAuthTest {

    private fun extract10DigitMobile(rawPhone: String): String {
        val digits = rawPhone.filter { it.isDigit() }
        return when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            digits.length > 10 -> digits.takeLast(10)
            else -> digits
        }
    }

    private fun normalizeIndianPhoneNumber(rawPhone: String): String {
        val digits = rawPhone.filter { it.isDigit() }
        val mobile10 = when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            digits.length > 10 -> digits.takeLast(10)
            else -> digits
        }
        return "+91$mobile10"
    }

    private fun isValidIndianMobileNumber(rawPhone: String): Boolean {
        val mobile10 = extract10DigitMobile(rawPhone)
        return mobile10.length == 10 && mobile10[0] in listOf('6', '7', '8', '9')
    }

    @Test
    fun testIndianMobileNumberExtraction() {
        assertEquals("9876543210", extract10DigitMobile("9876543210"))
        assertEquals("9876543210", extract10DigitMobile("+919876543210"))
        assertEquals("9876543210", extract10DigitMobile("919876543210"))
        assertEquals("9876543210", extract10DigitMobile("+91 98765-43210"))
    }

    @Test
    fun testIndianMobileNormalization() {
        assertEquals("+919876543210", normalizeIndianPhoneNumber("9876543210"))
        assertEquals("+919876543210", normalizeIndianPhoneNumber("+919876543210"))
        assertEquals("+919876543210", normalizeIndianPhoneNumber("919876543210"))
    }

    @Test
    fun testIndianMobileValidation() {
        assertTrue(isValidIndianMobileNumber("9876543210"))
        assertTrue(isValidIndianMobileNumber("8876543210"))
        assertTrue(isValidIndianMobileNumber("7876543210"))
        assertTrue(isValidIndianMobileNumber("6876543210"))

        // Invalid: Starts with 5, 4, 3, etc. or wrong length
        assertFalse(isValidIndianMobileNumber("5876543210"))
        assertFalse(isValidIndianMobileNumber("1234567890"))
        assertFalse(isValidIndianMobileNumber("98765"))
    }
}
