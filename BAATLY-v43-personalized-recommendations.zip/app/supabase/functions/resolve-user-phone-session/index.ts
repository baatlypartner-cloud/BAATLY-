// ====================================================================
// BAATLY USER APP: resolve-user-phone-session Edge Function
// Purpose: Securely bridges verified Supabase Phone OTP sessions to
//          legacy BAATLY accounts without duplicate accounts or wallets.
// Project: qewhxsbrnlgunygghpez
// Version: 2026-10-14
// ====================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

    if (!supabaseUrl || !supabaseServiceKey) {
      return new Response(
        JSON.stringify({ error: "Missing backend configuration" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 1. Authorize caller via incoming JWT
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Unauthorized: Missing Bearer token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "").trim();

    // User client to verify the caller's identity
    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData?.user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized: Invalid session", details: userError?.message }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const callerUser = userData.user;
    const verifiedPhone = callerUser.phone;

    if (!verifiedPhone || verifiedPhone.trim() === "") {
      return new Response(
        JSON.stringify({ error: "Verified phone number required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 2. Normalize verified phone to 10-digit and E.164
    const digitsOnly = verifiedPhone.replace(/\D/g, "");
    let mobile10 = digitsOnly;
    if (digitsOnly.length === 12 && digitsOnly.startsWith("91")) {
      mobile10 = digitsOnly.substring(2);
    } else if (digitsOnly.length > 10) {
      mobile10 = digitsOnly.slice(-10);
    }
    const e164 = `+91${mobile10}`;

    // Admin client with privileged service_role key
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    // 3. Search public.profiles for legacy accounts matching verified phone
    // Note: public.profiles schema contains id, user_id, username, display_name, avatar_url, bio, account_status, mobile_number
    const { data: matchedProfiles, error: queryError } = await adminClient
      .from("profiles")
      .select("id, user_id, username, display_name, avatar_url, bio, account_status, mobile_number")
      .or(`mobile_number.eq.${mobile10},mobile_number.eq.${e164},mobile_number.eq.91${mobile10},mobile_number.eq.+91${mobile10}`);

    if (queryError) {
      return new Response(
        JSON.stringify({ error: "Database query failed", details: queryError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 4. Handle ambiguous multiple profiles (Conflict check)
    if (matchedProfiles && matchedProfiles.length > 1) {
      return new Response(
        JSON.stringify({
          status: "conflict",
          error: "MULTIPLE_PROFILES_FOUND",
          message: "We couldn't safely identify your existing account. Please contact BAATLY support.",
        }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 5. Case A: Single legacy profile matched -> RESTORE ORIGINAL ACCOUNT
    if (matchedProfiles && matchedProfiles.length === 1) {
      const originalProfile = matchedProfiles[0];

      // Check account status
      const status = (originalProfile.account_status || "active").toLowerCase();
      if (status === "banned" || status === "suspended" || status === "deleted") {
        return new Response(
          JSON.stringify({
            status: "account_restricted",
            account_status: status,
            message: `Your account is ${status}. Please contact BAATLY support.`,
          }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // If the caller user ID already matches the legacy profile ID, session is already valid
      if (callerUser.id === originalProfile.id) {
        return new Response(
          JSON.stringify({
            status: "existing_user",
            session: {
              access_token: token,
              refresh_token: null,
              user_id: originalProfile.id,
            },
            profile: originalProfile,
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Otherwise, bridge to original auth.users account
      const { data: origUserRes, error: origUserErr } = await adminClient.auth.admin.getUserById(originalProfile.id);
      if (origUserErr || !origUserRes?.user) {
        return new Response(
          JSON.stringify({
            error: "Original auth user record not found",
            details: origUserErr?.message,
          }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const origUser = origUserRes.user;

      // Update original user with verified phone
      try {
        await adminClient.auth.admin.updateUserById(originalProfile.id, {
          phone: e164,
          phone_confirm: true,
        });
      } catch (updateErr: any) {
        console.warn("Notice: could not update phone on original auth user:", updateErr?.message);
      }

      // Generate a valid authenticated session for original user
      let sessionData: any = null;

      if (origUser.email) {
        const { data: linkData, error: linkErr } = await adminClient.auth.admin.generateLink({
          type: "magiclink",
          email: origUser.email,
        });

        if (linkData?.properties?.email_otp) {
          const verifyRes = await adminClient.auth.verifyOtp({
            email: origUser.email,
            token: linkData.properties.email_otp,
            type: "email",
          });
          if (verifyRes.data?.session) {
            sessionData = verifyRes.data.session;
          }
        } else if (linkData?.properties?.hashed_token) {
          const verifyRes = await adminClient.auth.verifyOtp({
            token_hash: linkData.properties.hashed_token,
            type: "email",
          });
          if (verifyRes.data?.session) {
            sessionData = verifyRes.data.session;
          }
        }
      }

      // Cleanup temporary phone auth user if different from original account
      if (callerUser.id !== originalProfile.id) {
        try {
          await adminClient.auth.admin.deleteUser(callerUser.id);
        } catch (_cleanupErr) {
          // Non-blocking cleanup
        }
      }

      if (!sessionData) {
        return new Response(
          JSON.stringify({
            error: "Failed to bridge authentication session for legacy user",
          }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({
          status: "existing_user",
          session: {
            access_token: sessionData.access_token,
            refresh_token: sessionData.refresh_token,
            user_id: originalProfile.id,
          },
          profile: originalProfile,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 6. Case B: 0 legacy profiles matched -> GENUINELY NEW USER
    // The current phone-auth session is the user's permanent identity
    return new Response(
      JSON.stringify({
        status: "new_user",
        phone: mobile10,
        e164: e164,
        temp_auth_user_id: callerUser.id,
        session: {
          access_token: token,
          refresh_token: null,
          user_id: callerUser.id,
        },
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({ error: "Internal server error", message: err?.message || String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
