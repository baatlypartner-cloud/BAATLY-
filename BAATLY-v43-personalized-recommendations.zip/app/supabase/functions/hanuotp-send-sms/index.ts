// ====================================================================
// BAATLY USER APP: hanuotp-send-sms Edge Function
// Purpose: Handles Supabase Auth Send SMS Hook and dispatches OTP
//          via HanuOTP SMS API (https://api.hanuotp.in/sms-otp.php).
// ====================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, webhook-id, webhook-timestamp, webhook-signature",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const hanuApiKey = Deno.env.get("HANUOTP_API_KEY") ?? "";
    const hookSecret = Deno.env.get("SEND_SMS_HOOK_SECRET") ?? "";

    if (!hanuApiKey) {
      console.error("[hanuotp-send-sms] Server misconfiguration: Missing HANUOTP_API_KEY in environment");
      return new Response(
        JSON.stringify({ error: "SMS service misconfigured on server" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const rawBody = await req.text();

    // Verify hook secret if provided
    if (hookSecret) {
      const webhookSig = req.headers.get("webhook-signature") ||
                         req.headers.get("x-supabase-signature") ||
                         req.headers.get("authorization");
      // Optional secret validation when configured
      if (webhookSig && webhookSig.startsWith("Bearer ") && hookSecret.startsWith("Bearer ")) {
        if (webhookSig !== hookSecret) {
          return new Response(
            JSON.stringify({ error: "Unauthorized hook invocation" }),
            { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
    }

    let payload: any;
    try {
      payload = JSON.parse(rawBody);
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid JSON payload" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Supabase Send SMS Hook payload format:
    // { "user": { "id": "...", "phone": "+91..." }, "sms": { "otp": "..." } }
    const phone = payload?.user?.phone || payload?.phone || "";
    const otp = payload?.sms?.otp || payload?.otp || "";

    if (!phone || !otp) {
      console.warn("[hanuotp-send-sms] Missing phone or OTP in request payload");
      return new Response(
        JSON.stringify({ error: "Missing required phone or OTP" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Normalize phone number to 91XXXXXXXXXX (country code 91 + 10 digits)
    const digitsOnly = String(phone).replace(/\D/g, "");
    let normalizedNumber = digitsOnly;
    if (digitsOnly.length === 10) {
      normalizedNumber = `91${digitsOnly}`;
    } else if (digitsOnly.length === 12 && digitsOnly.startsWith("91")) {
      normalizedNumber = digitsOnly;
    } else if (digitsOnly.length > 10) {
      normalizedNumber = `91${digitsOnly.slice(-10)}`;
    }

    if (normalizedNumber.length !== 12 || !normalizedNumber.startsWith("91")) {
      console.warn("[hanuotp-send-sms] Invalid Indian phone number length");
      return new Response(
        JSON.stringify({ error: "Invalid Indian mobile number. 10 digits required." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // HanuOTP GET request contract:
    // GET https://api.hanuotp.in/sms-otp.php?apikey={apikey}&number={number}&OTP={OTP}
    const apiUrl = new URL("https://api.hanuotp.in/sms-otp.php");
    apiUrl.searchParams.set("apikey", hanuApiKey);
    apiUrl.searchParams.set("number", normalizedNumber);
    apiUrl.searchParams.set("OTP", String(otp).trim());

    // Mask phone for safe diagnostic logging: show only first 2 and last 4 digits
    const maskedPhone = `${normalizedNumber.substring(0, 4)}****${normalizedNumber.slice(-4)}`;
    console.log(`[hanuotp-send-sms] Dispatching SMS OTP to ${maskedPhone}...`);

    const hanuResponse = await fetch(apiUrl.toString(), {
      method: "GET",
      headers: {
        "Accept": "application/json",
      },
    });

    const responseText = await hanuResponse.text();
    let responseJson: any = null;
    try {
      responseJson = JSON.parse(responseText);
    } catch {
      // Non-JSON response
    }

    const isHttpOk = hanuResponse.ok;
    const isSuccessReturn = responseJson && (responseJson.return === true || responseJson.return === "true");

    if (isHttpOk && isSuccessReturn) {
      console.log(`[hanuotp-send-sms] OTP delivered successfully to ${maskedPhone}. Request ID: ${responseJson.request_id || "N/A"}`);
      return new Response(
        JSON.stringify({ success: true, message: "SMS dispatched successfully" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Provider rejected the request or returned an error
    const rawErrorMsg = Array.isArray(responseJson?.message)
      ? responseJson.message.join(", ")
      : responseJson?.message || responseJson?.error || responseJson?.status || "SMS dispatch failed";

    console.error(`[hanuotp-send-sms] Provider rejected dispatch. HTTP: ${hanuResponse.status}, Details: ${rawErrorMsg}`);

    // Map provider rejection to safe error for client
    let safeClientReason = "SMS delivery failed. Please check your mobile number or try again.";
    const lower = String(rawErrorMsg).toLowerCase();
    if (lower.includes("balance") || lower.includes("credit") || lower.includes("low")) {
      safeClientReason = "SMS service provider credit exhaustion. Please contact support.";
    } else if (lower.includes("invalid api") || lower.includes("apikey")) {
      safeClientReason = "SMS service provider authentication failure. Please contact support.";
    } else if (lower.includes("dlt") || lower.includes("template") || lower.includes("sender")) {
      safeClientReason = "SMS template or sender ID approval required. Please contact support.";
    } else if (lower.includes("invalid number") || lower.includes("number not valid")) {
      safeClientReason = "Invalid mobile number. Please check the 10-digit number and try again.";
    }

    return new Response(
      JSON.stringify({
        error: "PROVIDER_REJECTED",
        message: safeClientReason,
        provider_code: hanuResponse.status,
      }),
      { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    console.error("[hanuotp-send-sms] Unexpected error:", err?.message || String(err));
    return new Response(
      JSON.stringify({ error: "INTERNAL_ERROR", message: "Failed to dispatch SMS due to an unexpected error." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
