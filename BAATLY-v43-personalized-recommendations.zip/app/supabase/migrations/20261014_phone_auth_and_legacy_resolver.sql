-- ====================================================================
-- BAATLY USER APP: PHONE AUTH & LEGACY ACCOUNT RESOLVER MIGRATION
-- Project Ref: qewhxsbrnlgunygghpez
-- Version: 2026-10-14
-- ====================================================================

-- 1. Safely update handle_new_user() to accommodate phone auth
-- When an OTP is verified by Supabase Phone Auth, a new auth.users record is created.
-- If the phone number already belongs to an existing BAATLY profile, the trigger MUST NOT
-- fail or raise an unhandled exception, and MUST NOT create a duplicate permanent profile/wallet.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_phone text;
    v_phone_digits text;
    v_existing_profile_id uuid;
    v_raw_mobile text;
BEGIN
    -- Extract phone if present
    v_phone := NEW.phone;
    IF v_phone IS NOT NULL AND v_phone <> '' THEN
        -- Normalize digits: strip all non-digits
        v_phone_digits := regexp_replace(v_phone, '\D', '', 'g');
        IF length(v_phone_digits) = 12 AND v_phone_digits LIKE '91%' THEN
            v_raw_mobile := substr(v_phone_digits, 3);
        ELSE
            v_raw_mobile := v_phone_digits;
        END IF;

        -- Check if an existing profile already claims this mobile number
        SELECT id INTO v_existing_profile_id
        FROM public.profiles
        WHERE mobile_number IN (v_raw_mobile, v_phone, '91' || v_raw_mobile, '+91' || v_raw_mobile)
        LIMIT 1;

        -- If a legacy profile already exists for this mobile number,
        -- DO NOT create a conflicting profile or wallet here.
        -- The secure session resolver (resolve-user-phone-session) will bridge
        -- the authenticated session to the original legacy profile.
        IF v_existing_profile_id IS NOT NULL THEN
            RETURN NEW;
        END IF;

        -- Genuine new phone-auth users will initialize their profile and zero-balance wallet
        -- through the existing complete_user_signup RPC after phone verification.
        RETURN NEW;
    END IF;

    RETURN NEW;
END;
$$;

-- Ensure trigger exists on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 2. Create authoritative helper function for legacy profile lookup
-- Matches the actual public.profiles schema:
-- id, user_id, username, display_name, avatar_url, bio, account_status, mobile_number
CREATE OR REPLACE FUNCTION public.lookup_profile_by_phone(
    p_phone text
)
RETURNS TABLE (
    match_count integer,
    profile_id uuid,
    user_id text,
    username text,
    display_name text,
    avatar_url text,
    bio text,
    account_status text,
    mobile_number text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_digits text;
    v_mobile10 text;
    v_e164 text;
    v_count integer;
BEGIN
    v_digits := regexp_replace(p_phone, '\D', '', 'g');
    IF length(v_digits) = 12 AND v_digits LIKE '91%' THEN
        v_mobile10 := substr(v_digits, 3);
    ELSIF length(v_digits) = 10 THEN
        v_mobile10 := v_digits;
    ELSE
        v_mobile10 := v_digits;
    END IF;
    v_e164 := '+91' || v_mobile10;

    -- Count matching profiles
    SELECT count(*)::integer INTO v_count
    FROM public.profiles
    WHERE mobile_number IN (v_mobile10, v_e164, '91' || v_mobile10, '+91' || v_mobile10);

    IF v_count = 1 THEN
        RETURN QUERY
        SELECT 
            v_count,
            p.id,
            p.user_id,
            p.username,
            p.display_name,
            p.avatar_url,
            p.bio,
            COALESCE(p.account_status, 'active'),
            p.mobile_number
        FROM public.profiles p
        WHERE p.mobile_number IN (v_mobile10, v_e164, '91' || v_mobile10, '+91' || v_mobile10)
        LIMIT 1;
    ELSE
        RETURN QUERY
        SELECT 
            v_count,
            NULL::uuid,
            NULL::text,
            NULL::text,
            NULL::text,
            NULL::text,
            NULL::text,
            NULL::text,
            NULL::text;
    END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION public.lookup_profile_by_phone(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.lookup_profile_by_phone(text) TO service_role;
