-- BAATLY personalized feed/Reels ranking and hashtag discovery.
-- Requires the existing BAATLY social schema (profiles, social_profiles, social_posts,
-- social_content_stats, social_likes, social_follows, blocks, and the private visibility helper).
BEGIN;

ALTER TABLE public.social_profiles ADD COLUMN IF NOT EXISTS is_private boolean NOT NULL DEFAULT false;
ALTER TABLE public.social_posts ADD COLUMN IF NOT EXISTS hashtags text[] NOT NULL DEFAULT ARRAY[]::text[];
CREATE INDEX IF NOT EXISTS social_posts_hashtags_gin_idx ON public.social_posts USING gin (hashtags);

-- Store hashtags in a normalized array whenever a creator publishes or edits a caption.
CREATE OR REPLACE FUNCTION public.social_extract_hashtags()
RETURNS trigger LANGUAGE plpgsql SET search_path='public','pg_temp'
AS $function$
BEGIN
  SELECT COALESCE(array_agg(DISTINCT lower(matches[1])), ARRAY[]::text[])
    INTO NEW.hashtags
  FROM regexp_matches(COALESCE(NEW.caption,''), '#([[:alnum:]_]{1,50})', 'g') AS matches;
  RETURN NEW;
END;
$function$;
DROP TRIGGER IF EXISTS social_posts_extract_hashtags ON public.social_posts;
CREATE TRIGGER social_posts_extract_hashtags
BEFORE INSERT OR UPDATE OF caption ON public.social_posts
FOR EACH ROW EXECUTE FUNCTION public.social_extract_hashtags();
UPDATE public.social_posts p
SET hashtags=COALESCE((
  SELECT array_agg(DISTINCT lower(matches[1]))
  FROM regexp_matches(COALESCE(p.caption,''), '#([[:alnum:]_]{1,50})', 'g') AS matches
), ARRAY[]::text[])
WHERE p.hashtags IS NULL OR cardinality(p.hashtags)=0;

CREATE TABLE IF NOT EXISTS public.social_recommendation_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  post_id uuid NOT NULL REFERENCES public.social_posts(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK (event_type IN ('impression','watch','skip','complete','like','comment','follow','not_interested','hide')),
  watch_ms bigint NOT NULL DEFAULT 0 CHECK (watch_ms >= 0),
  hashtag_snapshot text[] NOT NULL DEFAULT ARRAY[]::text[],
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS social_rec_events_user_time_idx ON public.social_recommendation_events(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS social_rec_events_user_kind_idx ON public.social_recommendation_events(user_id,event_type,created_at DESC);
CREATE INDEX IF NOT EXISTS social_rec_events_hashtags_gin_idx ON public.social_recommendation_events USING gin (hashtag_snapshot);
ALTER TABLE public.social_recommendation_events ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS public.social_hashtag_catalog (
  tag text PRIMARY KEY,
  category text NOT NULL DEFAULT 'General',
  is_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT social_hashtag_catalog_tag_format CHECK(tag ~ '^[a-z0-9_]{1,50}$')
);
ALTER TABLE public.social_hashtag_catalog ENABLE ROW LEVEL SECURITY;
INSERT INTO public.social_hashtag_catalog(tag,category) VALUES
 ('travel','Lifestyle'),('nature','Lifestyle'),('friends','Lifestyle'),('love','Lifestyle'),
 ('funny','Entertainment'),('comedy','Entertainment'),('memes','Entertainment'),('music','Entertainment'),
 ('dance','Entertainment'),('fashion','Lifestyle'),('beauty','Lifestyle'),('fitness','Fitness'),
 ('food','Food'),('cooking','Food'),('motivation','Lifestyle'),('dailyvlog','Creators'),
 ('photography','Creators'),('reels','Creators'),('haryana','Local'),('india','Local'),
 ('pets','Lifestyle'),('gaming','Entertainment'),('cricket','Sports'),('bollywood','Entertainment'),
 ('art','Creators'),('study','Education'),('technology','Technology'),('shopping','Lifestyle')
ON CONFLICT(tag) DO UPDATE SET category=EXCLUDED.category;

CREATE OR REPLACE FUNCTION public.social_record_recommendation_event(
  p_post_id uuid, p_event_type text, p_watch_ms bigint DEFAULT 0
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path='public','auth','private','pg_temp'
AS $function$
DECLARE
  v_uid uuid:=auth.uid();
  v_owner uuid;
  v_type text:=lower(trim(coalesce(p_event_type,'')));
  v_tags text[];
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF v_type NOT IN ('impression','watch','skip','complete','like','comment','follow','not_interested','hide')
    THEN RAISE EXCEPTION 'Invalid recommendation event'; END IF;
  SELECT owner_id,COALESCE(hashtags,ARRAY[]::text[])
    INTO v_owner,v_tags
  FROM public.social_posts
  WHERE id=p_post_id AND moderation_status='approved'
    AND (visible_until IS NULL OR visible_until>now());
  IF v_owner IS NULL THEN RAISE EXCEPTION 'Post not found or unavailable'; END IF;
  IF v_owner<>v_uid AND NOT private.social_owner_account_visible(v_owner) THEN RAISE EXCEPTION 'Content is private'; END IF;
  IF EXISTS (SELECT 1 FROM public.blocks b
    WHERE (b.blocker_id=v_uid AND b.blocked_user_id=v_owner)
       OR (b.blocker_id=v_owner AND b.blocked_user_id=v_uid))
  THEN RAISE EXCEPTION 'Content access is blocked'; END IF;
  IF v_type='like' AND NOT EXISTS (
    SELECT 1 FROM public.social_likes sl
    WHERE sl.content_type='post' AND sl.content_id=p_post_id AND sl.user_id=v_uid AND sl.is_active=true
  ) THEN RAISE EXCEPTION 'Like event requires an active like'; END IF;
  IF v_type='comment' AND NOT EXISTS (
    SELECT 1 FROM public.social_comments sc
    WHERE sc.content_type='post' AND sc.content_id=p_post_id AND sc.author_id=v_uid
      AND sc.is_deleted=false AND sc.created_at>now()-interval '10 minutes'
  ) THEN RAISE EXCEPTION 'Comment event requires a recent comment'; END IF;
  IF v_type='follow' AND NOT EXISTS (
    SELECT 1 FROM public.social_follows f WHERE f.follower_id=v_uid AND f.followed_id=v_owner
  ) THEN RAISE EXCEPTION 'Follow event requires an active follow'; END IF;
  IF v_type='impression' AND EXISTS (
    SELECT 1 FROM public.social_recommendation_events e
    WHERE e.user_id=v_uid AND e.post_id=p_post_id AND e.event_type='impression'
      AND e.created_at>now()-interval '2 minutes'
  ) THEN RETURN jsonb_build_object('success',true,'deduplicated',true); END IF;
  INSERT INTO public.social_recommendation_events(user_id,post_id,owner_id,event_type,watch_ms,hashtag_snapshot,created_at)
  VALUES(v_uid,p_post_id,v_owner,v_type,GREATEST(COALESCE(p_watch_ms,0),0),COALESCE(v_tags,ARRAY[]::text[]),now());
  RETURN jsonb_build_object('success',true,'event_type',v_type);
END;
$function$;

CREATE OR REPLACE FUNCTION public.social_get_trending_hashtags(p_limit integer DEFAULT 20)
RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='public','auth','private','pg_temp'
AS $function$
DECLARE v_uid uuid:=auth.uid(); v_result jsonb;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'tag',x.tag,'posts_count',x.posts_count,'reels_count',x.reels_count,
    'recent_posts_count',x.recent_posts_count,'engagement_count',x.engagement_count,'score',x.score
  ) ORDER BY x.score DESC,x.tag ASC),'[]'::jsonb)
  INTO v_result
  FROM (
    SELECT lower(h.tag) AS tag,
      COUNT(DISTINCT p.id)::integer AS posts_count,
      COUNT(DISTINCT p.id) FILTER (WHERE p.media_type='video')::integer AS reels_count,
      COUNT(DISTINCT p.id) FILTER (WHERE p.published_at>now()-interval '7 days')::integer AS recent_posts_count,
      (COALESCE(SUM(st.like_count),0)+COALESCE(SUM(st.comment_count),0)+COALESCE(SUM(LEAST(st.view_count,10000)),0))::integer AS engagement_count,
      (COUNT(DISTINCT p.id) FILTER (WHERE p.published_at>now()-interval '7 days')*3.0
        +COUNT(DISTINCT p.id)*0.25+COALESCE(SUM(st.like_count),0)*0.5
        +COALESCE(SUM(st.comment_count),0)*0.7+COALESCE(SUM(LEAST(st.view_count,10000)),0)*0.02) AS score
    FROM public.social_posts p
    CROSS JOIN LATERAL unnest(COALESCE(p.hashtags,ARRAY[]::text[])) AS h(tag)
    LEFT JOIN public.social_content_stats st ON st.content_type='post' AND st.content_id=p.id
    WHERE p.moderation_status='approved' AND (p.visible_until IS NULL OR p.visible_until>now())
      AND (p.owner_id=v_uid OR private.social_owner_account_visible(p.owner_id))
      AND NOT EXISTS(SELECT 1 FROM public.blocks b WHERE (b.blocker_id=v_uid AND b.blocked_user_id=p.owner_id) OR (b.blocker_id=p.owner_id AND b.blocked_user_id=v_uid))
    GROUP BY lower(h.tag)
  ) x LIMIT GREATEST(1,LEAST(COALESCE(p_limit,20),50));
  RETURN COALESCE(v_result,'[]'::jsonb);
END;
$function$;

CREATE OR REPLACE FUNCTION public.social_suggest_hashtags(p_prefix text,p_limit integer DEFAULT 10)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='public','auth','private','pg_temp'
AS $function$
DECLARE v_uid uuid:=auth.uid(); v_prefix text:=lower(regexp_replace(trim(coalesce(p_prefix,'')),'^#','')); v_result jsonb;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  WITH observed AS (
    SELECT lower(h.tag) AS tag,COUNT(DISTINCT p.id)::integer AS posts_count,
      COUNT(DISTINCT p.id) FILTER(WHERE p.media_type='video')::integer AS reels_count,
      COUNT(DISTINCT p.id) FILTER(WHERE p.published_at>now()-interval '7 days')::integer AS recent_posts_count,
      (COALESCE(SUM(st.like_count),0)+COALESCE(SUM(st.comment_count),0)+COALESCE(SUM(LEAST(st.view_count,10000)),0))::integer AS engagement_count,
      (COUNT(DISTINCT p.id) FILTER(WHERE p.published_at>now()-interval '7 days')*3.0+COUNT(DISTINCT p.id)*0.25
       +COALESCE(SUM(st.like_count),0)*0.5+COALESCE(SUM(st.comment_count),0)*0.7+COALESCE(SUM(LEAST(st.view_count,10000)),0)*0.02) AS score
    FROM public.social_posts p
    CROSS JOIN LATERAL unnest(COALESCE(p.hashtags,ARRAY[]::text[])) AS h(tag)
    LEFT JOIN public.social_content_stats st ON st.content_type='post' AND st.content_id=p.id
    WHERE p.moderation_status='approved' AND (p.visible_until IS NULL OR p.visible_until>now())
      AND (p.owner_id=v_uid OR private.social_owner_account_visible(p.owner_id))
      AND NOT EXISTS(SELECT 1 FROM public.blocks b WHERE (b.blocker_id=v_uid AND b.blocked_user_id=p.owner_id) OR (b.blocker_id=p.owner_id AND b.blocked_user_id=v_uid))
      AND (v_prefix='' OR lower(h.tag) LIKE v_prefix||'%')
    GROUP BY lower(h.tag)
  ), candidates AS (
    SELECT * FROM observed
    UNION ALL
    SELECT c.tag,0::integer,0::integer,0::integer,0::integer,0::numeric
    FROM public.social_hashtag_catalog c
    WHERE c.is_enabled=true AND (v_prefix='' OR c.tag LIKE v_prefix||'%')
      AND NOT EXISTS(SELECT 1 FROM observed o WHERE o.tag=c.tag)
  )
  SELECT COALESCE(jsonb_agg(jsonb_build_object('tag',x.tag,'posts_count',x.posts_count,'reels_count',x.reels_count,
    'recent_posts_count',x.recent_posts_count,'engagement_count',x.engagement_count,'score',x.score)
    ORDER BY x.score DESC,x.posts_count DESC,x.tag ASC),'[]'::jsonb)
  INTO v_result FROM (SELECT * FROM candidates ORDER BY score DESC,posts_count DESC,tag ASC LIMIT GREATEST(1,LEAST(COALESCE(p_limit,10),30))) x;
  RETURN COALESCE(v_result,'[]'::jsonb);
END;
$function$;

CREATE OR REPLACE FUNCTION public.social_get_hashtag_details(p_tag text)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='public','auth','private','pg_temp'
AS $function$
DECLARE v_uid uuid:=auth.uid(); v_tag text:=lower(regexp_replace(trim(coalesce(p_tag,'')),'^#','')); v_result jsonb;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF v_tag='' THEN RETURN jsonb_build_object('tag','','posts_count',0,'reels_count',0,'recent_posts_count',0,'engagement_count',0,'score',0); END IF;
  SELECT jsonb_build_object('tag',v_tag,'posts_count',COUNT(DISTINCT p.id)::integer,
    'reels_count',COUNT(DISTINCT p.id) FILTER(WHERE p.media_type='video')::integer,
    'recent_posts_count',COUNT(DISTINCT p.id) FILTER(WHERE p.published_at>now()-interval '7 days')::integer,
    'engagement_count',(COALESCE(SUM(st.like_count),0)+COALESCE(SUM(st.comment_count),0)+COALESCE(SUM(LEAST(st.view_count,10000)),0))::integer,
    'score',(COUNT(DISTINCT p.id) FILTER(WHERE p.published_at>now()-interval '7 days')*3.0+COUNT(DISTINCT p.id)*0.25
      +COALESCE(SUM(st.like_count),0)*0.5+COALESCE(SUM(st.comment_count),0)*0.7+COALESCE(SUM(LEAST(st.view_count,10000)),0)*0.02))
  INTO v_result FROM public.social_posts p
  LEFT JOIN public.social_content_stats st ON st.content_type='post' AND st.content_id=p.id
  WHERE v_tag=ANY(COALESCE(p.hashtags,ARRAY[]::text[]))
    AND p.moderation_status='approved' AND (p.visible_until IS NULL OR p.visible_until>now())
    AND (p.owner_id=v_uid OR private.social_owner_account_visible(p.owner_id))
    AND NOT EXISTS(SELECT 1 FROM public.blocks b WHERE (b.blocker_id=v_uid AND b.blocked_user_id=p.owner_id) OR (b.blocker_id=p.owner_id AND b.blocked_user_id=v_uid));
  RETURN COALESCE(v_result,jsonb_build_object('tag',v_tag,'posts_count',0,'reels_count',0,'recent_posts_count',0,'engagement_count',0,'score',0));
END;
$function$;

REVOKE ALL ON TABLE public.social_recommendation_events FROM PUBLIC,anon,authenticated;
REVOKE ALL ON TABLE public.social_hashtag_catalog FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.social_extract_hashtags() FROM PUBLIC,anon,authenticated;
REVOKE EXECUTE ON FUNCTION public.social_record_recommendation_event(uuid,text,bigint) FROM PUBLIC,anon;
REVOKE EXECUTE ON FUNCTION public.social_get_trending_hashtags(integer) FROM PUBLIC,anon;
REVOKE EXECUTE ON FUNCTION public.social_suggest_hashtags(text,integer) FROM PUBLIC,anon;
REVOKE EXECUTE ON FUNCTION public.social_get_hashtag_details(text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.social_record_recommendation_event(uuid,text,bigint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.social_get_trending_hashtags(integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.social_suggest_hashtags(text,integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.social_get_hashtag_details(text) TO authenticated;

-- Extend the existing personalized feed RPC so video-only queries are ranked separately.
DO $patch$
DECLARE v_def text;
BEGIN
  v_def := pg_get_functiondef('public.social_get_feed(integer,integer,text)'::regprocedure);

  -- Add explicit watch/skip/completion and hashtag interest scoring if this is an older feed version.
  IF position('social_recommendation_events' in v_def)=0 THEN
    v_def := replace(v_def, $old_score$
    (
      (SELECT count(*)::numeric * 3
       FROM unnest(COALESCE(p.hashtags, ARRAY[]::text[])) AS candidate(tag)
       WHERE EXISTS (
         SELECT 1 FROM public.social_likes liked
         JOIN public.social_posts liked_post ON liked_post.id=liked.content_id AND liked.content_type='post'
         WHERE liked.user_id=auth.uid() AND liked.is_active=true
           AND candidate.tag = ANY(COALESCE(liked_post.hashtags, ARRAY[]::text[]))
       ))
      + CASE WHEN EXISTS (SELECT 1 FROM public.social_post_views pv WHERE pv.viewer_id=auth.uid() AND pv.owner_id=p.owner_id) THEN 2 ELSE 0 END
      + CASE WHEN EXISTS (SELECT 1 FROM public.social_follows f WHERE f.follower_id=auth.uid() AND f.followed_id=p.owner_id) THEN 1 ELSE 0 END
      + LEAST(COALESCE(s.view_count,0),1000)::numeric / 1000
    ) AS recommendation_score$old_score$,
    $new_score$
    (
      (SELECT count(*)::numeric * 3
       FROM unnest(COALESCE(p.hashtags, ARRAY[]::text[])) AS candidate(tag)
       WHERE EXISTS (
         SELECT 1 FROM public.social_likes liked
         JOIN public.social_posts liked_post ON liked_post.id=liked.content_id AND liked.content_type='post'
         WHERE liked.user_id=auth.uid() AND liked.is_active=true
           AND candidate.tag = ANY(COALESCE(liked_post.hashtags, ARRAY[]::text[]))
       ))
      + CASE WHEN EXISTS (SELECT 1 FROM public.social_post_views pv WHERE pv.viewer_id=auth.uid() AND pv.owner_id=p.owner_id) THEN 2 ELSE 0 END
      + CASE WHEN EXISTS (SELECT 1 FROM public.social_follows f WHERE f.follower_id=auth.uid() AND f.followed_id=p.owner_id) THEN 1 ELSE 0 END
      + COALESCE((SELECT SUM(CASE e.event_type
          WHEN 'complete' THEN 5.0 WHEN 'watch' THEN 2.5 WHEN 'like' THEN 4.0
          WHEN 'comment' THEN 3.0 WHEN 'save' THEN 5.0 WHEN 'share' THEN 6.0
          WHEN 'impression' THEN 0.15 WHEN 'skip' THEN -2.5
          WHEN 'not_interested' THEN -15.0 WHEN 'hide' THEN -12.0 ELSE 0.0 END
          * EXP(-GREATEST(EXTRACT(EPOCH FROM (now()-e.created_at)),0)/604800.0))
        FROM public.social_recommendation_events e
        WHERE e.user_id=auth.uid() AND e.created_at>now()-interval '60 days'
          AND (e.owner_id=p.owner_id OR (cardinality(e.hashtag_snapshot)>0 AND e.hashtag_snapshot && COALESCE(p.hashtags,ARRAY[]::text[]))))),0)
      + LEAST(COALESCE(s.view_count,0),1000)::numeric / 1000
    ) AS recommendation_score$new_score$);
  END IF;

  -- Keep explicit negative feedback out of For You for two weeks.
  IF position('hidden.event_type=''not_interested''' in v_def)=0 THEN
    v_def := replace(v_def,
      'AND (p.owner_id=auth.uid() OR private.social_owner_account_visible(p.owner_id))',
      'AND (p.owner_id=auth.uid() OR private.social_owner_account_visible(p.owner_id))' || E'\n' ||
      '    AND NOT EXISTS (SELECT 1 FROM public.social_recommendation_events hidden WHERE hidden.user_id=auth.uid() AND hidden.post_id=p.id AND hidden.event_type=''not_interested'' AND hidden.created_at>now()-interval ''14 days'')');
  END IF;

  v_def := replace(v_def,
    'lower(trim(coalesce(p_feed_mode,''for_you'')))=''following''',
    'lower(trim(coalesce(p_feed_mode,''for_you''))) IN (''following'',''reels_following'')');
  v_def := replace(v_def,
    'lower(trim(coalesce(p_feed_mode,''for_you'')))=''for_you''',
    'lower(trim(coalesce(p_feed_mode,''for_you''))) IN (''for_you'',''reels_for_you'')');

  -- Only inject the media filter once so rerunning this migration stays safe.
  IF position('NOT IN (''reels_for_you'',''reels_following'')' in v_def)=0 THEN
    v_def := replace(v_def,
      'AND (p.owner_id=auth.uid() OR private.social_owner_account_visible(p.owner_id))',
      'AND (p.owner_id=auth.uid() OR private.social_owner_account_visible(p.owner_id))' || E'\n' ||
      '    AND (lower(trim(coalesce(p_feed_mode,''for_you''))) NOT IN (''reels_for_you'',''reels_following'')' || E'\n' ||
      '      OR p.media_type=''video''' || E'\n' ||
      '      OR lower(split_part(coalesce(p.media_path,''''),''?'',1)) ~ ''\\.(mp4|m4v|mov|webm|m3u8|3gp)$'')');
  END IF;
  IF position('reels_for_you' in v_def)=0 OR position('reels_following' in v_def)=0 THEN
    RAISE EXCEPTION 'Could not safely update feed mode predicates';
  END IF;
  EXECUTE v_def;
END
$patch$;
COMMIT;
