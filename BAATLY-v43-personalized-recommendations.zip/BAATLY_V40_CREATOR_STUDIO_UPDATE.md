# BAATLY User App v40 — Creator Studio and Playback Update

Version code remains **40**. This is an Android source ZIP, not a verified release APK.

## Creator Studio
- Post, Story and Reel selections open the editor before any upload starts.
- Photo edits: Original/Warm/Vivid/Mono/Vintage/Invert filters, rotate, text overlay and caption.
- Video edits: the same filter set, rotate, start/end trim, text overlay, optional music selected from the device, and separate original-audio/music volume sliders.
- Edited video is exported locally with Media3 Transformer before upload. Unedited photo/video is passed through without an unnecessary export step.
- In-app CameraX capture supports live color filters in preview and captured photos, with front/back camera switching.

## Playback performance
- Shared Media3 ExoPlayer path for Reels, Stories and full-screen video.
- Disk cache up to 192 MiB, cache-key stability for signed R2 URLs, adjacent Reels-page preparation and buffer tuning.
- Feed/story Edge Function responses are used to resolve signed media URLs in batches instead of signing every item individually on screen open.
- Video sound is enabled by default; the player requests media audio focus.

## Visual themes
- Super AI uses native dark cosmic Canvas artwork and animated orbit ribbons rather than a poster image.
- Astrology uses a dark solar-system theme with native animated orbits, differentiated planet colors, Saturn rings, stars and a warm solar glow.

## R2/Supabase
- The app calls the existing `baatly-r2-media` Edge Function and keeps media object keys/metadata in Supabase.
- Presigned R2 PUT URLs are used for media upload. The app does not embed R2 secret keys.
- No new backend schema or secrets are introduced in this UI/editor pass.

## Important validation note
Source ZIP integrity and Kotlin syntax were checked. This environment cannot download the Gradle wrapper from `services.gradle.org`, so a successful Android Gradle build and device-level playback/upload test are **not claimed**. Performance still depends on device codec support, video encoding and network/CDN conditions.
