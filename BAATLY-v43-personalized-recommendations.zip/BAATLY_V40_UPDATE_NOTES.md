# BAATLY User App v40 — Update notes

## UI changes

- Social Media is the default landing tab; **Feeds** is selected initially (not Reels).
- `Feedback` is renamed to `Feeds`; the segmented control is more compact.
- Reels use a vertical pager, play the active video automatically, loop muted and have a create-reel shortcut even when the feed already contains videos.
- Social search opens a full-screen search view with people/host results, not a small popup.
- Relationship retains the wallet and Messages icon and uses pull-to-refresh for the host list.
- Messages and Love Note lists classify conversations using approved-host role data (offline hosts remain in Love Note).
- Social profile Highlights now load from the backend. An active Story can be saved as a persistent Highlight with its media copied to R2.
- Super AI has branded purple/pink orb artwork; Entertainment has cinematic Indian-drama artwork and reads the published catalogue rather than fake hard-coded movie titles.
- `versionCode = 40`.

## Supabase + Cloudflare R2 media flow

The `baatly-media` bucket stays private; the app does not contain R2 secret keys.

- Photo/video post and story uploads request short-lived upload URLs from `baatly-r2-media` with `create_upload_url`, upload directly to the signed R2 URL, then create the social record through the existing authenticated Supabase RPC.
- Playback requests an authorized signed URL from the same Edge Function by social content type and database ID.
- Reels use server-provided `media_type`; R2 MP4/MOV/WebM/3GP keys can be classified as video.
- Entertainment reads published movies and short dramas from Supabase `streaming_catalog` and loads signed R2 media/poster URLs.
- Highlights use `add_highlight` to copy an approved active R2 Story into permanent `social/highlights/` storage, `list_highlights` to read it and `delete_highlight` to remove its objects.
- Expected object-key prefixes: `social/posts/`, `social/stories/`, `social/highlights/`, and `catalog/`.
- Social media is enabled in Supabase. Post/story creation, likes, view/unlock actions, and post-linked Love Notes no longer charge users or write new host social earnings. Historical ledger rows are retained.
- Stories expire after 24 hours; R2 lifecycle deletion is limited to `social/stories/`, not `social/highlights/`.

## Validation note

Cloudflare bucket/lifecycle, Supabase flags/tables/policies and the active Edge Function deployment were verified through the connected services. A live authenticated upload/playback run was not possible from this environment, and the full Android Gradle build remains unverified because the Gradle distribution download endpoint could not be resolved here. Run the Release workflow to get the authoritative compiler/build result before distributing the APK.
