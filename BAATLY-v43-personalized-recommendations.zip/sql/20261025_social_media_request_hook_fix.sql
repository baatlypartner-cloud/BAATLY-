-- BAATLY social media request-hook correction (2026-10-25)
-- Social Media is enabled. Do not return the old global HTTP 402 response for social RPCs/tables.
-- Also include the required headers field for intentionally blocked maintenance endpoints.
CREATE OR REPLACE FUNCTION private.baatly_api_pre_request()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
  v_path text := lower(trim(both '/' from coalesce(current_setting('request.path', true), '')));
  v_endpoint text := '';
  v_claims jsonb := nullif(current_setting('request.jwt.claims', true), '')::jsonb;
  v_jwt_role text := lower(coalesce(v_claims->>'role', ''));
BEGIN
  IF left(v_path, 8) = 'rest/v1/' THEN v_path := substr(v_path, 9); END IF;
  IF left(v_path, 4) = 'rpc/' THEN v_endpoint := split_part(v_path, '/', 2);
  ELSE v_endpoint := split_part(v_path, '/', 1); END IF;
  v_endpoint := regexp_replace(v_endpoint, '^public\\.', '');

  IF v_endpoint = 'run_baatly_retention_cleanup' AND v_jwt_role <> 'service_role' THEN
    RAISE SQLSTATE 'PGRST'
      USING message = json_build_object(
        'code', 'BAATLY_INTERNAL_ENDPOINT',
        'message', 'Not available to client apps',
        'details', 'This maintenance endpoint cannot be called by app clients.',
        'hint', 'Use the approved server-side maintenance path.'
      )::text,
      detail = json_build_object(
        'status', 403,
        'headers', json_build_object(),
        'status_text', 'Forbidden'
      )::text;
  END IF;

  RETURN;
END;
$function$;
