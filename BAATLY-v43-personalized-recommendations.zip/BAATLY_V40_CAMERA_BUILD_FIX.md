# BAATLY User App v40 — CameraX compile fix

Fixed `BaatlyCameraScreen.kt` compilation error:

- Removed invalid `CameraController.PREVIEW` use-case flag.
- Kept `CameraController.IMAGE_CAPTURE` enabled. CameraX `PreviewView` owns the preview stream; preview is not a `CameraController` enabled-use-case bit.
- Version code remains 40.

The existing code configures `PreviewView.controller = controller`, so the preview is still displayed while image capture is enabled.
