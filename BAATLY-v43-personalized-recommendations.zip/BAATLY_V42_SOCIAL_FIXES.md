# BAATLY User App — v42 Social Media Fixes

## Android source updates

- Added a real comments bottom sheet backed by `social_get_comments` and `social_add_comment`. Comments render the author's display name/avatar, text and timestamp, support submitting a comment, reload after successful submission, and expose loading/error/empty states.
- Fixed creator-owned Story UI: own Stories show a **Seen by** action and viewer list instead of Like/Comment/Follow. The viewer list is owner-only. Viewing another user's Story records the viewer against the Story ID.
- Added tap actions for Followers and Following counts, including list results with follow/request state.
- Added an own-profile Public/Private account switch and a follow-requests sheet with Accept/Reject actions.
- Changed profile Message action to route to the specific target conversation. For normal users it creates/resolves a direct conversation; approved hosts keep the existing host chat path.
- Added profile-grid post/Reel open behaviour with a retry state for failed media resolution. Media resolution uses the canonical media path so R2 playback URLs can be refreshed.
- Fixed video poster extraction: the scaled bitmap was being recycled twice, making the poster extraction fail; the `MediaMetadataRetriever` is also explicitly released for older Android versions.
- Refreshes a Highlight's signed R2 media URLs when it is tapped, and prevents an inaccessible private profile from showing a misleading “No Highlights yet” empty state.
- Added People, Posts, Reels and Hashtags filters to social search. Content results are clickable, use video poster frames, open in the viewer and record a content view.
- Added hashtag guidance to the post/Reel caption field. Hashtags are extracted server-side from captions.
- Implemented actual profile sharing through the Android share sheet.
- Incremented Android `versionCode` to **42**.

## Supabase backend changes already applied to the connected BAATLY project

Project: `qewhxsbrnlgunygghpez` (`ap-south-1`). The live backend was updated directly; app users do not need to paste SQL manually for that same project.

- `social_profiles.is_private` and the follow-request table support public/private accounts and requested-follow state. Existing accounts default to public to preserve their existing audience.
- `social_follow_toggle`, `social_set_account_privacy`, `social_get_follow_requests` and `social_respond_follow_request` handle follow requests and acceptance/rejection.
- `social_get_relationship_list` returns Followers/Following entries and checks private-profile visibility.
- `social_story_views`, `social_mark_story_view` and `social_get_story_viewers` store and return Story viewers. Only the Story owner can read its viewer list. Historical viewers from before tracking was enabled cannot be reconstructed.
- `social_posts.hashtags` plus a caption trigger store hashtags for Posts and Reels.
- `social_search_content` searches Posts/Reels/hashtags. Feed ranking now includes initial interest signals from followed creators, viewed creators and hashtags on posts the user has liked. This is a first-pass heuristic, not a trained ML recommendation model.
- Private content is checked in feed/profile RPCs, comment/like actions and the R2 media resolver. The overly broad `social_highlights_public_read` policy was removed.
- Social SECURITY DEFINER RPCs used by the app have execution revoked from `PUBLIC`/`anon` and granted to `authenticated` only.
- Cloudflare R2 Edge Function `baatly-r2-media` is active at **version 15** with private-profile visibility checks for Highlight and media URL resolution.

## Validation status

- Confirmed the backend migrations applied successfully and verified the new social RPCs are not executable by `anon` but are executable by `authenticated`.
- Confirmed the R2 media function is active at version 15.
- Kotlin source was checked for parse/syntax diagnostics; no parser errors were emitted. A full Android/Gradle compile **could not be completed** in this environment because the configured Gradle 9.3.1 distribution download was unreachable. Build and physical-device testing are still required before publishing.

## Suggested device test

1. Open any profile with a video Highlight; confirm its circle has a poster and tapping opens the video.
2. Tap Followers and Following on own and public profiles.
3. Enable Private account; view the profile from a non-follower and request to follow; approve that request from the owner account.
4. View an own Story; verify the bottom action says “Seen by”, not Like/Comment/Follow; view it from another account and verify the viewer appears.
5. Open another user's photo and Reel from their profile grid; confirm both render and the video plays.
6. Open that user's Message button and confirm the correct direct conversation opens.
7. Add a comment; confirm the author name/text appears and the comment remains after reopening the sheet.
8. Publish a caption with hashtags, then use Search > Posts/Reels/Hashtags and check that relevant content appears.


## v42 compile-log fix

- Added `@OptIn(ExperimentalMaterial3Api::class)` to `SocialProfileScreen`, covering both `ModalBottomSheet` calls reported by the v42 GitHub Actions Kotlin compile log at lines 295 and 321.
- The Agora native-library stripping message in the supplied log is a packaging warning; the task failure shown is `:app:compileReleaseKotlin`.
- Full Gradle compile remains unverified in the editing environment because `services.gradle.org` could not be resolved.
