package com.example.ui.call

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import com.example.MainActivity
import com.example.data.audio.BaatlyRingtoneManager
import com.example.data.local.SessionManager
import com.example.data.network.SupabaseClient
import com.example.data.network.SupabaseDataService
import com.example.data.network.SupabaseRealtimeManager
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class IncomingCallActivity : ComponentActivity() {

    private lateinit var sessionManager: SessionManager
    private lateinit var supabaseClient: SupabaseClient
    private lateinit var dataService: SupabaseDataService
    private lateinit var realtimeManager: SupabaseRealtimeManager

    private var callId: String = ""
    private var partnerId: String = ""
    private var callerName: String = ""
    private var avatarUrl: String = ""
    private var callType: String = "audio" // "audio" or "video"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Turn screen on and show when locked
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        // Parse Intent Extras
        callId = intent.getStringExtra("call_id") ?: ""
        partnerId = intent.getStringExtra("partner_id") ?: intent.getStringExtra("sender_id") ?: ""
        callerName = intent.getStringExtra("sender_name") ?: intent.getStringExtra("partner_name") ?: "Baatly Host"
        avatarUrl = intent.getStringExtra("avatar_url") ?: intent.getStringExtra("partner_avatar") ?: ""
        callType = intent.getStringExtra("call_type") ?: intent.getStringExtra("type") ?: "audio"

        // Initialize Services
        sessionManager = SessionManager(applicationContext)
        supabaseClient = SupabaseClient(sessionManager)
        dataService = SupabaseDataService(supabaseClient, sessionManager)
        realtimeManager = SupabaseRealtimeManager(supabaseClient.okHttpClient, sessionManager)

        // Play Ringtone
        BaatlyRingtoneManager.startRingtone(this)

        // Cancel previous notification since we are now displaying the full screen UI
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(callId.hashCode())

        // Subscriptions & Timeout
        lifecycleScope.launch {
            if (callId.isNotBlank()) {
                // Realtime cancellation check
                realtimeManager.subscribeToCall(callId) { updatedRecord ->
                    val status = updatedRecord.status.lowercase()
                    if (status == "cancelled" || status == "rejected" || status.contains("completed") || status.contains("fail") || status.contains("miss")) {
                        cleanupAndFinish()
                    }
                }
            }
        }

        // 30-Second unanswered timeout
        lifecycleScope.launch {
            delay(30000)
            if (!isDestroyed && !isFinishing) {
                // Mark missed and finish
                lifecycleScope.launch(Dispatchers.IO) {
                    if (callId.isNotBlank()) {
                        dataService.updateCallState(callId, "missed")
                    }
                }
                cleanupAndFinish()
            }
        }

        setContent {
            BaatlyTheme {
                IncomingCallScreen(
                    callerName = callerName,
                    avatarUrl = avatarUrl,
                    callType = callType,
                    dataService = dataService,
                    onAccept = { handleAccept() },
                    onDecline = { handleDecline() }
                )
            }
        }
    }

    private fun handleAccept() {
        BaatlyRingtoneManager.stopRingtone()

        // Launch MainActivity with ACCEPT extras to start existing call logic
        val mainIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("extra_accept_call", true)
            putExtra("call_id", callId)
            putExtra("partner_id", partnerId)
            putExtra("call_type", callType)
        }
        startActivity(mainIntent)
        finish()
    }

    private fun handleDecline() {
        lifecycleScope.launch(Dispatchers.IO) {
            if (callId.isNotBlank()) {
                dataService.updateCallState(callId, "rejected")
            }
        }
        cleanupAndFinish()
    }

    private fun cleanupAndFinish() {
        BaatlyRingtoneManager.stopRingtone()
        realtimeManager.unsubscribe()
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(callId.hashCode())
        finish()
    }

    override fun onDestroy() {
        BaatlyRingtoneManager.stopRingtone()
        realtimeManager.unsubscribe()
        super.onDestroy()
    }
}

@Composable
fun IncomingCallScreen(
    callerName: String,
    avatarUrl: String,
    callType: String,
    dataService: SupabaseDataService,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    val context = LocalContext.current
    var resolvedAvatarUrl by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(avatarUrl) {
        if (avatarUrl.isNotBlank() && avatarUrl != "null") {
            val resolved = dataService.resolveProfileAvatarUrl(avatarUrl)
            if (resolved.isNotBlank()) {
                resolvedAvatarUrl = resolved
            }
        }
    }

    Surface(
        color = Color.Black,
        modifier = Modifier.fillMaxSize()
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Full Screen Background Image
            if (!resolvedAvatarUrl.isNullOrBlank()) {
                AsyncImage(
                    model = resolvedAvatarUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DarkBackground)
                )
            }

            // Dim and blur overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.25f))
            )

            // Light white translucent overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = 0.55f))
            )

            // Main UI
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top section: Call Type & Badge
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 40.dp)
                ) {
                    Text(
                        text = "INCOMING CALL",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextMuted,
                            letterSpacing = 2.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = callerName,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        ),
                        modifier = Modifier.testTag("incoming_caller_name")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (callType.lowercase().contains("video")) "Video Call" else "Voice Call",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = PrimaryLavender
                        )
                    )
                }

                // Middle section: Central avatar
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(160.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(140.dp)
                            .clip(CircleShape)
                            .background(HostAvatarGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!resolvedAvatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = resolvedAvatarUrl,
                                contentDescription = callerName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Text(
                                text = callerName.take(1).uppercase(),
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            )
                        }
                    }
                }

                // Bottom section: Accept / Decline buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 48.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Decline Button (Red)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatingActionButton(
                            onClick = onDecline,
                            containerColor = DangerRed,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(64.dp)
                                .testTag("btn_decline_call")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CallEnd,
                                contentDescription = "Decline Call",
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Decline",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            )
                        )
                    }

                    // Accept Button (Green)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatingActionButton(
                            onClick = onAccept,
                            containerColor = OnlineGreen,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(64.dp)
                                .testTag("btn_accept_call")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Call,
                                contentDescription = "Accept Call",
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Accept",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}
