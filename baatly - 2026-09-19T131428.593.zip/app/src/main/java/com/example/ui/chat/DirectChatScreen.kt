package com.example.ui.chat

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ChatMessage
import com.example.data.network.SupabaseConfig
import com.example.domain.BillingEngine
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DirectChatScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val partner by viewModel.chatPartner.collectAsState()
    val activeConv by viewModel.activeConversation.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isBlocked by viewModel.isChatBlocked.collectAsState()
    val blockStatus by viewModel.chatBlockStatus.collectAsState()
    val isBlockedMe = blockStatus?.blockedMe == true && !isBlocked
    val currentUser by viewModel.currentUser.collectAsState()
    val walletSummary by viewModel.walletSummary.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()

    val isRecording by viewModel.audioRecorderManager.isRecording.collectAsState()
    val currentlyPlayingUrl by viewModel.audioPlayerManager.currentlyPlayingUrl.collectAsState()
    val isAudioPlaying by viewModel.audioPlayerManager.isPlaying.collectAsState()

    var messageText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }

    // Voice recording preview state
    var recordedVoiceFile by remember { mutableStateOf<File?>(null) }
    var recordedVoiceDuration by remember { mutableStateOf(0) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val isImeVisible = WindowInsets.isImeVisible

    // Image Picker Launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val tempFile = File(context.cacheDir, "chat_img_${System.currentTimeMillis()}.jpg")
                    tempFile.outputStream().use { output ->
                        inputStream?.copyTo(output)
                    }
                    viewModel.sendImageMessage(tempFile)
                } catch (e: Exception) {
                    viewModel.showUserMessage("Failed to load selected photo")
                }
            }
        }
    }

    BackHandler {
        viewModel.closeChatScreen()
    }

    val currentUserId = viewModel.sessionManager.userId.value ?: currentUser?.id ?: currentUser?.userId ?: ""

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    LaunchedEffect(isImeVisible) {
        if (isImeVisible && messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val host = partner
    val hostDisplayName = host?.displayName?.takeIf { it.isNotBlank() && it != "Partner" && it != "Baatly Host" }
        ?: host?.partnerDisplayName?.takeIf { it.isNotBlank() && it != "Partner" && it != "Baatly Host" }
        ?: host?.displayName?.takeIf { it.isNotBlank() }
        ?: "Host"

    val resolvedHostAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(host?.avatarUrl, viewModel.dataService)
    val isResolvingHostAvatar = !host?.avatarUrl.isNullOrBlank() && host?.avatarUrl != "null" && resolvedHostAvatarUrl == null

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(HostAvatarGradient)
                                .border(1.5.dp, if (host?.isOnline == true) OnlineGreen else Color(0xFFE2DED7), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!resolvedHostAvatarUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = resolvedHostAvatarUrl,
                                    contentDescription = hostDisplayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else if (isResolvingHostAvatar) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color(0xFF00A884),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = (hostDisplayName.take(1)).uppercase(),
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        fontSize = 16.sp
                                    )
                                )
                            }
                        }
                        Column {
                            Text(
                                text = hostDisplayName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF111B21)
                                )
                            )
                            Text(
                                text = if (host?.isOnline == true) "Online" else if (host != null) "Offline" else "",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (host?.isOnline == true) Color(0xFF00A884) else Color(0xFF667781)
                                )
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.closeChatScreen() },
                        modifier = Modifier.testTag("btn_back_direct_chat")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color(0xFF111B21)
                        )
                    }
                },
                actions = {
                    // Call Shortcut
                    if (host != null) {
                        IconButton(
                            onClick = {
                                viewModel.startCall(host, isVideo = false)
                            },
                            modifier = Modifier.testTag("btn_chat_header_call")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Call,
                                contentDescription = "Call Partner",
                                tint = Color(0xFF00A884)
                            )
                        }
                    }

                    // Three-dot Menu
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("btn_chat_menu")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MoreVert,
                            contentDescription = "Options",
                            tint = Color(0xFF111B21)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(Color.White)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Report User", color = DangerRed) },
                            leadingIcon = { Icon(Icons.Filled.Flag, contentDescription = null, tint = DangerRed) },
                            onClick = {
                                showMenu = false
                                if (host != null) {
                                    viewModel.openReportDialog(
                                        targetUserId = host.id,
                                        targetUserName = hostDisplayName,
                                        targetAvatarUrl = host.avatarUrl
                                    )
                                }
                            },
                            modifier = Modifier.testTag("menu_report_user")
                        )
                        if (blockStatus != null) {
                            if (isBlocked) {
                                DropdownMenuItem(
                                    text = { Text("Unblock Partner", color = Color(0xFF00A884)) },
                                    leadingIcon = { Icon(Icons.Filled.LockOpen, contentDescription = null, tint = Color(0xFF00A884)) },
                                    onClick = {
                                        showMenu = false
                                        if (host != null) {
                                            viewModel.unblockUser(host.id)
                                        }
                                    },
                                    modifier = Modifier.testTag("menu_unblock_host")
                                )
                            } else {
                                DropdownMenuItem(
                                    text = { Text("Block Partner", color = DangerRed) },
                                    leadingIcon = { Icon(Icons.Filled.Block, contentDescription = null, tint = DangerRed) },
                                    onClick = {
                                        showMenu = false
                                        if (host != null) {
                                            viewModel.blockUser(host.id)
                                        }
                                    },
                                    modifier = Modifier.testTag("menu_block_host")
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF7F5F0))
            )
        },
        contentWindowInsets = WindowInsets.statusBars,
        containerColor = WhatsAppChatBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WhatsAppChatBackground)
                .padding(top = innerPadding.calculateTopPadding())
                .consumeWindowInsets(innerPadding)
                .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
        ) {
            // Rate Information Bar
            Surface(
                color = Color(0xFFF0ECE5),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DED7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val rate = effectivePricing.messageRateRupees
                    val balanceRupees = walletSummary.availableBalanceRupees
                    Text(
                        text = if (rate > 0.0) "Chat Rate: ₹${rate.toInt()}/msg" else "Chat Rate: Free",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF54656F))
                    )
                    Text(
                        text = "Balance: ₹${BillingEngine.formatRupees(balanceRupees)}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF00A884),
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // Message List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .imeNestedScroll(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val myId = viewModel.sessionManager.userId.value ?: currentUser?.id ?: currentUser?.userId
                    val isMe = msg.senderId == myId
                    MessageBubble(
                        message = msg,
                        isMe = isMe,
                        isPlaying = isAudioPlaying && currentlyPlayingUrl == msg.mediaUrl,
                        onPlayVoice = { rawUrl ->
                            viewModel.audioPlayerManager.play(rawUrl)
                        },
                        viewModel = viewModel
                    )
                }
            }

            // Composer Area
            if (blockStatus == null) {
                Surface(
                    color = Color(0xFFF7F5F0),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = Color(0xFF00A884),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            } else if (isBlocked) {
                Surface(
                    color = Color(0xFFF7F5F0),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Partner is blocked.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = DangerRed),
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        TextButton(
                            onClick = {
                                if (host != null) {
                                    viewModel.unblockUser(host.id)
                                }
                            },
                            modifier = Modifier.testTag("btn_unblock_host")
                        ) {
                            Text("Unblock", color = Color(0xFF00A884), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else if (isBlockedMe) {
                Surface(
                    color = Color(0xFFF7F5F0),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = "This user is unavailable.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray)
                        )
                    }
                }
            } else if (recordedVoiceFile != null) {
                // Voice Note Preview Bar
                Surface(
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DED7)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = {
                                recordedVoiceFile?.delete()
                                recordedVoiceFile = null
                                recordedVoiceDuration = 0
                            },
                            modifier = Modifier.testTag("btn_discard_voice")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Discard Voice Note",
                                tint = DangerRed
                            )
                        }

                        IconButton(
                            onClick = {
                                recordedVoiceFile?.let {
                                    viewModel.audioPlayerManager.play(it.absolutePath)
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00A884))
                        ) {
                            Icon(
                                imageVector = if (isAudioPlaying && currentlyPlayingUrl == recordedVoiceFile?.absolutePath) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = "Preview",
                                tint = Color.White
                            )
                        }

                        Text(
                            text = "Voice Note (${recordedVoiceDuration}s)",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color(0xFF111B21),
                                fontWeight = FontWeight.SemiBold
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                val file = recordedVoiceFile
                                val duration = recordedVoiceDuration
                                recordedVoiceFile = null
                                recordedVoiceDuration = 0
                                if (file != null) {
                                    viewModel.sendVoiceMessage(file, duration)
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00A884))
                                .testTag("btn_send_voice_preview")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send Voice Note",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            } else if (isRecording) {
                // Active Recording Bar
                Surface(
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DangerRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.audioRecorderManager.cancelRecording() },
                            modifier = Modifier.testTag("btn_cancel_recording")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Cancel Recording",
                                tint = Color(0xFF667781)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                        )

                        Text(
                            text = "Recording audio note...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = DangerRed,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                val (file, duration) = viewModel.audioRecorderManager.stopRecording()
                                if (file != null) {
                                    recordedVoiceFile = file
                                    recordedVoiceDuration = duration
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                                .testTag("btn_stop_recording")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Stop,
                                contentDescription = "Stop Recording",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            } else {
                // Standard Composer
                Surface(
                    color = Color(0xFFF7F5F0),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DED7)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Image / Photo Picker Button
                        IconButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("btn_chat_image")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Photo,
                                contentDescription = "Send Photo",
                                tint = Color(0xFF54656F),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Gift Button
                        IconButton(
                            onClick = { viewModel.openGiftSheet() },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("btn_chat_gift")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CardGiftcard,
                                contentDescription = "Send Gift",
                                tint = SecondaryAmber,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Text Field
                        TextField(
                            value = messageText,
                            onValueChange = { messageText = it },
                            placeholder = {
                                Text(
                                    text = "Type message...",
                                    color = Color(0xFF667781),
                                    fontSize = 15.sp
                                )
                            },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = Color(0xFF111B21),
                                unfocusedTextColor = Color(0xFF111B21),
                                cursorColor = Color(0xFF00A884)
                            ),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 44.dp, max = 110.dp)
                                .border(1.dp, Color(0xFFE2DED7), RoundedCornerShape(24.dp))
                                .testTag("chat_input_field")
                        )

                        // Voice or Send button
                        if (messageText.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    val textToSend = messageText
                                    messageText = ""
                                    viewModel.sendMessage(textToSend)
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00A884))
                                    .testTag("btn_chat_send")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    viewModel.audioRecorderManager.startRecording()
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00A884))
                                    .testTag("btn_chat_voice_record")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Mic,
                                    contentDescription = "Record Voice Note",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: ChatMessage,
    isMe: Boolean,
    isPlaying: Boolean,
    onPlayVoice: (String) -> Unit,
    viewModel: BaatlyViewModel
) {
    val resolvedImageUrl by produceState<String?>(initialValue = message.mediaUrl, key1 = message.mediaUrl) {
        val raw = message.mediaUrl?.trim()
        if (raw.isNullOrBlank()) {
            value = null
        } else if (raw.startsWith("http://", ignoreCase = true) || raw.startsWith("https://", ignoreCase = true)) {
            value = raw
        } else {
            value = viewModel.dataService.getSignedMediaUrl(raw, SupabaseConfig.BUCKET_CHAT_MEDIA)
        }
    }

    val bubbleColor = if (isMe) WhatsAppOutgoingBubble else WhatsAppIncomingBubble
    val textColor = WhatsAppChatTextDark

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMe) 16.dp else 4.dp,
                bottomEnd = if (isMe) 4.dp else 16.dp
            ),
            color = bubbleColor,
            shadowElevation = 1.dp,
            border = androidx.compose.foundation.BorderStroke(0.5.dp, if (isMe) Color(0xFFC7EBC0) else Color(0xFFE5E0D8)),
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                when (message.messageType) {
                    "image" -> {
                        val imageSrc = resolvedImageUrl ?: message.mediaUrl
                        AsyncImage(
                            model = imageSrc,
                            contentDescription = "Shared Photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 180.dp, max = 280.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                    }
                    "voice" -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(
                                onClick = { message.mediaUrl?.let { onPlayVoice(it) } },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isMe) Color(0xFF00A884) else SecondaryAmber)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = "Play Voice Note",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Voice Note (${message.mediaDurationSeconds ?: 0}s)",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = textColor,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "Audio message",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF667781)
                                    )
                                )
                            }
                        }
                    }
                    "gift" -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White,
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2DED7)),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.CardGiftcard,
                                        contentDescription = "Gift",
                                        tint = SecondaryAmber,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "Sent a Gift",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color(0xFF111B21),
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                if (!message.messageText.isNullOrBlank()) {
                                    Text(
                                        text = message.messageText,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = Color(0xFF667781)
                                        )
                                    )
                                }
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = message.messageText ?: "",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = textColor,
                                fontSize = 15.sp,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }

                // Status ticks for outgoing messages
                if (isMe) {
                    val state = com.example.data.model.getMessageDeliveryState(
                        message.deliveredAt,
                        message.seenAt
                    )
                    val tickText = when (state) {
                        com.example.data.model.MessageDeliveryState.SEEN -> "✓✓"
                        com.example.data.model.MessageDeliveryState.DELIVERED -> "✓✓"
                        com.example.data.model.MessageDeliveryState.SENT -> "✓"
                    }
                    val tickColor = if (state == com.example.data.model.MessageDeliveryState.SEEN) WhatsAppTickBlue else WhatsAppTickGrey

                    Row(
                        modifier = Modifier
                            .align(Alignment.End)
                            .padding(top = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tickText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = tickColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = (-1).sp
                            ),
                            modifier = Modifier.testTag("msg_status_${message.id}")
                        )
                    }
                }
            }
        }
    }
}
