package com.example.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.util.Log

object BaatlyRingtoneManager {
    private var ringtone: Ringtone? = null

    fun startRingtone(context: Context) {
        synchronized(this) {
            try {
                if (ringtone?.isPlaying == true) {
                    return
                }
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val rt = RingtoneManager.getRingtone(context, uri) ?: return
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    rt.audioAttributes = AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .build()
                }
                ringtone = rt
                rt.play()
                Log.d("BaatlyRingtoneManager", "Ringtone started playing")
            } catch (e: Exception) {
                Log.e("BaatlyRingtoneManager", "Failed to start ringtone: ${e.message}", e)
            }
        }
    }

    fun stopRingtone() {
        synchronized(this) {
            try {
                if (ringtone?.isPlaying == true) {
                    ringtone?.stop()
                    Log.d("BaatlyRingtoneManager", "Ringtone stopped playing")
                }
                ringtone = null
            } catch (e: Exception) {
                Log.e("BaatlyRingtoneManager", "Failed to stop ringtone: ${e.message}", e)
            }
        }
    }
}
