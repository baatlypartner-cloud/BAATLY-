package com.example

import com.example.data.model.CallRecord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CallBillingSafetyTest {

    @Test
    fun testCallerCancelDuringRequesting_zeroChargeAndZeroDuration() {
        val call = CallRecord(
            id = "call_req_1",
            userId = "user_1",
            partnerId = "partner_1",
            channelName = "channel_1",
            callType = "audio",
            status = "cancelled",
            startedAt = "2026-09-19T10:00:00Z",
            connectedAt = null,
            endedAt = "2026-09-19T10:00:05Z",
            durationSeconds = 0,
            totalAmountRupees = 0.0,
            userChargeRupees = 0.0
        )

        assertFalse("Call must not be considered connected", call.isConnected)
        assertEquals("Duration must be 0", 0, call.effectiveDurationSeconds)
        assertEquals("User charge must be 0.0", 0.0, call.effectiveUserChargeRupees, 0.001)
    }

    @Test
    fun testCallerCancelDuringRinging_zeroChargeAndZeroDuration() {
        val call = CallRecord(
            id = "call_ring_1",
            userId = "user_1",
            partnerId = "partner_1",
            channelName = "channel_1",
            callType = "audio",
            status = "cancelled",
            startedAt = "2026-09-19T10:00:00Z",
            connectedAt = null,
            endedAt = "2026-09-19T10:00:15Z",
            durationSeconds = 15, // even if erroneously populated by a bug
            totalAmountRupees = 5.0,
            userChargeRupees = 5.0
        )

        assertFalse("Call must not be connected when connectedAt is null", call.isConnected)
        assertEquals("Effective duration must defensively be 0", 0, call.effectiveDurationSeconds)
        assertEquals("Effective user charge must defensively be 0.0", 0.0, call.effectiveUserChargeRupees, 0.001)
    }

    @Test
    fun testAcceptedWithoutConnectedAt_zeroChargeAndZeroDuration() {
        val call = CallRecord(
            id = "call_acc_1",
            userId = "user_1",
            partnerId = "partner_1",
            channelName = "channel_1",
            callType = "audio",
            status = "cancelled",
            startedAt = "2026-09-19T10:00:00Z",
            connectedAt = null,
            endedAt = "2026-09-19T10:00:10Z",
            durationSeconds = 0,
            totalAmountRupees = 0.0
        )

        assertFalse(call.isConnected)
        assertEquals(0, call.effectiveDurationSeconds)
        assertEquals(0.0, call.effectiveUserChargeRupees, 0.001)
    }

    @Test
    fun testRejectedOrDeclinedCall_zeroChargeAndZeroDuration() {
        val call = CallRecord(
            id = "call_declined_1",
            userId = "user_1",
            partnerId = "partner_1",
            channelName = "channel_1",
            callType = "audio",
            status = "rejected",
            startedAt = "2026-09-19T10:00:00Z",
            connectedAt = null,
            endedAt = "2026-09-19T10:00:08Z",
            durationSeconds = 0,
            totalAmountRupees = 0.0
        )

        assertFalse(call.isConnected)
        assertEquals(0, call.effectiveDurationSeconds)
        assertEquals(0.0, call.effectiveUserChargeRupees, 0.001)
    }

    @Test
    fun testMissedCall_zeroChargeAndZeroDuration() {
        val call = CallRecord(
            id = "call_missed_1",
            userId = "user_1",
            partnerId = "partner_1",
            channelName = "channel_1",
            callType = "audio",
            status = "missed",
            startedAt = "2026-09-19T10:00:00Z",
            connectedAt = null,
            endedAt = "2026-09-19T10:00:45Z",
            durationSeconds = 0,
            totalAmountRupees = 0.0
        )

        assertFalse(call.isConnected)
        assertEquals(0, call.effectiveDurationSeconds)
        assertEquals(0.0, call.effectiveUserChargeRupees, 0.001)
    }

    @Test
    fun testTrueConnectedCompletedCall_normalBillingAndDuration() {
        val call = CallRecord(
            id = "call_connected_1",
            userId = "user_1",
            partnerId = "partner_1",
            channelName = "channel_1",
            callType = "audio",
            status = "completed",
            startedAt = "2026-09-19T10:00:00Z",
            connectedAt = "2026-09-19T10:00:05Z",
            endedAt = "2026-09-19T10:03:05Z",
            durationSeconds = 180,
            totalAmountRupees = 15.0,
            userChargeRupees = 15.0
        )

        assertTrue("Call must be connected when connectedAt is non-blank and status is completed", call.isConnected)
        assertEquals("Duration must match connected duration", 180, call.effectiveDurationSeconds)
        assertEquals("User charge must match billed amount", 15.0, call.effectiveUserChargeRupees, 0.001)
    }
}
