# BAATLY AI voice migration — no Agora Conversational AI

Date: 2026-10-27

## Applied to live backend

- Supabase `ai-call-start` v27 reserves the normal ₹5/min AI audio session and returns `provider=cloudflare_sarvam_websocket` plus the direct `ai-voice-stream` WebSocket URL. It no longer calls Agora Conversational AI `/join`, creates an agent, or generates an AI-agent RTC token.
- Supabase `ai-voice-stream` v18 accepts `Authorization: Bearer <Supabase access token>` and retains query-token fallback for older clients. STT and TTS remain Sarvam; response generation uses the Cloudflare Workers AI endpoint. The reported rate now matches the ₹5/min session reservation.
- Supabase `ai-call-end` v26 no longer requires Agora credentials for a new direct-WebSocket session. Its legacy Agora-agent cleanup path remains available only for any old provider sessions.
- Cloudflare Worker `baatly-ai-gateway` v1.6.2 no longer exposes `/v1/agora/chat/completions`; the `AGORA_GATEWAY_TOKEN` secret was deleted.
- Supabase non-public `app_config.cloudflare_agora_gateway_token` was deleted after migrating `ai-call-start`.
- Database check at the time of the change found **0 active AI audio sessions**, so there was no active session to stop.

## Billing impact and scope

The AI audio session start path no longer starts Agora Conversational AI agents. AI speech uses Sarvam realtime STT/TTS and Cloudflare Workers AI for the LLM. This is separate from ordinary user-to-user/partner Agora RTC calling, which is intentionally unchanged. Sarvam and Cloudflare usage still have their own usage costs.

## APK build fix

`SuperAiScreen.kt` now imports `androidx.compose.foundation.verticalScroll` and `androidx.compose.foundation.rememberScrollState`, fixing the screenshot's `Unresolved reference 'verticalScroll'` compiler error.

## Verification and remaining test gates

- Cloudflare Worker source passes `node --check`.
- ZIP integrity is checked with `unzip -t` after packaging.
- Live Supabase versions and Worker version confirmed through management APIs; no active audio sessions were found during cutover.
- A full Android Gradle build could not be run in this runtime: Gradle 9.3.1 is not cached and `services.gradle.org` fails DNS resolution here. Do not treat the ZIP as a tested APK.
- Important: the Android Kotlin sources in this provided v44 bundle currently contain no callers for `ai-call-start` or `ai-voice-stream`. Thus the server side is migrated away from Agora Conversational AI, but native microphone capture, WebSocket streaming and audio playback still must be integrated and device-tested before AI voice calls can be used from this APK. Normal Agora RTC calls are unchanged.
