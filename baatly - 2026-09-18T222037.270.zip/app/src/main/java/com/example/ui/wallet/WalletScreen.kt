package com.example.ui.wallet

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import com.example.data.model.TransactionItem
import com.example.data.model.WalletRechargePackage
import com.example.data.model.UroPayPaymentUiState
import com.example.domain.BillingEngine
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val wallet by viewModel.walletSummary.collectAsState()
    val packages by viewModel.rechargePackages.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val paymentState by viewModel.uropayPaymentState.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()

    val isProcessingPayment = paymentState is UroPayPaymentUiState.CreatingOrder ||
            paymentState is UroPayPaymentUiState.Verifying ||
            paymentState is UroPayPaymentUiState.OpeningCheckout

    var selectedTab by remember { mutableIntStateOf(0) }
    val currentBalanceRupees = wallet.balanceRupees

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Wallet", color = TextPrimary) },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.setScreen(Screen.HOME) },
                        modifier = Modifier.testTag("btn_back_wallet")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.refreshWallet()
                        viewModel.refreshRechargePackages()
                        viewModel.fetchTransactions()
                    }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh", tint = TextSecondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // Balance Hero Card
            item {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = DarkSurface,
                    border = BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(PrimaryLavender),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "₹",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 32.sp,
                                    color = Color(0xFF1C1C22)
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "CURRENT WALLET BALANCE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "₹${BillingEngine.formatRupees(currentBalanceRupees)}",
                            style = MaterialTheme.typography.displaySmall.copy(
                                fontWeight = FontWeight.Black,
                                color = TextPrimary,
                                fontSize = 36.sp
                            )
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        val callRate = effectivePricing.callRateRupeesPerMinute
                        val callMinutes = if (callRate > 0.0) (currentBalanceRupees / callRate).toInt() else 0
                        Text(
                            text = "≈ $callMinutes min Audio Call time (₹${callRate.toInt()}/min)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = PrimaryLavender.copy(alpha = 0.85f),
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            // Standard Baatly Rates Banner
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(1.dp, DarkBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Standard Baatly Rates",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• Audio Call: ₹${effectivePricing.callRateRupeesPerMinute.toInt()}/min\n• Video Call: ₹${effectivePricing.videoCallRateRupeesPerMinute.toInt()}/min\n• Direct Chat: ₹${effectivePricing.messageRateRupees.toInt()}/msg\n• Gifts: As marked in gifts catalog",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                lineHeight = 22.sp
                            )
                        )
                    }
                }
            }

            // Section Tabs
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DarkSurface,
                    contentColor = PrimaryLavender,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = PrimaryLavender
                        )
                    },
                    divider = {}
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                "Recharge Packages",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 0) PrimaryLavender else TextSecondary
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            viewModel.fetchTransactions()
                        },
                        text = {
                            Text(
                                "History",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 1) PrimaryLavender else TextSecondary
                            )
                        }
                    )
                }
            }

            if (selectedTab == 0) {
                // Recharge Packages Section
                if (packages.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = PrimaryLavender,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                } else {
                    items(packages.sortedBy { it.sortOrder }, key = { it.id }) { pkg ->
                        RechargePackageCard(
                            pkg = pkg,
                            isProcessing = isProcessingPayment,
                            effectivePricing = effectivePricing,
                            onBuyClick = { viewModel.startUroPayRecharge(pkg) }
                        )
                    }
                }
            } else {
                // Transactions History Section
                if (transactions.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = DarkSurface,
                            border = BorderStroke(1.dp, DarkCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ReceiptLong,
                                    contentDescription = null,
                                    tint = TextSecondary.copy(alpha = 0.5f),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "No Transactions Yet",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextSecondary
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Your wallet recharges, call deductions, and gift transactions will appear here.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary.copy(alpha = 0.8f),
                                        textAlign = TextAlign.Center
                                    )
                                )
                            }
                        }
                    }
                } else {
                    items(transactions, key = { it.id }) { tx ->
                        TransactionRowCard(tx = tx)
                    }
                }
            }
        }
    }

    // UroPay Payment Status Dialog
    if (paymentState !is UroPayPaymentUiState.Idle) {
        UroPayPaymentStatusDialog(
            state = paymentState,
            onDismiss = { viewModel.resetPaymentState() },
            onLaunchCheckoutAgain = { url ->
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    viewModel.showUserMessage("Could not open browser: ${e.message}")
                }
            },
            onVerifyAgain = { paymentId -> viewModel.verifyUroPayPayment(paymentId) }
        )
    }
}

@Composable
fun RechargePackageCard(
    pkg: WalletRechargePackage,
    isProcessing: Boolean,
    effectivePricing: com.example.data.model.EffectiveUserPricing,
    onBuyClick: () -> Unit
) {
    val amountRupees = pkg.amountRupees
    val callMinutes = if (effectivePricing.callRateRupeesPerMinute > 0.0) (amountRupees / effectivePricing.callRateRupeesPerMinute).toInt() else 0

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(PrimaryLavenderContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "₹",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = PrimaryLavender,
                            fontSize = 20.sp
                        )
                    )
                }

                Column {
                    Text(
                        text = "₹${BillingEngine.formatRupees(amountRupees)} Wallet Balance",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "≈ $callMinutes min Audio Call time",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )
                }
            }

            Button(
                onClick = onBuyClick,
                enabled = !isProcessing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryLavender,
                    contentColor = Color(0xFF1C1C22),
                    disabledContainerColor = PrimaryLavender.copy(alpha = 0.4f),
                    disabledContentColor = Color(0xFF1C1C22).copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("btn_buy_pkg_${pkg.amountRupees.toInt()}")
            ) {
                Text(
                    text = "₹${pkg.amountRupees.toInt()}",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun TransactionRowCard(tx: TransactionItem) {
    val amount = tx.amountRupees
    val isCredit = tx.type.equals("credit", ignoreCase = true) || amount > 0
    val formattedAmount = if (amount > 0) "+₹${BillingEngine.formatRupees(amount)}" else "-₹${BillingEngine.formatRupees(kotlin.math.abs(amount))}"

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCredit) Color(0xFF1B382B) else Color(0xFF381B24)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isCredit) Icons.Filled.AddCircle else Icons.Filled.RemoveCircle,
                        contentDescription = null,
                        tint = if (isCredit) Color(0xFF4CAF50) else Color(0xFFEF5350),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column {
                    Text(
                        text = tx.description ?: if (isCredit) "Wallet Recharge" else "Usage Deduction",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    )
                    if (!tx.createdAt.isNullOrBlank()) {
                        Text(
                            text = tx.createdAt.take(16).replace("T", " "),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            Text(
                text = formattedAmount,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isCredit) Color(0xFF4CAF50) else Color(0xFFEF5350)
                )
            )
        }
    }
}

@Composable
fun UroPayPaymentStatusDialog(
    state: UroPayPaymentUiState,
    onDismiss: () -> Unit,
    onLaunchCheckoutAgain: (String) -> Unit,
    onVerifyAgain: (String) -> Unit
) {
    Dialog(
        onDismissRequest = {
            if (state !is UroPayPaymentUiState.CreatingOrder && state !is UroPayPaymentUiState.Verifying) {
                onDismiss()
            }
        },
        properties = DialogProperties(securePolicy = SecureFlagPolicy.SecureOff)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = DarkSurface,
            border = BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (state) {
                    is UroPayPaymentUiState.CreatingOrder -> {
                        CircularProgressIndicator(
                            color = PrimaryLavender,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "Preparing Checkout",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Setting up secure UroPay recharge for ₹${state.amountRupees.toInt()}...",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        )
                    }

                    is UroPayPaymentUiState.OpeningCheckout -> {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(PrimaryLavenderContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.OpenInBrowser,
                                contentDescription = null,
                                tint = PrimaryLavender,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Checkout Launched",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Complete your recharge via UroPay. You'll return to Baatly after completion.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                onVerifyAgain(state.paymentId)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimaryLavender,
                                contentColor = Color(0xFF1C1C22)
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("I've Completed Payment", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = { onLaunchCheckoutAgain(state.openUrl) },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = PrimaryLavender
                            ),
                            border = BorderStroke(1.dp, PrimaryLavender.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Re-open Checkout Window")
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        TextButton(
                            onClick = onDismiss
                        ) {
                            Text("Cancel", color = TextSecondary)
                        }
                    }

                    is UroPayPaymentUiState.Verifying -> {
                        CircularProgressIndicator(
                            color = PrimaryLavender,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "Verifying Payment",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Connecting with UroPay to verify transaction...",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        )
                    }

                    is UroPayPaymentUiState.Success -> {
                        LaunchedEffect(state.paymentId) {
                            kotlinx.coroutines.delay(2500L)
                            onDismiss()
                        }

                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1B382B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF4CAF50),
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Payment Successful!",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "+₹${BillingEngine.formatRupees(state.amountRupees)} added to your wallet.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color(0xFF81C784),
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "New Balance: ₹${BillingEngine.formatRupees(state.newBalanceRupees)}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary
                            )
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimaryLavender,
                                contentColor = Color(0xFF1C1C22)
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Done", fontWeight = FontWeight.Bold)
                        }
                    }

                    is UroPayPaymentUiState.Failed -> {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF381B24)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = Color(0xFFEF5350),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Payment Failed",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = state.errorMessage,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceVariant,
                                contentColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Close", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    is UroPayPaymentUiState.Pending -> {
                        CircularProgressIndicator(
                            color = PrimaryLavender,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "Payment Processing",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceVariant,
                                contentColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Dismiss", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    is UroPayPaymentUiState.Expired -> {
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceVariant,
                                contentColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Close", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    is UroPayPaymentUiState.SessionExpired -> {
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceVariant,
                                contentColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Close", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    is UroPayPaymentUiState.Cancelled -> {
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceVariant,
                                contentColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Close", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    is UroPayPaymentUiState.Idle -> {}
                    else -> {}
                }
            }
        }
    }
}
