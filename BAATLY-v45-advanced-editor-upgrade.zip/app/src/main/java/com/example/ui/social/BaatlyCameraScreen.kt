package com.example.ui.social

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.RenderEffect
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import com.example.ui.media.MediaEditorExporter
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.File

/** CameraX capture with category-based presets. On Android 12+ the preview receives a lightweight
 * RenderEffect approximation; Creator Studio uses GPUImage Plus for the final still-photo render. */
@Composable
fun BaatlyCameraScreen(
    onDismiss: () -> Unit,
    onCaptured: (Uri, String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var permissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var permissionAsked by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("Original") }
    var selectedFilterCategory by remember { mutableStateOf("All") }
    var usingFrontCamera by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf<String?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (!granted) cameraError = "Camera permission was denied. Allow it in Android Settings to take a photo."
    }
    LaunchedEffect(Unit) {
        if (!permissionGranted && !permissionAsked) {
            permissionAsked = true
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val controller = remember(context) {
        LifecycleCameraController(context).apply {
            setEnabledUseCases(CameraController.IMAGE_CAPTURE)
            cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            imageCaptureMode = ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
        }
    }

    LaunchedEffect(controller, lifecycleOwner, permissionGranted) {
        if (permissionGranted) {
            runCatching {
                controller.bindToLifecycle(lifecycleOwner)
                cameraError = null
            }.onFailure { error ->
                cameraError = error.message?.take(140) ?: "Camera could not start on this device."
                Log.e("BaatlyCamera", "Camera bind failed", error)
            }
        }
    }

    BackHandler { if (!isCapturing) onDismiss() }
    Dialog(onDismissRequest = { if (!isCapturing) onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (permissionGranted && cameraError == null) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                            // TextureView-backed preview is needed for Android 12+ RenderEffect filters.
                            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                            this.controller = controller
                            applyPreviewLook(this, selectedFilter)
                        }
                    },
                    update = { preview ->
                        preview.controller = controller
                        applyPreviewLook(preview, selectedFilter)
                    }
                )
            } else {
                Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(46.dp))
                    Text(cameraError ?: "Camera permission is needed to take a photo.", color = Color.White)
                    Button(
                        onClick = {
                            cameraError = null
                            if (!permissionGranted) permissionLauncher.launch(Manifest.permission.CAMERA)
                            else runCatching { controller.bindToLifecycle(lifecycleOwner) }
                                .onFailure { cameraError = it.message ?: "Camera could not start. Please try again." }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF2E78))
                    ) { Text(if (permissionGranted) "Retry camera" else "Allow camera") }
                }
            }

            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss, enabled = !isCapturing) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Close camera", tint = Color.White)
                }
                Text("BAATLY CAMERA", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    val newFront = !usingFrontCamera
                    runCatching {
                        controller.cameraSelector = if (newFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                        usingFrontCamera = newFront
                        cameraError = null
                    }.onFailure {
                        cameraError = "This camera is not available on the device."
                        Toast.makeText(context, cameraError, Toast.LENGTH_SHORT).show()
                    }
                }, enabled = permissionGranted && cameraError == null && !isCapturing) {
                    Icon(Icons.Filled.FlipCameraAndroid, contentDescription = "Switch camera", tint = Color.White)
                }
            }

            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    BaatlyFilterCatalog.categories.forEach { category ->
                        FilterChip(
                            selected = selectedFilterCategory == category,
                            onClick = { selectedFilterCategory = category },
                            label = { Text(category, fontSize = 10.sp) },
                            colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF6C2A68), selectedLabelColor = Color.White,
                                containerColor = Color(0xAA1C1630), labelColor = Color.White
                            )
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    BaatlyFilterCatalog.visible(selectedFilterCategory).forEach { preset ->
                        FilterChip(
                            selected = selectedFilter == preset.name,
                            onClick = { selectedFilter = preset.name },
                            label = { Text(preset.name, fontSize = 10.sp) },
                            colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFFF2E78), selectedLabelColor = Color.White,
                                containerColor = Color(0xAA1C1630), labelColor = Color.White
                            )
                        )
                    }
                }
                Text("Choose a look now; strength and final rendering are in Creator Studio.", color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp)
                Surface(
                    modifier = Modifier.size(78.dp).clip(CircleShape),
                    color = Color.White,
                    shape = CircleShape,
                    border = BorderStroke(4.dp, Color(0xFFFF2E78))
                ) {
                    IconButton(
                        enabled = permissionGranted && cameraError == null && !isCapturing,
                        onClick = {
                            if (isCapturing) return@IconButton
                            isCapturing = true
                            cameraError = null
                            val file = File(context.cacheDir, "baatly_camera_${System.currentTimeMillis()}.jpg")
                            runCatching {
                                val options = ImageCapture.OutputFileOptions.Builder(file).build()
                                controller.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                        isCapturing = false
                                        if (file.exists() && file.length() > 0L) onCaptured(Uri.fromFile(file), selectedFilter)
                                        else Toast.makeText(context, "Could not save photo. Please try again.", Toast.LENGTH_SHORT).show()
                                    }

                                    override fun onError(exception: ImageCaptureException) {
                                        isCapturing = false
                                        Log.e("BaatlyCamera", "Photo capture failed", exception)
                                        Toast.makeText(context, exception.message ?: "Camera capture failed", Toast.LENGTH_SHORT).show()
                                    }
                                })
                            }.onFailure { error ->
                                isCapturing = false
                                Log.e("BaatlyCamera", "takePicture threw", error)
                                Toast.makeText(context, error.message ?: "Camera is not ready yet", Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) {
                        if (isCapturing) CircularProgressIndicator(color = Color(0xFFFF2E78), modifier = Modifier.size(27.dp))
                        else Icon(Icons.Filled.CameraAlt, contentDescription = "Capture photo", tint = Color(0xFF2B163D), modifier = Modifier.size(32.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
    DisposableEffect(controller) {
        onDispose { runCatching { controller.unbind() } }
    }
}

private fun applyPreviewLook(preview: PreviewView, filterName: String) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val colorFilter = MediaEditorExporter.androidPreviewColorFilter(filterName, 0.88f)
        preview.setRenderEffect(colorFilter?.let { RenderEffect.createColorFilterEffect(it) })
    }
    // Android 7–11 do not expose view-level RenderEffect; selected preset still travels to
    // Creator Studio, where GPUImage Plus applies the final filter to captured media.
}

