package com.example.data.network

import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class SupabaseDataService(
    private val client: SupabaseClient,
    private val sessionManager: SessionManager
) {

    // 1. Available Partners (Hosts)
    suspend fun getAvailablePartners(): Result<List<PartnerProfile>> {
        return try {
            val list = mutableListOf<PartnerProfile>()
            try {
                val rpcRes = client.rpc("get_available_partners")
                val array = JSONArray(rpcRes)
                for (i in 0 until array.length()) {
                    list.add(parsePartnerProfile(array.getJSONObject(i)))
                }
            } catch (_: Exception) {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?is_partner=eq.true&approval_status=eq.approved&account_status=neq.deleted&select=*"
                val res = client.get(url)
                val array = JSONArray(res)
                for (i in 0 until array.length()) {
                    list.add(parsePartnerProfile(array.getJSONObject(i)))
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 2. Host Profile
    suspend fun getHostProfile(hostId: String): Result<PartnerProfile> {
        if (hostId.isBlank()) return Result.failure(Exception("Host ID is blank"))
        return try {
            val profile = try {
                val rpcRes = client.rpc("get_host_profile", mapOf("p_partner_id" to hostId))
                val json = if (rpcRes.trim().startsWith("[")) {
                    val arr = JSONArray(rpcRes)
                    if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
                } else {
                    JSONObject(rpcRes)
                }
                parsePartnerProfile(json)
            } catch (_: Exception) {
                try {
                    val url = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(id.eq.$hostId,user_id.eq.$hostId)&select=*"
                    val res = client.get(url)
                    val array = JSONArray(res)
                    if (array.length() > 0) parsePartnerProfile(array.getJSONObject(0))
                    else throw Exception("Host not found in partner_profiles")
                } catch (_: Exception) {
                    val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=eq.$hostId&select=*"
                    val profileRes = client.get(profileUrl)
                    val profileArr = JSONArray(profileRes)
                    if (profileArr.length() > 0) parsePartnerProfile(profileArr.getJSONObject(0))
                    else throw Exception("Host profile not found")
                }
            }
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 3. Request Call (RPC returns scalar UUID)
    suspend fun requestCall(partnerId: String): Result<CallRecord> {
        return try {
            val callerId = sessionManager.userId.value ?: throw Exception("Not logged in")
            val rpcRes = client.rpc("request_call", mapOf("p_partner_id" to partnerId))
            val rawCallId = rpcRes.trim().trim('"')
            val callId = if (rawCallId.startsWith("{")) {
                JSONObject(rawCallId).optString("id", rawCallId)
            } else {
                rawCallId
            }

            if (callId.isBlank()) {
                throw Exception("Invalid call ID returned from server")
            }

            // Authoritatively fetch the created call record from backend
            val callRecordResult = getCallRecord(callId)
            if (callRecordResult.isSuccess) {
                Result.success(callRecordResult.getOrThrow())
            } else {
                Result.failure(callRecordResult.exceptionOrNull() ?: Exception("Failed to retrieve created call record"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Fetch individual Call Record
    suspend fun getCallRecord(callId: String): Result<CallRecord> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/calls?id=eq.$callId&select=*,partner:partner_id(*)"
            val res = client.get(url)
            val array = JSONArray(res)
            if (array.length() > 0) {
                Result.success(parseCallRecord(array.getJSONObject(0)))
            } else {
                Result.failure(Exception("Call record not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 4. Update Call State (requested, ringing, accepted, connected, completed)
    suspend fun updateCallState(callId: String, newStatus: String): Result<Boolean> {
        return try {
            client.rpc("update_call_state", mapOf(
                "p_call_id" to callId,
                "p_new_status" to newStatus
            ))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 5. Settle Call
    suspend fun settleCall(callId: String): Result<Boolean> {
        return try {
            client.rpc("settle_call", mapOf("p_call_id" to callId))
            fetchWallet()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 6. Get Agora Token
    suspend fun getAgoraToken(channelName: String): Result<AgoraTokenResponse> {
        return try {
            val payload = JSONObject().apply {
                put("channel_name", channelName)
                put("role", "publisher")
            }
            val res = client.callEdgeFunction("agora-token", payload.toString())
            val json = JSONObject(res)
            val tokenResp = AgoraTokenResponse(
                appId = json.optString("app_id", SupabaseConfig.agoraAppId),
                channelName = json.optString("channel_name", channelName),
                uid = json.optLong("uid", 0),
                token = json.optString("token"),
                expiresIn = json.optLong("expires_in", 3600)
            )
            Result.success(tokenResp)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 7. Start Chat With Host
    suspend fun startChatWithHost(partnerId: String): Result<String> {
        return try {
            if (partnerId.isBlank()) {
                throw Exception("Invalid host / partner ID")
            }
            val rpcRes = client.rpc("start_chat_with_host", mapOf("p_partner_id" to partnerId))
            val raw = rpcRes.trim()
            var conversationId = ""
            if (raw.startsWith("[")) {
                val arr = JSONArray(raw)
                if (arr.length() > 0) {
                    val obj = arr.getJSONObject(0)
                    conversationId = obj.optString("id", obj.optString("conversation_id", obj.optString("p_conversation_id", "")))
                }
            } else if (raw.startsWith("{")) {
                val obj = JSONObject(raw)
                conversationId = obj.optString("id", obj.optString("conversation_id", obj.optString("p_conversation_id", "")))
            } else {
                conversationId = raw.trim('"')
            }
            if (conversationId.isBlank() || conversationId == "null") {
                throw Exception("Could not initialize chat conversation")
            }
            Result.success(conversationId)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseDataService", "startChatWithHost error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 8. Send Chat Message
    suspend fun sendMessage(
        conversationId: String,
        receiverId: String,
        messageType: String = "text",
        content: String? = null,
        mediaUrl: String? = null,
        mediaDurationSeconds: Int? = null
    ): Result<ChatMessage> {
        return try {
            val senderId = sessionManager.userId.value
                ?: throw Exception("User session not found. Please sign in.")

            if (conversationId.isBlank()) {
                throw Exception("Invalid conversation ID")
            }
            if (receiverId.isBlank()) {
                throw Exception("Invalid host ID")
            }

            val params = mapOf<String, Any?>(
                "p_conversation_id" to conversationId,
                "p_receiver_id" to receiverId,
                "p_message_type" to messageType,
                "p_message_text" to content,
                "p_media_url" to mediaUrl,
                "p_media_duration_seconds" to mediaDurationSeconds
            )

            val rpcRes = client.rpc("send_message", params)
            android.util.Log.d("SupabaseDataService", "send_message raw response: $rpcRes")

            val raw = rpcRes.trim()
            var success = true
            var serverMessageId: String? = null
            var errorMsg: String? = null

            if (raw.startsWith("{")) {
                val json = JSONObject(raw)
                if (json.has("success")) {
                    success = json.optBoolean("success", true)
                }
                if (!success) {
                    errorMsg = json.optString("error", json.optString("message", "Message rejected by server"))
                }
                serverMessageId = json.optString("message_id", json.optString("id", "")).takeIf { it.isNotBlank() }
            } else if (raw.startsWith("[")) {
                val arr = JSONArray(raw)
                if (arr.length() > 0) {
                    val json = arr.getJSONObject(0)
                    if (json.has("success")) {
                        success = json.optBoolean("success", true)
                    }
                    if (!success) {
                        errorMsg = json.optString("error", json.optString("message", "Message rejected by server"))
                    }
                    serverMessageId = json.optString("message_id", json.optString("id", "")).takeIf { it.isNotBlank() }
                }
            } else if (raw.isNotBlank() && raw != "null") {
                val cleaned = raw.trim('"')
                if (cleaned.isNotBlank() && cleaned != "null") {
                    serverMessageId = cleaned
                }
            }

            if (!success) {
                throw Exception(errorMsg ?: "Failed to send message")
            }

            // Sync wallet after successful send
            fetchWallet()

            val msg = ChatMessage(
                id = serverMessageId ?: UUID.randomUUID().toString(),
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                messageType = messageType,
                messageText = content,
                mediaUrl = mediaUrl,
                mediaDurationSeconds = mediaDurationSeconds,
                createdAt = "Just now"
            )
            Result.success(msg)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseDataService", "sendMessage error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 9. Send Gift
    suspend fun sendGift(
        giftId: String,
        receiverId: String,
        conversationId: String? = null,
        callId: String? = null
    ): Result<Boolean> {
        return try {
            client.rpc("send_gift", mapOf(
                "p_gift_id" to giftId,
                "p_receiver_id" to receiverId,
                "p_conversation_id" to conversationId,
                "p_call_id" to callId
            ))
            fetchWallet()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 10. Follow / Unfollow
    suspend fun followHost(partnerId: String): Result<Boolean> {
        return try {
            client.rpc("follow_host", mapOf("p_partner_id" to partnerId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun unfollowHost(partnerId: String): Result<Boolean> {
        return try {
            client.rpc("unfollow_host", mapOf("p_partner_id" to partnerId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 11. Clear My Conversation
    suspend fun clearMyConversation(conversationId: String): Result<Boolean> {
        return try {
            client.rpc("clear_my_conversation", mapOf("p_conversation_id" to conversationId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 12. Block User
    suspend fun blockUser(partnerId: String, reason: String = "User requested block"): Result<Boolean> {
        return try {
            try {
                client.rpc("block_user", mapOf("p_blocked_user_id" to partnerId, "p_reason" to reason))
            } catch (_: Exception) {
                client.rpc("block_user", mapOf("p_user_id" to partnerId, "p_reason" to reason))
            }
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Signed URL helper for private buckets (chat-media, profile-media)
    suspend fun getSignedMediaUrl(rawPathOrUrl: String, bucket: String = SupabaseConfig.BUCKET_CHAT_MEDIA): String {
        if (rawPathOrUrl.isBlank() ||
            rawPathOrUrl.startsWith("http://") ||
            rawPathOrUrl.startsWith("https://") ||
            rawPathOrUrl.startsWith("content://") ||
            rawPathOrUrl.startsWith("file://")
        ) {
            return rawPathOrUrl
        }
        return try {
            client.createSignedUrl(bucket, rawPathOrUrl, 3600)
        } catch (e: Exception) {
            rawPathOrUrl
        }
    }

    // 13. Fetch Wallet
    suspend fun fetchWallet(): Result<WalletInfo> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/wallets?user_id=eq.$userId&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val wallet = if (arr.length() > 0) {
                val json = arr.getJSONObject(0)
                val coins = json.optInt("coin_balance", 0)
                val cash = json.optDouble("cash_balance", 0.0)
                WalletInfo(
                    userId = json.optString("user_id", userId),
                    coinBalance = coins,
                    cashBalance = cash,
                    updatedAt = json.optString("updated_at")
                )
            } else {
                WalletInfo(userId = userId, coinBalance = 0, cashBalance = 0.0)
            }
            sessionManager.updateWallet(wallet)
            Result.success(wallet)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 14. Fetch Coin Packages
    suspend fun fetchCoinPackages(): Result<List<CoinPackage>> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/coin_packages?is_active=eq.true&order=display_order.asc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<CoinPackage>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    CoinPackage(
                        id = json.getString("id"),
                        coins = json.getInt("coins"),
                        priceInr = json.getDouble("price_inr"),
                        displayOrder = json.optInt("display_order", i),
                        isActive = json.optBoolean("is_active", true)
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 15. Fetch Gifts Catalogue (29 gifts)
    suspend fun fetchGifts(): Result<List<GiftItem>> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/gifts?is_active=eq.true&order=display_order.asc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<GiftItem>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    GiftItem(
                        id = json.getString("id"),
                        name = json.getString("name"),
                        category = json.optString("category", "General"),
                        iconUrl = json.optString("icon_url"),
                        animationUrl = json.optString("animation_url"),
                        coinPrice = json.optInt("coin_price", 10),
                        partnerEarningPercent = json.optDouble("partner_earning_percent", 50.0),
                        displayOrder = json.optInt("display_order", i),
                        isActive = json.optBoolean("is_active", true)
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 16. Fetch Recent Calls
    suspend fun fetchRecentCalls(): Result<List<CallRecord>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/calls?user_id=eq.$userId&order=created_at.desc&limit=50&select=*,partner:partner_id(*)"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<CallRecord>()
            for (i in 0 until arr.length()) {
                list.add(parseCallRecord(arr.getJSONObject(i)))
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 17. Fetch Conversations
    suspend fun fetchConversations(): Result<List<ConversationSummary>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/conversations?order=last_message_at.desc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<ConversationSummary>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val convId = json.getString("id")
                val partnerId = json.optString("partner_id")
                val partnerObj = json.optJSONObject("partner")
                var partner = partnerObj?.let { parsePartnerProfile(it) }

                // Authoritatively resolve host profile via get_host_profile RPC if missing or generic
                if (partner == null || partner.displayName.isNullOrBlank() || partner.displayName == "Host" || partner.displayName == "Baatly Host") {
                    if (partnerId.isNotBlank()) {
                        val hostRes = getHostProfile(partnerId)
                        if (hostRes.isSuccess) {
                            partner = hostRes.getOrNull()
                        }
                    }
                }

                // Check for last message content and unread count directly in conversation row
                var lastMsgText = listOf(
                    json.optString("last_message_text"),
                    json.optString("last_message"),
                    json.optString("last_message_preview"),
                    json.optString("message_text"),
                    json.optString("preview"),
                    json.optString("content")
                ).firstOrNull { it.isNotBlank() && it != "null" }

                var lastMsgType = json.optString("last_message_type", json.optString("message_type", "text"))
                var lastMsgAt = json.optString("last_message_at").takeIf { it.isNotBlank() && it != "null" }
                var unreadCount = listOf(
                    json.optInt("unread_count", -1),
                    json.optInt("unread_messages_count", -1),
                    json.optInt("user_unread_count", -1)
                ).firstOrNull { it >= 0 } ?: 0

                // Query the messages table for this conversation to get the exact latest message and unread count
                try {
                    val msgUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$convId&order=created_at.desc&limit=1&select=*"
                    val msgRes = client.get(msgUrl)
                    val msgArr = JSONArray(msgRes)
                    if (msgArr.length() > 0) {
                        val latestMsgObj = msgArr.getJSONObject(0)
                        val msgType = latestMsgObj.optString("message_type", "text")
                        lastMsgType = msgType
                        val candidate = listOf(
                            latestMsgObj.optString("message_text"),
                            latestMsgObj.optString("content"),
                            latestMsgObj.optString("text"),
                            latestMsgObj.optString("body")
                        ).firstOrNull { it.isNotBlank() && it != "null" }

                        if (!candidate.isNullOrBlank()) {
                            lastMsgText = candidate
                        } else if (msgType == "voice") {
                            lastMsgText = "🎙️ Voice message"
                        } else if (msgType == "gift") {
                            lastMsgText = "🎁 Gift"
                        } else if (msgType == "image") {
                            lastMsgText = "📷 Photo"
                        }

                        if (lastMsgAt.isNullOrBlank()) {
                            lastMsgAt = latestMsgObj.optString("created_at").takeIf { it.isNotBlank() && it != "null" }
                        }
                    }

                    // Count unread messages sent to this user in this conversation
                    val unreadUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$convId&sender_id=neq.$userId&is_read=eq.false&select=id"
                    val unreadRes = client.get(unreadUrl)
                    val unreadArr = JSONArray(unreadRes)
                    unreadCount = unreadArr.length()
                } catch (_: Exception) {}

                list.add(
                    ConversationSummary(
                        id = convId,
                        userId = json.optString("user_id", userId),
                        partnerId = partnerId,
                        lastMessageId = json.optString("last_message_id").takeIf { it.isNotBlank() },
                        lastMessageAt = lastMsgAt,
                        lastMessageText = lastMsgText,
                        lastMessageType = lastMsgType,
                        unreadCount = unreadCount,
                        userBlocked = json.optBoolean("user_blocked", false),
                        partnerBlocked = json.optBoolean("partner_blocked", false),
                        createdAt = json.optString("created_at"),
                        updatedAt = json.optString("updated_at"),
                        partner = partner
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 17b. Mark Messages As Read
    suspend fun markMessagesAsRead(conversationId: String): Result<Unit> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        if (conversationId.isBlank()) return Result.success(Unit)
        return try {
            try {
                client.rpc("mark_messages_read", mapOf("p_conversation_id" to conversationId))
            } catch (_: Exception) {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$conversationId&sender_id=neq.$userId&is_read=eq.false"
                val body = JSONObject().apply {
                    put("is_read", true)
                }
                client.patch(url, body.toString())
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 18. Fetch Messages in Conversation
    suspend fun fetchMessages(conversationId: String): Result<List<ChatMessage>> {
        if (conversationId.isBlank()) return Result.success(emptyList())
        return try {
            val rawRes = try {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$conversationId&order=created_at.asc&select=*"
                client.get(url)
            } catch (_: Exception) {
                try {
                    client.rpc("get_conversation_messages", mapOf("p_conversation_id" to conversationId))
                } catch (_: Exception) {
                    val fallbackUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$conversationId&order=created_at.asc"
                    client.get(fallbackUrl)
                }
            }

            val arr = JSONArray(rawRes)
            val list = mutableListOf<ChatMessage>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val msgId = json.optString("id").ifBlank { UUID.randomUUID().toString() }
                val convId = json.optString("conversation_id").ifBlank { conversationId }
                val senderId = json.optString("sender_id").ifBlank { json.optString("user_id") }
                val receiverId = json.optString("receiver_id").ifBlank { json.optString("partner_id") }
                val msgType = json.optString("message_type", "text")
                val textCandidate = listOf(
                    json.optString("message_text"),
                    json.optString("content"),
                    json.optString("text"),
                    json.optString("body")
                ).firstOrNull { it.isNotBlank() && it != "null" }
                val mediaCandidate = listOf(
                    json.optString("media_url"),
                    json.optString("media_path"),
                    json.optString("url")
                ).firstOrNull { it.isNotBlank() && it != "null" }
                val duration = json.optInt("media_duration_seconds", json.optInt("duration", 0))
                val giftId = json.optString("gift_id").takeIf { it.isNotBlank() && it != "null" }
                val createdAt = json.optString("created_at").takeIf { it.isNotBlank() && it != "null" }
                val isRead = json.optBoolean("is_read", false)

                val giftObj = json.optJSONObject("gift")
                val gift = giftObj?.let {
                    GiftItem(
                        id = it.optString("id"),
                        name = it.optString("name", "Gift"),
                        iconUrl = it.optString("icon_url").takeIf { u -> u.isNotBlank() && u != "null" },
                        coinPrice = it.optInt("coin_price", 10)
                    )
                }

                list.add(
                    ChatMessage(
                        id = msgId,
                        conversationId = convId,
                        senderId = senderId,
                        receiverId = receiverId,
                        messageType = msgType,
                        messageText = textCandidate,
                        mediaUrl = mediaCandidate,
                        mediaDurationSeconds = duration,
                        giftId = giftId,
                        createdAt = createdAt,
                        isRead = isRead,
                        gift = gift
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 19. Fetch Notifications
    suspend fun fetchNotifications(): Result<List<AppNotification>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/notifications?user_id=eq.$userId&order=created_at.desc&limit=30&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<AppNotification>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    AppNotification(
                        id = json.getString("id"),
                        userId = json.optString("user_id"),
                        title = json.optString("title", "Baatly Notification"),
                        body = json.optString("body"),
                        notificationType = json.optString("notification_type", "system"),
                        isRead = json.optBoolean("is_read", false),
                        createdAt = json.optString("created_at")
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 20. Upload Chat Media (image/voice)
    suspend fun uploadChatMedia(file: File, isVoice: Boolean): Result<String> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val ext = if (isVoice) "m4a" else "jpg"
            val mime = if (isVoice) "audio/mp4" else "image/jpeg"
            val relativePath = "$userId/${UUID.randomUUID()}.$ext"
            val storagePath = client.uploadFile(
                SupabaseConfig.BUCKET_CHAT_MEDIA,
                relativePath,
                file,
                mime
            )
            Result.success(storagePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseCallRecord(json: JSONObject): CallRecord {
        val partnerObj = json.optJSONObject("partner")
        val partner = partnerObj?.let { parsePartnerProfile(it) }
        val maxDurationSec = if (json.has("max_duration_seconds")) json.optInt("max_duration_seconds") else null
        val maxDurationCoin = if (json.has("max_duration_coins")) json.optInt("max_duration_coins") else null

        return CallRecord(
            id = json.getString("id"),
            userId = json.optString("user_id"),
            partnerId = json.optString("partner_id"),
            status = json.optString("status", "requested"),
            requestedAt = json.optString("requested_at").takeIf { it.isNotBlank() },
            ringingAt = json.optString("ringing_at").takeIf { it.isNotBlank() },
            acceptedAt = json.optString("accepted_at").takeIf { it.isNotBlank() },
            connectedAt = json.optString("connected_at").takeIf { it.isNotBlank() },
            endedAt = json.optString("ended_at").takeIf { it.isNotBlank() },
            durationSeconds = json.optInt("duration_seconds", 0),
            userCoinsCharged = json.optInt("user_coins_charged", 0),
            partnerEarning = json.optDouble("partner_earning", 0.0),
            terminationReason = json.optString("termination_reason").takeIf { it.isNotBlank() },
            billingStatus = json.optString("billing_status").takeIf { it.isNotBlank() },
            agoraChannelId = listOf(
                json.optString("agora_channel_id"),
                json.optString("channel_name"),
                json.optString("agora_channel")
            ).firstOrNull { it.isNotBlank() && it != "null" },
            createdAt = json.optString("created_at").takeIf { it.isNotBlank() },
            maxDurationSeconds = maxDurationSec,
            maxDurationCoins = maxDurationCoin,
            partner = partner
        )
    }

    fun parsePartnerProfile(json: JSONObject): PartnerProfile {
        val ageVal = if (json.has("age") && !json.isNull("age")) json.optInt("age").takeIf { it > 0 } else null
        val ratingVal = if (json.has("rating") && !json.isNull("rating")) json.optDouble("rating") else null

        val displayNameCandidate = listOf(
            json.optString("partner_display_name"),
            json.optString("host_display_name"),
            json.optString("display_name"),
            json.optString("full_name"),
            json.optString("first_name"),
            json.optString("name"),
            json.optString("host_name"),
            json.optString("partner_name"),
            json.optString("username")
        ).firstOrNull { it.isNotBlank() && it != "null" && it != "Host" && it != "Baatly Host" }
            ?: listOf(
                json.optString("partner_display_name"),
                json.optString("host_display_name"),
                json.optString("display_name"),
                json.optString("full_name"),
                json.optString("name"),
                json.optString("host_name"),
                json.optString("partner_name"),
                json.optString("username")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        val avatarCandidate = listOf(
            json.optString("partner_avatar_url"),
            json.optString("avatar_url"),
            json.optString("profile_photo_url"),
            json.optString("photo_url"),
            json.optString("image_url")
        ).firstOrNull { it.isNotBlank() && it != "null" }

        val idCandidate = listOf(
            json.optString("id"),
            json.optString("partner_id"),
            json.optString("user_id")
        ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        val userIdCandidate = listOf(
            json.optString("user_id"),
            json.optString("partner_id"),
            json.optString("id")
        ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        return PartnerProfile(
            id = idCandidate,
            userId = userIdCandidate,
            displayName = if (displayNameCandidate.isNotBlank()) displayNameCandidate else "Host",
            avatarUrl = avatarCandidate,
            bio = json.optString("bio").takeIf { it.isNotBlank() && it != "null" },
            age = ageVal,
            gender = json.optString("gender", "Female"),
            language = json.optString("language", "Hindi, English"),
            isPartner = json.optBoolean("is_partner", true),
            approvalStatus = json.optString("approval_status", "approved"),
            isAvailable = json.optBoolean("is_available", true),
            isOnline = json.optBoolean("is_online", true),
            audioEnabled = json.optBoolean("audio_enabled", true),
            chatEnabled = json.optBoolean("chat_enabled", true),
            accountStatus = json.optString("account_status", "active"),
            rating = ratingVal,
            followersCount = json.optInt("followers_count", 0),
            reviewsCount = json.optInt("reviews_count", 0),
            isFollowing = json.optBoolean("is_following", false)
        )
    }

    // ==========================================
    // SOCIAL MEDIA MODULE
    // ==========================================

    // Helper: resolve social media path into playable/viewable signed URL
    suspend fun resolveSocialMediaUrl(rawPathOrUrl: String?): String {
        if (rawPathOrUrl.isNullOrBlank() || rawPathOrUrl == "null") return ""
        val trimmed = rawPathOrUrl.trim()
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://") ||
            trimmed.startsWith("content://") || trimmed.startsWith("file://")
        ) {
            return trimmed
        }
        val clean = trimmed
            .removePrefix("social-media/")
            .removePrefix("${SupabaseConfig.BUCKET_SOCIAL_MEDIA}/")
            .removePrefix("/")
        if (clean.isBlank()) return ""
        return try {
            client.createSignedUrl(SupabaseConfig.BUCKET_SOCIAL_MEDIA, clean, 7200)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "Storage signing error for bucket social-media, path $clean: ${e.message}", e)
            ""
        }
    }

    // 1. Authoritative RPC: social_ensure_profile
    suspend fun ensureSocialProfile(): Result<Boolean> {
        return try {
            client.rpc("social_ensure_profile")
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 2. Authoritative RPC: social_is_host
    suspend fun isHostUser(userId: String): Boolean {
        if (userId.isBlank()) return false
        return try {
            val res = client.rpc("social_is_host", mapOf("p_user_id" to userId))
            res.trim().toBooleanStrictOrNull()
                ?: (res.trim().contains("true", ignoreCase = true) && !res.trim().contains("false", ignoreCase = true))
        } catch (_: Exception) {
            false
        }
    }

    // 3. Authoritative RPC: social_role
    suspend fun getSocialRole(userId: String): String {
        if (userId.isBlank()) return "user"
        return try {
            val res = client.rpc("social_role", mapOf("p_user_id" to userId))
            res.trim().trim('"').lowercase()
        } catch (_: Exception) {
            "user"
        }
    }

    // 4. Fetch Social Stories (Authoritative)
    suspend fun getSocialStories(): Result<List<SocialStory>> {
        return try {
            val currentUserId = sessionManager.userId.value ?: ""
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_stories?is_active=eq.true&order=created_at.desc&select=*"
            val res = client.get(url)
            val array = JSONArray(res)

            val rawStories = mutableListOf<SocialStory>()
            for (i in 0 until array.length()) {
                val storyJson = array.getJSONObject(i)
                val story = parseSocialStory(storyJson, currentUserId)
                if (story.isActive && !story.isExpired) {
                    rawStories.add(story)
                }
            }

            val enrichedStories = enrichStoriesWithProfiles(rawStories, currentUserId)
            Result.success(enrichedStories)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 5. Fetch Social Feed (Authoritative: direct REST on social_posts with enrichment)
    suspend fun getSocialFeed(page: Int = 0, limit: Int = 20): Result<List<SocialPost>> {
        return try {
            val currentUserId = sessionManager.userId.value ?: ""
            val offset = page * limit
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_posts?order=created_at.desc&limit=$limit&offset=$offset&select=*"
            val res = client.get(url)
            val array = JSONArray(res)

            val rawPosts = mutableListOf<SocialPost>()
            for (i in 0 until array.length()) {
                val postJson = array.getJSONObject(i)
                rawPosts.add(parseSocialPost(postJson, currentUserId))
            }

            val enrichedList = enrichPostsWithProfiles(rawPosts, currentUserId)
            Result.success(enrichedList)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 6. Fetch Social Profile (Authoritative)
    suspend fun getSocialProfile(targetUserId: String? = null): Result<SocialProfile> {
        val currentUserId = sessionManager.userId.value ?: ""
        val lookupId = if (!targetUserId.isNullOrBlank()) targetUserId else currentUserId

        return try {
            var profileObj: JSONObject? = null
            try {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_profiles?user_id=eq.$lookupId&select=*"
                val res = client.get(url)
                val arr = JSONArray(res)
                if (arr.length() > 0) profileObj = arr.getJSONObject(0)
            } catch (_: Exception) {}

            var baseProfileObj: JSONObject? = null
            try {
                val baseProfileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?or=(id.eq.$lookupId,user_id.eq.$lookupId)&select=*"
                val baseRes = client.get(baseProfileUrl)
                val baseArr = JSONArray(baseRes)
                if (baseArr.length() > 0) {
                    baseProfileObj = baseArr.getJSONObject(0)
                }
            } catch (_: Exception) {}

            var isHost = false
            var partnerProfile: PartnerProfile? = null
            try {
                val partnerUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(id.eq.$lookupId,user_id.eq.$lookupId)&select=*"
                val partnerRes = client.get(partnerUrl)
                val partnerArr = JSONArray(partnerRes)
                if (partnerArr.length() > 0) {
                    isHost = true
                    partnerProfile = parsePartnerProfile(partnerArr.getJSONObject(0))
                }
            } catch (_: Exception) {}

            if (!isHost) {
                isHost = isHostUser(lookupId) || baseProfileObj?.optBoolean("is_partner", false) == true
            }

            var isFollowing = false
            if (lookupId != currentUserId && currentUserId.isNotBlank()) {
                try {
                    val followUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/social_follows?follower_id=eq.$currentUserId&following_id=eq.$lookupId&select=*"
                    val followRes = client.get(followUrl)
                    isFollowing = JSONArray(followRes).length() > 0
                } catch (_: Exception) {}
            }

            val displayName = partnerProfile?.displayName ?: baseProfileObj?.optString("display_name") ?: "Baatly User"
            val signupUserId = partnerProfile?.userId ?: baseProfileObj?.optString("user_id") ?: lookupId
            val socialAvatarRaw = profileObj?.optString("social_avatar_url")?.takeIf { it.isNotBlank() && it != "null" }
                ?: partnerProfile?.avatarUrl ?: baseProfileObj?.optString("avatar_url")
            val resolvedAvatar = resolveSocialMediaUrl(socialAvatarRaw)

            val socialProfile = SocialProfile(
                userId = lookupId,
                bio = profileObj?.optString("bio")?.takeIf { it.isNotBlank() && it != "null" } ?: partnerProfile?.bio ?: "",
                hobbies = profileObj?.optString("hobbies")?.takeIf { it.isNotBlank() && it != "null" } ?: "",
                socialAvatarUrl = resolvedAvatar,
                followersCount = profileObj?.optInt("followers_count", partnerProfile?.followersCount ?: 0) ?: 0,
                followingCount = profileObj?.optInt("following_count", 0) ?: 0,
                totalLikes = profileObj?.optInt("total_likes", 0) ?: 0,
                totalViews = profileObj?.optInt("total_views", 0) ?: 0,
                createdAt = profileObj?.optString("created_at"),
                updatedAt = profileObj?.optString("updated_at"),
                displayName = displayName,
                signupUserId = signupUserId,
                isHost = isHost,
                isFollowing = isFollowing,
                partner = partnerProfile
            )

            Result.success(socialProfile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 7. Update Social Profile via RPC social_update_profile
    suspend fun updateSocialProfile(
        bio: String,
        hobbies: String,
        avatarFile: File? = null
    ): Result<Boolean> {
        val authUuid = sessionManager.userId.value?.takeIf { it.isNotBlank() }
            ?: sessionManager.currentUser.value?.id?.takeIf { it.isNotBlank() }
            ?: return Result.failure(Exception("Not logged in"))
        return try {
            var avatarStoragePath: String? = null
            if (avatarFile != null) {
                val ext = "jpg"
                val path = "$authUuid/${UUID.randomUUID()}.$ext"
                avatarStoragePath = client.uploadFile(
                    SupabaseConfig.BUCKET_SOCIAL_MEDIA,
                    path,
                    avatarFile,
                    "image/jpeg"
                )
            }

            val params = mapOf(
                "p_bio" to bio.trim(),
                "p_hobbies" to hobbies.trim(),
                "p_avatar_url" to (avatarStoragePath ?: "")
            )
            client.rpc("social_update_profile", params)
            Result.success(true)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "updateSocialProfile failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 8. Search Social Profile by Signup User ID
    // Strict Role Rule: USER -> may search/view HOST profiles only. USER -> may NOT search/view USER profiles.
    suspend fun searchSocialProfile(targetUserId: String): Result<SocialSearchResult> {
        val cleanTargetId = targetUserId.trim().removePrefix("@")
        if (cleanTargetId.isBlank()) return Result.failure(Exception("Please enter a Host User ID to search."))

        return try {
            var searchObj: JSONObject? = null
            try {
                val rpcRes = client.rpc("social_search_profile", mapOf("p_target_user_id" to cleanTargetId))
                searchObj = if (rpcRes.trim().startsWith("[")) {
                    val arr = JSONArray(rpcRes)
                    if (arr.length() > 0) arr.getJSONObject(0) else null
                } else {
                    JSONObject(rpcRes)
                }
            } catch (_: Exception) {}

            if (searchObj != null) {
                val isHost = searchObj.optBoolean("is_host", searchObj.optBoolean("is_partner", false))
                val targetRole = searchObj.optString("role", if (isHost) "host" else "user").lowercase()
                val hostUserId = searchObj.optString("user_id").takeIf { it.isNotBlank() } ?: cleanTargetId
                val effectiveIsHost = isHost || targetRole == "host" || targetRole == "partner" || isHostUser(hostUserId)

                if (!effectiveIsHost) {
                    return Result.failure(Exception("Normal user profiles cannot be viewed. You can only search and view Host profiles."))
                }
                val partnerObj = searchObj.optJSONObject("partner")
                val partner = partnerObj?.let { parsePartnerProfile(it) }
                val rawAvatar = searchObj.optString("avatar_url").takeIf { it.isNotBlank() && it != "null" }
                    ?: searchObj.optString("social_avatar_url").takeIf { it.isNotBlank() && it != "null" }
                val resolvedAvatar = resolveSocialMediaUrl(rawAvatar)

                return Result.success(
                    SocialSearchResult(
                        userId = hostUserId,
                        displayName = searchObj.optString("display_name", "Host"),
                        signupUserId = searchObj.optString("signup_user_id", cleanTargetId),
                        avatarUrl = resolvedAvatar,
                        isHost = true,
                        bio = searchObj.optString("bio").takeIf { it.isNotBlank() && it != "null" },
                        followersCount = searchObj.optInt("followers_count", 0),
                        partner = partner
                    )
                )
            }

            // Fallback REST Search: Find in partner_profiles / profiles
            val partnerUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(user_id.ilike.%25$cleanTargetId%25,display_name.ilike.%25$cleanTargetId%25)&approval_status=eq.approved&select=*"
            val partnerRes = client.get(partnerUrl)
            val partnerArr = JSONArray(partnerRes)

            if (partnerArr.length() > 0) {
                val pObj = partnerArr.getJSONObject(0)
                val partner = parsePartnerProfile(pObj)
                val resolvedAvatar = resolveSocialMediaUrl(partner.avatarUrl)
                return Result.success(
                    SocialSearchResult(
                        userId = partner.id,
                        displayName = partner.displayName,
                        signupUserId = partner.userId ?: cleanTargetId,
                        avatarUrl = resolvedAvatar,
                        isHost = true,
                        bio = partner.bio,
                        followersCount = partner.followersCount,
                        partner = partner
                    )
                )
            }

            // Check if this exists as a normal user in profiles table
            val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?user_id=ilike.%25$cleanTargetId%25&select=*"
            val profileRes = client.get(profileUrl)
            val profileArr = JSONArray(profileRes)
            if (profileArr.length() > 0) {
                val pObj = profileArr.getJSONObject(0)
                val isPartner = pObj.optBoolean("is_partner", false)
                if (!isPartner) {
                    return Result.failure(Exception("Normal user profiles cannot be viewed. You can only search and view Host profiles."))
                }
            }

            Result.failure(Exception("No host found with User ID '$cleanTargetId'"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 9. Create Story or Post via RPC social_create_content
    // Story: p_type = "story" (Costs 10 coins, valid 24h)
    // Post: p_type = "post" (Costs 20 coins, visible 7 days)
    suspend fun createSocialContent(
        type: String, // "story" or "post"
        mediaFile: File,
        caption: String
    ): Result<String> {
        val authUuid = sessionManager.userId.value?.takeIf { it.isNotBlank() }
            ?: sessionManager.currentUser.value?.id?.takeIf { it.isNotBlank() }
            ?: return Result.failure(Exception("Not logged in"))
        return try {
            val ext = "jpg"
            val relativePath = "$authUuid/${UUID.randomUUID()}.$ext"
            val uploadedPath = client.uploadFile(
                SupabaseConfig.BUCKET_SOCIAL_MEDIA,
                relativePath,
                mediaFile,
                "image/jpeg"
            )

            val rpcParams = mapOf(
                "p_type" to type.lowercase(),
                "p_media_path" to uploadedPath,
                "p_caption" to caption.trim()
            )
            val res = client.rpc("social_create_content", rpcParams)
            Result.success(res)
        } catch (e: Exception) {
            Log.e("SupabaseDataService", "createSocialContent failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 10. View Content via RPC social_view_content
    // First view by same User on Host Story = 3 coins + Host ₹0.50. Repeat view = Free.
    suspend fun viewSocialContent(contentType: String, contentId: String): Result<Boolean> {
        return try {
            client.rpc("social_view_content", mapOf(
                "p_content_type" to contentType.lowercase(),
                "p_content_id" to contentId
            ))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 11. Like / Unlike Content via RPC social_toggle_like
    // Like = 1 coin + Host ₹0.20. Unlike = No refund. Like again = 1 coin.
    suspend fun toggleSocialLike(contentType: String, contentId: String): Result<Boolean> {
        return try {
            val rpcRes = client.rpc("social_toggle_like", mapOf(
                "p_content_type" to contentType.lowercase(),
                "p_content_id" to contentId
            ))
            val isLiked = try {
                JSONObject(rpcRes).optBoolean("is_liked", true)
            } catch (_: Exception) {
                !rpcRes.contains("false", ignoreCase = true) && !rpcRes.contains("unliked", ignoreCase = true)
            }
            Result.success(isLiked)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 12. Add Comment / Reply via RPC social_add_comment
    // Every comment / reply = 3 coins + Host ₹0.50.
    suspend fun addSocialComment(contentType: String, contentId: String, comment: String): Result<SocialComment> {
        val cleanComment = comment.trim()
        if (cleanComment.isBlank()) return Result.failure(Exception("Comment cannot be empty"))
        val currentUserId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        val currentUserProfile = sessionManager.currentUser.value

        return try {
            val rpcRes = client.rpc("social_add_comment", mapOf(
                "p_content_type" to contentType.lowercase(),
                "p_content_id" to contentId,
                "p_comment" to cleanComment
            ))
            val commentId = try {
                val json = JSONObject(rpcRes)
                json.optString("id", UUID.randomUUID().toString())
            } catch (_: Exception) {
                rpcRes.trim().trim('"').takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
            }

            val socialComment = SocialComment(
                id = commentId,
                contentId = contentId,
                contentType = contentType,
                userId = currentUserId,
                comment = cleanComment,
                createdAt = "Just now",
                displayName = currentUserProfile?.displayName ?: "Me",
                avatarUrl = currentUserProfile?.avatarUrl
            )
            Result.success(socialComment)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 13. Unlock Host Post via RPC social_unlock_post
    // First unlock = 3 coins + Host ₹0.50. Repeat viewing while unlocked = FREE.
    suspend fun unlockSocialPost(postId: String): Result<Boolean> {
        return try {
            client.rpc("social_unlock_post", mapOf("p_post_id" to postId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 14. Follow / Unfollow via RPC social_follow_toggle
    suspend fun toggleSocialFollow(targetUserId: String): Result<Boolean> {
        return try {
            val rpcRes = client.rpc("social_follow_toggle", mapOf("p_target_user_id" to targetUserId))
            val isFollowing = try {
                JSONObject(rpcRes).optBoolean("is_following", true)
            } catch (_: Exception) {
                !rpcRes.contains("unfollowed", ignoreCase = true) && !rpcRes.contains("false", ignoreCase = true)
            }
            Result.success(isFollowing)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 12. Fetch Comments for Post / Story
    suspend fun getSocialComments(contentType: String, contentId: String): Result<List<SocialComment>> {
        return try {
            val list = mutableListOf<SocialComment>()
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_comments?content_id=eq.$contentId&content_type=eq.${contentType.lowercase()}&order=created_at.asc&select=*"
            val res = client.get(url)
            val array = JSONArray(res)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val userId = obj.optString("user_id")
                var userDisplay = obj.optString("display_name").takeIf { it.isNotBlank() } ?: "User"
                var userAvatar = obj.optString("avatar_url").takeIf { it.isNotBlank() }

                list.add(
                    SocialComment(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        contentId = contentId,
                        contentType = contentType,
                        userId = userId,
                        comment = obj.optString("comment", obj.optString("comment_text", "")),
                        createdAt = obj.optString("created_at"),
                        displayName = userDisplay,
                        avatarUrl = userAvatar
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 13. Fetch User's Social Posts
    suspend fun getUserSocialPosts(userId: String): Result<List<SocialPost>> {
        val currentUserId = sessionManager.userId.value ?: ""
        return try {
            val list = mutableListOf<SocialPost>()
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_posts?owner_id=eq.$userId&order=created_at.desc&select=*"
            val res = client.get(url)
            val array = JSONArray(res)
            for (i in 0 until array.length()) {
                list.add(parseSocialPost(array.getJSONObject(i), currentUserId))
            }
            val enriched = enrichPostsWithProfiles(list, currentUserId)
            Result.success(enriched)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 14. Fetch User's Social Stories
    suspend fun getUserSocialStories(userId: String): Result<List<SocialStory>> {
        val currentUserId = sessionManager.userId.value ?: ""
        return try {
            val list = mutableListOf<SocialStory>()
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/social_stories?owner_id=eq.$userId&order=created_at.desc&select=*"
            val res = client.get(url)
            val array = JSONArray(res)
            for (i in 0 until array.length()) {
                list.add(parseSocialStory(array.getJSONObject(i), currentUserId))
            }
            val enriched = enrichStoriesWithProfiles(list, currentUserId)
            Result.success(enriched)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 15. Fetch Social Earnings via Authoritative RPC social_get_earnings()
    suspend fun getSocialEarnings(): Result<String> {
        return try {
            val res = client.rpc("social_get_earnings")
            Result.success(res)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // -------------------------------------------------------------
    // Helper Parsers and Batch Enrichment for Social
    // -------------------------------------------------------------
    private fun parseSocialStory(json: JSONObject, currentUserId: String): SocialStory {
        val ownerId = json.optString("owner_id", json.optString("user_id", ""))
        val mediaPath = json.optString("media_path")
        val isOwner = ownerId == currentUserId

        return SocialStory(
            id = json.optString("id"),
            ownerId = ownerId,
            mediaPath = mediaPath,
            caption = json.optString("caption").takeIf { it.isNotBlank() && it != "null" },
            createdAt = json.optString("created_at"),
            expiresAt = json.optString("expires_at"),
            isActive = json.optBoolean("is_active", true),
            ownerDisplayName = json.optString("owner_display_name", json.optString("display_name", "Baatly User")),
            ownerUserId = json.optString("owner_user_id", json.optString("user_id")),
            ownerAvatarUrl = json.optString("owner_avatar_url", json.optString("avatar_url")),
            isOwnerHost = json.optBoolean("is_owner_host", json.optBoolean("is_host", false)),
            likesCount = json.optInt("likes_count", json.optInt("total_likes", 0)),
            viewsCount = json.optInt("views_count", json.optInt("total_views", 0)),
            isLiked = json.optBoolean("is_liked", false),
            isViewed = if (isOwner) true else json.optBoolean("is_viewed", false)
        )
    }

    private fun parseSocialPost(json: JSONObject, currentUserId: String): SocialPost {
        val ownerId = json.optString("owner_id", json.optString("user_id", ""))
        val mediaPath = json.optString("media_path")
        val isOwner = ownerId == currentUserId
        val visibleUntil = json.optString("visible_until")
        val isExpired = try {
            if (visibleUntil.isNotBlank() && visibleUntil != "null") {
                // simple check or boolean flag
                json.optBoolean("is_expired", false)
            } else false
        } catch (_: Exception) { false }

        return SocialPost(
            id = json.optString("id"),
            ownerId = ownerId,
            mediaPath = mediaPath,
            caption = json.optString("caption").takeIf { it.isNotBlank() && it != "null" },
            publishedAt = json.optString("published_at"),
            visibleUntil = visibleUntil.takeIf { it.isNotBlank() && it != "null" },
            createdAt = json.optString("created_at"),
            updatedAt = json.optString("updated_at"),
            ownerDisplayName = json.optString("owner_display_name", json.optString("display_name", "Baatly User")),
            ownerUserId = json.optString("owner_user_id", json.optString("user_id")),
            ownerAvatarUrl = json.optString("owner_avatar_url", json.optString("avatar_url")),
            isOwnerHost = json.optBoolean("is_owner_host", json.optBoolean("is_host", false)),
            isUnlocked = if (isOwner) true else json.optBoolean("is_unlocked", false),
            likesCount = json.optInt("likes_count", json.optInt("total_likes", 0)),
            commentsCount = json.optInt("comments_count", json.optInt("total_comments", 0)),
            viewsCount = json.optInt("views_count", json.optInt("total_views", 0)),
            isLiked = json.optBoolean("is_liked", false),
            isExpired = isExpired
        )
    }

    private suspend fun enrichStoriesWithProfiles(stories: List<SocialStory>, currentUserId: String): List<SocialStory> {
        val ownerIds = stories.map { it.ownerId }.distinct().filter { it.isNotBlank() }
        val partnerMap = mutableMapOf<String, PartnerProfile>()
        val profileMap = mutableMapOf<String, JSONObject>()

        if (ownerIds.isNotEmpty()) {
            try {
                val partnerUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?id=in.(${ownerIds.joinToString(",")})&select=*"
                val partnerRes = client.get(partnerUrl)
                val partnerArr = JSONArray(partnerRes)
                for (i in 0 until partnerArr.length()) {
                    val p = parsePartnerProfile(partnerArr.getJSONObject(i))
                    partnerMap[p.id] = p
                    partnerMap[p.userId ?: ""] = p
                }
            } catch (_: Exception) {}

            try {
                val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=in.(${ownerIds.joinToString(",")})&select=*"
                val profileRes = client.get(profileUrl)
                val profileArr = JSONArray(profileRes)
                for (i in 0 until profileArr.length()) {
                    val obj = profileArr.getJSONObject(i)
                    profileMap[obj.optString("id")] = obj
                }
            } catch (_: Exception) {}
        }

        return stories.map { story ->
            val resolvedMedia = resolveSocialMediaUrl(story.mediaPath)
            val partner = partnerMap[story.ownerId]
            val profile = profileMap[story.ownerId]

            val isHost = partner != null || story.isOwnerHost || profile?.optBoolean("is_partner", false) == true
            val displayName = partner?.displayName ?: profile?.optString("display_name") ?: story.ownerDisplayName ?: "Baatly User"
            val userId = partner?.userId ?: profile?.optString("user_id") ?: story.ownerUserId ?: ""
            val avatarRaw = partner?.avatarUrl ?: profile?.optString("avatar_url") ?: story.ownerAvatarUrl
            val resolvedAvatar = resolveSocialMediaUrl(avatarRaw)

            story.copy(
                resolvedMediaUrl = resolvedMedia,
                ownerDisplayName = displayName,
                ownerUserId = userId,
                ownerAvatarUrl = resolvedAvatar,
                isOwnerHost = isHost,
                ownerPartner = partner
            )
        }
    }

    private suspend fun enrichPostsWithProfiles(posts: List<SocialPost>, currentUserId: String): List<SocialPost> {
        val ownerIds = posts.map { it.ownerId }.distinct().filter { it.isNotBlank() }
        val partnerMap = mutableMapOf<String, PartnerProfile>()
        val profileMap = mutableMapOf<String, JSONObject>()

        if (ownerIds.isNotEmpty()) {
            try {
                val partnerUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?id=in.(${ownerIds.joinToString(",")})&select=*"
                val partnerRes = client.get(partnerUrl)
                val partnerArr = JSONArray(partnerRes)
                for (i in 0 until partnerArr.length()) {
                    val p = parsePartnerProfile(partnerArr.getJSONObject(i))
                    partnerMap[p.id] = p
                    partnerMap[p.userId ?: ""] = p
                }
            } catch (_: Exception) {}

            try {
                val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=in.(${ownerIds.joinToString(",")})&select=*"
                val profileRes = client.get(profileUrl)
                val profileArr = JSONArray(profileRes)
                for (i in 0 until profileArr.length()) {
                    val obj = profileArr.getJSONObject(i)
                    profileMap[obj.optString("id")] = obj
                }
            } catch (_: Exception) {}
        }

        return posts.map { post ->
            val resolvedMedia = resolveSocialMediaUrl(post.mediaPath)
            val partner = partnerMap[post.ownerId]
            val profile = profileMap[post.ownerId]

            val isHost = partner != null || post.isOwnerHost || profile?.optBoolean("is_partner", false) == true
            val displayName = partner?.displayName ?: profile?.optString("display_name") ?: post.ownerDisplayName ?: "Baatly User"
            val userId = partner?.userId ?: profile?.optString("user_id") ?: post.ownerUserId ?: ""
            val avatarRaw = partner?.avatarUrl ?: profile?.optString("avatar_url") ?: post.ownerAvatarUrl
            val resolvedAvatar = resolveSocialMediaUrl(avatarRaw)

            // If user's own post, it's always unlocked
            val isUnlocked = if (post.ownerId == currentUserId || !isHost) true else post.isUnlocked

            post.copy(
                resolvedMediaUrl = resolvedMedia,
                ownerDisplayName = displayName,
                ownerUserId = userId,
                ownerAvatarUrl = resolvedAvatar,
                isOwnerHost = isHost,
                isUnlocked = isUnlocked,
                ownerPartner = partner
            )
        }
    }
}


