package com.example.data.network

import android.util.Log
import com.example.data.model.ChatMessage
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SupabaseRealtimeManager(
    private val okHttpClient: OkHttpClient,
    private val sessionManager: com.example.data.local.SessionManager
) {
    private var webSocket: WebSocket? = null
    private var activeConversationId: String? = null
    private var onNewMessageCallback: ((ChatMessage) -> Unit)? = null
    private var onResyncCallback: (() -> Unit)? = null

    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var isConnected = false
    private var refCount = 1

    fun subscribeToConversation(
        conversationId: String,
        onNewMessage: (ChatMessage) -> Unit,
        onResync: () -> Unit
    ) {
        if (activeConversationId == conversationId && isConnected) {
            return
        }

        unsubscribe()
        activeConversationId = conversationId
        onNewMessageCallback = onNewMessage
        onResyncCallback = onResync

        connectWebSocket()
    }

    private fun connectWebSocket() {
        val convId = activeConversationId ?: return

        try {
            val baseUrl = SupabaseConfig.supabaseUrl
                .replace("https://", "wss://")
                .replace("http://", "ws://")
            val wsUrl = "$baseUrl/realtime/v1/websocket?apikey=${SupabaseConfig.publishableKey}&vsn=1.0.0"

            val request = Request.Builder()
                .url(wsUrl)
                .build()

            val client = okHttpClient.newBuilder()
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .build()

            webSocket = client.newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    isConnected = true
                    Log.d("RealtimeManager", "Realtime WebSocket connected")
                    joinConversationChannel(webSocket, convId)
                    startHeartbeat(webSocket)
                    // Trigger initial resync to ensure no missed messages during connect
                    onResyncCallback?.invoke()
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    handleWebSocketMessage(text)
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    isConnected = false
                    webSocket.close(code, reason)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    isConnected = false
                    Log.d("RealtimeManager", "Realtime WebSocket closed: $reason")
                    scheduleReconnect()
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    isConnected = false
                    Log.e("RealtimeManager", "Realtime WebSocket failure: ${t.message}")
                    scheduleReconnect()
                }
            })
        } catch (e: Exception) {
            Log.e("RealtimeManager", "Failed to connect realtime: ${e.message}")
            scheduleReconnect()
        }
    }

    private fun joinConversationChannel(ws: WebSocket, conversationId: String) {
        val token = sessionManager.accessToken.value
        if (!token.isNullOrBlank()) {
            val authMsg = JSONObject().apply {
                put("topic", "realtime")
                put("event", "access_token")
                put("payload", JSONObject().apply {
                    put("access_token", token)
                })
                put("ref", (refCount++).toString())
            }
            ws.send(authMsg.toString())
        }

        val topic = "realtime:public:messages:conversation_id=eq.$conversationId"
        val ref = (refCount++).toString()

        val postgresChanges = org.json.JSONArray().apply {
            put(JSONObject().apply {
                put("event", "INSERT")
                put("schema", "public")
                put("table", "messages")
                put("filter", "conversation_id=eq.$conversationId")
            })
        }

        val payload = JSONObject().apply {
            put("config", JSONObject().apply {
                put("postgres_changes", postgresChanges)
            })
            if (!token.isNullOrBlank()) {
                put("access_token", token)
                put("user_token", token)
            }
        }

        val joinMsg = JSONObject().apply {
            put("topic", topic)
            put("event", "phx_join")
            put("payload", payload)
            put("ref", ref)
        }

        ws.send(joinMsg.toString())
        Log.d("RealtimeManager", "Subscribed to channel: $topic")
    }

    private fun startHeartbeat(ws: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && isConnected) {
                delay(25000)
                try {
                    val hb = JSONObject().apply {
                        put("topic", "phoenix")
                        put("event", "heartbeat")
                        put("payload", JSONObject())
                        put("ref", (refCount++).toString())
                    }
                    ws.send(hb.toString())
                } catch (_: Exception) {
                    break
                }
            }
        }
    }

    private fun handleWebSocketMessage(text: String) {
        try {
            val json = JSONObject(text)
            val event = json.optString("event")
            val payload = json.optJSONObject("payload") ?: return

            if (event == "postgres_changes") {
                val data = payload.optJSONObject("data")
                val record = data?.optJSONObject("record")
                if (record != null) {
                    val message = ChatMessage(
                        id = record.getString("id"),
                        conversationId = record.getString("conversation_id"),
                        senderId = record.getString("sender_id"),
                        receiverId = record.optString("receiver_id"),
                        messageType = record.optString("message_type", "text"),
                        messageText = record.optString("message_text").takeIf { it.isNotBlank() },
                        mediaUrl = record.optString("media_url").takeIf { it.isNotBlank() },
                        mediaDurationSeconds = record.optInt("media_duration_seconds", 0),
                        giftId = record.optString("gift_id").takeIf { it.isNotBlank() },
                        createdAt = record.optString("created_at"),
                        isRead = record.optBoolean("is_read", false)
                    )
                    scope.launch(Dispatchers.Main) {
                        onNewMessageCallback?.invoke(message)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("RealtimeManager", "Error parsing realtime message: ${e.message}")
        }
    }

    private fun scheduleReconnect() {
        if (activeConversationId == null) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(3000)
            if (activeConversationId != null && !isConnected) {
                Log.d("RealtimeManager", "Attempting Realtime reconnection...")
                connectWebSocket()
            }
        }
    }

    fun unsubscribe() {
        heartbeatJob?.cancel()
        reconnectJob?.cancel()
        try {
            webSocket?.close(1000, "Leaving chat screen")
        } catch (_: Exception) {}
        webSocket = null
        isConnected = false
        activeConversationId = null
        onNewMessageCallback = null
        onResyncCallback = null
    }

    fun destroy() {
        unsubscribe()
        scope.cancel()
    }
}
