package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ConversationSummary
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.BaatlyTopBar
import com.example.ui.theme.*

@Composable
fun ChatListScreen(viewModel: BaatlyViewModel) {
    val conversations by viewModel.conversations.collectAsState()
    val wallet by viewModel.wallet.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    Scaffold(
        topBar = {
            BaatlyTopBar(
                coinBalance = wallet?.balance ?: 0,
                onCoinClick = { viewModel.setScreen(Screen.WALLET) },
                onNotificationClick = { viewModel.setScreen(Screen.NOTIFICATIONS) },
                unreadNotifications = notifications.count { !it.isRead },
                onRefreshClick = { viewModel.refreshConversations() }
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Text(
                text = "Conversations",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                ),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Permanent Official Baatly System Conversation
                item(key = "system_baatly_chat") {
                    BaatlySystemConversationItem(
                        onClick = { viewModel.setScreen(Screen.BAATLY_SYSTEM_CHAT) }
                    )
                }

                // Divider / Section Header
                item(key = "section_header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = DarkBorderSubtle
                        )
                        Text(
                            text = "HOST CONVERSATIONS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextTertiary,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 1.sp
                            )
                        )
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = DarkBorderSubtle
                        )
                    }
                }

                if (conversations.isEmpty()) {
                    item(key = "empty_state") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp, horizontal = 20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Chat,
                                    contentDescription = null,
                                    tint = TextTertiary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "No active chats yet.",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = TextSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Start a chat from the Home screen or after any call.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary)
                                )
                            }
                        }
                    }
                } else {
                    items(conversations, key = { it.id }) { conv ->
                        ConversationItem(
                            conversation = conv,
                            onClick = { viewModel.openConversation(conv) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ConversationItem(
    conversation: ConversationSummary,
    onClick: () -> Unit
) {
    val partner = conversation.partner
    val partnerDisplayName = partner?.displayName?.takeIf { it.isNotBlank() && it != "Host" && it != "Baatly Host" }
        ?: partner?.displayName?.takeIf { it.isNotBlank() }
        ?: "Host"

    val previewText = when {
        !conversation.lastMessageText.isNullOrBlank() -> conversation.lastMessageText
        conversation.lastMessageType == "voice" -> "🎙️ Voice message"
        conversation.lastMessageType == "gift" -> "🎁 Gift"
        conversation.lastMessageType == "image" -> "📷 Photo"
        else -> "Tap to chat"
    }

    val formattedTime = formatMessageTime(conversation.lastMessageAt)
    val unreadCount = conversation.unreadCount

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (unreadCount > 0) PrimaryLavender.copy(alpha = 0.6f) else DarkCardBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Partner Avatar with online status
            Box {
                AsyncImage(
                    model = partner?.avatarUrl ?: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200",
                    contentDescription = partnerDisplayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .border(1.5.dp, if (partner?.isOnline == true) OnlineGreen else DarkBorderSubtle, RoundedCornerShape(18.dp))
                )
                if (partner?.isOnline == true) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(OnlineGreen)
                            .border(2.dp, DarkSurface, CircleShape)
                            .align(Alignment.BottomEnd)
                    )
                }
            }

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = partnerDisplayName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = if (unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                            color = Color.White
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (formattedTime.isNotBlank()) {
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (unreadCount > 0) PrimaryLavender else TextTertiary,
                                fontWeight = if (unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = previewText,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (unreadCount > 0) TextPrimary else TextSecondary,
                            fontWeight = if (unreadCount > 0) FontWeight.Medium else FontWeight.Normal
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (unreadCount > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(PrimaryLavender)
                                .padding(horizontal = 7.dp, vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (unreadCount > 99) "99+" else unreadCount.toString(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

fun formatMessageTime(rawTimestamp: String?): String {
    if (rawTimestamp.isNullOrBlank()) return ""
    return try {
        if (!rawTimestamp.contains("T") && !rawTimestamp.contains("-")) {
            return rawTimestamp
        }
        val clean = rawTimestamp.replace("Z", "+00:00")
        val zdt = java.time.ZonedDateTime.parse(clean).withZoneSameInstant(java.time.ZoneId.systemDefault())
        val now = java.time.ZonedDateTime.now(java.time.ZoneId.systemDefault())
        val today = now.toLocalDate()
        val msgDate = zdt.toLocalDate()

        when {
            msgDate.isEqual(today) -> zdt.format(java.time.format.DateTimeFormatter.ofPattern("h:mm a"))
            msgDate.isEqual(today.minusDays(1)) -> "Yesterday"
            msgDate.year == today.year -> zdt.format(java.time.format.DateTimeFormatter.ofPattern("MMM d"))
            else -> zdt.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yy"))
        }
    } catch (_: Exception) {
        try {
            val datePart = rawTimestamp.substringBefore("T")
            val timePart = rawTimestamp.substringAfter("T").substringBefore(".").substringBefore("+").substringBefore("Z")
            if (timePart.isNotBlank() && timePart != rawTimestamp) {
                val parts = timePart.split(":")
                if (parts.size >= 2) {
                    val hour = parts[0].toIntOrNull() ?: 0
                    val minute = parts[1].toIntOrNull() ?: 0
                    val amPm = if (hour >= 12) "PM" else "AM"
                    val displayHour = if (hour % 12 == 0) 12 else hour % 12
                    val displayMin = if (minute < 10) "0$minute" else "$minute"
                    "$displayHour:$displayMin $amPm"
                } else {
                    datePart
                }
            } else {
                datePart
            }
        } catch (_: Exception) {
            ""
        }
    }
}

@Composable
fun BaatlySystemConversationItem(
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = DarkSurface
        ),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryLavender.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("baatly_system_chat_item")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // System Avatar / Shield
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(PrimaryLavender.copy(alpha = 0.15f))
                    .border(1.5.dp, PrimaryLavender, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Baatly Official",
                    tint = PrimaryLavender,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Baatly",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Official Verified",
                            tint = PrimaryLavender,
                            modifier = Modifier.size(16.dp)
                        )
                        Surface(
                            color = PrimaryLavender.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "SYSTEM",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = PrimaryLavender,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Text(
                        text = "Always Active",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = OnlineGreen,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Welcome to Baatly • Official support & safety rules",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = PrimaryLavender.copy(alpha = 0.9f),
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

