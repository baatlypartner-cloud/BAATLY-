# BAATLY User App — UI pass (versionCode 40)

This pass focuses on Android UI, navigation, and presentation only. No Supabase schema, R2 configuration, Edge Function, API credentials, storage connection, or backend service code was changed in this pass.

## Screen/navigation changes
- Launch screen for authenticated users is Social Media.
- Bottom navigation is Social Media, Relationship, Entertainment, Astrologer, and Super AI.
- Social Media has Feedback and Reels views; Reels use a vertical pager and current-page video auto-play/loop behavior.
- Social header has profile avatar, search, and Messages shortcut; wallet/notification controls are not shown there.
- Relationship is the online-host discovery screen; it shows the wallet and refreshes via pull-to-refresh.
- Messages has Messages and Love Note tabs. The current UI classifies conversations using the approved/online host list available to the existing client; a complete classification for offline hosts requires a later backend/data integration pass.
- Instagram-style social profile layout includes Highlights, Posts/Reels/Tagged tabs, and a media grid. Highlights are UI-only placeholders in this pass.
- Entertainment and Super AI have themed UI screens; entertainment cards are placeholders until catalogue/media wiring is done.
- Host-only Call Now and Love Note controls are shown on host posts/reels/stories; ordinary member posts show social actions only.
- Full-screen video playback and story video playback UI are included where the current client already has usable video URLs.
- `versionCode` is set to 40.

## Not included in this pass
- No new backend or R2 upload/playback connection.
- No changes to database charge rules or server-side social monetization.
- UI-only highlights/catalogue population and video-upload activation are reserved for the integration pass.
- APK build verification was blocked because Gradle Wrapper needed to download Gradle 9.3.1 and the environment could not resolve `services.gradle.org`. Source changes were not validated by a successful Gradle build in this environment.
