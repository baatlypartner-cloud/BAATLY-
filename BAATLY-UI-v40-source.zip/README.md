<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/d45863de-561b-4b4a-a740-0d78c7ce49c6

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Meta App Events (version code 36)

The Android app includes Meta's `facebook-core` App Events SDK (18.2.3) and configures
automatic SDK initialization, automatic app-event logging, and advertiser ID collection.
Meta's SDK automatically reports the install event on first launch and activation events
thereafter; there is no separate manual `MOBILE_APP_INSTALL` event added, to avoid
duplicating SDK-managed events. Extra screen-title/AppLink metadata is disabled.

After building and installing the version-code-36 APK from Google Play or a test build,
open the app while online and verify incoming events in Meta Events Manager / App Events.
Meta Ads install attribution also depends on the correct Android package/store listing and
ad campaign/app configuration in Meta.

