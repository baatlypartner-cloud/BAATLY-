package com.example.ui.superai

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

private val Plum = Color(0xFF2B163D)
private val Cream = Color(0xFFFFF8F3)

@Composable
fun SuperAiScreen(onBackToSocial: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Cream).statusBarsPadding().padding(horizontal = 22.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("BAATLY", color = Plum, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text("S U P E R  A I", color = VibrantPink, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            }
        }
        Spacer(Modifier.height(30.dp))
        Box(
            Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(30.dp)).background(Brush.verticalGradient(listOf(Color(0xFFFFF8F3), Color(0xFFF5E5F3), Color(0xFFE9D7FA)))),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(236.dp).clip(RoundedCornerShape(120.dp)).background(Brush.radialGradient(listOf(Color.White, Color(0xFFFFB7D9), Color(0xFF8D3AC5)))), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White.copy(alpha = 0.75f), modifier = Modifier.size(170.dp))
                Icon(Icons.Filled.SmartToy, contentDescription = "BAATLY Super AI", tint = Plum, modifier = Modifier.size(80.dp))
            }
            Text("✦", color = Color(0xFFFFB703), fontSize = 34.sp, modifier = Modifier.align(Alignment.TopEnd).padding(48.dp))
            Text("✧", color = VibrantPink, fontSize = 42.sp, modifier = Modifier.align(Alignment.BottomStart).padding(44.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("BAATLY SUPER AI", color = Plum, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Spacer(Modifier.height(5.dp))
        Text("Your personal AI companion", color = Color(0xFF77647F), fontSize = 16.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(19.dp))
        Surface(shape = RoundedCornerShape(28.dp), color = Color(0xFF9B176B)) {
            Text("C O M I N G  S O O N", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 28.dp, vertical = 14.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("A smarter way to talk, create and explore.", color = Plum, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        Surface(shape = RoundedCornerShape(22.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("A new experience is coming", color = Plum, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("BAATLY Super AI is being prepared for you.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(18.dp))
    }
}
