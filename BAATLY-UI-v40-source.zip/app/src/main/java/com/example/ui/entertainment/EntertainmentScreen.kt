package com.example.ui.entertainment

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*

private val Plum = Color(0xFF2B163D)
private val Cream = Color(0xFFFFF8F3)

@Composable
fun EntertainmentScreen(viewModel: BaatlyViewModel) {
    var selectedFilter by remember { mutableStateOf("All") }
    var showSearch by remember { mutableStateOf(false) }
    val filters = listOf("All", "Hindi", "Haryanvi", "Short Drama", "Movies")

    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("BAATLY", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Plum)
                Text("E N T E R T A I N M E N T", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = VibrantPink, letterSpacing = 1.5.sp)
            }
            IconButton(onClick = { showSearch = true }) { Icon(Icons.Filled.Search, contentDescription = "Search entertainment", tint = Plum, modifier = Modifier.size(25.dp)) }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item {
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(218.dp).clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF311545), Color(0xFF8D204F), Color(0xFFFF8A5B))))
                ) {
                    Column(Modifier.align(Alignment.CenterStart).padding(20.dp).fillMaxWidth(0.72f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Surface(color = Color(0xFFFFB703), shape = RoundedCornerShape(12.dp)) {
                            Text("BAATLY ORIGINALS", color = Plum, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                        }
                        Text("Stories that\nstay with you", color = Color.White, fontSize = 27.sp, lineHeight = 30.sp, fontWeight = FontWeight.Black)
                        Text("Hindi • Haryanvi • Short dramas", color = Color.White.copy(alpha = 0.88f), fontSize = 11.sp)
                        Button(onClick = { selectedFilter = "Short Drama" }, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 5.dp)) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Explore", fontWeight = FontWeight.Bold)
                        }
                    }
                    Icon(Icons.Filled.Tv, contentDescription = null, tint = Color.White.copy(alpha = 0.18f), modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp).size(112.dp))
                }
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filters.size) { index ->
                        val label = filters[index]
                        FilterChip(
                            selected = selectedFilter == label,
                            onClick = { selectedFilter = label },
                            label = { Text(label, fontWeight = FontWeight.SemiBold) },
                            shape = RoundedCornerShape(22.dp),
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = VibrantPink, selectedLabelColor = Color.White, containerColor = Color(0xFFFFEEF2), labelColor = Plum),
                            border = null
                        )
                    }
                }
            }
            item { ContentSection(title = "Continue Watching", seeAll = "Resume", items = listOf(CatalogItem("Shehar Ke Rishte", "Episode 4 • 12 min", "Drama", Color(0xFF503044)), CatalogItem("Gaon Ki Kahaani", "Episode 2 • 18 min", "Haryanvi", Color(0xFF9A503C)), CatalogItem("Aakhri Chitthi", "Episode 1 • 16 min", "Drama", Color(0xFF283A44)))) }
            if (selectedFilter == "All" || selectedFilter == "Short Drama" || selectedFilter == "Hindi" || selectedFilter == "Haryanvi") {
                item { ContentSection(title = "Trending Short Dramas", seeAll = "See all", items = listOf(CatalogItem("Mitti Ka Vaada", "8 episodes", "Original", Color(0xFF6C314D)), CatalogItem("College Wali", "10 episodes", "Romance", Color(0xFF4C455F)), CatalogItem("Saas Aur Main", "6 episodes", "Family", Color(0xFF9B5640)), CatalogItem("Do Raaste", "5 episodes", "Drama", Color(0xFF374F61)))) }
            }
            if (selectedFilter == "All" || selectedFilter == "Movies" || selectedFilter == "Hindi") {
                item { ContentSection(title = "Hindi Movies", seeAll = "See all", items = listOf(CatalogItem("Nayi Subah", "2h 08m", "Drama", Color(0xFF51495C)), CatalogItem("Dil Se Gaon Tak", "1h 54m", "Romance", Color(0xFF824A3F)), CatalogItem("Aakhri Faisla", "2h 21m", "Thriller", Color(0xFF343B4A)))) }
            }
            if (selectedFilter == "All" || selectedFilter == "Movies" || selectedFilter == "Haryanvi") {
                item { ContentSection(title = "Haryanvi Originals", seeAll = "See all", items = listOf(CatalogItem("Pind Ka Pyaar", "2h 02m", "Haryanvi", Color(0xFF805044)), CatalogItem("Maa Ki Kasam", "1h 47m", "Family", Color(0xFF5F6449)), CatalogItem("Khet Aur Khwaab", "1h 58m", "Drama", Color(0xFF4C4655)))) }
            }
            item {
                Text("Your licensed movies and episodes will appear in this catalogue once the media backend is connected.", color = TextTertiary, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 18.dp))
            }
        }
    }
    if (showSearch) {
        var query by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSearch = false },
            containerColor = Color.White,
            title = { Text("Search Entertainment", color = Plum, fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true, placeholder = { Text("Movie, drama, actor…") }) },
            confirmButton = { TextButton(onClick = { showSearch = false }) { Text("Search", color = VibrantPink) } }
        )
    }
}

private data class CatalogItem(val title: String, val subtitle: String, val genre: String, val color: Color)

@Composable
private fun ContentSection(title: String, seeAll: String, items: List<CatalogItem>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Plum, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(seeAll, color = VibrantPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            items(items.size) { index ->
                val item = items[index]
                Column(Modifier.width(128.dp).clickable { }.testTag("entertainment_${item.title.replace(' ', '_')}") ) {
                    Box(Modifier.fillMaxWidth().height(168.dp).clip(RoundedCornerShape(15.dp)).background(Brush.verticalGradient(listOf(item.color, item.color.copy(alpha = 0.62f), Color(0xFF1E1425))))) {
                        Column(Modifier.align(Alignment.TopStart).padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Surface(color = Color.White.copy(alpha = 0.18f), shape = RoundedCornerShape(8.dp)) { Text(item.genre.uppercase(), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) }
                        }
                        Text(item.title, color = Color.White, fontSize = 17.sp, lineHeight = 19.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomStart).padding(10.dp), maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Play ${item.title}", tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.align(Alignment.Center).size(32.dp).background(Color.Black.copy(alpha = 0.22f), RoundedCornerShape(50)).padding(5.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(item.title, color = Plum, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(item.subtitle, color = TextSecondary, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}
