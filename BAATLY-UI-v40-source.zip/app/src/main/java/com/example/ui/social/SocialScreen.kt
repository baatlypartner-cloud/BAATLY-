package com.example.ui.social

import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.SocialPost
import com.example.data.model.SocialStory
import com.example.data.model.SocialProfile
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.rememberResolvedProfileImageUrl
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

private val BrandPlum = Color(0xFF2B163D)
private val SocialCream = Color(0xFFFFF8F3)
private val SocialSoftPink = Color(0xFFFFEEF2)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val posts by viewModel.socialPosts.collectAsState()
    val stories by viewModel.socialStories.collectAsState()
    val isLoading by viewModel.isSocialLoading.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val activeLikeOperations by viewModel.activeLikeOperations.collectAsState()
    val availablePartners by viewModel.availablePartners.collectAsState()
    var selectedTab by remember { mutableStateOf("Reels") }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedStory by remember { mutableStateOf<SocialStory?>(null) }
    var commentTarget by remember { mutableStateOf<SocialPost?>(null) }
    var loveNoteTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var createStoryDialog by remember { mutableStateOf(false) }
    var showReelUploadInfo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { viewModel.refreshSocialFeed() }

    val storyPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val input = context.contentResolver.openInputStream(uri)
                    val file = File(context.cacheDir, "baatly_story_${System.currentTimeMillis()}.jpg")
                    file.outputStream().use { output -> input?.copyTo(output) }
                    viewModel.createSocialStory(file, "My Story") { }
                } catch (_: Exception) {
                    viewModel.showUserMessage("Couldn't load that photo")
                }
            }
        }
    }

    val postPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val input = context.contentResolver.openInputStream(uri)
                    val file = File(context.cacheDir, "baatly_post_${System.currentTimeMillis()}.jpg")
                    file.outputStream().use { output -> input?.copyTo(output) }
                    viewModel.createSocialPost(file, "Shared on BAATLY") { }
                } catch (_: Exception) {
                    viewModel.showUserMessage("Couldn't load that photo")
                }
            }
        }
    }

    val resolvedAvatar by rememberResolvedProfileImageUrl(currentUser?.avatarUrl, viewModel.dataService)

    Column(Modifier.fillMaxSize().background(SocialCream)) {
        SocialHeader(
            avatarUrl = resolvedAvatar,
            onProfile = { viewModel.openSocialProfile(null) },
            onSearch = { showSearch = true },
            onMessages = { viewModel.setScreen(Screen.CHAT_LIST) }
        )
        if (selectedTab == "Reels") {
            val reels = remember(posts) { posts.filter { it.mediaType.equals("video", ignoreCase = true) } }
            Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black)) {
                if (reels.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(horizontal = 26.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(54.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("Reels are on their way", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(5.dp))
                        Text("Vertical videos will autoplay here as you swipe.", color = Color.White.copy(alpha = 0.78f), fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { showReelUploadInfo = true }, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(24.dp)) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Create Reel")
                        }
                    }
                } else {
                    val pagerState = rememberPagerState(pageCount = { reels.size })
                    VerticalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize().testTag("social_reels_vertical_pager"),
                        beyondViewportPageCount = 1,
                        pageSpacing = 0.dp
                    ) { page ->
                        val post = reels[page]
                        ReelPage(
                            post = post,
                            viewModel = viewModel,
                            shouldPlay = pagerState.currentPage == page,
                            isLiking = activeLikeOperations.contains(post.id),
                            onLike = { viewModel.toggleSocialLike(post) },
                            onFollow = { viewModel.toggleSocialFollow(post.userId) },
                            onComment = { commentTarget = post },
                            onProfile = { viewModel.openSocialProfile(post.userId) },
                            onCall = {
                                val partner = availablePartners.firstOrNull { it.id == post.userId || it.userId == post.userId }
                                if (post.isHost && post.canVoiceCall && partner != null) viewModel.requestCall(partner)
                                else viewModel.showUserMessage("This host isn't available for a call right now")
                            },
                            onLoveNote = { loveNoteTarget = "post" to post.id }
                        )
                    }
                }
                FeedbackReelsTabs(
                    selected = selectedTab,
                    onSelect = { selectedTab = it },
                    modifier = Modifier.align(Alignment.TopCenter).zIndex(2f)
                )
            }
        } else {
            FeedbackReelsTabs(selected = selectedTab, onSelect = { selectedTab = it })
            PullToRefreshBox(
                isRefreshing = isLoading,
                onRefresh = { viewModel.refreshSocialFeed() },
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item(key = "social_stories") {
                        SocialStoriesRow(
                            stories = stories,
                            viewModel = viewModel,
                            onAddStory = { storyPicker.launch("image/*") },
                            onStoryClick = { selectedStory = it }
                        )
                    }
                    item(key = "social_post_create") {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { postPicker.launch("image/*") }) {
                                Icon(Icons.Filled.Add, contentDescription = null, tint = VibrantPink)
                                Spacer(Modifier.width(4.dp))
                                Text("Create post", color = VibrantPink, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    if (isLoading && posts.isEmpty()) {
                        item(key = "social_loading") {
                            Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = VibrantPink)
                            }
                        }
                    } else if (posts.isEmpty()) {
                        item(key = "social_empty") {
                            Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(48.dp))
                                    Text("Your feed starts here", color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Text("Share a photo or video with your BAATLY community.", color = TextSecondary, fontSize = 13.sp)
                                }
                            }
                        }
                    } else {
                        items(posts, key = { it.id }) { post ->
                            SocialFeedPostCard(
                                post = post,
                                viewModel = viewModel,
                                isLiking = activeLikeOperations.contains(post.id),
                                onLike = { viewModel.toggleSocialLike(post) },
                                onFollow = { viewModel.toggleSocialFollow(post.userId) },
                                onProfile = { viewModel.openSocialProfile(post.userId) },
                                onComment = { commentTarget = post },
                                onCall = {
                                    val partner = availablePartners.firstOrNull { it.id == post.userId || it.userId == post.userId }
                                    if (post.isHost && post.canVoiceCall && partner != null) viewModel.requestCall(partner)
                                    else viewModel.showUserMessage("This host isn't available for a call right now")
                                },
                                onLoveNote = { loveNoteTarget = "post" to post.id }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSearch) {
        AlertDialog(
            onDismissRequest = { showSearch = false },
            containerColor = Color.White,
            title = { Text("Search BAATLY", color = BrandPlum, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            viewModel.searchSocialHosts(it)
                        },
                        singleLine = true,
                        placeholder = { Text("Search people or hosts") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    val results by viewModel.socialSearchResults.collectAsState()
                    results.take(5).forEach { profile ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                                showSearch = false
                                viewModel.openSocialProfile(profile.userId)
                            }.padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AsyncImage(model = profile.avatarUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(38.dp).clip(CircleShape))
                            Column(Modifier.weight(1f)) {
                                Text(profile.displayName.ifBlank { profile.username }, color = BrandPlum, fontWeight = FontWeight.SemiBold)
                                Text(if (profile.isHost) "Approved host" else "BAATLY member", color = TextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSearch = false }) { Text("Done", color = VibrantPink) } }
        )
    }

    selectedStory?.let { story ->
        StoryViewerDialog(
            story = story,
            viewModel = viewModel,
            onDismiss = { selectedStory = null },
            onLike = { viewModel.showUserMessage("Story likes will be connected in the backend pass") },
            onComment = { viewModel.showUserMessage("Story comments will be connected in the backend pass") },
            onFollow = { viewModel.toggleSocialFollow(story.userId) },
            onCall = {
                val partner = availablePartners.firstOrNull { it.id == story.userId || it.userId == story.userId }
                if (story.isHost && story.canVoiceCall && partner != null) viewModel.requestCall(partner)
                else viewModel.showUserMessage("This host isn't available for a call right now")
            },
            onLoveNote = { loveNoteTarget = "story" to story.id }
        )
    }

    commentTarget?.let { post ->
        var commentText by remember(post.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { commentTarget = null },
            containerColor = Color.White,
            title = { Text("Comments", color = BrandPlum, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Comments on ${post.creatorName}'s post", color = TextSecondary, fontSize = 13.sp)
                    OutlinedTextField(value = commentText, onValueChange = { commentText = it }, placeholder = { Text("Write a comment…") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    Text("Comment posting will be connected in the backend pass.", color = TextTertiary, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { commentTarget = null }) { Text("Close", color = VibrantPink) } }
        )
    }

    if (showReelUploadInfo) {
        AlertDialog(
            onDismissRequest = { showReelUploadInfo = false },
            containerColor = Color.White,
            title = { Text("Create a Reel", color = BrandPlum, fontWeight = FontWeight.Bold) },
            text = { Text("The Reels screen supports vertical video playback. Video upload will be enabled in the media-integration phase so clips keep the correct video format.", color = TextSecondary) },
            confirmButton = { TextButton(onClick = { showReelUploadInfo = false; selectedTab = "Feedback" }) { Text("Go to Feedback", color = VibrantPink) } },
            dismissButton = { TextButton(onClick = { showReelUploadInfo = false }) { Text("Close", color = TextSecondary) } }
        )
    }

    loveNoteTarget?.let { target ->
        var message by remember(target) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { loveNoteTarget = null },
            containerColor = Color.White,
            title = { Text("Send Love Note 💌", color = BrandPlum, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Write a note to this approved host.", color = TextSecondary, fontSize = 13.sp)
                    OutlinedTextField(value = message, onValueChange = { message = it }, placeholder = { Text("Write your message…") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = message.isNotBlank(), onClick = {
                    viewModel.sendSocialLoveNote(target.first, target.second, message.trim()) { loveNoteTarget = null }
                }) { Text("Send", color = VibrantPink) }
            },
            dismissButton = { TextButton(onClick = { loveNoteTarget = null }) { Text("Cancel", color = TextSecondary) } }
        )
    }
}

@Composable
private fun SocialHeader(
    avatarUrl: String?,
    onProfile: () -> Unit,
    onSearch: () -> Unit,
    onMessages: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(SocialCream).statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        AsyncImage(
            model = avatarUrl,
            contentDescription = "My profile",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(42.dp).clip(CircleShape).background(SocialSoftPink).clickable(onClick = onProfile).testTag("btn_social_my_profile")
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
            Text("BAATLY", fontSize = 26.sp, fontWeight = FontWeight.Black, color = BrandPlum, letterSpacing = 0.2.sp)
            Text("U S E R  A P P", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = VibrantPink, letterSpacing = 1.5.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onSearch, modifier = Modifier.size(38.dp).testTag("btn_social_search")) {
                Icon(Icons.Filled.Search, contentDescription = "Search", tint = BrandPlum, modifier = Modifier.size(25.dp))
            }
            IconButton(onClick = onMessages, modifier = Modifier.size(38.dp).testTag("btn_social_messages")) {
                Icon(Icons.Outlined.MailOutline, contentDescription = "Messages", tint = BrandPlum, modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
private fun FeedbackReelsTabs(selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(28.dp), color = Color(0xFFF3ECEA), modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.padding(3.dp)) {
            listOf("Feedback", "Reels").forEach { tab ->
                Surface(
                    shape = RoundedCornerShape(25.dp),
                    color = if (selected == tab) VibrantPink else Color.Transparent,
                    modifier = Modifier.weight(1f).clickable { onSelect(tab) }.testTag("tab_social_${tab.lowercase()}")
                ) {
                    Box(Modifier.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Text(tab, color = if (selected == tab) Color.White else BrandPlum, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialStoriesRow(
    stories: List<SocialStory>,
    viewModel: BaatlyViewModel,
    onAddStory: () -> Unit,
    onStoryClick: (SocialStory) -> Unit
) {
    LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(13.dp), modifier = Modifier.padding(top = 8.dp)) {
        item(key = "my_story") {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp).clickable(onClick = onAddStory)) {
                Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White).border(2.dp, DarkCardBorder, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Add, contentDescription = "Add story", tint = BrandPlum, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(5.dp))
                Text("Your story", color = BrandPlum, fontSize = 11.sp, maxLines = 1)
            }
        }
        items(stories, key = { it.id }) { story ->
            val storyAvatar by rememberResolvedProfileImageUrl(story.creatorAvatarUrl, viewModel.dataService)
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp).clickable { onStoryClick(story) }) {
                Box(Modifier.size(72.dp).clip(CircleShape).border(3.dp, Brush.sweepGradient(listOf(VibrantPink, Color(0xFFFFB703), VibrantPink)), CircleShape).padding(4.dp)) {
                    AsyncImage(model = storyAvatar, contentDescription = story.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape).background(SocialSoftPink))
                }
                Spacer(Modifier.height(5.dp))
                Text(story.creatorName.ifBlank { "Member" }, color = BrandPlum, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SocialFeedPostCard(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    isLiking: Boolean,
    onLike: () -> Unit,
    onFollow: () -> Unit,
    onProfile: () -> Unit,
    onComment: () -> Unit,
    onCall: () -> Unit,
    onLoveNote: () -> Unit
) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    val resolvedAvatar by rememberResolvedProfileImageUrl(post.creatorAvatarUrl, viewModel.dataService)
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket) {
        val raw = post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket).takeIf { it.isNotBlank() }
    }
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF0E8E4)),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
    ) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onProfile).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AsyncImage(model = resolvedAvatar, contentDescription = post.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.size(44.dp).clip(CircleShape).background(SocialSoftPink))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(post.creatorName.ifBlank { "BAATLY member" }, color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (post.isHost) Text("✓", color = VibrantPink, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                    Text(if (post.isHost) "Approved host" else "BAATLY community", color = TextSecondary, fontSize = 11.sp)
                }
                TextButton(onClick = onFollow, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)) { Text(if (post.isFollowing) "Following" else "Follow", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                Icon(Icons.Filled.MoreHoriz, contentDescription = "More", tint = BrandPlum)
            }
            if (post.caption.isNotBlank()) Text(post.caption, color = BrandPlum, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 15.dp, vertical = 4.dp))
            Box(Modifier.fillMaxWidth().height(365.dp).background(Color(0xFFEFE7E4)).clickable(enabled = !mediaUrl.isNullOrBlank()) { if (!mediaUrl.isNullOrBlank()) viewModel.openFullScreenMedia(mediaUrl!!, post.mediaType) }) {
                if (post.mediaType.equals("video", ignoreCase = true) && !mediaUrl.isNullOrBlank()) {
                    AutoPlayVideo(mediaUrl!!, shouldPlay = false, modifier = Modifier.fillMaxSize())
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play video", tint = Color.White, modifier = Modifier.align(Alignment.Center).size(52.dp).background(Color.Black.copy(alpha = 0.35f), CircleShape).padding(12.dp))
                } else {
                    AsyncImage(model = mediaUrl, contentDescription = post.caption, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                ActionItem(icon = if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, label = "${post.likesCount}", tint = if (post.isLiked) VibrantPink else BrandPlum, onClick = onLike, isLoading = isLiking)
                ActionItem(icon = Icons.Filled.ChatBubbleOutline, label = "Comment", tint = BrandPlum, onClick = onComment)
                if (post.isHost) {
                    ActionItem(icon = Icons.Filled.Call, label = "Call Now", tint = VibrantPink, onClick = onCall)
                    ActionItem(icon = Icons.Filled.MailOutline, label = "Love Note", tint = PrimaryLavender, onClick = onLoveNote)
                }
            }
        }
    }
}

@Composable
private fun ReelPage(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    shouldPlay: Boolean,
    isLiking: Boolean,
    onLike: () -> Unit,
    onFollow: () -> Unit,
    onComment: () -> Unit,
    onProfile: () -> Unit,
    onCall: () -> Unit,
    onLoveNote: () -> Unit
) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    val resolvedAvatar by rememberResolvedProfileImageUrl(post.creatorAvatarUrl, viewModel.dataService)
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket) {
        val raw = post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket).takeIf { it.isNotBlank() }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!mediaUrl.isNullOrBlank()) AutoPlayVideo(mediaUrl!!, shouldPlay = shouldPlay, modifier = Modifier.fillMaxSize())
        else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }

        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.16f), Color.Transparent, Color.Black.copy(alpha = 0.62f)))))
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp, bottom = 46.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onLike)) {
                Icon(if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, contentDescription = "Like", tint = if (post.isLiked) VibrantPink else Color.White, modifier = Modifier.size(32.dp))
                Text(if (post.likesCount > 0) compactCount(post.likesCount) else "Like", color = Color.White, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onComment)) {
                Icon(Icons.Filled.ChatBubbleOutline, contentDescription = "Comment", tint = Color.White, modifier = Modifier.size(30.dp))
                Text("Comment", color = Color.White, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onFollow)) {
                Icon(Icons.Filled.Add, contentDescription = "Follow", tint = Color.White, modifier = Modifier.size(30.dp))
                Text(if (post.isFollowing) "Following" else "Follow", color = Color.White, fontSize = 11.sp)
            }
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = 16.dp, end = 88.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.clickable(onClick = onProfile)) {
                AsyncImage(model = resolvedAvatar, contentDescription = post.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.size(42.dp).clip(CircleShape).border(2.dp, Color.White, CircleShape))
                Text(post.creatorName.ifBlank { "BAATLY member" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (post.isHost) Text("✓", color = Color.White, fontWeight = FontWeight.Black)
            }
            if (post.caption.isNotBlank()) Text(post.caption, color = Color.White, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (post.isHost) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onCall, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Call Now", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = onLoveNote, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.MailOutline, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Love Note", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    isLoading: Boolean = false
) {
    Row(modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(enabled = !isLoading, onClick = onClick).padding(horizontal = 5.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        if (isLoading) CircularProgressIndicator(modifier = Modifier.size(16.dp), color = tint, strokeWidth = 2.dp)
        else Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun StoryViewerDialog(
    story: SocialStory,
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onFollow: () -> Unit,
    onCall: () -> Unit,
    onLoveNote: () -> Unit
) {
    var mediaUrl by remember(story.id) { mutableStateOf<String?>(null) }
    LaunchedEffect(story.mediaPath, story.mediaUrl) {
        val raw = story.mediaPath?.takeIf { it.isNotBlank() } ?: story.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, isStory = true, explicitBucket = story.mediaBucket).takeIf { it.isNotBlank() }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val isVideoStory = story.mediaPath.orEmpty().substringBefore('?').substringAfterLast('.', "").lowercase() in setOf("mp4", "mov", "m4v", "webm", "m3u8")
            if (isVideoStory && !mediaUrl.isNullOrBlank()) {
                AutoPlayVideo(mediaUrl!!, shouldPlay = true, modifier = Modifier.fillMaxSize())
            } else {
                AsyncImage(model = mediaUrl, contentDescription = story.caption, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Row(Modifier.align(Alignment.TopStart).statusBarsPadding().fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AsyncImage(model = story.creatorAvatarUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(38.dp).clip(CircleShape).border(1.dp, Color.White, CircleShape))
                    Text(story.creatorName, color = Color.White, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Close story", tint = Color.White) }
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (story.caption.isNotBlank()) Text(story.caption, color = Color.White, fontSize = 14.sp)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onLike, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.FavoriteBorder, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Like")
                    }
                    OutlinedButton(onClick = onComment, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Comment")
                    }
                    OutlinedButton(onClick = onFollow, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text("Follow") }
                }
                if (story.isHost) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onCall, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(22.dp)) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Call Now")
                        }
                        OutlinedButton(onClick = onLoveNote, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(22.dp)) {
                            Icon(Icons.Filled.MailOutline, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Love Note")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AutoPlayVideo(url: String, shouldPlay: Boolean, modifier: Modifier = Modifier) {
    val videoRef = remember { mutableStateOf<VideoView?>(null) }
    AndroidView(
        modifier = modifier.background(Color.Black),
        factory = { ctx ->
            VideoView(ctx).also { view ->
                videoRef.value = view
                view.tag = url
                view.setOnPreparedListener { player ->
                    player.isLooping = true
                    player.setVolume(0f, 0f)
                    if (shouldPlay) view.start() else view.pause()
                }
                view.setVideoURI(Uri.parse(url))
            }
        },
        update = { view ->
            if (view.tag != url) {
                view.tag = url
                view.setOnPreparedListener { player ->
                    player.isLooping = true
                    player.setVolume(0f, 0f)
                    if (shouldPlay) view.start() else view.pause()
                }
                view.setVideoURI(Uri.parse(url))
            } else if (shouldPlay && !view.isPlaying) {
                view.start()
            } else if (!shouldPlay && view.isPlaying) {
                view.pause()
            }
        }
    )
    DisposableEffect(url) {
        onDispose {
            videoRef.value?.stopPlayback()
            videoRef.value = null
        }
    }
}

private fun compactCount(value: Int): String = when {
    value >= 1_000_000 -> "%.1fM".format(value / 1_000_000f)
    value >= 1_000 -> "%.1fK".format(value / 1_000f)
    else -> value.toString()
}
