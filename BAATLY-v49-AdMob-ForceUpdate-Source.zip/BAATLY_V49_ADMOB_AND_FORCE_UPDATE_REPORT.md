# BAATLY v49 — AdMob and mandatory Play Store update integration

## Included in this source update

- Google Mobile Ads Next-Gen Android SDK `1.6.0`.
- Google User Messaging Platform consent SDK `4.0.0`.
- Google Play App Update library `2.1.0` for checking Play Store update availability.
- Centralized AdMob IDs and per-placement rendering/frequency rules.
- Debug builds use Google's official test ad-unit IDs. Release builds use BAATLY's production AdMob unit IDs.
- UMP consent information is refreshed at app startup. Ads initialize only when UMP says ads may be requested.
- First usable app frame is gated by a Play update availability check. If Google Play reports a higher available version code, a non-dismissable update dialog is shown. The button opens BAATLY's Play Store listing. A bounded 8-second check timeout / Play API failure unlocks the app so offline users are not permanently blocked.
- `versionCode` incremented to `49`, `versionName` set to `1.0.49`.
- Release builds no longer silently fall back to the debug signing certificate. The supplied ZIP does not contain the private Play upload keystore; configure `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` with the owner's upload key before building a Play-uploadable release. Without that key, release output remains unsigned instead of being signed with an incompatible debug key.

## Ad unit mapping

AdMob App ID: `ca-app-pub-9363095174633972~9323820583`

| Unit | Ad unit ID | App placement / trigger |
|---|---|---|
| `BAATLY_Home_AppOpen` | `ca-app-pub-9363095174633972/4795775416` | Warm return after at least 4 hours in background; not on first launch; suppressed during calls and mandatory update |
| `BAATLY_HostList_Native` | `ca-app-pub-9363095174633972/3291122057` | After every 5 host cards |
| `BAATLY_ChatList_Native` | `ca-app-pub-9363095174633972/2085851599` | After the 8th conversation, then every 10 conversations |
| `BAATLY_Reels_Native` | `ca-app-pub-9363095174633972/1485271702` | Full-page native-ad slot after every 8 organic reels |
| `BAATLY_PanditAI_Native` | `ca-app-pub-9363095174633972/3351840962` | After each completed AI Astrologer / Pandit Ji response |
| `BAATLY_SuperAI_Native` | `ca-app-pub-9363095174633972/9473387024` | After each completed SuperAI assistant response |
| `BAATLY_Entertainment_Banner` | `ca-app-pub-9363095174633972/6354455002` | Entertainment catalogue screen while visible and catalogue is available |
| `BAATLY_Entertainment_Native` | `ca-app-pub-9363095174633972/8980618347` | After first 6 catalogue cards, then every 10 cards in a content section |
| `BAATLY_PostCall_Interstitial` | `ca-app-pub-9363095174633972/5375369073` | After a successfully completed call, never while ringing or connected; shared completion hook covers audio and any future video-call flow using the same call lifecycle |

Note: the current BAATLY UI's video-call button still reports video calling as unavailable. The post-call ad hook is connected to the shared call completion handler, but a video-call experience must be enabled separately before it can generate completed video-call events.

## Mandatory update behavior

- Play Store package: `com.aistudio.baatly.app`.
- Listing: `https://play.google.com/store/apps/details?id=com.aistudio.baatly.app`.
- The app asks Play Core for `AppUpdateInfo` at startup and on resume.
- The lock screen is shown if Play reports `UPDATE_AVAILABLE` and `availableVersionCode` is greater than the installed build's `BuildConfig.VERSION_CODE`.
- The dialog has no close button, outside-tap dismissal, or back dismissal. Its only action opens the Play Store listing.
- To make a future release mandatory for existing installs, upload a new AAB with the same application ID, the same Play upload/signing identity, and a `versionCode` greater than the currently published version. Users receive the gate only after Google Play makes that newer version available to their account/device.
- The supplied project ZIP does not include the private upload keystore. Set `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` for the existing Play upload key. The Gradle release configuration intentionally does not use the debug key as a fallback.
- The app fails closed if Play cannot verify the installed version: after an 8-second timeout or Play API failure, BAATLY content remains blocked and the user sees only Retry and Open Play Store actions. A device needs connectivity and a Google Play-installed copy for reliable Play update availability checks.

## Items intentionally not included

The separate Entertainment movie/episode mid-roll video-ad system (IMA/VAST) was deferred as requested. The current nine ad units do not create movie mid-roll inventory; that will be a separate implementation.

## Validation status

Source-level checks and manifest XML validation were run. A full Gradle Android build could not be completed in this execution environment because the Gradle 9.3.1 wrapper distribution was not cached and `services.gradle.org` was unreachable (DNS/network failure). Therefore this ZIP is an updated source project, not a verified APK/AAB. Sync and build it in Android Studio or a machine with the project's Gradle distribution and Android SDK installed before release.
