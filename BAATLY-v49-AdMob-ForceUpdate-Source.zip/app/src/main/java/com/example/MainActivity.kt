package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.net.Uri
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.ads.BaatlyAds
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.notification.NotificationHelper
import com.example.ui.*
import com.example.ui.auth.AuthScreen
import com.example.ui.call.ActiveCallScreen
import com.example.ui.chat.BaatlySystemChatScreen
import com.example.ui.chat.ChatListScreen
import com.example.ui.chat.DirectChatScreen
import com.example.ui.components.BaatlyBottomNavBar
import com.example.ui.components.CallRatingDialog
import com.example.ui.components.GiftAnimationOverlay
import com.example.ui.components.RechargePopup
import com.example.ui.components.ReportUserDialog
import com.example.ui.gift.GiftBottomSheet
import com.example.ui.home.HomeScreen
import com.example.ui.host.HostProfileScreen
import com.example.ui.notifications.NotificationsScreen
import com.example.ui.onboarding.OnboardingFlow
import com.example.data.model.UroPayPaymentUiState
import com.example.ui.profile.UserProfileScreen
import com.example.ui.recent.RecentCallsScreen
import com.example.ui.theme.BaatlyTheme
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.wallet.WalletScreen
import com.example.ui.astrologer.AstrologerScreen
import com.example.ui.social.SocialScreen
import com.example.ui.social.SocialProfileScreen
import com.example.ui.entertainment.EntertainmentScreen
import com.example.ui.superai.SuperAiScreen
import com.example.ui.media.FullScreenMediaViewer
import com.example.data.model.PhoneAuthStep

class MainActivity : BaseActivity() {

    private val viewModel: BaatlyViewModel by viewModels()
    private val mandatoryUpdateRequired = mutableStateOf(false)
    private val initialUpdateCheckComplete = mutableStateOf(false)
    private val updateCheckFailed = mutableStateOf(false)
    private val updateCheckInProgressState = mutableStateOf(false)
    private val playUpdateManager by lazy { AppUpdateManagerFactory.create(this) }
    private val updateMainHandler = Handler(Looper.getMainLooper())
    private var updateCheckInFlight = false
    private var updateCheckTimeout: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BaatlyApplication.applyWindowProtection(this)
        enableEdgeToEdge()

        // Initialize Notification Channels
        NotificationHelper.createNotificationChannels(this)

        // Process any tap from Notification or Deep Link
        handleNotificationIntent(intent)
        handleDeepLinkIntent(intent)

        // Pre-warm Custom Tabs provider for fast checkout launch
        com.example.ui.payment.UroPayCheckoutLauncher.prewarm(this)
        viewModel.onCompletedCallForAd = { BaatlyAds.showPostCallInterstitial(this) }

        setContent {
            BaatlyTheme {
                Box(Modifier.fillMaxSize()) {
                    when {
                        !initialUpdateCheckComplete.value || updateCheckInProgressState.value -> {
                            Column(
                                modifier = Modifier.fillMaxSize().background(DarkBackground),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(color = NeonPink)
                                Spacer(Modifier.height(14.dp))
                                Text("Checking for BAATLY updates…", color = TextPrimary, fontSize = 14.sp)
                            }
                        }
                        mandatoryUpdateRequired.value -> MandatoryBaatlyUpdateDialog(onUpdate = { openBaatlyPlayStore() })
                        updateCheckFailed.value -> MandatoryUpdateCheckFailureScreen(
                            onRetry = { checkForMandatoryUpdate() },
                            onOpenStore = { openBaatlyPlayStore() }
                        )
                        else -> BaatlyApp(viewModel = viewModel)
                    }
                }
            }
        }
        requestAdConsentAndInitialize()
        checkForMandatoryUpdate()
    }

    override fun onDestroy() {
        super.onDestroy()
        com.example.ui.payment.UroPayCheckoutLauncher.unbind(this)
    }

    override fun onResume() {
        super.onResume()
        NotificationHelper.isAppInForeground = true
        viewModel.onAppResumed()
        checkForMandatoryUpdate()
    }

    override fun onPause() {
        super.onPause()
        NotificationHelper.isAppInForeground = false
        BaatlyAds.recordBackground(this)
    }

    private fun requestAdConsentAndInitialize() {
        try {
            val consentInformation = UserMessagingPlatform.getConsentInformation(this)
            val parameters = ConsentRequestParameters.Builder().build()
            consentInformation.requestConsentInfoUpdate(
                this,
                parameters,
                {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) {
                        if (consentInformation.canRequestAds()) BaatlyAds.initialize(applicationContext)
                    }
                },
                { error ->
                    android.util.Log.w("BaatlyAds", "Consent information update failed: ${error.message}")
                    if (consentInformation.canRequestAds()) BaatlyAds.initialize(applicationContext)
                }
            )
        } catch (t: Throwable) {
            android.util.Log.e("BaatlyAds", "UMP consent setup failed; ads remain disabled", t)
        }
    }

    /** Blocks the first usable frame only after Play has checked for a newer version. */
    private fun checkForMandatoryUpdate() {
        if (updateCheckInFlight) return
        updateCheckInFlight = true
        updateCheckInProgressState.value = true

        updateCheckTimeout?.let { updateMainHandler.removeCallbacks(it) }
        val timeout = Runnable {
            updateCheckInFlight = false
            updateCheckInProgressState.value = false
            updateCheckFailed.value = true
            initialUpdateCheckComplete.value = true
            android.util.Log.w("MandatoryUpdate", "Play update check timed out; keeping the app locked until Play can verify the version")
        }
        updateCheckTimeout = timeout
        updateMainHandler.postDelayed(timeout, 8_000L)

        fun finishCheck() {
            updateMainHandler.removeCallbacks(timeout)
            if (updateCheckTimeout === timeout) updateCheckTimeout = null
            updateCheckInFlight = false
            updateCheckInProgressState.value = false
            initialUpdateCheckComplete.value = true
        }

        try {
            playUpdateManager.appUpdateInfo
                .addOnSuccessListener { info ->
                    val newerVersionAvailable = info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                        info.availableVersionCode() > BuildConfig.VERSION_CODE
                    mandatoryUpdateRequired.value = newerVersionAvailable
                    updateCheckFailed.value = false
                    finishCheck()
                    if (!newerVersionAvailable) {
                        val active = viewModel.activeCall.value != null && viewModel.callState.value in listOf(CallState.CONNECTED, CallState.RINGING)
                        BaatlyAds.showAppOpenOnEligibleResume(this, active, false)
                    }
                }
                .addOnFailureListener { error ->
                    android.util.Log.w("MandatoryUpdate", "Play update check unavailable: ${error.message}")
                    updateCheckFailed.value = true
                    finishCheck()
                }
        } catch (t: Throwable) {
            android.util.Log.w("MandatoryUpdate", "Play update API unavailable", t)
            updateCheckFailed.value = true
            finishCheck()
        }
    }

    private fun openBaatlyPlayStore() {
        val marketUri = Uri.parse("market://details?id=com.aistudio.baatly.app")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, marketUri).setPackage("com.android.vending"))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.aistudio.baatly.app")))
            } catch (error: Exception) {
                android.util.Log.e("MandatoryUpdate", "Unable to open Play Store", error)
                Toast.makeText(this, "Open Google Play and update BAATLY to continue.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
        handleDeepLinkIntent(intent)
    }

    private fun handleDeepLinkIntent(intent: Intent?) {
        val data = intent?.data ?: return
        android.util.Log.d("MainActivity", "handleDeepLinkIntent: data=$data")
        viewModel.handlePaymentReturnDeepLink(data)
    }

    private fun handleNotificationIntent(intent: Intent?) {
        val extras = intent?.extras ?: return
        val isAcceptCall = extras.getBoolean("extra_accept_call", false)
        if (isAcceptCall) {
            val callId = extras.getString("call_id").orEmpty()
            val partnerId = extras.getString("partner_id").orEmpty()
            val callType = extras.getString("call_type").orEmpty()
            val isVideo = callType.lowercase().contains("video")
            viewModel.acceptIncomingCall(callId, partnerId, isVideo)
            return
        }
        val map = mutableMapOf<String, String?>()
        for (key in extras.keySet()) {
            map[key] = extras.get(key)?.toString()
        }
        val notifType = extras.getString("notification_type") ?: extras.getString("type")
        val navigateToCall = extras.getBoolean("extra_navigate_to_call", false)
        if (navigateToCall) {
            viewModel.setScreen(Screen.ACTIVE_CALL)
            return
        }
        if (!notifType.isNullOrBlank() || map.containsKey("conversation_id") || map.containsKey("call_id") || map.containsKey("partner_id")) {
            viewModel.handleNotificationTap(notifType, map)
        }
    }
}

@Composable
private fun MandatoryUpdateCheckFailureScreen(onRetry: () -> Unit, onOpenStore: () -> Unit) {
    BackHandler(enabled = true) { /* Do not allow bypassing the required Play version check. */ }
    Column(
        modifier = Modifier.fillMaxSize().background(DarkBackground).padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.SystemUpdate, contentDescription = null, tint = NeonPink, modifier = Modifier.size(46.dp))
        Spacer(Modifier.height(16.dp))
        Text("BAATLY Update Check Required", color = TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(
            "Connect to the internet and verify BAATLY through Google Play before continuing. You cannot use the app until the version check succeeds.",
            color = TextMuted, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Text("Retry version check", fontWeight = FontWeight.Bold)
        }
        OutlinedButton(onClick = onOpenStore, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Text("Open BAATLY on Play Store", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MandatoryBaatlyUpdateDialog(onUpdate: () -> Unit) {
    BackHandler(enabled = true) { /* The update is required; this dialog cannot be dismissed. */ }
    Dialog(onDismissRequest = { }, properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 26.dp),
            shape = RoundedCornerShape(24.dp),
            color = DarkCard,
            tonalElevation = 10.dp
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.SystemUpdate, contentDescription = null, tint = NeonPink, modifier = Modifier.size(42.dp))
                Text("BAATLY Update Required", color = TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text("A new version of BAATLY is available. Update the app to continue using BAATLY.", color = TextMuted, fontSize = 14.sp, textAlign = TextAlign.Center)
                Button(onClick = onUpdate, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Filled.SystemUpdate, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Update BAATLY", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BaatlyApp(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val socialReelsFullscreen by viewModel.socialReelsFullscreen.collectAsState()
    val token by viewModel.isLoggedIn.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val phoneAuthStep by viewModel.phoneAuthStep.collectAsState()
    val isOnboardingCompleted by viewModel.isOnboardingCompleted.collectAsState()
    val isRestoringSession by viewModel.isRestoringSession.collectAsState()
    val startupError by viewModel.startupError.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val showGiftSheet by viewModel.showGiftSheet.collectAsState()
    val recentGift by viewModel.recentGiftAnimation.collectAsState()
    val pendingRatingCall by viewModel.pendingRatingCall.collectAsState()
    val isSubmittingRating by viewModel.isSubmittingRating.collectAsState()
    val activeReportTarget by viewModel.activeReportTarget.collectAsState()
    val isSubmittingReport by viewModel.isSubmittingReport.collectAsState()
    val paymentState by viewModel.uropayPaymentState.collectAsState()
    val showRechargePopup by viewModel.showRechargePopup.collectAsState()

    // Trigger UroPay Browser Launch on OpeningCheckout state (one-shot launch)
    LaunchedEffect(paymentState) {
        val state = paymentState
        if (state is UroPayPaymentUiState.OpeningCheckout) {
            val success = com.example.ui.payment.UroPayCheckoutLauncher.launch(
                context = context,
                openUrl = state.openUrl,
                paymentId = state.paymentId,
                onError = { errMsg ->
                    viewModel.onCheckoutLaunchFailed(state.paymentId, errMsg, state.amountRupees)
                }
            )
            if (success) {
                viewModel.onCheckoutLaunched(state.paymentId)
            }
        }
    }

    // Request Audio Permission for Voice Calls & Notes
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    // Request Notification Permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(token) {
        if (!token.isNullOrBlank() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Show User Messages / Toasts
    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    val activeCall by viewModel.activeCall.collectAsState()
    val callState by viewModel.callState.collectAsState()
    val activePartner by viewModel.activeCallPartner.collectAsState()
    val isCallActiveInBackground = activeCall != null && (callState == CallState.CONNECTED || callState == CallState.RINGING)
    val activity = context as? android.app.Activity

    // Back button handling
    BackHandler(enabled = currentScreen !in listOf(Screen.HOME, Screen.SOCIAL, Screen.AUTH)) {
        if (isCallActiveInBackground && currentScreen == Screen.CHAT_LIST) {
            viewModel.setScreen(Screen.ACTIVE_CALL)
        } else {
            when (currentScreen) {
                Screen.PROFILE -> viewModel.setScreen(if (isCallActiveInBackground) Screen.ACTIVE_CALL else Screen.SOCIAL_PROFILE)
                Screen.HOST_PROFILE, Screen.RECENT_CALLS, Screen.WALLET,
                Screen.NOTIFICATIONS, Screen.ASTROLOGER, Screen.SOCIAL_PROFILE,
                Screen.ENTERTAINMENT, Screen.SUPER_AI -> {
                    viewModel.setScreen(if (isCallActiveInBackground) Screen.ACTIVE_CALL else Screen.SOCIAL)
                }
                Screen.ROLEPLAY -> viewModel.setScreen(Screen.HOME)
                Screen.LEGAL_DETAIL -> {
                    viewModel.closeLegalPage()
                }
                Screen.CHAT_LIST -> {
                    viewModel.setScreen(if (isCallActiveInBackground) Screen.ACTIVE_CALL else Screen.SOCIAL)
                }
                Screen.DIRECT_CHAT -> {
                    viewModel.closeChatScreen()
                }
                Screen.BAATLY_SYSTEM_CHAT -> {
                    viewModel.setScreen(Screen.CHAT_LIST)
                }
                Screen.FULL_SCREEN_MEDIA_VIEWER -> {
                    viewModel.closeFullScreenMedia()
                }
                Screen.ACTIVE_CALL -> {
                    // Send app to background so ongoing call continues with foreground service
                    activity?.moveTaskToBack(true)
                }
                else -> {}
            }
        }
    }

    val isUserFullyAuthenticated = !token.isNullOrBlank() &&
        currentUser != null &&
        currentUser?.userId?.isNotBlank() == true &&
        currentUser?.displayName?.isNotBlank() == true &&
        phoneAuthStep !is PhoneAuthStep.ProfileCompletion &&
        currentScreen != Screen.AUTH

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = DarkBackground
    ) {
        when {
            startupError != null -> {
                StartupErrorScreen(
                    errorMessage = startupError ?: "Something went wrong. Please retry.",
                    onRetry = { viewModel.retryStartup() }
                )
            }
            isRestoringSession -> {
                StartupLoadingScreen()
            }
            !isOnboardingCompleted && !isUserFullyAuthenticated -> {
                OnboardingFlow(
                    onComplete = {
                        viewModel.completeOnboarding()
                    }
                )
            }
            !isUserFullyAuthenticated -> {
                AuthScreen(viewModel = viewModel)
            }
            else -> {
                Scaffold(
                    bottomBar = {
                        if (!socialReelsFullscreen && !WindowInsets.isImeVisible && currentScreen in listOf(Screen.HOME, Screen.CHAT_LIST, Screen.ASTROLOGER, Screen.SOCIAL, Screen.ENTERTAINMENT, Screen.SUPER_AI, Screen.SOCIAL_PROFILE)) {
                            BaatlyBottomNavBar(
                                currentScreen = currentScreen,
                                onNavigate = { screen -> viewModel.setScreen(screen) }
                            )
                        }
                    },
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    containerColor = DarkBackground
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = if (!socialReelsFullscreen && currentScreen in listOf(Screen.HOME, Screen.CHAT_LIST, Screen.ASTROLOGER, Screen.SOCIAL, Screen.ENTERTAINMENT, Screen.SUPER_AI, Screen.SOCIAL_PROFILE)) innerPadding.calculateBottomPadding() else 0.dp)
                    ) {
                        when (currentScreen) {
                            Screen.AUTH -> AuthScreen(viewModel = viewModel)
                            Screen.HOME -> HomeScreen(viewModel = viewModel)
                            Screen.ROLEPLAY -> com.example.ui.roleplay.RoleplayScreen(viewModel = viewModel, onBack = { viewModel.setScreen(Screen.HOME) })
                            Screen.HOST_PROFILE -> HostProfileScreen(viewModel = viewModel)
                            Screen.ACTIVE_CALL -> {
                                val isVideoCall = viewModel.agoraCallManager.isVideoCall.collectAsState().value ||
                                                  viewModel.activeCall.collectAsState().value?.callType.equals("video", ignoreCase = true)
                                if (isVideoCall) {
                                    com.example.ui.call.VideoCallScreen(viewModel = viewModel)
                                } else {
                                    ActiveCallScreen(viewModel = viewModel)
                                }
                            }
                            Screen.DIRECT_CHAT -> DirectChatScreen(viewModel = viewModel)
                            Screen.BAATLY_SYSTEM_CHAT -> BaatlySystemChatScreen(viewModel = viewModel)
                            Screen.CHAT_LIST -> ChatListScreen(viewModel = viewModel)
                            Screen.WALLET -> WalletScreen(viewModel = viewModel)
                            Screen.RECENT_CALLS -> RecentCallsScreen(viewModel = viewModel)
                            Screen.PROFILE -> UserProfileScreen(viewModel = viewModel)
                            Screen.NOTIFICATIONS -> NotificationsScreen(viewModel = viewModel)
                            Screen.ASTROLOGER -> AstrologerScreen(viewModel = viewModel)
                            Screen.SOCIAL -> SocialScreen(viewModel = viewModel)
                            Screen.SOCIAL_PROFILE -> SocialProfileScreen(viewModel = viewModel)
                            Screen.ENTERTAINMENT -> EntertainmentScreen(viewModel = viewModel)
                            Screen.SUPER_AI -> SuperAiScreen(viewModel = viewModel)
                            Screen.FULL_SCREEN_MEDIA_VIEWER -> {
                                val mediaUrl by viewModel.fullScreenMediaUrl.collectAsState()
                                if (!mediaUrl.isNullOrBlank()) {
                                    FullScreenMediaViewer(
                                        mediaUrl = mediaUrl!!,
                                        mediaType = viewModel.fullScreenMediaType.collectAsState().value,
                                        onDismiss = { viewModel.closeFullScreenMedia() }
                                    )
                                } else {
                                    HomeScreen(viewModel = viewModel)
                                }
                            }
                            Screen.LEGAL_DETAIL -> {
                                val activeLegalPage by viewModel.activeLegalPage.collectAsState()
                                if (activeLegalPage != null) {
                                    com.example.ui.legal.LegalDetailScreen(
                                        page = activeLegalPage!!,
                                        onBack = { viewModel.closeLegalPage() }
                                    )
                                } else {
                                    UserProfileScreen(viewModel = viewModel)
                                }
                            }
                        }

                        // Background Active Call Banner
                        if (isCallActiveInBackground && currentScreen != Screen.ACTIVE_CALL) {
                            Surface(
                                color = androidx.compose.ui.graphics.Color(0xFF2E7D32),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .statusBarsPadding()
                                    .padding(top = 10.dp, start = 16.dp, end = 16.dp)
                                    .fillMaxWidth()
                                    .clickable { viewModel.setScreen(Screen.ACTIVE_CALL) }
                                    .testTag("banner_active_call_in_bg")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Call,
                                            contentDescription = null,
                                            tint = androidx.compose.ui.graphics.Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "Call in progress with ${activePartner?.displayName ?: "Host"}",
                                            color = androidx.compose.ui.graphics.Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                    Text(
                                        text = "TAP TO RETURN",
                                        color = androidx.compose.ui.graphics.Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }

                        if (showGiftSheet) {
                            GiftBottomSheet(viewModel = viewModel)
                        }

                        recentGift?.let { gift ->
                            GiftAnimationOverlay(gift = gift)
                        }

                        // Call-End Rating Dialog (Authoritative)
                        pendingRatingCall?.let { pending ->
                            CallRatingDialog(
                                pendingCall = pending,
                                isSubmitting = isSubmittingRating,
                                onDismiss = { viewModel.dismissRatingPopup() },
                                onSubmit = { rating, reviewText ->
                                    viewModel.submitCallRating(rating, reviewText)
                                }
                            )
                        }

                        // User / Host Reporting Dialog (Authoritative)
                        activeReportTarget?.let { target ->
                            ReportUserDialog(
                                target = target,
                                isSubmitting = isSubmittingReport,
                                onDismiss = { viewModel.closeReportDialog() },
                                onSubmit = { category, description ->
                                    viewModel.submitUserReport(category, description)
                                }
                            )
                        }

                        // Render UroPay Payment Status Dialog globally if not on Wallet screen
                        if (currentScreen != Screen.WALLET && paymentState !is UroPayPaymentUiState.Idle) {
                            com.example.ui.wallet.UroPayPaymentStatusDialog(
                                state = paymentState,
                                onDismiss = { viewModel.resetPaymentState() },
                                onLaunchCheckoutAgain = { url ->
                                    val pid = (paymentState as? UroPayPaymentUiState.OpeningCheckout)?.paymentId
                                    com.example.ui.payment.UroPayCheckoutLauncher.launch(
                                        context = context,
                                        openUrl = url,
                                        paymentId = pid,
                                        force = true,
                                        onError = { errMsg ->
                                            viewModel.showUserMessage(errMsg)
                                        }
                                    )
                                },
                                onVerifyAgain = { paymentId -> viewModel.verifyUroPayPayment(paymentId) }
                            )
                        }

                        // Low Balance Call Quick Recharge Popup
                        if (showRechargePopup) {
                            RechargePopup(
                                viewModel = viewModel,
                                onDismiss = { viewModel.closeRechargePopup() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StartupLoadingScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(
                color = NeonPink,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = "Starting Baatly...",
                color = TextMuted,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun StartupErrorScreen(errorMessage: String, onRetry: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = null,
                    tint = NeonPink,
                    modifier = Modifier.size(56.dp)
                )
                Text(
                    text = "Something went wrong",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = errorMessage,
                    color = TextMuted,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_retry_startup")
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Retry", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
