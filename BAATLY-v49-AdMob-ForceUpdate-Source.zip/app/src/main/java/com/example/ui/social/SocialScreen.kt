package com.example.ui.social

import com.example.ui.ads.BaatlyAds
import com.example.ui.ads.BaatlyNativeAdCard
import androidx.activity.compose.BackHandler

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.SocialPost
import com.example.data.model.SocialStory
import com.example.data.model.SocialProfile
import com.example.data.model.SocialHashtag
import com.example.ui.media.BaatlyVideoPlayer
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.components.rememberResolvedProfileImageUrl
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val BrandPlum = Color(0xFFF7F2FF)
private val SocialCream = Color(0xFF070817)
private val SocialSoftPink = Color(0xFF242044)

private data class SocialCommentTarget(val contentType: String, val contentId: String, val creatorName: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val authUserId by viewModel.sessionManager.userId.collectAsState()
    val searchHistoryPrefs = remember(context, authUserId) {
        context.getSharedPreferences("baatly_social_search_history_${authUserId ?: "signed_out"}", Context.MODE_PRIVATE)
    }
    var recentSearches by remember(searchHistoryPrefs) {
        mutableStateOf(searchHistoryPrefs.getStringSet("terms", mutableSetOf<String>())?.toList().orEmpty().take(8))
    }
    val savedPostPrefs = remember(context, authUserId) {
        context.getSharedPreferences("baatly_saved_social_posts_${authUserId ?: "signed_out"}", Context.MODE_PRIVATE)
    }
    var savedPostIds by remember(savedPostPrefs) {
        mutableStateOf(savedPostPrefs.getStringSet("post_ids", mutableSetOf<String>())?.toSet().orEmpty())
    }
    fun toggleSavedPost(postId: String) {
        val updated = if (postId in savedPostIds) savedPostIds - postId else savedPostIds + postId
        savedPostIds = updated
        savedPostPrefs.edit().putStringSet("post_ids", updated.toMutableSet()).apply()
        viewModel.showUserMessage(if (postId in updated) "Post saved on this device" else "Post removed from saved items")
    }
    fun sharePost(caption: String, mediaUrl: String?) {
        val shareText = listOf(caption.trim(), mediaUrl?.takeIf { it.startsWith("https://", true) || it.startsWith("http://", true) })
            .filterNotNull().filter { it.isNotBlank() }.joinToString("\n")
        if (shareText.isBlank()) {
            viewModel.showUserMessage("This post doesn't have a shareable link yet")
            return
        }
        runCatching {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            context.startActivity(Intent.createChooser(sendIntent, "Share BAATLY post"))
        }.onFailure { viewModel.showUserMessage("Unable to open the share menu") }
    }
    fun rememberSearchTerm(value: String) {
        val term = value.trim().take(80)
        if (term.isBlank()) return
        val updated = (listOf(term) + recentSearches.filterNot { it.equals(term, ignoreCase = true) }).take(8)
        recentSearches = updated
        searchHistoryPrefs.edit().putStringSet("terms", updated.toSet()).apply()
    }
    fun removeSearchTerm(value: String) {
        val updated = recentSearches.filterNot { it == value }
        recentSearches = updated
        searchHistoryPrefs.edit().putStringSet("terms", updated.toSet()).apply()
    }
    val posts by viewModel.socialPosts.collectAsState()
    val socialReels by viewModel.socialReels.collectAsState()
    val isSocialReelsLoading by viewModel.isSocialReelsLoading.collectAsState()
    val stories by viewModel.socialStories.collectAsState()
    val isLoading by viewModel.isSocialLoading.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val activeLikeOperations by viewModel.activeLikeOperations.collectAsState()
    val availablePartners by viewModel.availablePartners.collectAsState()
    var selectedTab by remember { mutableStateOf("Feeds") }
    var selectedFeedLabel by remember { mutableStateOf("For You") }
    var showFeedSettings by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val voiceSearchLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim().orEmpty()
        if (spoken.isNotBlank()) {
            searchQuery = spoken.take(80)
            rememberSearchTerm(spoken)
        }
    }
    var searchType by remember { mutableStateOf("People") }
    var contentSearchResults by remember { mutableStateOf(emptyList<SocialPost>()) }
    var contentSearchLoading by remember { mutableStateOf(false) }
    var contentSearchError by remember { mutableStateOf<String?>(null) }
    var trendingHashtags by remember { mutableStateOf(emptyList<SocialHashtag>()) }
    var hashtagSuggestions by remember { mutableStateOf(emptyList<SocialHashtag>()) }
    var hashtagDetails by remember { mutableStateOf<SocialHashtag?>(null) }
    val socialFeedMode by viewModel.socialFeedMode.collectAsState()
    LaunchedEffect(socialFeedMode) {
        if (socialFeedMode == "following") selectedFeedLabel = "Following"
        else if (selectedFeedLabel == "Following") selectedFeedLabel = "For You"
    }
    var selectedStory by remember { mutableStateOf<SocialStory?>(null) }
    var commentTarget by remember { mutableStateOf<SocialCommentTarget?>(null) }
    var loveNoteTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var createStoryDialog by remember { mutableStateOf(false) }
    var pendingMedia by remember { mutableStateOf<PendingSocialMedia?>(null) }
    var showCamera by remember { mutableStateOf(false) }
    var cameraPurpose by remember { mutableStateOf("post") }

    LaunchedEffect(Unit) {
        viewModel.refreshSocialFeed()
        viewModel.refreshSocialReels()
        viewModel.dataService.getTrendingSocialHashtags(12).onSuccess { trends ->
            trendingHashtags = if (trends.isNotEmpty()) trends else viewModel.dataService.suggestSocialHashtags("", 12).getOrDefault(emptyList())
        }
    }

    LaunchedEffect(showSearch, searchQuery, searchType) {
        if (!showSearch || searchType != "Hashtags") {
            hashtagSuggestions = emptyList()
            hashtagDetails = null
            return@LaunchedEffect
        }
        delay(250)
        val cleanQuery = searchQuery.trim().removePrefix("#").substringAfterLast('#')
        if (cleanQuery.isBlank()) {
            hashtagSuggestions = trendingHashtags.ifEmpty {
                viewModel.dataService.getTrendingSocialHashtags(12).getOrDefault(emptyList()).ifEmpty {
                    viewModel.dataService.suggestSocialHashtags("", 12).getOrDefault(emptyList())
                }.also { trendingHashtags = it }
            }
            hashtagDetails = null
        } else {
            hashtagSuggestions = viewModel.dataService.suggestSocialHashtags(cleanQuery, 10).getOrDefault(emptyList())
            hashtagDetails = viewModel.dataService.getSocialHashtagDetails(cleanQuery).getOrNull()
        }
    }

    fun prepareMediaForEditor(uri: Uri?, purpose: String, prefix: String) {
        if (uri == null) return
        scope.launch {
            try {
                val originalMime = context.contentResolver.getType(uri)?.lowercase()?.substringBefore(';').orEmpty()
                val file = withContext(Dispatchers.IO) { copySelectedMediaToCache(context, uri, prefix) }
                val finalMime = originalMime.ifBlank { mimeTypeForExtension(file.extension) }
                pendingMedia = PendingSocialMedia(Uri.fromFile(file), purpose, finalMime)
            } catch (error: Exception) {
                viewModel.showUserMessage("Could not open selected media: ${error.message ?: "Choose a supported photo or video and retry."}")
            }
        }
    }

    val storyPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "story", "baatly_story_source")
    }

    val storyVideoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "story", "baatly_story_source")
    }

    val postPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "post", "baatly_post_source")
    }

    val postVideoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "post", "baatly_post_source")
    }

    val reelPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        prepareMediaForEditor(uri, "reel", "baatly_reel_source")
    }

    val resolvedAvatar by rememberResolvedProfileImageUrl(currentUser?.avatarUrl, viewModel.dataService)
    BackHandler(enabled = selectedTab == "Reels") { selectedTab = "Feeds" }

    Column(Modifier.fillMaxSize().background(SocialCream)) {
        if (selectedTab != "Reels") SocialHeader(
            avatarUrl = resolvedAvatar,
            onProfile = { viewModel.openSocialProfile(null) },
            onSearch = { showSearch = true },
            onMessages = { viewModel.setScreen(Screen.CHAT_LIST) }
        )
        if (selectedTab == "Reels") {
            val reels = socialReels
            val reelPages = remember(reels) {
                buildList {
                    reels.forEachIndexed { index, reel ->
                        add(reel)
                        if ((index + 1) % 8 == 0) add(null)
                    }
                }
            }
            Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black)) {
                if (isSocialReelsLoading && reels.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = VibrantPink) }
                } else if (reels.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(horizontal = 26.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(54.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("Reels are on their way", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(5.dp))
                        Text("Vertical videos will autoplay here as you swipe.", color = Color.White.copy(alpha = 0.78f), fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { reelPicker.launch("video/*") }, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(24.dp)) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Create Reel")
                        }
                    }
                } else {
                    val pagerState = rememberPagerState(pageCount = { reelPages.size })
                    VerticalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize().testTag("social_reels_vertical_pager"),
                        beyondViewportPageCount = 1,
                        pageSpacing = 0.dp
                    ) { page ->
                        val post = reelPages[page]
                        if (post == null) {
                            Box(Modifier.fillMaxSize().background(Color(0xFF101018)).padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                                BaatlyNativeAdCard(BaatlyAds.REELS)
                            }
                        } else {
                            ReelPage(
                                post = post,
                                viewModel = viewModel,
                                shouldPlay = pagerState.currentPage == page,
                                isLiking = activeLikeOperations.contains(post.id),
                                isSaved = post.id in savedPostIds,
                                onLike = { viewModel.toggleSocialLike(post) },
                                onFollow = { viewModel.toggleSocialFollow(post.userId) },
                                onComment = { commentTarget = SocialCommentTarget("post", post.id, post.creatorName) },
                                onShare = { resolvedUrl -> sharePost(post.caption, resolvedUrl) },
                                onSave = { toggleSavedPost(post.id) },
                                onProfile = { viewModel.openSocialProfile(post.userId) },
                                onNotInterested = { viewModel.markSocialPostNotInterested(post) },
                                onCall = {
                                    val partner = availablePartners.firstOrNull { it.id == post.userId || it.userId == post.userId }
                                    if (post.isHost && post.canVoiceCall && partner != null) viewModel.requestCall(partner)
                                    else viewModel.showUserMessage("This host isn't available for a call right now")
                                },
                                onLoveNote = { loveNoteTarget = "post" to post.id }
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding()
                        .padding(horizontal = 10.dp, vertical = 8.dp).zIndex(2f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(42.dp).clickable { selectedTab = "Feeds" },
                        shape = CircleShape, color = Color.Black.copy(alpha = 0.45f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.55f))
                    ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back to Feeds", tint = Color.White) } }
                    Surface(
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(24.dp),
                        color = Color.Black.copy(alpha = 0.44f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF9B4CBE).copy(alpha = 0.8f))
                    ) {
                        Row(Modifier.padding(2.dp)) {
                            listOf("Reels", "Feeds").forEach { tab ->
                                Surface(
                                    modifier = Modifier.weight(1f).clickable { selectedTab = tab },
                                    color = if (selectedTab == tab) VibrantPink else Color.Transparent,
                                    shape = RoundedCornerShape(22.dp)
                                ) {
                                    Box(Modifier.padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                                        Text(tab, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                    Surface(
                        modifier = Modifier.size(42.dp).clickable { showSearch = true }, shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.45f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.55f))
                    ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Search, contentDescription = "Search Reels", tint = Color.White) } }
                }
                Surface(
                    modifier = Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 58.dp).zIndex(3f)
                        .clickable { selectedTab = "Feeds" },
                    shape = RoundedCornerShape(22.dp),
                    color = Color.Black.copy(alpha = 0.56f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFA5D5))
                ) {
                    Text("Back to Feeds", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp))
                }
                if (selectedTab == "Reels" && reels.isNotEmpty()) {
                    Surface(
                        shape = CircleShape,
                        color = VibrantPink,
                        shadowElevation = 5.dp,
                        modifier = Modifier.align(Alignment.TopEnd).padding(top = 56.dp, end = 16.dp).size(38.dp).zIndex(3f)
                            .clickable { reelPicker.launch("video/*") }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Add, contentDescription = "Create Reel", tint = Color.White, modifier = Modifier.size(23.dp))
                        }
                    }
                }
            }
        } else {
            FeedsReelsTabs(selected = selectedTab, onSelect = { selectedTab = it })
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("For You", "Following", "Personalized").forEach { label ->
                        val selected = selectedFeedLabel == label
                        Surface(
                            modifier = Modifier.weight(1f).height(42.dp).clickable {
                                selectedFeedLabel = label
                                viewModel.setSocialFeedMode(if (label == "Following") "following" else "for_you")
                            },
                            shape = RoundedCornerShape(18.dp),
                            color = if (selected) VibrantPink else DarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) VibrantPink else DarkCardBorder)
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.background(
                                if (selected) Brush.horizontalGradient(listOf(Color(0xFFFF2D89), Color(0xFFEA00A8))) else Brush.horizontalGradient(listOf(DarkSurface, DarkSurface))
                            )) {
                                Text(label, color = if (selected) Color.White else BrandPlum, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, fontSize = 10.sp, maxLines = 1)
                            }
                        }
                    }
                }
                Box {
                    IconButton(onClick = { showFeedSettings = true }, modifier = Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(DarkSurface).border(1.dp, DarkCardBorder, RoundedCornerShape(15.dp))) {
                        Icon(Icons.Filled.Tune, contentDescription = "Feed settings", tint = BrandPlum, modifier = Modifier.size(21.dp))
                    }
                    DropdownMenu(expanded = showFeedSettings, onDismissRequest = { showFeedSettings = false }) {
                        DropdownMenuItem(text = { Text("Refresh recommendations") }, onClick = { showFeedSettings = false; selectedFeedLabel = "Personalized"; viewModel.setSocialFeedMode("for_you"); viewModel.refreshSocialFeed() })
                        DropdownMenuItem(text = { Text("Show followed creators") }, onClick = { showFeedSettings = false; selectedFeedLabel = "Following"; viewModel.setSocialFeedMode("following") })
                    }
                }
            }
            PullToRefreshBox(
                isRefreshing = isLoading,
                onRefresh = { viewModel.refreshSocialFeed() },
                modifier = Modifier.weight(1f)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item(key = "social_stories") {
                        SocialStoriesRow(
                            stories = stories,
                            currentUserId = authUserId.orEmpty(),
                            currentUserAvatarUrl = resolvedAvatar,
                            viewModel = viewModel,
                            onAddStory = { createStoryDialog = true },
                            onStoryClick = { selectedStory = it }
                        )
                    }
                    item(key = "trending_hashtags") {
                        TrendingHashtagsRow(tags = trendingHashtags, onTagClick = { tag ->
                            searchType = "Hashtags"
                            searchQuery = "#${tag.tag}"
                            showSearch = true
                        })
                    }
                    item(key = "social_post_create") {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SocialCreateActionCard("Camera", "Take a photo", Icons.Filled.CameraAlt, listOf(Color(0xFF8B21D8), Color(0xFF47207A)), Modifier.weight(1f)) {
                                cameraPurpose = "post"; showCamera = true
                            }
                            SocialCreateActionCard("Video", "Record a video", Icons.Filled.PlayArrow, listOf(Color(0xFFFF3F85), Color(0xFF8B2AE8)), Modifier.weight(1f)) {
                                postVideoPicker.launch("video/*")
                            }
                            SocialCreateActionCard("Create post", "Share your thoughts", Icons.Filled.Add, listOf(Color(0xFFFF7A58), Color(0xFF7625C8)), Modifier.weight(1f)) {
                                postPicker.launch("image/*")
                            }
                        }
                    }
                    if (isLoading && posts.isEmpty()) {
                        item(key = "social_loading") {
                            Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = VibrantPink)
                            }
                        }
                    } else if (posts.isEmpty()) {
                        item(key = "social_empty") {
                            Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(48.dp))
                                    Text("Your feed starts here", color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Text("Share a photo or video with your BAATLY community.", color = TextSecondary, fontSize = 13.sp)
                                }
                            }
                        }
                    } else {
                        items(posts, key = { it.id }) { post ->
                            SocialFeedPostCard(
                                post = post,
                                viewModel = viewModel,
                                isLiking = activeLikeOperations.contains(post.id),
                                isSaved = post.id in savedPostIds,
                                onLike = { viewModel.toggleSocialLike(post) },
                                onFollow = { viewModel.toggleSocialFollow(post.userId) },
                                onShare = { resolvedUrl -> sharePost(post.caption, resolvedUrl) },
                                onSave = { toggleSavedPost(post.id) },
                                onProfile = { viewModel.openSocialProfile(post.userId) },
                                onComment = { commentTarget = SocialCommentTarget("post", post.id, post.creatorName) },
                                onCall = {
                                    val partner = availablePartners.firstOrNull { it.id == post.userId || it.userId == post.userId }
                                    if (post.isHost && post.canVoiceCall && partner != null) viewModel.requestCall(partner)
                                    else viewModel.showUserMessage("This host isn't available for a call right now")
                                },
                                onLoveNote = { loveNoteTarget = "post" to post.id }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSearch) {
        Dialog(
            onDismissRequest = { showSearch = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFFF8F6FB),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { showSearch = false }) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Back to social media", tint = Color(0xFF171331))
                        }
                        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Text("Search ", color = Color(0xFF171331), fontWeight = FontWeight.Black, fontSize = 22.sp)
                            Text("BAATLY", color = VibrantPink, fontWeight = FontWeight.Black, fontSize = 22.sp)
                        }
                    }
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { rememberSearchTerm(searchQuery) }),
                        placeholder = { Text(when (searchType) { "People" -> "Search people or hosts"; "Hashtags" -> "Search #hashtags"; "Reels" -> "Search Reels"; else -> "Search posts" }) },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Color(0xFF171331)) },
                        trailingIcon = {
                            IconButton(onClick = {
                                val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "BAATLY par kya search karna hai?")
                                }
                                runCatching { voiceSearchLauncher.launch(speechIntent) }
                                    .onFailure { viewModel.showUserMessage("Voice search is not available on this device") }
                            }) {
                                Icon(Icons.Filled.Mic, contentDescription = "Voice search", tint = Color(0xFF171331))
                            }
                        },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VibrantPink,
                            unfocusedBorderColor = Color(0xFFE8E1EF),
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = Color(0xFF171331),
                            unfocusedTextColor = Color(0xFF171331),
                            focusedPlaceholderColor = Color(0xFF958BA8),
                            unfocusedPlaceholderColor = Color(0xFF958BA8)
                        )
                    )
                    androidx.compose.foundation.lazy.LazyRow(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        items(listOf("People", "Posts", "Reels", "Hashtags")) { type ->
                            FilterChip(
                                selected = searchType == type,
                                onClick = { searchType = type },
                                label = { Text(type) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = VibrantPink, selectedLabelColor = Color.White)
                            )
                        }
                    }
                    if (searchType == "Hashtags") {
                        HashtagSuggestionsRow(
                            title = if (searchQuery.isBlank() && hashtagSuggestions.any { it.score > 0.0 }) "Trending hashtags" else if (searchQuery.isBlank()) "Explore hashtags" else "Suggestions",
                            tags = hashtagSuggestions,
                            onTagClick = { tag -> searchQuery = "#${tag.tag}" }
                        )
                        hashtagDetails?.takeIf { searchQuery.isNotBlank() }?.let { detail ->
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                                color = Color.White, shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE8E1EF))
                            ) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("#${detail.tag}", color = Color(0xFF171331), fontWeight = FontWeight.Black, fontSize = 20.sp)
                                    Text("${detail.postsCount} posts · ${detail.reelsCount} Reels · ${detail.recentPostsCount} new in 7 days", color = Color(0xFF6D6480), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    val results by viewModel.socialSearchResults.collectAsState()
                    val searching by viewModel.isSocialSearching.collectAsState()
                    val searchError by viewModel.socialSearchError.collectAsState()
                    LaunchedEffect(searchQuery, searchType) {
                        if (searchQuery.isBlank()) {
                            contentSearchResults = emptyList()
                            contentSearchError = null
                            contentSearchLoading = false
                            if (searchType == "People") viewModel.searchSocialHosts("")
                        } else if (searchType == "People") {
                            contentSearchResults = emptyList()
                            viewModel.searchSocialHosts(searchQuery)
                        } else {
                            contentSearchLoading = true
                            contentSearchError = null
                            contentSearchResults = emptyList()
                            val kind = when (searchType) { "Reels" -> "reels"; "Hashtags" -> "hashtags"; else -> "posts" }
                            viewModel.dataService.searchSocialContent(searchQuery, kind, limit = 40).onSuccess {
                                contentSearchResults = it
                                contentSearchLoading = false
                            }.onFailure {
                                contentSearchError = it.message ?: "Search failed"
                                contentSearchLoading = false
                            }
                        }
                    }
                    val isSearching = if (searchType == "People") searching else contentSearchLoading
                    val resultCount = if (searchType == "People") results.size else contentSearchResults.size
                    val visibleError = if (searchType == "People") searchError else contentSearchError
                    when {
                        isSearching -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = VibrantPink)
                        }
                        searchQuery.isBlank() -> LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                Surface(shape = RoundedCornerShape(22.dp), color = Color(0xFFFFEAF2), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF2D9E7))) {
                                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                            Text("Find people, posts, Reels and hashtags", color = Color(0xFF171331), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                            Text("Discover creators, trending content and topics you love.", color = Color(0xFF6D6480), fontSize = 11.sp)
                                        }
                                        Icon(Icons.Filled.Search, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(38.dp))
                                    }
                                }
                            }
                            if (recentSearches.isNotEmpty()) item {
                                Surface(shape = RoundedCornerShape(20.dp), color = Color.White, border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE9E1ED))) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.History, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(19.dp))
                                            Spacer(Modifier.width(7.dp))
                                            Text("Recent searches", color = Color(0xFF171331), fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                            TextButton(onClick = {
                                                recentSearches = emptyList()
                                                searchHistoryPrefs.edit().remove("terms").apply()
                                            }) { Text("Clear all", color = VibrantPink, fontSize = 11.sp) }
                                        }
                                        recentSearches.forEach { term ->
                                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { searchQuery = term }.padding(horizontal = 6.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Filled.History, contentDescription = null, tint = Color(0xFF9690A5), modifier = Modifier.size(17.dp))
                                                Spacer(Modifier.width(10.dp))
                                                Text(term, color = Color(0xFF241B3B), fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                IconButton(onClick = { removeSearchTerm(term) }, modifier = Modifier.size(30.dp)) {
                                                    Icon(Icons.Filled.Close, contentDescription = "Remove recent search", tint = Color(0xFF8B8299), modifier = Modifier.size(17.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (trendingHashtags.isNotEmpty()) item {
                                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Text("Trending on BAATLY", color = Color(0xFF171331), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        items(trendingHashtags) { tag ->
                                            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFF3EAF7), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE8DDF0)), modifier = Modifier.clickable { searchType = "Hashtags"; searchQuery = "#${tag.tag}" }) {
                                                Text("#${tag.tag}", color = Color(0xFF302448), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp))
                                            }
                                        }
                                    }
                                }
                            }
                            val creators = posts.distinctBy { it.userId }.take(10)
                            if (creators.isNotEmpty()) item {
                                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Text("Explore creators", color = Color(0xFF171331), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        items(creators, key = { it.userId }) { post ->
                                            Column(Modifier.width(112.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { showSearch = false; viewModel.openSocialProfile(post.userId) }.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                AsyncImage(model = post.creatorAvatarUrl, contentDescription = post.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.size(54.dp).clip(CircleShape).border(2.dp, VibrantPink, CircleShape))
                                                Text(post.creatorName, color = Color(0xFF171331), fontWeight = FontWeight.SemiBold, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                    }
                                }
                            }
                            if (trendingHashtags.isEmpty() && creators.isEmpty()) item {
                                Text("Search creators and hashtags as new public content is published.", color = Color(0xFF6D6480), fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                            }
                        }
                        !visibleError.isNullOrBlank() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            Text(visibleError.orEmpty(), color = Color(0xFF6D6480), modifier = Modifier.padding(24.dp))
                        }
                        resultCount == 0 -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            Text("No ${searchType.lowercase()} found", color = Color(0xFF6D6480))
                        }
                        searchType == "People" -> LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(results, key = { it.userId }) { profile ->
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).clickable {
                                    showSearch = false; viewModel.openSocialProfile(profile.userId)
                                }.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    val resultAvatar by rememberResolvedProfileImageUrl(profile.avatarUrl, viewModel.dataService)
                                    AsyncImage(model = resultAvatar, contentDescription = profile.displayName, contentScale = ContentScale.Crop, modifier = Modifier.size(50.dp).clip(CircleShape).background(Color(0xFFF8EEF4)))
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(profile.displayName.ifBlank { profile.username.ifBlank { "BAATLY member" } }, color = Color(0xFF171331), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(profile.username.takeIf { it.isNotBlank() }?.let { "@$it" } ?: if (profile.isHost) "Approved host" else "BAATLY member", color = Color(0xFF6D6480), fontSize = 12.sp)
                                    }
                                    Text("View profile", color = VibrantPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        else -> LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            items(contentSearchResults, key = { it.id }) { post ->
                                var resultMediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
                                var resultMediaRetryAttempted by remember(post.id) { mutableStateOf(false) }
                                LaunchedEffect(post.id, post.mediaPath, post.mediaUrl, post.mediaBucket) {
                                    resultMediaRetryAttempted = false
                                    val raw = post.mediaUrl?.takeIf { it.startsWith("https://", ignoreCase = true) || it.startsWith("http://", ignoreCase = true) }
                                        ?: post.mediaPath?.takeIf { it.isNotBlank() }
                                        ?: post.mediaUrl
                                    resultMediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id).takeIf { it.isNotBlank() }
                                }
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White).clickable {
                                    scope.launch {
                                        val media = resultMediaUrl ?: viewModel.dataService.resolveSocialMediaUrl(post.mediaUrl?.takeIf { it.startsWith("https://", true) || it.startsWith("http://", true) } ?: post.mediaPath ?: post.mediaUrl, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id)
                                        if (media.isNotBlank()) { showSearch = false; viewModel.openFullScreenMedia(media, post.mediaType); viewModel.dataService.recordSocialPostView(post.id) }
                                        else viewModel.showUserMessage("This media is temporarily unavailable. Try again.")
                                    }
                                }.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Box(Modifier.size(78.dp, 96.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFECE4E9))) {
                                        if (!resultMediaUrl.isNullOrBlank()) {
                                            if (post.mediaType.equals("video", true)) SocialVideoThumbnail(resultMediaUrl!!, Modifier.fillMaxSize())
                                            else AsyncImage(
                                                model = resultMediaUrl,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize(),
                                                onError = {
                                                    if (!resultMediaRetryAttempted) {
                                                        resultMediaRetryAttempted = true
                                                        scope.launch {
                                                            val key = post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
                                                            val refreshed = viewModel.dataService.resolveSocialMediaUrl(key, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id, forceRefresh = true)
                                                            if (refreshed.isNotBlank()) resultMediaUrl = refreshed
                                                        }
                                                    }
                                                }
                                            )
                                        }
                                    }
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(post.creatorName, color = Color(0xFF171331), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(post.caption.ifBlank { if (post.mediaType.equals("video", true)) "Reel" else "Photo post" }, color = Color(0xFF6D6480), maxLines = 3, fontSize = 12.sp)
                                        if (post.caption.contains('#')) Text(post.caption.split(' ').filter { it.startsWith('#') }.take(3).joinToString(" "), color = VibrantPink, fontSize = 11.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCamera) {
        BaatlyCameraScreen(
            onDismiss = { showCamera = false },
            onCaptured = { uri, chosenFilter ->
                showCamera = false
                pendingMedia = PendingSocialMedia(uri, cameraPurpose, "image/jpeg", chosenFilter)
            }
        )
    }

    pendingMedia?.let { media ->
        MediaEditorScreen(
            pending = media,
            dataService = viewModel.dataService,
            onDismiss = { pendingMedia = null },
            onPublish = { editedUri, caption ->
                pendingMedia = null
                when (media.purpose) {
                    "story" -> viewModel.createSocialStoryFromUri(context, editedUri, caption.ifBlank { "My Story" }) { }
                    "reel" -> viewModel.createSocialPostFromUri(context, editedUri, caption.ifBlank { "Reel on BAATLY" }) { }
                    else -> viewModel.createSocialPostFromUri(context, editedUri, caption) { }
                }
            }
        )
    }

    if (createStoryDialog) {
        Dialog(
            onDismissRequest = { createStoryDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.54f)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp),
                    shape = RoundedCornerShape(30.dp),
                    color = Color(0xFFFFF8FD),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF0D6EC)),
                    shadowElevation = 18.dp
                ) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            IconButton(onClick = { createStoryDialog = false }, modifier = Modifier.size(34.dp).clip(CircleShape).background(Color(0xFFF5E7F1))) {
                                Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color(0xFF251A3E))
                            }
                        }
                        Box(Modifier.size(92.dp).clip(RoundedCornerShape(25.dp)).background(Brush.linearGradient(listOf(VibrantPink, PrimaryLavender))), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
                        }
                        Text("Create Story", color = Color(0xFF24153E), fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("Choose a photo or short video for your 24-hour story.", color = Color(0xFF71657E), fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            StoryChoiceCard("Photo", "Gallery", Icons.Filled.ImageIcon, listOf(Color(0xFFFF0AA8), Color(0xFFE63272)), Modifier.weight(1f)) {
                                createStoryDialog = false; storyPicker.launch("image/*")
                            }
                            StoryChoiceCard("Video", "Gallery", Icons.Filled.VideoLibrary, listOf(Color(0xFF8B36FF), Color(0xFF5125C9)), Modifier.weight(1f)) {
                                createStoryDialog = false; storyVideoPicker.launch("video/*")
                            }
                            StoryChoiceCard("Camera", "Capture now", Icons.Filled.CameraAlt, listOf(Color(0xFF121A3B), Color(0xFF252B54)), Modifier.weight(1f)) {
                                createStoryDialog = false; cameraPurpose = "story"; showCamera = true
                            }
                        }
                        Text("OR", color = Color(0xFF978AA7), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { createStoryDialog = false; viewModel.setScreen(Screen.SUPER_AI) },
                            shape = RoundedCornerShape(18.dp),
                            color = Color(0xFFFCE5F3),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF4C8E2))
                        ) {
                            Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Favorite, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Create with AI", color = Color(0xFF4A2464), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.width(8.dp))
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = VibrantPink)
                            }
                        }
                        Text("Open BAATLY Super AI to create an image, then add it to your Story.", color = Color(0xFF8C8198), fontSize = 10.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        }
    }

    selectedStory?.let { story ->
        val storySequence = remember(stories, story.userId) {
            stories.filter { it.userId == story.userId }.sortedBy { it.createdAt }.ifEmpty { listOf(story) }
        }
        StoryViewerDialog(
            stories = storySequence,
            initialStoryId = story.id,
            viewModel = viewModel,
            onDismiss = { selectedStory = null },
            onLike = { item -> viewModel.toggleSocialStoryLike(item) },
            onComment = { item -> commentTarget = SocialCommentTarget("story", item.id, item.creatorName) },
            onFollow = { item -> viewModel.toggleSocialFollow(item.userId) },
            onCall = { item ->
                val partner = availablePartners.firstOrNull { it.id == item.userId || it.userId == item.userId }
                if (item.isHost && item.canVoiceCall && partner != null) viewModel.requestCall(partner)
                else viewModel.showUserMessage("This host isn't available for a call right now")
            },
            onLoveNote = { item -> loveNoteTarget = "story" to item.id }
        )
    }

    commentTarget?.let { target ->
        SocialCommentsSheet(
            viewModel = viewModel,
            contentType = target.contentType,
            contentId = target.contentId,
            creatorName = target.creatorName,
            onDismiss = { commentTarget = null }
        )
    }

    loveNoteTarget?.let { target ->
        var message by remember(target) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { loveNoteTarget = null },
            containerColor = DarkSurface,
            title = { Text("Send Love Note 💌", color = BrandPlum, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Write a note to this approved host.", color = TextSecondary, fontSize = 13.sp)
                    OutlinedTextField(value = message, onValueChange = { message = it }, placeholder = { Text("Write your message…") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = message.isNotBlank(), onClick = {
                    viewModel.sendSocialLoveNote(target.first, target.second, message.trim()) { loveNoteTarget = null }
                }) { Text("Send", color = VibrantPink) }
            },
            dismissButton = { TextButton(onClick = { loveNoteTarget = null }) { Text("Cancel", color = TextSecondary) } }
        )
    }
}

@Composable
private fun SocialCreateActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    BoxWithConstraints(modifier = modifier) {
        val compact = maxWidth < 122.dp
        Surface(
            modifier = Modifier.fillMaxWidth().height(if (compact) 104.dp else 96.dp).clickable(onClick = onClick),
            shape = RoundedCornerShape(20.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, colors.first().copy(alpha = 0.85f))
        ) {
            if (compact) {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(colors)).padding(7.dp)) {
                    Icon(Icons.Filled.ArrowForwardIos, contentDescription = null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.align(Alignment.TopEnd).size(10.dp))
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(Modifier.size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.20f)), contentAlignment = Alignment.Center) {
                            Icon(icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(23.dp))
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                        Text(subtitle, color = Color.White.copy(alpha = 0.84f), fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                    }
                }
            } else {
                Row(Modifier.fillMaxSize().background(Brush.linearGradient(colors)).padding(horizontal = 9.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.19f)), contentAlignment = Alignment.Center) {
                        Icon(icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(27.dp))
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(subtitle, color = Color.White.copy(alpha = 0.84f), fontSize = 9.sp, maxLines = 2, lineHeight = 11.sp)
                    }
                    Icon(Icons.Filled.ArrowForwardIos, contentDescription = null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(12.dp))
                }
            }
        }
    }
}

@Composable
private fun StoryChoiceCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(modifier = modifier.height(112.dp).clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), color = colors.first()) {
        Column(Modifier.fillMaxSize().background(Brush.linearGradient(colors)).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(7.dp))
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = Color.White.copy(alpha = 0.82f), fontSize = 9.sp)
        }
    }
}

@Composable
private fun TrendingHashtagsRow(tags: List<SocialHashtag>, onTagClick: (SocialHashtag) -> Unit) {
    val hasTrends = tags.any { it.score > 0.0 }
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF17142D),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF53306C))
    ) {
        Column(Modifier.padding(horizontal = 11.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Whatshot, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(7.dp))
                Text(if (hasTrends) "Trending hashtags" else "Explore hashtags", color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text(if (hasTrends) "Recent posts & engagement" else "Discover topics", color = TextSecondary, fontSize = 9.sp, maxLines = 1)
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(18.dp))
            }
            if (tags.isEmpty()) {
                Text("Hashtag trends will appear when the community posts with tags.", color = TextSecondary, fontSize = 11.sp)
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(end = 2.dp)) {
                    items(tags, key = { it.tag }) { item ->
                        val hot = item.score > 0.0 && item == tags.firstOrNull { it.score > 0.0 }
                        Surface(
                            modifier = Modifier.clickable { onTagClick(item) },
                            shape = RoundedCornerShape(22.dp),
                            color = if (hot) VibrantPink else Color(0xFF111027),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (hot) Color(0xFFFF6DC7) else Color(0xFF584078))
                        ) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (hot) { Icon(Icons.Filled.Whatshot, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)) }
                                Text("#${item.tag}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HashtagSuggestionsRow(title: String, tags: List<SocialHashtag>, onTagClick: (SocialHashtag) -> Unit) {
    if (tags.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = Color(0xFF171331), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(horizontal = 2.dp)) {
            items(tags, key = { it.tag }) { item ->
                FilterChip(
                    selected = false,
                    onClick = { onTagClick(item) },
                    label = { Text("#${item.tag} · ${item.postsCount}", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(containerColor = Color(0xFFF3EAF7), labelColor = Color(0xFF302448))
                )
            }
        }
    }
}

@Composable
private fun SocialHeader(
    avatarUrl: String?,
    onProfile: () -> Unit,
    onSearch: () -> Unit,
    onMessages: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(SocialCream).statusBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            Modifier.size(54.dp).clip(CircleShape)
                .background(Brush.sweepGradient(listOf(VibrantPink, PrimaryLavender, Color(0xFFFFB703), VibrantPink)))
                .padding(3.dp).clip(CircleShape).background(SocialCream).padding(2.dp)
                .clickable(onClick = onProfile).testTag("btn_social_my_profile"),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(model = avatarUrl, contentDescription = "My profile", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape).background(SocialSoftPink))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
            Text("BAATLY", style = androidx.compose.ui.text.TextStyle(brush = Brush.horizontalGradient(listOf(Color(0xFFFF6AAE), Color(0xFFFF0AA8), Color(0xFFB35BFF))), fontWeight = FontWeight.Black, fontSize = 28.sp, letterSpacing = 0.2.sp))
            Text("U S E R  A P P", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = BrandPlum.copy(alpha = 0.86f), letterSpacing = 2.1.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onSearch, modifier = Modifier.size(42.dp).testTag("btn_social_search")) {
                Icon(Icons.Filled.Search, contentDescription = "Search", tint = BrandPlum, modifier = Modifier.size(26.dp))
            }
            IconButton(onClick = onMessages, modifier = Modifier.size(42.dp).testTag("btn_social_messages")) {
                Icon(Icons.Outlined.MailOutline, contentDescription = "Messages", tint = BrandPlum, modifier = Modifier.size(25.dp))
            }
        }
    }
}

@Composable
private fun FeedsReelsTabs(selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = DarkSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 4.dp)
    ) {
        Row(Modifier.padding(2.dp)) {
            listOf("Feeds", "Reels").forEach { tab ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (selected == tab) VibrantPink else Color.Transparent,
                    modifier = Modifier.weight(1f).clickable { onSelect(tab) }.testTag("tab_social_${tab.lowercase()}")
                ) {
                    Box(Modifier.background(if (selected == tab) Brush.horizontalGradient(listOf(VibrantPink, PrimaryLavender)) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))).padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                        Text(tab, color = if (selected == tab) Color.White else BrandPlum, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialStoriesRow(
    stories: List<SocialStory>,
    currentUserId: String,
    currentUserAvatarUrl: String?,
    viewModel: BaatlyViewModel,
    onAddStory: () -> Unit,
    onStoryClick: (SocialStory) -> Unit
) {
    val groups = remember(stories, currentUserId) {
        stories.filter { it.userId.isNotBlank() }
            .groupBy { it.userId }
            .mapValues { (_, group) -> group.sortedBy { it.createdAt } }
    }
    val ownStories = groups[currentUserId].orEmpty()
    val otherGroups = remember(groups, currentUserId) {
        groups.filterKeys { it != currentUserId }.values
            .sortedByDescending { group -> group.lastOrNull()?.createdAt.orEmpty() }
    }
    val ownAvatar by rememberResolvedProfileImageUrl(ownStories.firstOrNull()?.creatorAvatarUrl ?: currentUserAvatarUrl, viewModel.dataService)

    LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(13.dp), modifier = Modifier.padding(top = 8.dp)) {
        item(key = "my_story") {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(82.dp)) {
                Box(Modifier.size(78.dp)) {
                    val ownRing = if (ownStories.isEmpty()) {
                        Modifier.border(2.dp, DarkCardBorder, CircleShape)
                    } else {
                        Modifier.border(3.dp, Brush.sweepGradient(listOf(VibrantPink, Color(0xFFFFB703), VibrantPink)), CircleShape)
                    }
                    Box(
                        Modifier.fillMaxSize().clip(CircleShape).then(ownRing)
                            .padding(if (ownStories.isEmpty()) 0.dp else 4.dp)
                            .clip(CircleShape).background(DarkSurface)
                            .clickable { if (ownStories.isEmpty()) onAddStory() else onStoryClick(ownStories.first()) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (ownStories.isEmpty()) {
                            Icon(Icons.Filled.Add, contentDescription = "Add story", tint = BrandPlum, modifier = Modifier.size(30.dp))
                        } else {
                            AsyncImage(model = ownAvatar, contentDescription = "Your story", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape))
                        }
                    }
                    if (ownStories.isNotEmpty()) {
                        Surface(
                            modifier = Modifier.align(Alignment.BottomEnd).size(25.dp).clickable(onClick = onAddStory),
                            shape = CircleShape, color = VibrantPink, border = androidx.compose.foundation.BorderStroke(2.dp, SocialCream)
                        ) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Add, contentDescription = "Add to your story", tint = Color.White, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text("Your story", color = BrandPlum, fontSize = 11.sp, maxLines = 1)
            }
        }
        items(otherGroups, key = { it.firstOrNull()?.userId ?: it.firstOrNull()?.id ?: "story_group_${it.hashCode()}" }) { group ->
            val story = group.first()
            val groupAvatar by rememberResolvedProfileImageUrl(story.creatorAvatarUrl, viewModel.dataService)
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(82.dp).clickable { onStoryClick(story) }) {
                Box(Modifier.size(78.dp).clip(CircleShape).border(3.dp, Brush.sweepGradient(listOf(VibrantPink, Color(0xFFFFB703), VibrantPink)), CircleShape).padding(4.dp)) {
                    AsyncImage(model = groupAvatar, contentDescription = story.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape).background(SocialSoftPink))
                }
                Spacer(Modifier.height(5.dp))
                Text(story.creatorName.ifBlank { "Member" }, color = BrandPlum, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SocialFeedPostCard(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    isLiking: Boolean,
    isSaved: Boolean,
    onLike: () -> Unit,
    onFollow: () -> Unit,
    onShare: (String?) -> Unit,
    onSave: () -> Unit,
    onProfile: () -> Unit,
    onComment: () -> Unit,
    onCall: () -> Unit,
    onLoveNote: () -> Unit
) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    var imageFallbackAttempted by remember(post.id) { mutableStateOf(false) }
    var showMoreActions by remember(post.id) { mutableStateOf(false) }
    val mediaScope = rememberCoroutineScope()
    val resolvedAvatar by rememberResolvedProfileImageUrl(post.creatorAvatarUrl, viewModel.dataService)
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket) {
        imageFallbackAttempted = false
        val raw = post.mediaUrl?.takeIf { it.startsWith("https://", ignoreCase = true) || it.startsWith("http://", ignoreCase = true) }
            ?: post.mediaPath?.takeIf { it.isNotBlank() }
            ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id).takeIf { it.isNotBlank() }
    }
    fun refreshCanonicalPostMedia() {
        if (imageFallbackAttempted) return
        imageFallbackAttempted = true
        mediaScope.launch {
            val key = post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
            val refreshed = viewModel.dataService.resolveSocialMediaUrl(key, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id, forceRefresh = true)
            if (refreshed.isNotBlank()) mediaUrl = refreshed
        }
    }
    LaunchedEffect(post.id) {
        viewModel.dataService.recordSocialPostView(post.id)
        viewModel.recordSocialRecommendationEvent(post.id, "impression")
    }
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF17142D)),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
    ) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onProfile).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AsyncImage(model = resolvedAvatar, contentDescription = post.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.size(44.dp).clip(CircleShape).background(SocialSoftPink))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(post.creatorName.ifBlank { "BAATLY member" }, color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (post.isHost) Text("✓", color = VibrantPink, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                    Text(if (post.isHost) "Approved host" else "BAATLY community", color = TextSecondary, fontSize = 11.sp)
                }
                Surface(
                    modifier = Modifier.clickable(onClick = onFollow),
                    color = Color.Transparent,
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VibrantPink)
                ) {
                    Text(if (post.isFollowing) "Following" else "Follow", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 13.dp, vertical = 6.dp))
                }
                Box {
                    IconButton(onClick = { showMoreActions = true }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.MoreHoriz, contentDescription = "More post actions", tint = BrandPlum)
                    }
                    DropdownMenu(expanded = showMoreActions, onDismissRequest = { showMoreActions = false }) {
                        DropdownMenuItem(text = { Text("Share post") }, onClick = { showMoreActions = false; onShare(mediaUrl) })
                        DropdownMenuItem(text = { Text(if (isSaved) "Remove from saved" else "Save post") }, onClick = { showMoreActions = false; onSave() })
                        if (post.isHost) {
                            DropdownMenuItem(text = { Text("Call Now") }, onClick = { showMoreActions = false; onCall() })
                            DropdownMenuItem(text = { Text("Send Love Note") }, onClick = { showMoreActions = false; onLoveNote() })
                        }
                    }
                }
            }
            if (post.caption.isNotBlank()) Text(post.caption, color = BrandPlum, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 15.dp, vertical = 4.dp))
            Box(Modifier.fillMaxWidth().height(365.dp).background(DarkSurfaceVariant).clickable(enabled = !mediaUrl.isNullOrBlank()) { if (!mediaUrl.isNullOrBlank()) viewModel.openFullScreenMedia(mediaUrl!!, post.mediaType) }) {
                if (post.mediaType.equals("video", ignoreCase = true)) {
                    if (!mediaUrl.isNullOrBlank()) {
                        // Show a real poster frame in the feed immediately; the video opens on tap.
                        SocialVideoThumbnail(url = mediaUrl!!, modifier = Modifier.fillMaxSize())
                    } else {
                        Box(Modifier.fillMaxSize().background(Color(0xFF24152F)), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    }
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play video", tint = Color.White, modifier = Modifier.align(Alignment.Center).size(52.dp).background(Color.Black.copy(alpha = 0.35f), CircleShape).padding(12.dp))
                } else {
                    AsyncImage(
                        model = mediaUrl,
                        contentDescription = post.caption,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        onError = { refreshCanonicalPostMedia() }
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                ActionItem(icon = if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, label = "${post.likesCount}", tint = if (post.isLiked) VibrantPink else BrandPlum, onClick = onLike, isLoading = isLiking)
                ActionItem(icon = Icons.Filled.ChatBubbleOutline, label = "Comment", tint = BrandPlum, onClick = onComment)
                ActionItem(icon = Icons.Filled.Send, label = "Share", tint = BrandPlum, onClick = { onShare(mediaUrl) })
                ActionItem(icon = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder, label = if (isSaved) "Saved" else "Save", tint = if (isSaved) VibrantPink else BrandPlum, onClick = onSave)
            }
        }
    }
}

@Composable
private fun ReelPage(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    shouldPlay: Boolean,
    isLiking: Boolean,
    isSaved: Boolean,
    onLike: () -> Unit,
    onFollow: () -> Unit,
    onComment: () -> Unit,
    onShare: (String?) -> Unit,
    onSave: () -> Unit,
    onProfile: () -> Unit,
    onNotInterested: () -> Unit,
    onCall: () -> Unit,
    onLoveNote: () -> Unit
) {
    var showMoreActions by remember(post.id) { mutableStateOf(false) }
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    val resolvedAvatar by rememberResolvedProfileImageUrl(post.creatorAvatarUrl, viewModel.dataService)
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket) {
        val raw = post.mediaUrl?.takeIf { it.startsWith("https://", ignoreCase = true) || it.startsWith("http://", ignoreCase = true) }
            ?: post.mediaPath?.takeIf { it.isNotBlank() }
            ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id).takeIf { it.isNotBlank() }
    }
    LaunchedEffect(post.id, shouldPlay, mediaUrl) {
        if (shouldPlay && !mediaUrl.isNullOrBlank()) {
            val startedAt = System.currentTimeMillis()
            viewModel.recordSocialRecommendationEvent(post.id, "impression")
            try {
                awaitCancellation()
            } finally {
                viewModel.recordSocialReelWatch(post.id, System.currentTimeMillis() - startedAt)
            }
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!mediaUrl.isNullOrBlank()) BaatlyVideoPlayer(mediaUrl!!, shouldPlay = shouldPlay, modifier = Modifier.fillMaxSize(), soundEnabled = true)
        else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }

        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.16f), Color.Transparent, Color.Black.copy(alpha = 0.62f)))))
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 14.dp, bottom = 46.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onLike)) {
                Icon(if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, contentDescription = "Like", tint = if (post.isLiked) VibrantPink else Color.White, modifier = Modifier.size(32.dp))
                Text(if (post.likesCount > 0) compactCount(post.likesCount) else "Like", color = Color.White, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onComment)) {
                Icon(Icons.Filled.ChatBubbleOutline, contentDescription = "Comment", tint = Color.White, modifier = Modifier.size(30.dp))
                Text("Comment", color = Color.White, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onShare(mediaUrl) }) {
                Icon(Icons.Filled.Send, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(28.dp))
                Text("Share", color = Color.White, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onSave)) {
                Icon(if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder, contentDescription = "Save", tint = if (isSaved) VibrantPink else Color.White, modifier = Modifier.size(28.dp))
                Text(if (isSaved) "Saved" else "Save", color = Color.White, fontSize = 11.sp)
            }
            Box {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { showMoreActions = true }) {
                    Icon(Icons.Filled.MoreHoriz, contentDescription = "More reel options", tint = Color.White, modifier = Modifier.size(30.dp))
                    Text("More", color = Color.White, fontSize = 11.sp)
                }
                DropdownMenu(expanded = showMoreActions, onDismissRequest = { showMoreActions = false }) {
                    DropdownMenuItem(
                        text = { Text("Not interested") },
                        onClick = { showMoreActions = false; onNotInterested() }
                    )
                }
            }
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = 16.dp, end = 88.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.clickable(onClick = onProfile)) {
                AsyncImage(model = resolvedAvatar, contentDescription = post.creatorName, contentScale = ContentScale.Crop, modifier = Modifier.size(42.dp).clip(CircleShape).border(2.dp, Color.White, CircleShape))
                Text(post.creatorName.ifBlank { "BAATLY member" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (post.isHost) Text("✓", color = Color.White, fontWeight = FontWeight.Black)
                Surface(
                    modifier = Modifier.clickable(onClick = onFollow),
                    color = Color.Transparent,
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VibrantPink)
                ) {
                    Text(if (post.isFollowing) "Following" else "Follow", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                }
            }
            if (post.caption.isNotBlank()) Text(post.caption, color = Color.White, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (post.isHost) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onCall, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Call Now", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = onLoveNote, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        Icon(Icons.Filled.MailOutline, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Love Note", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    isLoading: Boolean = false
) {
    Row(modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(enabled = !isLoading, onClick = onClick).padding(horizontal = 5.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        if (isLoading) CircularProgressIndicator(modifier = Modifier.size(16.dp), color = tint, strokeWidth = 2.dp)
        else Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(18.dp))
        Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun StoryViewerDialog(
    stories: List<SocialStory>,
    initialStoryId: String?,
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit,
    onLike: (SocialStory) -> Unit,
    onComment: (SocialStory) -> Unit,
    onFollow: (SocialStory) -> Unit,
    onCall: (SocialStory) -> Unit,
    onLoveNote: (SocialStory) -> Unit
) {
    val sequence = remember(stories) { stories.sortedBy { it.createdAt } }
    var currentIndex by remember(sequence, initialStoryId) {
        mutableIntStateOf(sequence.indexOfFirst { it.id == initialStoryId }.takeIf { it >= 0 } ?: 0)
    }
    val story = sequence.getOrNull(currentIndex) ?: return
    var mediaUrl by remember(story.id) { mutableStateOf<String?>(null) }
    var storyImageFallbackAttempted by remember(story.id) { mutableStateOf(false) }
    var progress by remember(story.id) { mutableFloatStateOf(0f) }
    var showViewers by remember(story.id) { mutableStateOf(false) }
    var storyViewers by remember(story.id) { mutableStateOf(emptyList<com.example.data.model.SocialStoryViewer>()) }
    val viewerScope = rememberCoroutineScope()
    val isVideoStory = remember(story.id, story.mediaPath, story.mediaUrl) {
        story.mediaPath.orEmpty().substringBefore('?').substringAfterLast('.', "").lowercase() in setOf("mp4", "mov", "m4v", "webm", "m3u8", "3gp")
            || story.mediaUrl.orEmpty().substringBefore('?').substringAfterLast('.', "").lowercase() in setOf("mp4", "mov", "m4v", "webm", "m3u8", "3gp")
    }

    LaunchedEffect(story.id, story.mediaPath, story.mediaUrl) {
        storyImageFallbackAttempted = false
        val raw = story.mediaUrl?.takeIf { it.startsWith("https://") || it.startsWith("http://") }
            ?: story.mediaPath?.takeIf { it.isNotBlank() } ?: story.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, isStory = true, explicitBucket = story.mediaBucket, contentType = "story", contentId = story.id).takeIf { it.isNotBlank() }
    }
    fun refreshCanonicalStoryMedia() {
        if (storyImageFallbackAttempted) return
        storyImageFallbackAttempted = true
        viewerScope.launch {
            val key = story.mediaPath?.takeIf { it.isNotBlank() } ?: story.mediaUrl
            val refreshed = viewModel.dataService.resolveSocialMediaUrl(key, isStory = true, explicitBucket = story.mediaBucket, contentType = "story", contentId = story.id, forceRefresh = true)
            if (refreshed.isNotBlank()) mediaUrl = refreshed
        }
    }
    LaunchedEffect(story.id, story.isOwner) {
        if (story.isOwner) {
            viewModel.dataService.getSocialStoryViewers(story.id).onSuccess { storyViewers = it }
        } else {
            viewModel.dataService.markSocialStoryViewed(story.id).onSuccess { views ->
                // Keep the viewer count in sync in memory for the active story.
                storyViewers = emptyList()
            }
        }
    }
    LaunchedEffect(story.id, currentIndex, sequence.size) {
        progress = 0f
        val durationMs = if (isVideoStory) 12_000L else 5_000L
        val step = 100L
        var elapsed = 0L
        while (elapsed < durationMs) {
            kotlinx.coroutines.delay(step)
            elapsed += step
            progress = (elapsed.toFloat() / durationMs).coerceIn(0f, 1f)
        }
        if (currentIndex < sequence.lastIndex) currentIndex++ else onDismiss()
    }

    fun moveNext() {
        if (currentIndex < sequence.lastIndex) currentIndex++ else onDismiss()
    }
    fun movePrevious() {
        if (currentIndex > 0) currentIndex--
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (isVideoStory && !mediaUrl.isNullOrBlank()) {
                BaatlyVideoPlayer(mediaUrl!!, shouldPlay = true, modifier = Modifier.fillMaxSize(), soundEnabled = true)
            } else {
                AsyncImage(
                    model = mediaUrl,
                    contentDescription = story.caption,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    onError = { refreshCanonicalStoryMedia() }
                )
            }
            // Transparent tap zones deliver Instagram-like previous/next navigation.
            Row(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxSize().clickable { movePrevious() })
                Box(Modifier.weight(1f).fillMaxSize().clickable { moveNext() })
            }
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent, Color.Black.copy(alpha = 0.34f)))))
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    sequence.forEachIndexed { index, _ ->
                        val segment = when {
                            index < currentIndex -> 1f
                            index == currentIndex -> progress
                            else -> 0f
                        }
                        androidx.compose.material3.LinearProgressIndicator(
                            progress = { segment },
                            modifier = Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(4.dp)),
                            color = Color.White,
                            trackColor = Color.White.copy(alpha = 0.35f)
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AsyncImage(model = story.creatorAvatarUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(38.dp).clip(CircleShape).border(1.dp, Color.White, CircleShape))
                        Column {
                            Text(story.creatorName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${currentIndex + 1} of ${sequence.size}", color = Color.White.copy(alpha = 0.75f), fontSize = 10.sp)
                        }
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Close story", tint = Color.White) }
                }
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (story.caption.isNotBlank()) Text(story.caption, color = Color.White, fontSize = 14.sp)
                if (story.isOwner) {
                    OutlinedButton(
                        onClick = {
                            viewerScope.launch {
                                viewModel.dataService.getSocialStoryViewers(story.id).onSuccess { storyViewers = it }
                                showViewers = true
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Filled.Visibility, contentDescription = "View story viewers", modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("Seen by ${storyViewers.size}")
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onLike(story) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.FavoriteBorder, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Like")
                        }
                        OutlinedButton(onClick = { onComment(story) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                            Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Comment")
                        }
                        OutlinedButton(onClick = { onFollow(story) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text("Follow") }
                    }
                }
                if (story.isHost && !story.isOwner) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onCall(story) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(22.dp)) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Call Now")
                        }
                        OutlinedButton(onClick = { onLoveNote(story) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)), shape = RoundedCornerShape(22.dp)) {
                            Icon(Icons.Filled.MailOutline, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Love Note")
                        }
                    }
                }
            }
            if (showViewers && story.isOwner) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = 430.dp)
                        .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)).background(DarkSurface)
                        .clickable { }.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Story viewers (${storyViewers.size})", color = BrandPlum, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        TextButton(onClick = { showViewers = false }) { Text("Close", color = VibrantPink) }
                    }
                    if (storyViewers.isEmpty()) {
                        Text("No viewers yet", color = TextSecondary, fontSize = 13.sp)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(storyViewers, key = { it.userId }) { viewer ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    AsyncImage(model = viewer.avatarUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(38.dp).clip(CircleShape).background(SocialSoftPink))
                                    Column(Modifier.weight(1f)) {
                                        Text(viewer.displayName.ifBlank { viewer.username.ifBlank { "BAATLY member" } }, color = BrandPlum, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        Text(viewer.username.takeIf { it.isNotBlank() }?.let { "@$it" } ?: "Viewed your Story", color = TextSecondary, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun compactCount(value: Int): String = when {
    value >= 1_000_000 -> "%.1fM".format(value / 1_000_000f)
    value >= 1_000 -> "%.1fK".format(value / 1_000f)
    else -> value.toString()
}


private fun mimeTypeForExtension(extensionRaw: String): String = when (extensionRaw.lowercase()) {
    "jpg", "jpeg" -> "image/jpeg"
    "png" -> "image/png"
    "webp" -> "image/webp"
    "mp4", "m4v" -> "video/mp4"
    "mov" -> "video/quicktime"
    "webm" -> "video/webm"
    "3gp" -> "video/3gpp"
    else -> "application/octet-stream"
}

private fun copySelectedMediaToCache(context: Context, uri: Uri, prefix: String): File {
    val resolver = context.contentResolver
    val mime = resolver.getType(uri)?.lowercase()?.substringBefore(';').orEmpty()
    val displayName = runCatching {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
        }.orEmpty()
    }.getOrDefault("")
    val candidateExtension = (displayName.ifBlank { uri.lastPathSegment.orEmpty() }).substringAfterLast('.', "").lowercase()
    val extension = when (mime) {
        "image/jpeg", "image/jpg" -> "jpg"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "video/mp4" -> "mp4"
        "video/quicktime" -> "mov"
        "video/webm" -> "webm"
        "video/3gpp" -> "3gp"
        else -> candidateExtension.takeIf { it in setOf("jpg", "jpeg", "png", "webp", "mp4", "m4v", "mov", "webm", "3gp") }
            ?: throw IllegalArgumentException("Supported formats are JPG, PNG, WebP, MP4, MOV, WebM and 3GP")
    }
    val file = File(context.cacheDir, "${prefix}_${System.currentTimeMillis()}.$extension")
    val input = resolver.openInputStream(uri) ?: throw IllegalStateException("Could not open selected media")
    input.use { source -> file.outputStream().use { output -> source.copyTo(output) } }
    if (file.length() <= 0L) {
        file.delete()
        throw IllegalStateException("Selected media is empty")
    }
    return file
}
