package com.example.ui.ads

import android.app.Activity
import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.TextView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.appopen.AppOpenAdPreloader
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize
import com.google.android.libraries.ads.mobile.sdk.banner.AdView
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import com.google.android.libraries.ads.mobile.sdk.common.PreloadConfiguration
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdPreloader
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdEventCallback
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAd
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoader
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoaderCallback
import com.google.android.libraries.ads.mobile.sdk.nativead.MediaView
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdRequest
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdView
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Centralized BAATLY AdMob IDs, SDK initialization, frequency rules and ad rendering. */
object BaatlyAds {
    const val APP_ID = "ca-app-pub-9363095174633972~9323820583"
    const val APP_OPEN = "ca-app-pub-9363095174633972/4795775416"
    const val HOST_LIST = "ca-app-pub-9363095174633972/3291122057"
    const val CHAT_LIST = "ca-app-pub-9363095174633972/2085851599"
    const val REELS = "ca-app-pub-9363095174633972/1485271702"
    const val PANDIT_AI = "ca-app-pub-9363095174633972/3351840962"
    const val SUPER_AI = "ca-app-pub-9363095174633972/9473387024"
    const val ENTERTAINMENT_BANNER = "ca-app-pub-9363095174633972/6354455002"
    const val ENTERTAINMENT_NATIVE = "ca-app-pub-9363095174633972/8980618347"
    const val POST_CALL = "ca-app-pub-9363095174633972/5375369073"

    private const val PREFS = "baatly_ad_frequency"
    private const val KEY_FIRST_LAUNCH_SEEN = "first_launch_seen"
    private const val KEY_LAST_BACKGROUND = "last_background_at"
    private const val KEY_LAST_APP_OPEN = "last_app_open_shown"
    private const val APP_OPEN_COOLDOWN_MS = 4L * 60L * 60L * 1000L
    private val initialized = AtomicBoolean(false)
    @Volatile private var sdkReady = false
    private val _readyState = MutableStateFlow(false)
    val readyState = _readyState.asStateFlow()

    fun nativeUnit(productionId: String): String = if (BuildConfig.DEBUG) "/21775744923/example/native" else productionId
    fun bannerUnit(): String = if (BuildConfig.DEBUG) "/21775744923/example/adaptive-banner" else ENTERTAINMENT_BANNER

    /** Call only after UMP has processed the user's consent information. */
    fun initialize(context: Context) {
        if (!initialized.compareAndSet(false, true)) return
        Thread {
            try {
                MobileAds.initialize(
                    context.applicationContext,
                    InitializationConfig.Builder(APP_ID).build()
                ) {
                    sdkReady = true
                    _readyState.value = true
                    startPreloading()
                }
            } catch (t: Throwable) {
                initialized.set(false)
                android.util.Log.e("BaatlyAds", "GMA Next-Gen initialization failed", t)
            }
        }.start()
    }

    private fun startPreloading() {
        try {
            val appOpenId = if (BuildConfig.DEBUG) "/21775744923/example/app-open" else APP_OPEN
            val appOpenRequest = AdRequest.Builder(appOpenId).build()
            AppOpenAdPreloader.start(appOpenId, PreloadConfiguration(appOpenRequest))

            val interstitialId = if (BuildConfig.DEBUG) "/21775744923/example/interstitial" else POST_CALL
            val interstitialRequest = AdRequest.Builder(interstitialId).build()
            InterstitialAdPreloader.start(interstitialId, PreloadConfiguration(interstitialRequest))
        } catch (t: Throwable) {
            android.util.Log.w("BaatlyAds", "Ad preloading could not start", t)
        }
    }

    fun recordBackground(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putLong(KEY_LAST_BACKGROUND, System.currentTimeMillis()).apply()
    }

    /** Suppresses the very first launch and enforces a four-hour app-open cooldown. */
    fun showAppOpenOnEligibleResume(activity: Activity, callInProgress: Boolean, updateRequired: Boolean) {
        if (!sdkReady || callInProgress || updateRequired) return
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!prefs.getBoolean(KEY_FIRST_LAUNCH_SEEN, false)) {
            prefs.edit().putBoolean(KEY_FIRST_LAUNCH_SEEN, true).putLong(KEY_LAST_BACKGROUND, now).apply()
            return
        }
        val lastBackground = prefs.getLong(KEY_LAST_BACKGROUND, 0L)
        val lastShown = prefs.getLong(KEY_LAST_APP_OPEN, 0L)
        if (lastBackground == 0L || now - lastBackground < APP_OPEN_COOLDOWN_MS || now - lastShown < APP_OPEN_COOLDOWN_MS) return
        val preloadId = if (BuildConfig.DEBUG) "/21775744923/example/app-open" else APP_OPEN
        val ad = try { AppOpenAdPreloader.pollAd(preloadId) } catch (_: Throwable) { null } ?: return
        prefs.edit().putLong(KEY_LAST_APP_OPEN, now).apply()
        try { ad.show(activity) } catch (t: Throwable) { android.util.Log.w("BaatlyAds", "App open ad failed to show", t) }
    }

    /** Show a preloaded interstitial only after a completed (not cancelled/failed) call. */
    fun isReady(): Boolean = sdkReady

    fun showPostCallInterstitial(activity: Activity) {
        if (!sdkReady || activity.isFinishing || activity.isDestroyed) return
        val preloadId = if (BuildConfig.DEBUG) "/21775744923/example/interstitial" else POST_CALL
        val ad = try { InterstitialAdPreloader.pollAd(preloadId) } catch (_: Throwable) { null } ?: return
        try {
            ad.adEventCallback = object : InterstitialAdEventCallback {
                override fun onAdDismissedFullScreenContent() { android.util.Log.d("BaatlyAds", "Post-call ad dismissed") }
                override fun onAdFailedToShowFullScreenContent(fullScreenContentError: com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError) {
                    android.util.Log.w("BaatlyAds", "Post-call ad failed: ${fullScreenContentError.message}")
                }
                override fun onAdImpression() { android.util.Log.d("BaatlyAds", "Post-call impression") }
            }
            ad.show(activity)
        } catch (t: Throwable) {
            android.util.Log.w("BaatlyAds", "Post-call interstitial could not be shown", t)
        }
    }
}

@Composable
fun BaatlyNativeAdCard(adUnitId: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val sdkReady by BaatlyAds.readyState.collectAsState()
    var loadedAd by remember(adUnitId) { mutableStateOf<NativeAd?>(null) }
    var failed by remember(adUnitId) { mutableStateOf(false) }

    DisposableEffect(adUnitId, sdkReady) {
        var isActive = true
        var ownedAd: NativeAd? = null
        if (sdkReady) {
            val request = NativeAdRequest.Builder(BaatlyAds.nativeUnit(adUnitId), listOf(NativeAd.NativeAdType.NATIVE)).build()
            NativeAdLoader.load(request, object : NativeAdLoaderCallback {
                override fun onNativeAdLoaded(nativeAd: NativeAd) {
                    Handler(Looper.getMainLooper()).post {
                        if (isActive) {
                            ownedAd = nativeAd
                            loadedAd?.takeIf { it !== nativeAd }?.destroy()
                            loadedAd = nativeAd
                            failed = false
                        } else {
                            nativeAd.destroy()
                        }
                    }
                }
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Handler(Looper.getMainLooper()).post { if (isActive) failed = true }
                }
            })
        }
        onDispose {
            isActive = false
            ownedAd?.destroy()
            if (loadedAd === ownedAd) loadedAd = null
        }
    }

    val ad = loadedAd
    if (ad != null && !failed) {
        AndroidView(
            modifier = modifier.fillMaxWidth(),
            factory = { ctx -> createNativeAdView(ctx, ad) },
            update = { view -> if (view.tag != ad) view.tag = ad }
        )
    }
}

private fun createNativeAdView(context: Context, ad: NativeAd): NativeAdView {
    val root = NativeAdView(context)
    root.setBackgroundColor(AndroidColor.rgb(24, 20, 43))
    root.setPadding(dp(context, 12), dp(context, 10), dp(context, 12), dp(context, 10))
    val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    val attribution = TextView(context).apply {
        text = "Ad"
        setTextColor(AndroidColor.rgb(255, 198, 80))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        typeface = Typeface.DEFAULT_BOLD
    }
    val iconAndHeadline = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val iconView = ImageView(context).apply {
        setImageDrawable(ad.icon?.drawable)
        visibility = if (ad.icon?.drawable != null) View.VISIBLE else View.GONE
        scaleType = ImageView.ScaleType.CENTER_CROP
        layoutParams = LinearLayout.LayoutParams(dp(context, 44), dp(context, 44)).apply { rightMargin = dp(context, 10) }
    }
    val headline = TextView(context).apply {
        text = ad.headline.orEmpty()
        setTextColor(AndroidColor.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        typeface = Typeface.DEFAULT_BOLD
        maxLines = 2
    }
    val body = TextView(context).apply {
        text = ad.body.orEmpty()
        setTextColor(AndroidColor.LTGRAY)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        maxLines = 3
    }
    val advertiser = TextView(context).apply {
        text = ad.advertiser.orEmpty()
        setTextColor(AndroidColor.GRAY)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
    }
    val mediaView = MediaView(context).apply {
        imageScaleType = ImageView.ScaleType.CENTER_CROP
        visibility = if (ad.mediaContent.aspectRatio > 0f) View.VISIBLE else View.GONE
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 156)).apply {
            topMargin = dp(context, 8)
            bottomMargin = dp(context, 8)
        }
    }
    val secondaryAssets = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val store = TextView(context).apply {
        text = ad.store.orEmpty()
        setTextColor(AndroidColor.LTGRAY)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        visibility = if (ad.store.isNullOrBlank()) View.GONE else View.VISIBLE
    }
    val price = TextView(context).apply {
        text = ad.price.orEmpty()
        setTextColor(AndroidColor.LTGRAY)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        visibility = if (ad.price.isNullOrBlank()) View.GONE else View.VISIBLE
    }
    val rating = RatingBar(context, null, android.R.attr.ratingBarStyleSmall).apply {
        numStars = 5
        stepSize = 0.5f
        rating = ad.starRating?.toFloat() ?: 0f
        visibility = if (ad.starRating == null) View.GONE else View.VISIBLE
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 20)).apply { rightMargin = dp(context, 8) }
    }
    val cta = TextView(context).apply {
        text = ad.callToAction.orEmpty()
        setTextColor(AndroidColor.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(context, 12), dp(context, 8), dp(context, 12), dp(context, 8))
        setBackgroundColor(AndroidColor.rgb(122, 55, 190))
        visibility = if (ad.callToAction.isNullOrBlank()) View.GONE else View.VISIBLE
    }

    iconAndHeadline.addView(iconView)
    iconAndHeadline.addView(headline, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    secondaryAssets.addView(rating)
    secondaryAssets.addView(store)
    if (!ad.price.isNullOrBlank()) {
        val separator = TextView(context).apply {
            text = "  ·  "
            setTextColor(AndroidColor.GRAY)
            visibility = if (ad.store.isNullOrBlank()) View.GONE else View.VISIBLE
        }
        secondaryAssets.addView(separator)
        secondaryAssets.addView(price)
    }

    column.addView(attribution)
    column.addView(iconAndHeadline, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 4) })
    column.addView(mediaView)
    column.addView(body)
    column.addView(advertiser)
    column.addView(secondaryAssets)
    column.addView(cta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 7) })
    root.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    root.headlineView = headline
    root.iconView = iconView
    root.bodyView = body
    root.advertiserView = advertiser
    root.storeView = store
    root.priceView = price
    root.starRatingView = rating
    root.callToActionView = cta
    root.registerNativeAd(ad, mediaView)
    return root
}

@Composable
fun BaatlyEntertainmentBanner(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val sdkReady by BaatlyAds.readyState.collectAsState()
    var loaded by remember { mutableStateOf(false) }
    val adView = remember(context) { AdView(context) }
    DisposableEffect(adView, sdkReady) {
        if (sdkReady) {
            val widthDp = (context.resources.displayMetrics.widthPixels / context.resources.displayMetrics.density).toInt().coerceAtLeast(320)
            val size = AdSize.getLargeAnchoredAdaptiveBannerAdSize(context, widthDp)
            val request = BannerAdRequest.Builder(BaatlyAds.bannerUnit(), size).build()
            adView.loadAd(request, object : AdLoadCallback<BannerAd> {
                override fun onAdLoaded(ad: BannerAd) { Handler(Looper.getMainLooper()).post { loaded = true } }
                override fun onAdFailedToLoad(adError: LoadAdError) { Handler(Looper.getMainLooper()).post { loaded = false } }
            })
        }
        onDispose { try { adView.destroy() } catch (_: Throwable) {} }
    }
    if (loaded) {
        Surface(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
            AndroidView(factory = { adView }, modifier = Modifier.fillMaxWidth().wrapContentHeight())
        }
    }
}

private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
