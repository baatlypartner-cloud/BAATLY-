package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.HomeMode
import com.example.ui.Screen
import com.example.data.model.PartnerProfile
import com.example.data.model.PublicUserRating
import com.example.ui.components.rememberResolvedProfileImageUrl
import com.example.ui.ads.BaatlyAds
import com.example.ui.ads.BaatlyNativeAdCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: BaatlyViewModel) {
    val homeMode by viewModel.homeMode.collectAsState()
    val availablePartners by viewModel.availablePartners.collectAsState()
    val isLoadingPartners by viewModel.isLoadingPartners.collectAsState()
    val wallet by viewModel.walletSummary.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()
    val hostPublicRatings by viewModel.hostPublicRatings.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val displayedPartners = remember(availablePartners, homeMode) {
        when (homeMode) {
            HomeMode.CALL, HomeMode.VIDEO -> availablePartners.filter { it.audioEnabled }
            HomeMode.CHAT -> availablePartners.filter { it.chatEnabled }
        }
    }
    val filteredPartners = remember(displayedPartners, searchQuery) {
        if (searchQuery.isBlank()) displayedPartners
        else displayedPartners.filter {
            it.displayName.contains(searchQuery, ignoreCase = true) ||
                (it.bio?.contains(searchQuery, ignoreCase = true) == true)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
        RelationshipHeader(
            balance = wallet.availableBalanceRupees,
            onWalletClick = { viewModel.setScreen(Screen.WALLET) },
            onMessagesClick = { viewModel.setScreen(Screen.CHAT_LIST) },
            onNotificationsClick = { viewModel.setScreen(Screen.NOTIFICATIONS) }
        )

        PullToRefreshBox(
            isRefreshing = isLoadingPartners && availablePartners.isNotEmpty(),
            onRefresh = {
                viewModel.refreshPartners()
                viewModel.refreshWallet()
            },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "relationship_hero") {
                    RelationshipHeroBanner(
                        greeting = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
                            in 4..11 -> "Good morning"
                            in 12..16 -> "Good afternoon"
                            else -> "Good evening"
                        }
                    )
                }
                item(key = "relationship_search") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search hosts by name, mood or interest…", color = TextTertiary, fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search hosts", tint = VibrantPink) },
                            shape = RoundedCornerShape(24.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VibrantPink,
                                unfocusedBorderColor = DarkCardBorder,
                                focusedContainerColor = DarkSurface,
                                unfocusedContainerColor = DarkSurface,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                cursorColor = VibrantPink
                            ),
                            modifier = Modifier.weight(1f).testTag("input_search_hosts")
                        )
                        Surface(
                            modifier = Modifier.size(52.dp).clickable { viewModel.refreshPartners() },
                            shape = RoundedCornerShape(17.dp),
                            color = DarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Tune, contentDescription = "Refresh host list", tint = VibrantPink)
                            }
                        }
                    }
                }
                item(key = "relationship_modes") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        RelationshipQuickAction("Voice Call", "Talk now", Icons.Filled.Call, listOf(Color(0xFFFF0AA8), Color(0xFF8B35FF)), Modifier.weight(1f)) {
                            viewModel.setHomeMode(HomeMode.CALL)
                        }
                        RelationshipQuickAction("Video Call", "Coming soon", Icons.Filled.Videocam, listOf(Color(0xFF803BFF), Color(0xFF326BFF)), Modifier.weight(1f)) {
                            viewModel.showUserMessage("Video calling is currently unavailable. Voice calls are supported.")
                        }
                        RelationshipQuickAction("Love Note", "Send a message", Icons.Filled.Email, listOf(Color(0xFFFF7956), Color(0xFFDB278F)), Modifier.weight(1f)) {
                            viewModel.setHomeMode(HomeMode.CHAT)
                        }
                        RelationshipQuickAction("Roleplay", "AI characters", Icons.Filled.FavoriteBorder, listOf(Color(0xFF3157FF), Color(0xFF7B36FF)), Modifier.weight(1f)) {
                            viewModel.setScreen(Screen.ROLEPLAY)
                        }
                    }
                }
                item(key = "relationship_available_title") {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Available now", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(OnlineGreen))
                            Text("${filteredPartners.size} online", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                        }
                    }
                }
                if (isLoadingPartners && filteredPartners.isEmpty()) {
                    item(key = "relationship_loading") {
                        Box(Modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = VibrantPink)
                        }
                    }
                } else if (filteredPartners.isEmpty()) {
                    item(key = "relationship_empty") {
                        Box(Modifier.fillMaxWidth().height(300.dp).padding(28.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(42.dp))
                                Text(
                                    text = when (homeMode) {
                                        HomeMode.CALL -> "No hosts available for voice calls right now"
                                        HomeMode.VIDEO -> "No hosts available for video calls right now"
                                        HomeMode.CHAT -> "No hosts available for Love Notes right now"
                                    },
                                    style = MaterialTheme.typography.bodyLarge.copy(color = TextSecondary, fontWeight = FontWeight.Medium)
                                )
                                Text("Pull down to refresh", style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                            }
                        }
                    }
                } else {
                    filteredPartners.forEachIndexed { index, partner ->
                        item(key = "host-${partner.id}") {
                            val hostUserId = partner.userId?.takeIf { it.isNotBlank() } ?: partner.id
                            Box(Modifier.padding(horizontal = 16.dp)) {
                                RelationshipPartnerCard(
                                    partner = partner,
                                    homeMode = homeMode,
                                    publicRating = hostPublicRatings[hostUserId],
                                    callRate = effectivePricing.callRateRupeesPerMinute,
                                    noteRate = effectivePricing.messageRateRupees,
                                    dataService = viewModel.dataService,
                                    onOpenProfile = { viewModel.openHostProfile(partner) },
                                    onCall = { viewModel.requestCall(partner) },
                                    onLoveNote = { viewModel.openChatWithHost(partner) },
                                    onVideoInfo = { viewModel.showUserMessage("Video calling is currently unavailable. Voice calls are supported.") }
                                )
                            }
                        }
                        if ((index + 1) % 5 == 0) {
                            item(key = "host-native-ad-${index + 1}") {
                                BaatlyNativeAdCard(BaatlyAds.HOST_LIST, Modifier.padding(horizontal = 16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RelationshipPartnerCard(
    partner: PartnerProfile,
    homeMode: HomeMode,
    publicRating: PublicUserRating?,
    callRate: Double,
    noteRate: Double,
    dataService: com.example.data.network.SupabaseDataService,
    onOpenProfile: () -> Unit,
    onCall: () -> Unit,
    onLoveNote: () -> Unit,
    onVideoInfo: () -> Unit
) {
    val resolvedAvatar by rememberResolvedProfileImageUrl(partner.avatarUrl, dataService)
    val hobbies = partner.hobbiesList.take(3)
    val ratingValue = publicRating?.averageRating?.takeIf { it > 0 } ?: partner.rating.takeIf { it > 0 }
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenProfile),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF080F2C),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF46309A))
    ) {
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(104.dp).height(132.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Color(0xFF491A7A), Color(0xFF14265F))))) {
                if (!resolvedAvatar.isNullOrBlank()) {
                    AsyncImage(model = resolvedAvatar, contentDescription = partner.displayName, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(partner.displayName.take(1).uppercase(), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black)
                    }
                }
                if (partner.isOnline) Surface(Modifier.align(Alignment.TopStart).padding(5.dp), color = Color(0xFF00B97A), shape = RoundedCornerShape(12.dp)) {
                    Text("● Online", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp))
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(partner.displayName, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    if (partner.age > 0) Text("${partner.age}", color = TextSecondary, fontSize = 10.sp)
                }
                if (ratingValue != null) {
                    val ratingCount = publicRating?.totalReviews ?: partner.reviewsCount
                    Text("★ ${String.format(java.util.Locale.US, "%.1f", ratingValue)}" + if (ratingCount > 0) " · $ratingCount" else "", color = Color(0xFFFFD24D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text(partner.bio?.takeIf { it.isNotBlank() } ?: "BAATLY member", color = Color(0xFFB9C0E2), fontSize = 10.sp, lineHeight = 14.sp, maxLines = 3, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                if (hobbies.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        hobbies.forEach { item ->
                            Surface(color = Color(0xFF17184A), shape = RoundedCornerShape(10.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF5639A0))) {
                                Text(item, color = Color(0xFFE0D9FF), fontSize = 8.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp), maxLines = 1)
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = onCall, modifier = Modifier.weight(1f).height(36.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE600A7)), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("Call", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = onLoveNote, modifier = Modifier.weight(1f).height(36.dp), shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7543FF)), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                        Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(13.dp), tint = Color(0xFFC6A9FF)); Spacer(Modifier.width(3.dp)); Text("Note", color = Color.White, fontSize = 10.sp)
                    }
                }
                Text(
                    when (homeMode) {
                        HomeMode.CHAT -> if (noteRate > 0) "₹${noteRate.toInt()} / note" else "Love Note"
                        else -> if (callRate > 0) "₹${callRate.toInt()} / min" else "Voice call"
                    },
                    color = TextSecondary, fontSize = 8.sp
                )
                TextButton(onClick = onVideoInfo, contentPadding = PaddingValues(0.dp), modifier = Modifier.height(20.dp)) {
                    Icon(Icons.Filled.Videocam, contentDescription = null, tint = Color(0xFF8F85B7), modifier = Modifier.size(12.dp)); Spacer(Modifier.width(3.dp)); Text("Video · coming soon", color = Color(0xFF8F85B7), fontSize = 8.sp)
                }
            }
        }
    }
}

@Composable
private fun RelationshipHeroBanner(greeting: String) {
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .height(132.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF26104A), Color(0xFF4B145C), Color(0xFF101A45))))
    ) {
        Image(
            painter = painterResource(id = com.example.R.drawable.img_onboard_chat),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF170C32).copy(alpha = 0.94f), Color(0xFF231144).copy(alpha = 0.75f), Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(start = 17.dp, end = 112.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("$greeting  👋", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text("Connect, talk, share and build meaningful relationships on BAATLY.", color = Color(0xFFE5DDFB), fontSize = 11.sp, lineHeight = 16.sp)
        }
        Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = Color(0xFFFF72CF), modifier = Modifier.align(Alignment.TopEnd).padding(14.dp).size(23.dp))
    }
}

@Composable
private fun RelationshipQuickAction(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.height(84.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        color = DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, colors.first().copy(alpha = 0.8f))
    ) {
        Column(
            Modifier.fillMaxSize().background(Brush.linearGradient(colors)).padding(horizontal = 3.dp, vertical = 9.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(5.dp))
            Text(title, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(subtitle, color = Color.White.copy(alpha = 0.84f), fontSize = 7.sp, maxLines = 1)
        }
    }
}

@Composable
private fun RelationshipHeader(balance: Double, onWalletClick: () -> Unit, onMessagesClick: () -> Unit, onNotificationsClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(DarkBackground).statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(VibrantPink, PrimaryLavender))), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = Color.White, modifier = Modifier.size(23.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                Text("BAATLY", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 0.4.sp))
                Text("R E L A T I O N S H I P", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = VibrantPink, fontSize = 9.sp))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(
                shape = CircleShape,
                color = DarkSurfaceVariant,
                modifier = Modifier.clickable(onClick = onWalletClick).testTag("relationship_wallet_badge")
            ) {
                Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Box(Modifier.size(25.dp).clip(CircleShape).background(Color(0xFFFFB703)), contentAlignment = Alignment.Center) {
                        Text("₹", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    }
                    Text("₹${"%.0f".format(balance)}", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
            IconButton(onClick = onMessagesClick, modifier = Modifier.size(42.dp).testTag("btn_relationship_messages")) {
                Icon(Icons.Filled.Email, contentDescription = "Messages", tint = Color.White, modifier = Modifier.size(25.dp))
            }
            IconButton(onClick = onNotificationsClick, modifier = Modifier.size(42.dp).testTag("btn_relationship_notifications")) {
                Icon(Icons.Filled.Notifications, contentDescription = "Notifications", tint = Color.White, modifier = Modifier.size(23.dp))
            }
        }
    }
}

@Composable
private fun SegmentButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    testTag: String,
    selectedColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) selectedColor else Color.Transparent,
        modifier = modifier.testTag(testTag).clickable(onClick = onClick)
    ) {
        Row(modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(icon, contentDescription = null, tint = if (selected) Color.White else TextSecondary, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Text(title, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (selected) Color.White else TextSecondary))
        }
    }
}
