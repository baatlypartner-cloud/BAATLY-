package com.example.ui.entertainment

import com.example.ui.ads.BaatlyAds
import com.example.ui.ads.BaatlyNativeAdCard
import com.example.ui.ads.BaatlyEntertainmentBanner
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import coil.compose.AsyncImage
import com.example.data.model.StreamingCatalogItem
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*
import kotlinx.coroutines.launch

private val Plum = Color(0xFFF7F2FF)
private val Cream = Color(0xFF070817)

@Composable
fun EntertainmentScreen(viewModel: BaatlyViewModel) {
    var selectedFilter by remember { mutableStateOf("All") }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var catalogue by remember { mutableStateOf<List<StreamingCatalogItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val filters = listOf("All", "Hindi", "Haryanvi", "Short Drama", "Web Series", "Movies")

    LaunchedEffect(Unit) {
        isLoading = true
        viewModel.dataService.getStreamingCatalog().onSuccess { items ->
            catalogue = items
            loadError = null
        }.onFailure { error ->
            loadError = error.message ?: "Could not load catalogue"
        }
        isLoading = false
    }

    val filteredCatalogue = remember(catalogue, selectedFilter, searchQuery) {
        catalogue.filter { item ->
            val typeMatches = when (selectedFilter) {
                "Short Drama" -> item.contentType.equals("short_drama", true)
                "Movies" -> item.contentType.equals("movie", true)
                "Web Series" -> item.contentType.equals("web_series", true) || item.contentType.equals("series", true)
                "Hindi" -> item.language.equals("Hindi", true)
                "Haryanvi" -> item.language.equals("Haryanvi", true)
                else -> true
            }
            val q = searchQuery.trim()
            typeMatches && (q.isBlank() || item.title.contains(q, true) || item.description.orEmpty().contains(q, true) || item.language.contains(q, true))
        }
    }
    val dramas = filteredCatalogue.filter { it.contentType.equals("short_drama", true) }
    val hindiMovies = filteredCatalogue.filter { it.contentType.equals("movie", true) && it.language.equals("Hindi", true) }
    val haryanviMovies = filteredCatalogue.filter { it.contentType.equals("movie", true) && it.language.equals("Haryanvi", true) }
    val baatlyOriginals = filteredCatalogue.filter {
        it.contentType.lowercase() in setOf("original", "baatly_original", "baatly_originals")
    }

    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(VibrantPink, PrimaryLavender))), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(27.dp))
            }
            Column(Modifier.width(142.dp)) {
                Text("BAATLY", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Plum)
                Text("E N T E R T A I N M E N T", fontSize = 7.sp, fontWeight = FontWeight.Bold, color = VibrantPink, letterSpacing = 1.2.sp)
            }
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                singleLine = true,
                placeholder = { Text("Search movies, dramas…", fontSize = 10.sp, color = TextMuted) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(18.dp)) },
                shape = RoundedCornerShape(22.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VibrantPink,
                    unfocusedBorderColor = DarkCardBorder,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = VibrantPink
                ),
                modifier = Modifier.weight(1f).height(49.dp)
            )
            IconButton(onClick = { viewModel.setScreen(Screen.NOTIFICATIONS) }, modifier = Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(DarkSurface)) {
                Icon(Icons.Filled.Notifications, contentDescription = "Notifications", tint = Plum, modifier = Modifier.size(21.dp))
            }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item {
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(218.dp).clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF311545), Color(0xFF8D204F), Color(0xFFFF8A5B))))
                ) {
                    Image(
                        painter = painterResource(id = com.example.R.drawable.entertainment_hero),
                        contentDescription = "Cinematic Indian drama artwork",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xDD1D1028), Color(0x801D1028), Color.Transparent))))
                    Column(Modifier.align(Alignment.CenterStart).padding(20.dp).fillMaxWidth(0.78f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Surface(color = Color(0xFFFFD166), shape = RoundedCornerShape(12.dp)) {
                            Text("BAATLY ORIGINALS", color = Plum, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                        }
                        Text("Stories that\nstay with you", color = Color.White, fontSize = 27.sp, lineHeight = 30.sp, fontWeight = FontWeight.Black)
                        Text("Hindi • Haryanvi • Short dramas", color = Color.White.copy(alpha = 0.92f), fontSize = 11.sp)
                        Button(onClick = {
                            val firstPlayable = dramas.firstOrNull { it.mediaUrl.isNotBlank() }
                            if (firstPlayable != null) viewModel.openFullScreenMedia(firstPlayable.mediaUrl, "video")
                            else {
                                selectedFilter = "Short Drama"
                                if (!isLoading && dramas.isNotEmpty()) viewModel.showUserMessage("No playable episode is published yet")
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 5.dp)) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Watch Now", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(filters.size) { index ->
                        val label = filters[index]
                        val glyph = when (label) {
                            "All" -> "▦"
                            "Hindi" -> "🎬"
                            "Haryanvi" -> "✦"
                            "Short Drama" -> "🎭"
                            "Web Series" -> "▣"
                            else -> "▣"
                        }
                        Column(
                            modifier = Modifier.width(67.dp).clip(RoundedCornerShape(15.dp))
                                .background(if (selectedFilter == label) Color(0xFF21114A) else Color.Transparent)
                                .clickable { selectedFilter = label }.padding(vertical = 7.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(CircleShape)
                                    .background(if (selectedFilter == label) Brush.linearGradient(listOf(VibrantPink, PrimaryLavender)) else Brush.linearGradient(listOf(DarkSurface, DarkSurfaceVariant)))
                                    .then(if (selectedFilter == label) Modifier.border(1.5.dp, VibrantPink, CircleShape) else Modifier.border(1.dp, DarkCardBorder, CircleShape)),
                                contentAlignment = Alignment.Center
                            ) { Text(glyph, fontSize = 20.sp, color = Color.White, fontWeight = FontWeight.Bold) }
                            Text(label, color = if (selectedFilter == label) VibrantPink else TextSecondary, fontSize = 9.sp, maxLines = 1, fontWeight = if (selectedFilter == label) FontWeight.Bold else FontWeight.Medium)
                        }
                    }
                }
            }
            if (filteredCatalogue.isNotEmpty()) {
                item(key = "entertainment-banner-ad") {
                    BaatlyEntertainmentBanner(Modifier.padding(horizontal = 14.dp))
                }
            }
            if (isLoading) {
                item {
                    Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = VibrantPink)
                    }
                }
            } else if (!loadError.isNullOrBlank() && catalogue.isEmpty()) {
                item {
                    EmptyCatalogueCard(
                        title = "Entertainment catalogue unavailable",
                        message = "Check your connection and try loading the catalogue again.",
                        action = {
                            scope.launch {
                                isLoading = true
                                viewModel.dataService.getStreamingCatalog().onSuccess { catalogue = it; loadError = null }.onFailure { loadError = it.message }
                                isLoading = false
                            }
                        }
                    )
                }
            } else if (filteredCatalogue.isEmpty()) {
                item {
                    EmptyCatalogueCard(
                        title = if (selectedFilter == "All") "Your entertainment starts here" else "Nothing in this category yet",
                        message = "Movies and short-drama episodes will appear here when an admin publishes them to the BAATLY catalogue."
                    )
                }
            } else {
                if (selectedFilter == "All" || selectedFilter == "Short Drama" || selectedFilter == "Hindi" || selectedFilter == "Haryanvi") {
                    if (dramas.isNotEmpty()) item {
                        ContentSection(
                            title = "Trending Short Dramas", seeAll = "See all · ${dramas.size}",
                            items = dramas.map { it.toCatalogCard() },
                            onPlay = { item -> if (item.mediaUrl.isNotBlank()) viewModel.openFullScreenMedia(item.mediaUrl, "video") else viewModel.showUserMessage("Episode video is not available yet") }
                        )
                    }
                }
                if (selectedFilter == "All" || selectedFilter == "Movies" || selectedFilter == "Hindi") {
                    if (hindiMovies.isNotEmpty()) item {
                        ContentSection(
                            title = "Hindi Movies", seeAll = "${hindiMovies.size} titles",
                            items = hindiMovies.map { it.toCatalogCard() },
                            onPlay = { item -> if (item.mediaUrl.isNotBlank()) viewModel.openFullScreenMedia(item.mediaUrl, "video") else viewModel.showUserMessage("Movie video is not available yet") }
                        )
                    }
                }
                if (selectedFilter == "All" || selectedFilter == "Movies" || selectedFilter == "Haryanvi") {
                    if (haryanviMovies.isNotEmpty()) item {
                        ContentSection(
                            title = "Haryanvi Movies", seeAll = "${haryanviMovies.size} titles",
                            items = haryanviMovies.map { it.toCatalogCard() },
                            onPlay = { item -> if (item.mediaUrl.isNotBlank()) viewModel.openFullScreenMedia(item.mediaUrl, "video") else viewModel.showUserMessage("Movie video is not available yet") }
                        )
                    }
                }
                if (selectedFilter == "All" && baatlyOriginals.isNotEmpty()) {
                    item {
                        ContentSection(
                            title = "BAATLY Originals", seeAll = "${baatlyOriginals.size} titles",
                            items = baatlyOriginals.map { it.toCatalogCard() },
                            onPlay = { item -> if (item.mediaUrl.isNotBlank()) viewModel.openFullScreenMedia(item.mediaUrl, "video") else viewModel.showUserMessage("Original video is not available yet") }
                        )
                    }
                }
                if (selectedFilter == "All" || selectedFilter == "Web Series") {
                    val webSeries = filteredCatalogue.filter { it.contentType.equals("web_series", true) || it.contentType.equals("series", true) }
                    if (webSeries.isNotEmpty()) item {
                        ContentSection(
                            title = "Web Series", seeAll = "${webSeries.size} titles",
                            items = webSeries.map { it.toCatalogCard() },
                            onPlay = { item -> if (item.mediaUrl.isNotBlank()) viewModel.openFullScreenMedia(item.mediaUrl, "video") else viewModel.showUserMessage("Episode video is not available yet") }
                        )
                    }
                }
                if (dramas.isEmpty() && hindiMovies.isEmpty() && haryanviMovies.isEmpty() && baatlyOriginals.isEmpty()) {
                    item {
                        ContentSection(
                            title = "Published Catalogue", seeAll = "${filteredCatalogue.size} titles",
                            items = filteredCatalogue.map { it.toCatalogCard() },
                            onPlay = { item -> if (item.mediaUrl.isNotBlank()) viewModel.openFullScreenMedia(item.mediaUrl, "video") else viewModel.showUserMessage("Video is not available yet") }
                        )
                    }
                }
            }
        }
    }
    if (showSearch) {
        AlertDialog(
            onDismissRequest = { showSearch = false; searchQuery = "" },
            containerColor = DarkSurface,
            title = { Text("Search Entertainment", color = Plum, fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, singleLine = true, placeholder = { Text("Movie, drama, language…") }) },
            confirmButton = { TextButton(onClick = { showSearch = false }) { Text("Show results", color = VibrantPink) } },
            dismissButton = { TextButton(onClick = { showSearch = false; searchQuery = "" }) { Text("Close", color = TextSecondary) } }
        )
    }
}

private fun StreamingCatalogItem.toCatalogCard(): CatalogItem = CatalogItem(
    id = id,
    title = title,
    subtitle = when {
        episodeNumber != null -> "Episode $episodeNumber" + (seasonNumber?.let { " • Season $it" } ?: "")
        durationSeconds != null -> {
            val mins = durationSeconds / 60
            if (mins >= 60) "${mins / 60}h ${mins % 60}m" else "$mins min"
        }
        else -> language
    },
    genre = language.ifBlank { if (contentType == "short_drama") "Short Drama" else "Movie" },
    thumbnailUrl = thumbnailUrl,
    mediaUrl = mediaUrl,
    color = Color(0xFF503044)
)

@Composable
private fun EmptyCatalogueCard(title: String, message: String, action: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(22.dp)).background(DarkSurface).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Icon(Icons.Filled.Movie, contentDescription = null, tint = Color(0xFFBDA7C5), modifier = Modifier.size(42.dp))
        Text(title, color = Plum, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(message, color = TextSecondary, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        action?.let { Button(onClick = it, colors = ButtonDefaults.buttonColors(containerColor = VibrantPink)) { Icon(Icons.Filled.Refresh, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("Retry") } }
    }
}

private data class CatalogItem(val id: String, val title: String, val subtitle: String, val genre: String, val thumbnailUrl: String?, val mediaUrl: String, val color: Color)

@Composable
private fun ContentSection(title: String, seeAll: String, items: List<CatalogItem>, onPlay: (CatalogItem) -> Unit) {
    val displayItems = remember(items) {
        buildList<CatalogItem?> {
            items.forEachIndexed { index, item ->
                add(item)
                val count = index + 1
                if (count == 6 || (count > 6 && (count - 6) % 10 == 0)) add(null)
            }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Plum, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(seeAll, color = VibrantPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            items(displayItems.size) { index ->
                val item = displayItems[index]
                if (item == null) {
                    Box(Modifier.width(280.dp).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        BaatlyNativeAdCard(BaatlyAds.ENTERTAINMENT_NATIVE)
                    }
                } else Column(Modifier.width(148.dp).clickable { onPlay(item) }.testTag("entertainment_${item.title.replace(' ', '_')}") ) {
                    Box(Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(16.dp)).background(Brush.verticalGradient(listOf(item.color, item.color.copy(alpha = 0.62f), Color(0xFF1E1425))))) {
                        if (!item.thumbnailUrl.isNullOrBlank()) {
                            AsyncImage(model = item.thumbnailUrl, contentDescription = item.title, contentScale = androidx.compose.ui.layout.ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)))))
                        }
                        Surface(color = Color.Black.copy(alpha = 0.35f), shape = RoundedCornerShape(8.dp), modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
                            Text(item.genre.uppercase(), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp))
                        }
                        Text(item.title, color = Color.White, fontSize = 17.sp, lineHeight = 19.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomStart).padding(10.dp), maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Play ${item.title}", tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.align(Alignment.Center).size(32.dp).background(Color.Black.copy(alpha = 0.28f), RoundedCornerShape(50)).padding(5.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(item.title, color = Plum, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(item.subtitle, color = TextSecondary, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}
