package com.example.data.network

import com.example.data.local.SessionManager
import com.example.data.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class SupabaseDataService(
    private val client: SupabaseClient,
    private val sessionManager: SessionManager
) {

    // 1. Available Partners (Hosts)
    suspend fun getAvailablePartners(): Result<List<PartnerProfile>> {
        return try {
            val list = mutableListOf<PartnerProfile>()
            try {
                val rpcRes = client.rpc("get_available_partners")
                val array = JSONArray(rpcRes)
                for (i in 0 until array.length()) {
                    list.add(parsePartnerProfile(array.getJSONObject(i)))
                }
            } catch (_: Exception) {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?is_partner=eq.true&approval_status=eq.approved&account_status=neq.deleted&select=*"
                val res = client.get(url)
                val array = JSONArray(res)
                for (i in 0 until array.length()) {
                    list.add(parsePartnerProfile(array.getJSONObject(i)))
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 2. Host Profile
    suspend fun getHostProfile(hostId: String): Result<PartnerProfile> {
        if (hostId.isBlank()) return Result.failure(Exception("Host ID is blank"))
        return try {
            val profile = try {
                val rpcRes = client.rpc("get_host_profile", mapOf("p_partner_id" to hostId))
                val json = if (rpcRes.trim().startsWith("[")) {
                    val arr = JSONArray(rpcRes)
                    if (arr.length() > 0) arr.getJSONObject(0) else JSONObject()
                } else {
                    JSONObject(rpcRes)
                }
                parsePartnerProfile(json)
            } catch (_: Exception) {
                try {
                    val url = "${SupabaseConfig.supabaseUrl}/rest/v1/partner_profiles?or=(id.eq.$hostId,user_id.eq.$hostId)&select=*"
                    val res = client.get(url)
                    val array = JSONArray(res)
                    if (array.length() > 0) parsePartnerProfile(array.getJSONObject(0))
                    else throw Exception("Host not found in partner_profiles")
                } catch (_: Exception) {
                    val profileUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/profiles?id=eq.$hostId&select=*"
                    val profileRes = client.get(profileUrl)
                    val profileArr = JSONArray(profileRes)
                    if (profileArr.length() > 0) parsePartnerProfile(profileArr.getJSONObject(0))
                    else throw Exception("Host profile not found")
                }
            }
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 3. Request Call (RPC returns scalar UUID)
    suspend fun requestCall(partnerId: String): Result<CallRecord> {
        return try {
            val callerId = sessionManager.userId.value ?: throw Exception("Not logged in")
            val rpcRes = client.rpc("request_call", mapOf("p_partner_id" to partnerId))
            val rawCallId = rpcRes.trim().trim('"')
            val callId = if (rawCallId.startsWith("{")) {
                JSONObject(rawCallId).optString("id", rawCallId)
            } else {
                rawCallId
            }

            if (callId.isBlank()) {
                throw Exception("Invalid call ID returned from server")
            }

            // Authoritatively fetch the created call record from backend
            val callRecordResult = getCallRecord(callId)
            if (callRecordResult.isSuccess) {
                Result.success(callRecordResult.getOrThrow())
            } else {
                Result.failure(callRecordResult.exceptionOrNull() ?: Exception("Failed to retrieve created call record"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Fetch individual Call Record
    suspend fun getCallRecord(callId: String): Result<CallRecord> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/calls?id=eq.$callId&select=*,partner:partner_id(*)"
            val res = client.get(url)
            val array = JSONArray(res)
            if (array.length() > 0) {
                Result.success(parseCallRecord(array.getJSONObject(0)))
            } else {
                Result.failure(Exception("Call record not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 4. Update Call State (requested, ringing, accepted, connected, completed)
    suspend fun updateCallState(callId: String, newStatus: String): Result<Boolean> {
        return try {
            client.rpc("update_call_state", mapOf(
                "p_call_id" to callId,
                "p_new_status" to newStatus
            ))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 5. Settle Call
    suspend fun settleCall(callId: String): Result<Boolean> {
        return try {
            client.rpc("settle_call", mapOf("p_call_id" to callId))
            fetchWallet()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 6. Get Agora Token
    suspend fun getAgoraToken(channelName: String): Result<AgoraTokenResponse> {
        return try {
            val payload = JSONObject().apply {
                put("channel_name", channelName)
                put("role", "publisher")
            }
            val res = client.callEdgeFunction("agora-token", payload.toString())
            val json = JSONObject(res)
            val tokenResp = AgoraTokenResponse(
                appId = json.optString("app_id", SupabaseConfig.agoraAppId),
                channelName = json.optString("channel_name", channelName),
                uid = json.optLong("uid", 0),
                token = json.optString("token"),
                expiresIn = json.optLong("expires_in", 3600)
            )
            Result.success(tokenResp)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 7. Start Chat With Host
    suspend fun startChatWithHost(partnerId: String): Result<String> {
        return try {
            if (partnerId.isBlank()) {
                throw Exception("Invalid host / partner ID")
            }
            val rpcRes = client.rpc("start_chat_with_host", mapOf("p_partner_id" to partnerId))
            val raw = rpcRes.trim()
            var conversationId = ""
            if (raw.startsWith("[")) {
                val arr = JSONArray(raw)
                if (arr.length() > 0) {
                    val obj = arr.getJSONObject(0)
                    conversationId = obj.optString("id", obj.optString("conversation_id", obj.optString("p_conversation_id", "")))
                }
            } else if (raw.startsWith("{")) {
                val obj = JSONObject(raw)
                conversationId = obj.optString("id", obj.optString("conversation_id", obj.optString("p_conversation_id", "")))
            } else {
                conversationId = raw.trim('"')
            }
            if (conversationId.isBlank() || conversationId == "null") {
                throw Exception("Could not initialize chat conversation")
            }
            Result.success(conversationId)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseDataService", "startChatWithHost error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 8. Send Chat Message
    suspend fun sendMessage(
        conversationId: String,
        receiverId: String,
        messageType: String = "text",
        content: String? = null,
        mediaUrl: String? = null,
        mediaDurationSeconds: Int? = null
    ): Result<ChatMessage> {
        return try {
            val senderId = sessionManager.userId.value
                ?: throw Exception("User session not found. Please sign in.")

            if (conversationId.isBlank()) {
                throw Exception("Invalid conversation ID")
            }
            if (receiverId.isBlank()) {
                throw Exception("Invalid host ID")
            }

            val params = mapOf<String, Any?>(
                "p_conversation_id" to conversationId,
                "p_receiver_id" to receiverId,
                "p_message_type" to messageType,
                "p_message_text" to content,
                "p_media_url" to mediaUrl,
                "p_media_duration_seconds" to mediaDurationSeconds
            )

            val rpcRes = client.rpc("send_message", params)
            android.util.Log.d("SupabaseDataService", "send_message raw response: $rpcRes")

            val raw = rpcRes.trim()
            var success = true
            var serverMessageId: String? = null
            var errorMsg: String? = null

            if (raw.startsWith("{")) {
                val json = JSONObject(raw)
                if (json.has("success")) {
                    success = json.optBoolean("success", true)
                }
                if (!success) {
                    errorMsg = json.optString("error", json.optString("message", "Message rejected by server"))
                }
                serverMessageId = json.optString("message_id", json.optString("id", "")).takeIf { it.isNotBlank() }
            } else if (raw.startsWith("[")) {
                val arr = JSONArray(raw)
                if (arr.length() > 0) {
                    val json = arr.getJSONObject(0)
                    if (json.has("success")) {
                        success = json.optBoolean("success", true)
                    }
                    if (!success) {
                        errorMsg = json.optString("error", json.optString("message", "Message rejected by server"))
                    }
                    serverMessageId = json.optString("message_id", json.optString("id", "")).takeIf { it.isNotBlank() }
                }
            } else if (raw.isNotBlank() && raw != "null") {
                val cleaned = raw.trim('"')
                if (cleaned.isNotBlank() && cleaned != "null") {
                    serverMessageId = cleaned
                }
            }

            if (!success) {
                throw Exception(errorMsg ?: "Failed to send message")
            }

            // Sync wallet after successful send
            fetchWallet()

            val msg = ChatMessage(
                id = serverMessageId ?: UUID.randomUUID().toString(),
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                messageType = messageType,
                messageText = content,
                mediaUrl = mediaUrl,
                mediaDurationSeconds = mediaDurationSeconds,
                createdAt = "Just now"
            )
            Result.success(msg)
        } catch (e: Exception) {
            android.util.Log.e("SupabaseDataService", "sendMessage error: ${e.message}", e)
            Result.failure(e)
        }
    }

    // 9. Send Gift
    suspend fun sendGift(
        giftId: String,
        receiverId: String,
        conversationId: String? = null,
        callId: String? = null
    ): Result<Boolean> {
        return try {
            client.rpc("send_gift", mapOf(
                "p_gift_id" to giftId,
                "p_receiver_id" to receiverId,
                "p_conversation_id" to conversationId,
                "p_call_id" to callId
            ))
            fetchWallet()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 10. Follow / Unfollow
    suspend fun followHost(partnerId: String): Result<Boolean> {
        return try {
            client.rpc("follow_host", mapOf("p_partner_id" to partnerId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun unfollowHost(partnerId: String): Result<Boolean> {
        return try {
            client.rpc("unfollow_host", mapOf("p_partner_id" to partnerId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 11. Clear My Conversation
    suspend fun clearMyConversation(conversationId: String): Result<Boolean> {
        return try {
            client.rpc("clear_my_conversation", mapOf("p_conversation_id" to conversationId))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 12. Block User
    suspend fun blockUser(partnerId: String, reason: String = "User requested block"): Result<Boolean> {
        return try {
            try {
                client.rpc("block_user", mapOf("p_blocked_user_id" to partnerId, "p_reason" to reason))
            } catch (_: Exception) {
                client.rpc("block_user", mapOf("p_user_id" to partnerId, "p_reason" to reason))
            }
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Signed URL helper for private buckets (chat-media, profile-media)
    suspend fun getSignedMediaUrl(rawPathOrUrl: String, bucket: String = SupabaseConfig.BUCKET_CHAT_MEDIA): String {
        if (rawPathOrUrl.isBlank() ||
            rawPathOrUrl.startsWith("http://") ||
            rawPathOrUrl.startsWith("https://") ||
            rawPathOrUrl.startsWith("content://") ||
            rawPathOrUrl.startsWith("file://")
        ) {
            return rawPathOrUrl
        }
        return try {
            client.createSignedUrl(bucket, rawPathOrUrl, 3600)
        } catch (e: Exception) {
            rawPathOrUrl
        }
    }

    // 13. Fetch Wallet
    suspend fun fetchWallet(): Result<WalletInfo> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/wallets?user_id=eq.$userId&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val wallet = if (arr.length() > 0) {
                val json = arr.getJSONObject(0)
                val coins = json.optInt("coin_balance", 0)
                val cash = json.optDouble("cash_balance", 0.0)
                WalletInfo(
                    userId = json.optString("user_id", userId),
                    coinBalance = coins,
                    cashBalance = cash,
                    updatedAt = json.optString("updated_at")
                )
            } else {
                WalletInfo(userId = userId, coinBalance = 0, cashBalance = 0.0)
            }
            sessionManager.updateWallet(wallet)
            Result.success(wallet)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 14. Fetch Coin Packages
    suspend fun fetchCoinPackages(): Result<List<CoinPackage>> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/coin_packages?is_active=eq.true&order=display_order.asc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<CoinPackage>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    CoinPackage(
                        id = json.getString("id"),
                        coins = json.getInt("coins"),
                        priceInr = json.getDouble("price_inr"),
                        displayOrder = json.optInt("display_order", i),
                        isActive = json.optBoolean("is_active", true)
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 15. Fetch Gifts Catalogue (29 gifts)
    suspend fun fetchGifts(): Result<List<GiftItem>> {
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/gifts?is_active=eq.true&order=display_order.asc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<GiftItem>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    GiftItem(
                        id = json.getString("id"),
                        name = json.getString("name"),
                        category = json.optString("category", "General"),
                        iconUrl = json.optString("icon_url"),
                        animationUrl = json.optString("animation_url"),
                        coinPrice = json.optInt("coin_price", 10),
                        partnerEarningPercent = json.optDouble("partner_earning_percent", 50.0),
                        displayOrder = json.optInt("display_order", i),
                        isActive = json.optBoolean("is_active", true)
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 16. Fetch Recent Calls
    suspend fun fetchRecentCalls(): Result<List<CallRecord>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/calls?user_id=eq.$userId&order=created_at.desc&limit=50&select=*,partner:partner_id(*)"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<CallRecord>()
            for (i in 0 until arr.length()) {
                list.add(parseCallRecord(arr.getJSONObject(i)))
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 17. Fetch Conversations
    suspend fun fetchConversations(): Result<List<ConversationSummary>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/conversations?order=last_message_at.desc&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<ConversationSummary>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val convId = json.getString("id")
                val partnerId = json.optString("partner_id")
                val partnerObj = json.optJSONObject("partner")
                var partner = partnerObj?.let { parsePartnerProfile(it) }

                // Authoritatively resolve host profile via get_host_profile RPC if missing or generic
                if (partner == null || partner.displayName.isNullOrBlank() || partner.displayName == "Host" || partner.displayName == "Baatly Host") {
                    if (partnerId.isNotBlank()) {
                        val hostRes = getHostProfile(partnerId)
                        if (hostRes.isSuccess) {
                            partner = hostRes.getOrNull()
                        }
                    }
                }

                // Check for last message content and unread count directly in conversation row
                var lastMsgText = listOf(
                    json.optString("last_message_text"),
                    json.optString("last_message"),
                    json.optString("last_message_preview"),
                    json.optString("message_text"),
                    json.optString("preview"),
                    json.optString("content")
                ).firstOrNull { it.isNotBlank() && it != "null" }

                var lastMsgType = json.optString("last_message_type", json.optString("message_type", "text"))
                var lastMsgAt = json.optString("last_message_at").takeIf { it.isNotBlank() && it != "null" }
                var unreadCount = listOf(
                    json.optInt("unread_count", -1),
                    json.optInt("unread_messages_count", -1),
                    json.optInt("user_unread_count", -1)
                ).firstOrNull { it >= 0 } ?: 0

                // Query the messages table for this conversation to get the exact latest message and unread count
                try {
                    val msgUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$convId&order=created_at.desc&limit=1&select=*"
                    val msgRes = client.get(msgUrl)
                    val msgArr = JSONArray(msgRes)
                    if (msgArr.length() > 0) {
                        val latestMsgObj = msgArr.getJSONObject(0)
                        val msgType = latestMsgObj.optString("message_type", "text")
                        lastMsgType = msgType
                        val candidate = listOf(
                            latestMsgObj.optString("message_text"),
                            latestMsgObj.optString("content"),
                            latestMsgObj.optString("text"),
                            latestMsgObj.optString("body")
                        ).firstOrNull { it.isNotBlank() && it != "null" }

                        if (!candidate.isNullOrBlank()) {
                            lastMsgText = candidate
                        } else if (msgType == "voice") {
                            lastMsgText = "🎙️ Voice message"
                        } else if (msgType == "gift") {
                            lastMsgText = "🎁 Gift"
                        } else if (msgType == "image") {
                            lastMsgText = "📷 Photo"
                        }

                        if (lastMsgAt.isNullOrBlank()) {
                            lastMsgAt = latestMsgObj.optString("created_at").takeIf { it.isNotBlank() && it != "null" }
                        }
                    }

                    // Count unread messages sent to this user in this conversation
                    val unreadUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$convId&sender_id=neq.$userId&is_read=eq.false&select=id"
                    val unreadRes = client.get(unreadUrl)
                    val unreadArr = JSONArray(unreadRes)
                    unreadCount = unreadArr.length()
                } catch (_: Exception) {}

                list.add(
                    ConversationSummary(
                        id = convId,
                        userId = json.optString("user_id", userId),
                        partnerId = partnerId,
                        lastMessageId = json.optString("last_message_id").takeIf { it.isNotBlank() },
                        lastMessageAt = lastMsgAt,
                        lastMessageText = lastMsgText,
                        lastMessageType = lastMsgType,
                        unreadCount = unreadCount,
                        userBlocked = json.optBoolean("user_blocked", false),
                        partnerBlocked = json.optBoolean("partner_blocked", false),
                        createdAt = json.optString("created_at"),
                        updatedAt = json.optString("updated_at"),
                        partner = partner
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 17b. Mark Messages As Read
    suspend fun markMessagesAsRead(conversationId: String): Result<Unit> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        if (conversationId.isBlank()) return Result.success(Unit)
        return try {
            try {
                client.rpc("mark_messages_read", mapOf("p_conversation_id" to conversationId))
            } catch (_: Exception) {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$conversationId&sender_id=neq.$userId&is_read=eq.false"
                val body = JSONObject().apply {
                    put("is_read", true)
                }
                client.patch(url, body.toString())
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 18. Fetch Messages in Conversation
    suspend fun fetchMessages(conversationId: String): Result<List<ChatMessage>> {
        if (conversationId.isBlank()) return Result.success(emptyList())
        return try {
            val rawRes = try {
                val url = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$conversationId&order=created_at.asc&select=*"
                client.get(url)
            } catch (_: Exception) {
                try {
                    client.rpc("get_conversation_messages", mapOf("p_conversation_id" to conversationId))
                } catch (_: Exception) {
                    val fallbackUrl = "${SupabaseConfig.supabaseUrl}/rest/v1/messages?conversation_id=eq.$conversationId&order=created_at.asc"
                    client.get(fallbackUrl)
                }
            }

            val arr = JSONArray(rawRes)
            val list = mutableListOf<ChatMessage>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val msgId = json.optString("id").ifBlank { UUID.randomUUID().toString() }
                val convId = json.optString("conversation_id").ifBlank { conversationId }
                val senderId = json.optString("sender_id").ifBlank { json.optString("user_id") }
                val receiverId = json.optString("receiver_id").ifBlank { json.optString("partner_id") }
                val msgType = json.optString("message_type", "text")
                val textCandidate = listOf(
                    json.optString("message_text"),
                    json.optString("content"),
                    json.optString("text"),
                    json.optString("body")
                ).firstOrNull { it.isNotBlank() && it != "null" }
                val mediaCandidate = listOf(
                    json.optString("media_url"),
                    json.optString("media_path"),
                    json.optString("url")
                ).firstOrNull { it.isNotBlank() && it != "null" }
                val duration = json.optInt("media_duration_seconds", json.optInt("duration", 0))
                val giftId = json.optString("gift_id").takeIf { it.isNotBlank() && it != "null" }
                val createdAt = json.optString("created_at").takeIf { it.isNotBlank() && it != "null" }
                val isRead = json.optBoolean("is_read", false)

                val giftObj = json.optJSONObject("gift")
                val gift = giftObj?.let {
                    GiftItem(
                        id = it.optString("id"),
                        name = it.optString("name", "Gift"),
                        iconUrl = it.optString("icon_url").takeIf { u -> u.isNotBlank() && u != "null" },
                        coinPrice = it.optInt("coin_price", 10)
                    )
                }

                list.add(
                    ChatMessage(
                        id = msgId,
                        conversationId = convId,
                        senderId = senderId,
                        receiverId = receiverId,
                        messageType = msgType,
                        messageText = textCandidate,
                        mediaUrl = mediaCandidate,
                        mediaDurationSeconds = duration,
                        giftId = giftId,
                        createdAt = createdAt,
                        isRead = isRead,
                        gift = gift
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 19. Fetch Notifications
    suspend fun fetchNotifications(): Result<List<AppNotification>> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val url = "${SupabaseConfig.supabaseUrl}/rest/v1/notifications?user_id=eq.$userId&order=created_at.desc&limit=30&select=*"
            val res = client.get(url)
            val arr = JSONArray(res)
            val list = mutableListOf<AppNotification>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    AppNotification(
                        id = json.getString("id"),
                        userId = json.optString("user_id"),
                        title = json.optString("title", "Baatly Notification"),
                        body = json.optString("body"),
                        notificationType = json.optString("notification_type", "system"),
                        isRead = json.optBoolean("is_read", false),
                        createdAt = json.optString("created_at")
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // 20. Upload Chat Media (image/voice)
    suspend fun uploadChatMedia(file: File, isVoice: Boolean): Result<String> {
        val userId = sessionManager.userId.value ?: return Result.failure(Exception("Not logged in"))
        return try {
            val ext = if (isVoice) "m4a" else "jpg"
            val mime = if (isVoice) "audio/mp4" else "image/jpeg"
            val relativePath = "$userId/${UUID.randomUUID()}.$ext"
            val storagePath = client.uploadFile(
                SupabaseConfig.BUCKET_CHAT_MEDIA,
                relativePath,
                file,
                mime
            )
            Result.success(storagePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseCallRecord(json: JSONObject): CallRecord {
        val partnerObj = json.optJSONObject("partner")
        val partner = partnerObj?.let { parsePartnerProfile(it) }
        val maxDurationSec = if (json.has("max_duration_seconds")) json.optInt("max_duration_seconds") else null
        val maxDurationCoin = if (json.has("max_duration_coins")) json.optInt("max_duration_coins") else null

        return CallRecord(
            id = json.getString("id"),
            userId = json.optString("user_id"),
            partnerId = json.optString("partner_id"),
            status = json.optString("status", "requested"),
            requestedAt = json.optString("requested_at").takeIf { it.isNotBlank() },
            ringingAt = json.optString("ringing_at").takeIf { it.isNotBlank() },
            acceptedAt = json.optString("accepted_at").takeIf { it.isNotBlank() },
            connectedAt = json.optString("connected_at").takeIf { it.isNotBlank() },
            endedAt = json.optString("ended_at").takeIf { it.isNotBlank() },
            durationSeconds = json.optInt("duration_seconds", 0),
            userCoinsCharged = json.optInt("user_coins_charged", 0),
            partnerEarning = json.optDouble("partner_earning", 0.0),
            terminationReason = json.optString("termination_reason").takeIf { it.isNotBlank() },
            billingStatus = json.optString("billing_status").takeIf { it.isNotBlank() },
            agoraChannelId = listOf(
                json.optString("agora_channel_id"),
                json.optString("channel_name"),
                json.optString("agora_channel")
            ).firstOrNull { it.isNotBlank() && it != "null" },
            createdAt = json.optString("created_at").takeIf { it.isNotBlank() },
            maxDurationSeconds = maxDurationSec,
            maxDurationCoins = maxDurationCoin,
            partner = partner
        )
    }

    fun parsePartnerProfile(json: JSONObject): PartnerProfile {
        val ageVal = if (json.has("age") && !json.isNull("age")) json.optInt("age").takeIf { it > 0 } else null
        val ratingVal = if (json.has("rating") && !json.isNull("rating")) json.optDouble("rating") else null

        val displayNameCandidate = listOf(
            json.optString("partner_display_name"),
            json.optString("host_display_name"),
            json.optString("display_name"),
            json.optString("full_name"),
            json.optString("first_name"),
            json.optString("name"),
            json.optString("host_name"),
            json.optString("partner_name"),
            json.optString("username")
        ).firstOrNull { it.isNotBlank() && it != "null" && it != "Host" && it != "Baatly Host" }
            ?: listOf(
                json.optString("partner_display_name"),
                json.optString("host_display_name"),
                json.optString("display_name"),
                json.optString("full_name"),
                json.optString("name"),
                json.optString("host_name"),
                json.optString("partner_name"),
                json.optString("username")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        val avatarCandidate = listOf(
            json.optString("partner_avatar_url"),
            json.optString("avatar_url"),
            json.optString("profile_photo_url"),
            json.optString("photo_url"),
            json.optString("image_url")
        ).firstOrNull { it.isNotBlank() && it != "null" }

        val idCandidate = listOf(
            json.optString("id"),
            json.optString("partner_id"),
            json.optString("user_id")
        ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        val userIdCandidate = listOf(
            json.optString("user_id"),
            json.optString("partner_id"),
            json.optString("id")
        ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

        return PartnerProfile(
            id = idCandidate,
            userId = userIdCandidate,
            displayName = if (displayNameCandidate.isNotBlank()) displayNameCandidate else "Host",
            avatarUrl = avatarCandidate,
            bio = json.optString("bio").takeIf { it.isNotBlank() && it != "null" },
            age = ageVal,
            gender = json.optString("gender", "Female"),
            language = json.optString("language", "Hindi, English"),
            isPartner = json.optBoolean("is_partner", true),
            approvalStatus = json.optString("approval_status", "approved"),
            isAvailable = json.optBoolean("is_available", true),
            isOnline = json.optBoolean("is_online", true),
            audioEnabled = json.optBoolean("audio_enabled", true),
            chatEnabled = json.optBoolean("chat_enabled", true),
            accountStatus = json.optString("account_status", "active"),
            rating = ratingVal,
            followersCount = json.optInt("followers_count", 0),
            reviewsCount = json.optInt("reviews_count", 0),
            isFollowing = json.optBoolean("is_following", false)
        )
    }
}

