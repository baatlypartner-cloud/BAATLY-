package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class UserSession(
    @Json(name = "access_token") val accessToken: String,
    @Json(name = "refresh_token") val refreshToken: String? = null,
    @Json(name = "user") val user: AuthUser? = null,
    @Json(name = "profile") val profile: UserProfile? = null
)

@JsonClass(generateAdapter = true)
data class AuthUser(
    @Json(name = "id") val id: String,
    @Json(name = "email") val email: String? = null,
    @Json(name = "phone") val phone: String? = null
)

@JsonClass(generateAdapter = true)
data class UserProfile(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "username") val username: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "gender") val gender: String? = null,
    @Json(name = "language") val language: String? = null,
    @Json(name = "account_status") val accountStatus: String? = "active",
    @Json(name = "is_online") val isOnline: Boolean? = false,
    @Json(name = "mobile_number") val mobileNumber: String? = null,
    @Json(name = "referral_code") val referralCode: String? = null,
    @Json(name = "referral_code_used") val referralCodeUsed: String? = null,
    @Json(name = "followers_count") val followersCount: Int? = 0,
    @Json(name = "following_count") val followingCount: Int? = 0,
    @Json(name = "rating") val rating: Double? = null,
    @Json(name = "reviews_count") val reviewsCount: Int? = 0,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class PartnerProfile(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "display_name") val displayName: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "age") val age: Int? = null,
    @Json(name = "gender") val gender: String? = null,
    @Json(name = "language") val language: String? = null,
    @Json(name = "is_partner") val isPartner: Boolean = true,
    @Json(name = "approval_status") val approvalStatus: String = "approved",
    @Json(name = "is_available") val isAvailable: Boolean = true,
    @Json(name = "is_online") val isOnline: Boolean = true,
    @Json(name = "audio_enabled") val audioEnabled: Boolean = true,
    @Json(name = "chat_enabled") val chatEnabled: Boolean = true,
    @Json(name = "account_status") val accountStatus: String = "active",
    @Json(name = "rating") val rating: Double? = null,
    @Json(name = "followers_count") val followersCount: Int = 0,
    @Json(name = "reviews_count") val reviewsCount: Int = 0,
    @Json(name = "is_following") val isFollowing: Boolean = false
)

@JsonClass(generateAdapter = true)
data class CallRecord(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "partner_id") val partnerId: String? = null,
    @Json(name = "status") val status: String = "requested", // requested, ringing, accepted, connected, completed
    @Json(name = "requested_at") val requestedAt: String? = null,
    @Json(name = "ringing_at") val ringingAt: String? = null,
    @Json(name = "accepted_at") val acceptedAt: String? = null,
    @Json(name = "connected_at") val connectedAt: String? = null,
    @Json(name = "ended_at") val endedAt: String? = null,
    @Json(name = "duration_seconds") val durationSeconds: Int = 0,
    @Json(name = "user_coins_charged") val userCoinsCharged: Int = 0,
    @Json(name = "partner_earning") val partnerEarning: Double = 0.0,
    @Json(name = "termination_reason") val terminationReason: String? = null,
    @Json(name = "billing_status") val billingStatus: String? = null,
    @Json(name = "agora_channel_id") val agoraChannelId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "max_duration_seconds") val maxDurationSeconds: Int? = null,
    @Json(name = "max_duration_coins") val maxDurationCoins: Int? = null,
    @Json(name = "partner") val partner: PartnerProfile? = null
) {
    val channelName: String? get() = agoraChannelId
    val coinsSpent: Int get() = userCoinsCharged
}

@JsonClass(generateAdapter = true)
data class AgoraTokenResponse(
    @Json(name = "app_id") val appId: String? = null,
    @Json(name = "channel_name") val channelName: String? = null,
    @Json(name = "uid") val uid: Long? = 0,
    @Json(name = "token") val token: String? = null,
    @Json(name = "expires_in") val expiresIn: Long? = null
)

@JsonClass(generateAdapter = true)
data class ConversationSummary(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "partner_id") val partnerId: String? = null,
    @Json(name = "last_message_id") val lastMessageId: String? = null,
    @Json(name = "last_message_at") val lastMessageAt: String? = null,
    @Json(name = "last_message_text") val lastMessageText: String? = null,
    @Json(name = "last_message_type") val lastMessageType: String? = null,
    @Json(name = "unread_count") val unreadCount: Int = 0,
    @Json(name = "user_blocked") val userBlocked: Boolean = false,
    @Json(name = "partner_blocked") val partnerBlocked: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null,
    @Json(name = "partner") val partner: PartnerProfile? = null
)

@JsonClass(generateAdapter = true)
data class ChatMessage(
    @Json(name = "id") val id: String,
    @Json(name = "conversation_id") val conversationId: String,
    @Json(name = "sender_id") val senderId: String,
    @Json(name = "receiver_id") val receiverId: String? = null,
    @Json(name = "message_type") val messageType: String = "text", // text, image, voice, gift
    @Json(name = "message_text") val messageText: String? = null,
    @Json(name = "media_url") val mediaUrl: String? = null,
    @Json(name = "media_duration_seconds") val mediaDurationSeconds: Int? = null,
    @Json(name = "gift_id") val giftId: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "is_read") val isRead: Boolean = false,
    @Json(name = "gift") val gift: GiftItem? = null
) {
    val content: String? get() = messageText
}

@JsonClass(generateAdapter = true)
data class GiftItem(
    @Json(name = "id") val id: String,
    @Json(name = "name") val name: String,
    @Json(name = "category") val category: String? = "general",
    @Json(name = "icon_url") val iconUrl: String? = null,
    @Json(name = "animation_url") val animationUrl: String? = null,
    @Json(name = "coin_price") val coinPrice: Int = 10,
    @Json(name = "partner_earning_percent") val partnerEarningPercent: Double? = 50.0,
    @Json(name = "display_order") val displayOrder: Int? = 0,
    @Json(name = "is_active") val isActive: Boolean = true
)

@JsonClass(generateAdapter = true)
data class GiftTransaction(
    @Json(name = "id") val id: String,
    @Json(name = "sender_id") val senderId: String,
    @Json(name = "receiver_id") val receiverId: String,
    @Json(name = "gift_id") val giftId: String,
    @Json(name = "coins_spent") val coinsSpent: Int,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "gift") val gift: GiftItem? = null
)

@JsonClass(generateAdapter = true)
data class WalletInfo(
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "coin_balance") val coinBalance: Int = 0,
    @Json(name = "cash_balance") val cashBalance: Double = 0.0,
    @Json(name = "updated_at") val updatedAt: String? = null
) {
    val balance: Int get() = coinBalance
}

@JsonClass(generateAdapter = true)
data class CoinPackage(
    @Json(name = "id") val id: String,
    @Json(name = "coins") val coins: Int,
    @Json(name = "price_inr") val priceInr: Double,
    @Json(name = "display_order") val displayOrder: Int = 0,
    @Json(name = "is_active") val isActive: Boolean = true
)

@JsonClass(generateAdapter = true)
data class TransactionItem(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "type") val type: String = "debit",
    @Json(name = "coins") val coins: Int = 0,
    @Json(name = "description") val description: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class AppNotification(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "title") val title: String = "",
    @Json(name = "body") val body: String = "",
    @Json(name = "notification_type") val notificationType: String = "system",
    @Json(name = "is_read") val isRead: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null
)
