# BAATLY User App v40 — Social Error and Artwork Fixes

## Live Supabase repair
- Removed the stale global `private.baatly_api_pre_request()` rule that returned HTTP 402 for every Social/Story/Follow RPC and table request.
- Corrected the remaining maintenance-only PostgREST error details to include the required `headers` object.
- Verified `social_search_profiles('ruhi', 10)` executes in PostgreSQL and returns a JSON array (3 matches in the verification query).
- Confirmed `social_media_enabled` is `true`, `baatly-r2-media` is active (v9), and the active `social_highlights` / `social_highlight_items` tables exist.

## Android source changes
- Replaced the Astrologer placeholder UI with a native Compose celestial/orbit illustration in BAATLY cream, plum, pink and gold colours; no photo asset is used for the astrology artwork.
- Changed Super AI from a card-like poster to a low-opacity full-screen atmosphere background, with readable themed content layered over it.
- Kept versionCode at 40.
- Updated the signed-in user's Following stat immediately after a successful follow/unfollow action. Public profile follower/following counts still reflect real database relationships; if there are no follows, they correctly show 0.
- Search, post/story creation and Highlights access are no longer blocked by the global social 402 hook. Reels use the feed's video media type and R2 playback path.

## Verification limitations
Gradle compilation could not run in this environment because `services.gradle.org` could not resolve (DNS/network failure). The source ZIP is packaged and ZIP integrity is checked, but an APK build is **not** claimed as verified. After upload to GitHub Actions, run `:app:assembleRelease` and review any new compiler errors.
