# BAATLY User App — v40

Native Android application built with Kotlin and Jetpack Compose.

## Open and build

1. Open this project root in Android Studio.
2. Use JDK 17 for the Gradle build.
3. Create `.env` from `.env.example` and populate the project's existing Supabase and Agora runtime configuration using your own values.
4. For a signed Release APK, configure the signing variables/secrets in your CI workflow. Do not commit the upload keystore or passwords.
5. Run `./gradlew :app:assembleRelease`.

The project `versionCode` is set to **40**.

## v40 update

See `BAATLY_V40_UPDATE_NOTES.md` for the UI corrections, media handling and backend endpoints used by the app.

## Latest error/artwork fix

See `BAATLY_V40_ERROR_FIX_NOTES.md` for the root cause of social post/story/search/Highlights failures and the latest UI/artwork changes. The corresponding SQL migration is in `sql/20261025_social_media_request_hook_fix.sql`.
