package com.example.ui.astrologer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val AstroPlum = Color(0xFF2B163D)
private val AstroCream = Color(0xFFFFF8F3)
private val AstroPink = Color(0xFFFF2D68)
private val AstroGold = Color(0xFFF4B95F)
private val AstroLilac = Color(0xFF9670D8)

private data class ZodiacSign(val name: String, val glyph: String)

@Composable
fun AstrologerScreen(viewModel: BaatlyViewModel) {
    val signs = remember {
        listOf(
            ZodiacSign("Aries", "♈"), ZodiacSign("Taurus", "♉"), ZodiacSign("Gemini", "♊"),
            ZodiacSign("Cancer", "♋"), ZodiacSign("Leo", "♌"), ZodiacSign("Virgo", "♍"),
            ZodiacSign("Libra", "♎"), ZodiacSign("Scorpio", "♏"), ZodiacSign("Sagittarius", "♐"),
            ZodiacSign("Capricorn", "♑"), ZodiacSign("Aquarius", "♒"), ZodiacSign("Pisces", "♓")
        )
    }
    var selectedZodiac by remember { mutableStateOf("Aries") }
    val selectedGlyph = signs.firstOrNull { it.name == selectedZodiac }?.glyph ?: "♈"

    Column(
        modifier = Modifier.fillMaxSize().background(AstroCream).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("BAATLY", color = AstroPlum, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 0.4.sp)
                Text("A S T R O L O G E R", color = AstroPink, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
            }
            Surface(shape = CircleShape, color = Color.White, shadowElevation = 2.dp) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = "Astrology", tint = AstroPlum, modifier = Modifier.padding(12.dp).size(23.dp))
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Your cosmic guide ✨", color = AstroPlum, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("Explore zodiac signs, planetary rhythms and Vedic wisdom.", color = TextSecondary, fontSize = 13.sp, lineHeight = 19.sp)
        }

        AstrologyOrbitArtwork(
            modifier = Modifier.fillMaxWidth().height(226.dp),
            selectedGlyph = selectedGlyph
        )

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1E2E9)),
            shadowElevation = 1.dp
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFFFFEEF4)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.NightsStay, contentDescription = null, tint = AstroPink, modifier = Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Vedic astrology", color = AstroPlum, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("The horoscope and birth-chart engine is coming soon. Zodiac selection is available for the preview.", color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
                }
                Surface(color = Color(0xFFFFF3D9), shape = RoundedCornerShape(9.dp)) {
                    Text("SOON", color = Color(0xFF98601C), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                }
            }
        }

        Text("Choose your zodiac", color = AstroPlum, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            signs.forEach { sign ->
                val active = selectedZodiac == sign.name
                Surface(
                    shape = RoundedCornerShape(17.dp),
                    color = if (active) AstroPink else Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (active) AstroPink else Color(0xFFEDE0E8)),
                    modifier = Modifier.width(80.dp).clickable { selectedZodiac = sign.name }
                ) {
                    Column(Modifier.padding(vertical = 10.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(sign.glyph, fontSize = 24.sp, color = if (active) Color.White else AstroPlum)
                        Text(sign.name, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (active) Color.White else AstroPlum, maxLines = 1)
                    }
                }
            }
        }

        Text("Astrology services", color = AstroPlum, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        AstroServiceCard("Daily Vedic Horoscope", "Personalized planetary transit insights based on your zodiac sign.", "Daily insights") {
            viewModel.showUserMessage("Daily horoscope will be available when the verified astrology engine launches.")
        }
        AstroServiceCard("Kundali / Birth Chart", "A birth-chart experience designed around date, time and place of birth.", "Coming soon") {
            viewModel.showUserMessage("Kundali calculations are being prepared.")
        }
        AstroServiceCard("Kundali Milan", "A future compatibility experience for couples and families.", "Coming soon") {
            viewModel.showUserMessage("Kundali Milan is coming soon.")
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun AstrologyOrbitArtwork(modifier: Modifier, selectedGlyph: String) {
    Box(
        modifier.clip(RoundedCornerShape(28.dp)).background(
            Brush.linearGradient(listOf(Color(0xFFFFF1E1), Color(0xFFFFE8F0), Color(0xFFECE5FF)))
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.51f
            val base = min(size.width * 0.26f, size.height * 0.34f)
            val center = Offset(cx, cy)
            val ringSizes = listOf(1.55f, 2.05f, 2.55f)
            ringSizes.forEachIndexed { index, scale ->
                val rx = base * scale
                val ry = base * scale * 0.72f
                drawArc(
                    color = listOf(AstroGold, AstroPink, AstroLilac)[index].copy(alpha = 0.48f),
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    topLeft = Offset(cx - rx, cy - ry), size = Size(rx * 2f, ry * 2f),
                    style = Stroke(width = (1.1f + (index * 0.25f)).dp.toPx())
                )
            }
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFFFFDF7), Color(0xFFFFC2D8), Color(0xFFB48BE8), Color(0xFF5B2A73)),
                    center = Offset(cx - base * 0.16f, cy - base * 0.22f), radius = base * 1.45f
                ), radius = base, center = center
            )
            drawCircle(Color.White.copy(alpha = 0.65f), radius = base * 0.11f, center = Offset(cx - base * 0.35f, cy - base * 0.42f))
            drawCircle(Color(0xFFFFD782).copy(alpha = 0.9f), radius = base * 0.065f, center = Offset(cx + base * 0.57f, cy + base * 0.18f))
            for (i in 0 until 12) {
                val angle = (i * 30.0 - 90.0) * Math.PI / 180.0
                val x = cx + (base * 1.52f * cos(angle)).toFloat()
                val y = cy + (base * 1.05f * sin(angle)).toFloat()
                drawCircle(if (i % 3 == 0) AstroGold else AstroPlum.copy(alpha = 0.52f), radius = if (i % 3 == 0) 3.0f.dp.toPx() else 1.8f.dp.toPx(), center = Offset(x, y))
            }
            val stars = listOf(Offset(size.width * 0.12f, size.height * 0.22f), Offset(size.width * 0.83f, size.height * 0.18f), Offset(size.width * 0.16f, size.height * 0.78f), Offset(size.width * 0.86f, size.height * 0.78f), Offset(size.width * 0.72f, size.height * 0.38f))
            stars.forEachIndexed { i, p ->
                drawLine(AstroGold.copy(alpha = 0.78f), Offset(p.x - 5.dp.toPx(), p.y), Offset(p.x + 5.dp.toPx(), p.y), strokeWidth = 1.2f.dp.toPx())
                drawLine(AstroGold.copy(alpha = 0.78f), Offset(p.x, p.y - 5.dp.toPx()), Offset(p.x, p.y + 5.dp.toPx()), strokeWidth = 1.2f.dp.toPx())
                if (i % 2 == 0) drawCircle(Color.White.copy(alpha = 0.85f), radius = 2.dp.toPx(), center = p)
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 13.dp),
            color = Color.White.copy(alpha = 0.82f), shape = RoundedCornerShape(20.dp)
        ) {
            Text("VEDIC • ZODIAC • COSMOS", color = AstroPlum, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp))
        }
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
            color = AstroPlum.copy(alpha = 0.88f), shape = CircleShape
        ) {
            Text("Selected sign  $selectedGlyph", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 15.dp, vertical = 7.dp))
        }
    }
}

@Composable
private fun AstroServiceCard(title: String, description: String, tag: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = Color.White,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF0E4EB))
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFFFEEF4)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.WbSunny, contentDescription = null, tint = AstroPink, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = AstroPlum, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(description, color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
            }
            Text(tag, color = AstroPink, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}
