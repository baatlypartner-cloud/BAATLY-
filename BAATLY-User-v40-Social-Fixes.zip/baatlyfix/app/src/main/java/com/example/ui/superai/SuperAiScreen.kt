package com.example.ui.superai

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

private val Plum = Color(0xFF2B163D)
private val Cream = Color(0xFFFFF8F3)
private val Rose = Color(0xFFFFD6E5)

@Composable
fun SuperAiScreen(onBackToSocial: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFFF7EE), Color(0xFFFFE8F1), Color(0xFFEAE0FF))))) {
        // The artwork is a screen-wide atmosphere, not a separate poster/card.
        Image(
            painter = painterResource(id = com.example.R.drawable.super_ai_hero),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().graphicsLayer { alpha = 0.34f }
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to Color(0xEFFFF8F3),
                    0.34f to Color(0x55FFF1F7),
                    0.70f to Color(0x66F4E7FF),
                    1f to Color(0xF5FFF8F3)
                )
            )
        )
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("BAATLY", color = Plum, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 0.4.sp)
                    Text("S U P E R  A I", color = VibrantPink, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.7.sp)
                }
                Surface(shape = CircleShape, color = Color.White.copy(alpha = 0.8f), shadowElevation = 2.dp) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = "Super AI", tint = Plum, modifier = Modifier.padding(11.dp).size(22.dp))
                }
            }
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                FeaturePill(Icons.Filled.GraphicEq, "VOICE", Modifier.weight(1f))
                FeaturePill(Icons.Filled.Sms, "CHAT", Modifier.weight(1f))
                FeaturePill(Icons.Filled.AutoAwesome, "CREATE", Modifier.weight(1f))
            }
            Spacer(Modifier.height(34.dp))
            Text("Your own world\nof intelligent conversation", color = Plum, fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text("An expressive AI companion for talking, creating and exploring—in your language, your style.", color = Color(0xFF67566F), fontSize = 14.sp, lineHeight = 21.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 8.dp))
            Spacer(Modifier.height(24.dp))
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = Color(0xFF82145B),
                shadowElevation = 12.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.65f))
            ) {
                Text("C O M I N G   S O O N", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 28.dp, vertical = 15.dp))
            }
            Spacer(Modifier.height(26.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White.copy(alpha = 0.74f),
                shape = RoundedCornerShape(26.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.9f)),
                shadowElevation = 3.dp
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(42.dp).clip(CircleShape).background(Rose), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.SmartToy, contentDescription = null, tint = Plum, modifier = Modifier.size(22.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text("BAATLY Super AI", color = Plum, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("A new experience is taking shape", color = Color(0xFF806E87), fontSize = 11.sp)
                        }
                    }
                    HorizontalDivider(color = Color(0xFFEDE1EB))
                    Text("Designed around natural voice, helpful chat and creative tools. We’ll reveal each capability as it’s ready.", color = Color(0xFF67566F), fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("Made for your next conversation ✨", color = Plum.copy(alpha = 0.78f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun FeaturePill(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.68f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.9f))
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Plum, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(5.dp))
            Text(label, color = Plum, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.6.sp)
        }
    }
}
