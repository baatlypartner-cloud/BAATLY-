package com.example.ui

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AgoraCallManager
import com.example.data.audio.AudioPlayerManager
import com.example.data.audio.AudioRecorderManager
import com.example.data.billing.GooglePlayBillingManager
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.network.AiCallService
import com.example.data.network.AiChatService
import com.example.data.network.AiHostRegistry
import com.example.ui.call.AiCallUiState
import com.example.data.network.SupabaseAuthService
import com.example.data.network.SupabaseClient
import com.example.data.network.SupabaseDataService
import com.example.data.notification.NotificationHelper
import com.example.data.repository.MembershipRepository
import com.example.domain.BillingEngine
import com.example.util.BaatlyAnalytics
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class BaatlyViewModel(application: Application) : AndroidViewModel(application) {

    val sessionManager = SessionManager(application)
    private val supabaseClient = SupabaseClient(sessionManager)
    val authService = SupabaseAuthService(supabaseClient, sessionManager)
    val dataService = SupabaseDataService(supabaseClient, sessionManager)
    val aiChatService = AiChatService(supabaseClient)
    val aiCallService = AiCallService(supabaseClient)

    val billingManager = GooglePlayBillingManager(application.applicationContext, viewModelScope)

    private val _userSelectedIndianState = MutableStateFlow<String?>(sessionManager.getUserSelectedState())
    val userSelectedIndianState: StateFlow<String?> = _userSelectedIndianState.asStateFlow()

    private val _showIndiaStateDialog = MutableStateFlow(false)
    val showIndiaStateDialog: StateFlow<Boolean> = _showIndiaStateDialog.asStateFlow()

    private var pendingAlternativeBillingContinuation: (() -> Unit)? = null

    fun setUserSelectedIndianState(state: String) {
        val normalized = com.example.data.billing.IndiaAdministrativeAreas.normalize(state) ?: state
        if (com.example.data.billing.IndiaAdministrativeAreas.isValid(normalized)) {
            sessionManager.setUserSelectedState(normalized)
            _userSelectedIndianState.value = normalized
            _showIndiaStateDialog.value = false
            val continuation = pendingAlternativeBillingContinuation
            pendingAlternativeBillingContinuation = null
            continuation?.invoke()
        }
    }

    fun dismissIndiaStateDialog() {
        _showIndiaStateDialog.value = false
        pendingAlternativeBillingContinuation = null
    }

    sealed class PendingPurchaseTarget {
        data class Coins(val pkg: CoinPackage, val context: Context?) : PendingPurchaseTarget()
        data class Membership(val plan: MembershipPlan, val context: Context?) : PendingPurchaseTarget()
    }
    private var currentPurchaseTarget: PendingPurchaseTarget? = null

    val membershipRepository = MembershipRepository(dataService, sessionManager, viewModelScope)
    val membershipState: StateFlow<MembershipState> = membershipRepository.membershipState
    val effectivePricing: StateFlow<EffectiveUserPricing> = membershipRepository.effectivePricing
    val activePlan: StateFlow<MembershipPlan> = membershipRepository.activePlan
    val membershipPurchaseUiState: StateFlow<MembershipPurchaseUiState> = membershipRepository.purchaseUiState

    private val _previousScreen = MutableStateFlow<Screen>(Screen.HOME)
    val previousScreen: StateFlow<Screen> = _previousScreen.asStateFlow()

    // Isolated AI Call State
    private val _aiCallSessionId = MutableStateFlow<String?>(null)
    val aiCallSessionId: StateFlow<String?> = _aiCallSessionId.asStateFlow()

    private val _aiCallHost = MutableStateFlow<PartnerProfile?>(null)
    val aiCallHost: StateFlow<PartnerProfile?> = _aiCallHost.asStateFlow()

    private val _aiCallHostId = MutableStateFlow<String?>(null)
    val aiCallHostId: StateFlow<String?> = _aiCallHostId.asStateFlow()

    private val _aiCallVoiceId = MutableStateFlow("ritu")
    val aiCallVoiceId: StateFlow<String> = _aiCallVoiceId.asStateFlow()

    private val _aiCallState = MutableStateFlow(AiCallUiState.CONNECTING)
    val aiCallState: StateFlow<AiCallUiState> = _aiCallState.asStateFlow()

    private val _aiCallElapsedSeconds = MutableStateFlow(0)
    val aiCallElapsedSeconds: StateFlow<Int> = _aiCallElapsedSeconds.asStateFlow()

    private val _aiCallTranscript = MutableStateFlow("")
    val aiCallTranscript: StateFlow<String> = _aiCallTranscript.asStateFlow()

    private val _aiCallReply = MutableStateFlow("")
    val aiCallReply: StateFlow<String> = _aiCallReply.asStateFlow()

    private val _aiCallIsRecording = MutableStateFlow(false)
    val aiCallIsRecording: StateFlow<Boolean> = _aiCallIsRecording.asStateFlow()

    private val _aiCallIsProcessing = MutableStateFlow(false)
    val aiCallIsProcessing: StateFlow<Boolean> = _aiCallIsProcessing.asStateFlow()

    private val _aiCallIsSpeaking = MutableStateFlow(false)
    val aiCallIsSpeaking: StateFlow<Boolean> = _aiCallIsSpeaking.asStateFlow()

    private val _aiCallError = MutableStateFlow<String?>(null)
    val aiCallError: StateFlow<String?> = _aiCallError.asStateFlow()

    private var isStartingAiCall = false
    private var isProcessingAiTurn = false
    private var aiCallTimerJob: Job? = null
    private var aiTurnJob: Job? = null
    private var aiPlaybackJob: Job? = null
    private var currentAiAudioFile: File? = null
    private var currentAiPlaybackFile: File? = null

    // In-memory cache for isolated AI conversations and messages
    private val aiConversationIdByHostId = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val aiMessagesByHostId = java.util.concurrent.ConcurrentHashMap<String, List<ChatMessage>>()
    private val aiConversationSummaries = java.util.concurrent.ConcurrentHashMap<String, ConversationSummary>()

    val agoraCallManager = AgoraCallManager(application)
    val audioRecorderManager = AudioRecorderManager(application)
    val audioPlayerManager = AudioPlayerManager(application)
    val realtimeManager = com.example.data.network.SupabaseRealtimeManager(supabaseClient.okHttpClient, sessionManager)

    // User & Auth State
    val isLoggedIn = sessionManager.accessToken
    val currentUser = sessionManager.currentUser
    val wallet = sessionManager.wallet
    val isOnboardingCompleted = sessionManager.isOnboardingCompletedFlow

    fun completeOnboarding() {
        sessionManager.setOnboardingCompleted(true)
    }

    private val _isRestoringSession = MutableStateFlow(sessionManager.isLoggedIn)
    val isRestoringSession: StateFlow<Boolean> = _isRestoringSession.asStateFlow()

    private val _startupError = MutableStateFlow<String?>(null)
    val startupError: StateFlow<String?> = _startupError.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _userIdAvailable = MutableStateFlow<Boolean?>(null)
    val userIdAvailable: StateFlow<Boolean?> = _userIdAvailable.asStateFlow()

    // Navigation & Screen State
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _homeMode = MutableStateFlow(HomeMode.CALL) // CALL or CHAT
    val homeMode: StateFlow<HomeMode> = _homeMode.asStateFlow()

    // Hosts State
    private val _availablePartners = MutableStateFlow<List<PartnerProfile>>(emptyList())
    val availablePartners: StateFlow<List<PartnerProfile>> = _availablePartners.asStateFlow()

    private val _isLoadingPartners = MutableStateFlow(false)
    val isLoadingPartners: StateFlow<Boolean> = _isLoadingPartners.asStateFlow()

    private val _selectedPartner = MutableStateFlow<PartnerProfile?>(null)
    val selectedPartner: StateFlow<PartnerProfile?> = _selectedPartner.asStateFlow()

    // Call State
    private val _activeCall = MutableStateFlow<CallRecord?>(null)
    val activeCall: StateFlow<CallRecord?> = _activeCall.asStateFlow()

    private val _activeCallPartner = MutableStateFlow<PartnerProfile?>(null)
    val activeCallPartner: StateFlow<PartnerProfile?> = _activeCallPartner.asStateFlow()

    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _callRemainingSeconds = MutableStateFlow(0)
    val callRemainingSeconds: StateFlow<Int> = _callRemainingSeconds.asStateFlow()

    private val _callElapsedSeconds = MutableStateFlow(0)
    val callElapsedSeconds: StateFlow<Int> = _callElapsedSeconds.asStateFlow()

    private var callTimerJob: Job? = null

    // Chat State
    private val _conversations = MutableStateFlow<List<ConversationSummary>>(emptyList())
    val conversations: StateFlow<List<ConversationSummary>> = _conversations.asStateFlow()

    private val _activeConversation = MutableStateFlow<ConversationSummary?>(null)
    val activeConversation: StateFlow<ConversationSummary?> = _activeConversation.asStateFlow()

    private val _chatPartner = MutableStateFlow<PartnerProfile?>(null)
    val chatPartner: StateFlow<PartnerProfile?> = _chatPartner.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    private val conversationMessagesCache = java.util.concurrent.ConcurrentHashMap<String, List<ChatMessage>>()

    private val _isChatBlocked = MutableStateFlow(false)
    val isChatBlocked: StateFlow<Boolean> = _isChatBlocked.asStateFlow()

    // Gifts State
    private val _gifts = MutableStateFlow<List<GiftItem>>(emptyList())
    val gifts: StateFlow<List<GiftItem>> = _gifts.asStateFlow()

    private val _showGiftSheet = MutableStateFlow(false)
    val showGiftSheet: StateFlow<Boolean> = _showGiftSheet.asStateFlow()

    private val _recentGiftAnimation = MutableStateFlow<GiftItem?>(null)
    val recentGiftAnimation: StateFlow<GiftItem?> = _recentGiftAnimation.asStateFlow()

    // Wallet & Packages State
    private val _coinPackages = MutableStateFlow<List<CoinPackage>>(emptyList())
    val coinPackages: StateFlow<List<CoinPackage>> = _coinPackages.asStateFlow()

    private val _transactions = MutableStateFlow<List<TransactionItem>>(emptyList())
    val transactions: StateFlow<List<TransactionItem>> = _transactions.asStateFlow()

    private val _uroPayPaymentState = MutableStateFlow<UroPayPaymentUiState>(UroPayPaymentUiState.Idle)
    val uroPayPaymentState: StateFlow<UroPayPaymentUiState> = _uroPayPaymentState.asStateFlow()

    private val _isProcessingPayment = MutableStateFlow(false)
    val isProcessingPayment: StateFlow<Boolean> = _isProcessingPayment.asStateFlow()

    private var verificationJob: Job? = null
    private var orderCreationJob: Job? = null

    // Recent Calls State
    private val _recentCalls = MutableStateFlow<List<CallRecord>>(emptyList())
    val recentCalls: StateFlow<List<CallRecord>> = _recentCalls.asStateFlow()

    // Notifications State
    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    // Social Media State
    private val _socialPosts = MutableStateFlow<List<SocialPost>>(emptyList())
    val socialPosts: StateFlow<List<SocialPost>> = _socialPosts.asStateFlow()

    private val _socialStories = MutableStateFlow<List<SocialStory>>(emptyList())
    val socialStories: StateFlow<List<SocialStory>> = _socialStories.asStateFlow()

    private val _isLoadingSocial = MutableStateFlow(false)
    val isLoadingSocial: StateFlow<Boolean> = _isLoadingSocial.asStateFlow()

    private val _isRefreshingSocial = MutableStateFlow(false)
    val isRefreshingSocial: StateFlow<Boolean> = _isRefreshingSocial.asStateFlow()

    private val _mySocialProfile = MutableStateFlow<SocialProfile?>(null)
    val mySocialProfile: StateFlow<SocialProfile?> = _mySocialProfile.asStateFlow()

    private val _viewedSocialProfile = MutableStateFlow<SocialProfile?>(null)
    val viewedSocialProfile: StateFlow<SocialProfile?> = _viewedSocialProfile.asStateFlow()

    private val _isLoadingSocialProfile = MutableStateFlow(false)
    val isLoadingSocialProfile: StateFlow<Boolean> = _isLoadingSocialProfile.asStateFlow()

    private val _activeStoryViewer = MutableStateFlow<SocialStory?>(null)
    val activeStoryViewer: StateFlow<SocialStory?> = _activeStoryViewer.asStateFlow()

    private val _activePostViewer = MutableStateFlow<SocialPost?>(null)
    val activePostViewer: StateFlow<SocialPost?> = _activePostViewer.asStateFlow()

    private val _isRenewingPost = MutableStateFlow<String?>(null)
    val isRenewingPost: StateFlow<String?> = _isRenewingPost.asStateFlow()

    private val _activeCommentsPost = MutableStateFlow<SocialPost?>(null)
    val activeCommentsPost: StateFlow<SocialPost?> = _activeCommentsPost.asStateFlow()

    private val _activeCommentsStory = MutableStateFlow<SocialStory?>(null)
    val activeCommentsStory: StateFlow<SocialStory?> = _activeCommentsStory.asStateFlow()

    private val _socialComments = MutableStateFlow<List<SocialComment>>(emptyList())
    val socialComments: StateFlow<List<SocialComment>> = _socialComments.asStateFlow()

    private val _isLoadingComments = MutableStateFlow(false)
    val isLoadingComments: StateFlow<Boolean> = _isLoadingComments.asStateFlow()

    private val _socialSearchResult = MutableStateFlow<SocialSearchResult?>(null)
    val socialSearchResult: StateFlow<SocialSearchResult?> = _socialSearchResult.asStateFlow()

    private val _isSearchingSocial = MutableStateFlow(false)
    val isSearchingSocial: StateFlow<Boolean> = _isSearchingSocial.asStateFlow()

    private val _socialSearchError = MutableStateFlow<String?>(null)
    val socialSearchError: StateFlow<String?> = _socialSearchError.asStateFlow()

    // General Toast / SnackBar State
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Legal & Safety Center State
    private val _activeLegalPage = MutableStateFlow<com.example.ui.legal.LegalPage?>(null)
    val activeLegalPage: StateFlow<com.example.ui.legal.LegalPage?> = _activeLegalPage.asStateFlow()

    private data class PendingNotificationNavigation(val type: String?, val extras: Map<String, String?>)
    private var pendingNotification: PendingNotificationNavigation? = null

    init {
        viewModelScope.launch {
            _currentScreen.collect { screen ->
                NotificationHelper.currentScreenName = screen.name
            }
        }
        viewModelScope.launch {
            _activeConversation.collect { conv ->
                NotificationHelper.activeConversationId = conv?.id
            }
        }
        viewModelScope.launch {
            billingManager.userChoiceEvents.collect { event ->
                when (event) {
                    is GooglePlayBillingManager.UserChoiceEvent.AlternativeBillingSelected -> {
                        Log.d("BaatlyViewModel", "Google Play Alternative Billing selected; token received")
                        handleAlternativeBillingSelected(event.externalTransactionToken)
                    }
                }
            }
        }
        viewModelScope.launch {
            billingManager.googlePurchases.collect { purchases ->
                for (purchase in purchases) {
                    val acked = billingManager.consumeOrAcknowledgePurchase(purchase)
                    Log.d("BaatlyViewModel", "Google Play purchase processed: orderId=${purchase.orderId}, acked=$acked")
                }
                dataService.fetchWallet()
                dataService.fetchTransactions().onSuccess { _transactions.value = it }
                membershipRepository.refreshMembership()
            }
        }
        if (sessionManager.isLoggedIn || !sessionManager.refreshToken.value.isNullOrBlank()) {
            loadInitialData()
        } else {
            _isRestoringSession.value = false
        }
    }

    private fun handleAlternativeBillingSelected(externalTransactionToken: String) {
        val target = currentPurchaseTarget
        if (target == null) {
            Log.w("BaatlyViewModel", "handleAlternativeBillingSelected: no pending purchase target found")
            return
        }

        val state = _userSelectedIndianState.value
        if (state.isNullOrBlank() || !com.example.data.billing.IndiaAdministrativeAreas.isValid(state)) {
            Log.d("BaatlyViewModel", "No valid Indian state selected. Prompting user for state selection.")
            pendingAlternativeBillingContinuation = {
                val chosenState = _userSelectedIndianState.value
                if (!chosenState.isNullOrBlank() && com.example.data.billing.IndiaAdministrativeAreas.isValid(chosenState)) {
                    executeAlternativeBillingPurchase(target, externalTransactionToken, chosenState)
                }
            }
            _showIndiaStateDialog.value = true
            return
        }

        executeAlternativeBillingPurchase(target, externalTransactionToken, state)
    }

    private fun executeAlternativeBillingPurchase(
        target: PendingPurchaseTarget,
        externalTransactionToken: String,
        state: String
    ) {
        when (target) {
            is PendingPurchaseTarget.Coins -> {
                purchaseCoinPackageInternal(
                    pkg = target.pkg,
                    context = target.context,
                    externalTransactionToken = externalTransactionToken,
                    administrativeArea = state
                )
            }
            is PendingPurchaseTarget.Membership -> {
                if (target.context != null) {
                    viewModelScope.launch {
                        membershipRepository.startMembershipPurchase(
                            context = target.context,
                            externalTransactionToken = externalTransactionToken,
                            administrativeArea = state
                        )
                    }
                }
            }
        }
    }

    fun setScreen(screen: Screen) {
        if (screen != _currentScreen.value) {
            _previousScreen.value = _currentScreen.value
        }
        _currentScreen.value = screen
    }

    fun onMembershipScreenOpened() {
        BaatlyAnalytics.logMembershipScreenOpened(
            userId = sessionManager.userId.value,
            isMember = effectivePricing.value.isMember
        )
        refreshMembership()
    }

    fun refreshMembership() {
        viewModelScope.launch {
            membershipRepository.refreshMembership()
        }
    }

    fun buyMembership(context: Context, activity: Activity? = null) {
        val plan = activePlan.value
        val playProductId = com.example.data.billing.GooglePlayProductMapper.getGooglePlayProductIdForMembershipPlan(plan.id)
        if (activity != null && billingManager.isReady.value && !playProductId.isNullOrBlank()) {
            currentPurchaseTarget = PendingPurchaseTarget.Membership(plan, context)
            viewModelScope.launch {
                val launched = billingManager.launchBillingFlow(activity, playProductId, isSubscription = true)
                if (!launched) {
                    Log.d("BaatlyViewModel", "Google Play billing flow not launched, falling back to direct UroPay checkout")
                    val state = _userSelectedIndianState.value
                    membershipRepository.startMembershipPurchase(context, null, state)
                }
            }
        } else {
            viewModelScope.launch {
                val state = _userSelectedIndianState.value
                membershipRepository.startMembershipPurchase(context, null, state)
            }
        }
    }

    fun resetMembershipPurchaseUiState() {
        membershipRepository.resetPurchaseUiState()
    }

    fun handleMembershipBack() {
        val prev = _previousScreen.value
        _currentScreen.value = if (prev == Screen.MEMBERSHIP || prev == Screen.AUTH) Screen.HOME else prev
    }

    fun setHomeMode(mode: HomeMode) {
        _homeMode.value = mode
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    fun toggleGiftSheet(show: Boolean) {
        _showGiftSheet.value = show
    }

    fun openLegalPage(page: com.example.ui.legal.LegalPage) {
        _activeLegalPage.value = page
        _currentScreen.value = Screen.LEGAL_DETAIL
    }

    fun closeLegalPage() {
        _activeLegalPage.value = null
        _currentScreen.value = Screen.PROFILE
    }

    // AUTH FLOWS
    fun checkUserIdAvailability(userId: String) {
        if (userId.length < 3) {
            _userIdAvailable.value = null
            return
        }
        viewModelScope.launch {
            val isAvail = authService.checkUserIdAvailable(userId)
            _userIdAvailable.value = isAvail
        }
    }

    fun signIn(userId: String, password: String) {
        if (userId.isBlank() || password.isBlank()) {
            _authError.value = "Please enter both User ID and Password."
            return
        }
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            val result = authService.signIn(userId, password)
            _isAuthLoading.value = false
            result.onSuccess {
                loadInitialData()
                _currentScreen.value = Screen.HOME
            }.onFailure { error ->
                _authError.value = error.message ?: "Authentication failed."
            }
        }
    }

    fun signUp(
        displayName: String,
        userId: String,
        password: String,
        mobileNumber: String,
        avatarFile: File? = null,
        referralCode: String? = null
    ) {
        val normalizedUserId = userId.trim().lowercase()

        // Validation 1: User ID
        val userIdRegex = Regex("""^[a-z0-9._-]{3,30}$""")
        if (!userIdRegex.matches(normalizedUserId)) {
            _authError.value = "User ID must be 3-30 characters (letters, numbers, '.', '_', '-')."
            return
        }

        // Validation 2: Display Name
        if (displayName.trim().isBlank()) {
            _authError.value = "Display Name is required."
            return
        }

        // Validation 3: Password
        if (password.length < 6) {
            _authError.value = "Password must be at least 6 characters."
            return
        }

        // Validation 4: Mobile Number (10 digits)
        val cleanPhone = mobileNumber.trim().replace("+91", "").replace(" ", "").replace("-", "").filter { it.isDigit() }
        val mobileRegex = Regex("""^[0-9]{10}$""")
        if (!mobileRegex.matches(cleanPhone)) {
            _authError.value = "Please enter a valid 10-digit mobile number."
            return
        }

        _isAuthLoading.value = true
        _authError.value = null

        viewModelScope.launch {
            val result = authService.signUp(
                userId = normalizedUserId,
                password = password,
                displayName = displayName.trim(),
                mobileNumber = cleanPhone,
                avatarFile = avatarFile,
                referralCode = referralCode?.trim().takeIf { !it.isNullOrBlank() }
            )
            _isAuthLoading.value = false
            result.onSuccess {
                loadInitialData()
                _currentScreen.value = Screen.HOME
            }.onFailure { error ->
                _authError.value = error.message ?: "Sign up failed."
            }
        }
    }

    fun clearAuthError() {
        _authError.value = null
        _userIdAvailable.value = null
    }

    fun updateUserProfile(
        displayName: String,
        bio: String?,
        avatarFile: File? = null,
        onComplete: ((Boolean, String?) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val res = authService.updateProfile(displayName, bio, avatarFile)
            res.onSuccess { updated ->
                _userMessage.value = "Profile updated successfully!"
                onComplete?.invoke(true, null)
            }.onFailure { err ->
                val errorMsg = err.message ?: "Failed to update profile."
                _userMessage.value = errorMsg
                onComplete?.invoke(false, errorMsg)
            }
        }
    }

    fun signOut() {
        val currentToken = sessionManager.fcmToken.value
        viewModelScope.launch {
            try {
                dataService.deactivateFcmToken(currentToken)
            } catch (_: Exception) {}
        }
        authService.signOut()
        _availablePartners.value = emptyList()
        _conversations.value = emptyList()
        _recentCalls.value = emptyList()
        _notifications.value = emptyList()
        _socialPosts.value = emptyList()
        _mySocialProfile.value = null
        _currentScreen.value = Screen.AUTH
    }

    private val _isSubmittingDeletion = MutableStateFlow(false)
    val isSubmittingDeletion: StateFlow<Boolean> = _isSubmittingDeletion.asStateFlow()

    fun requestAccountDeletion(onResult: (Boolean, String) -> Unit) {
        if (_isSubmittingDeletion.value) return
        _isSubmittingDeletion.value = true
        viewModelScope.launch {
            try {
                val res = authService.requestAccountDeletion()
                _isSubmittingDeletion.value = false
                res.fold(
                    onSuccess = {
                        val successMsg = "Your account deletion request has been submitted successfully."
                        _userMessage.value = successMsg
                        onResult(true, successMsg)
                    },
                    onFailure = { err ->
                        Log.e("BaatlyViewModel", "Account deletion request failed: ${err.message}", err)
                        val errorMsg = "We could not submit the deletion request. Please try again."
                        _userMessage.value = errorMsg
                        onResult(false, errorMsg)
                    }
                )
            } catch (e: Exception) {
                _isSubmittingDeletion.value = false
                Log.e("BaatlyViewModel", "Account deletion request exception: ${e.message}", e)
                val errorMsg = "We could not submit the deletion request. Please try again."
                _userMessage.value = errorMsg
                onResult(false, errorMsg)
            }
        }
    }

    fun retryStartup() {
        _startupError.value = null
        if (sessionManager.isLoggedIn || !sessionManager.refreshToken.value.isNullOrBlank()) {
            loadInitialData()
        }
    }

    fun syncFcmToken() {
        if (!sessionManager.isLoggedIn || sessionManager.userId.value.isNullOrBlank()) return

        // 1. If we have a cached FCM token in prefs, attempt immediate registration
        val cachedToken = sessionManager.fcmToken.value
        if (!cachedToken.isNullOrBlank()) {
            viewModelScope.launch {
                dataService.registerFcmToken(cachedToken)
            }
        }

        // 2. Fetch fresh token from FirebaseMessaging
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful && !task.result.isNullOrBlank()) {
                    val token = task.result
                    sessionManager.saveFcmToken(token)
                    viewModelScope.launch {
                        dataService.registerFcmToken(token)
                    }
                } else {
                    Log.d("BaatlyViewModel", "FCM get token task: ${task.exception?.message}")
                }
            }
        } catch (e: Exception) {
            Log.w("BaatlyViewModel", "FirebaseMessaging token sync error: ${e.message}")
        }
    }

    fun handleNotificationTap(type: String?, extras: Map<String, String?>) {
        if (_isRestoringSession.value) {
            Log.d("BaatlyViewModel", "Session restoration in progress, queuing notification tap...")
            pendingNotification = PendingNotificationNavigation(type, extras)
            return
        }

        if (!sessionManager.isLoggedIn) {
            _currentScreen.value = Screen.AUTH
            return
        }

        val notifId = extras["notification_id"] ?: extras["id"]
        if (!notifId.isNullOrBlank()) {
            markNotificationAsRead(notifId)
        }

        val notifType = (type ?: extras["notification_type"] ?: extras["type"] ?: "").lowercase()
        val conversationId = extras["conversation_id"] ?: extras["conversationId"]
        val partnerId = extras["partner_id"] ?: extras["partnerId"] ?: extras["sender_id"] ?: extras["senderId"] ?: extras["creator_id"] ?: extras["owner_id"] ?: extras["target_user_id"]
        val callId = extras["call_id"] ?: extras["callId"]
        val storyId = extras["story_id"] ?: extras["storyId"]
        val postId = extras["post_id"] ?: extras["postId"]
        val contentId = extras["content_id"] ?: extras["contentId"] ?: storyId ?: postId
        val contentType = (extras["content_type"] ?: extras["contentType"] ?: if (storyId != null) "story" else if (postId != null) "post" else "").lowercase()

        when (notifType) {
            "new_message", "chat" -> {
                if (!conversationId.isNullOrBlank()) {
                    val conv = _conversations.value.find { it.id == conversationId }
                    if (conv != null) {
                        openConversation(conv)
                        return
                    }
                }
                if (!partnerId.isNullOrBlank()) {
                    val partner = _availablePartners.value.find { it.id == partnerId || it.userId == partnerId }
                    if (partner != null) {
                        openChatWithHost(partner)
                        return
                    }
                }
                _currentScreen.value = Screen.CHAT_LIST
            }
            "incoming_call", "call" -> {
                _currentScreen.value = Screen.RECENT_CALLS
            }
            "story_reply" -> {
                if (!conversationId.isNullOrBlank()) {
                    val conv = _conversations.value.find { it.id == conversationId }
                    if (conv != null) {
                        openConversation(conv)
                        return
                    }
                }
                if (!partnerId.isNullOrBlank()) {
                    val partner = _availablePartners.value.find { it.id == partnerId || it.userId == partnerId }
                    if (partner != null) {
                        openChatWithHost(partner)
                        return
                    } else {
                        openSocialProfile(partnerId)
                        return
                    }
                }
                _currentScreen.value = Screen.SOCIAL
            }
            "follow", "profile", "user" -> {
                if (!partnerId.isNullOrBlank()) {
                    val partner = _availablePartners.value.find { it.id == partnerId || it.userId == partnerId }
                    if (partner != null) {
                        openHostProfile(partner)
                    } else {
                        openSocialProfile(partnerId)
                    }
                    return
                }
                _currentScreen.value = Screen.SOCIAL
            }
            "like", "social_like" -> {
                _currentScreen.value = Screen.SOCIAL
                if (contentType == "story" || !storyId.isNullOrBlank()) {
                    val targetStoryId = storyId ?: contentId
                    val story = _socialStories.value.find { it.id == targetStoryId }
                    if (story != null) {
                        openStoryViewer(story)
                    }
                } else {
                    val targetPostId = postId ?: contentId
                    val post = _socialPosts.value.find { it.id == targetPostId }
                    if (post != null) {
                        openCommentsForPost(post)
                    }
                }
            }
            "comment", "social_comment" -> {
                _currentScreen.value = Screen.SOCIAL
                if (contentType == "story" || !storyId.isNullOrBlank()) {
                    val targetStoryId = storyId ?: contentId
                    val story = _socialStories.value.find { it.id == targetStoryId }
                    if (story != null) {
                        openCommentsForStory(story)
                    }
                } else {
                    val targetPostId = postId ?: contentId
                    val post = _socialPosts.value.find { it.id == targetPostId }
                    if (post != null) {
                        openCommentsForPost(post)
                    }
                }
            }
            "new_post", "social_post" -> {
                _currentScreen.value = Screen.SOCIAL
                refreshSocialFeed()
                val targetPostId = postId ?: contentId
                if (!targetPostId.isNullOrBlank()) {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(400)
                        val post = _socialPosts.value.find { it.id == targetPostId }
                        if (post != null) {
                            openCommentsForPost(post)
                        }
                    }
                }
            }
            "new_story" -> {
                _currentScreen.value = Screen.SOCIAL
                refreshSocialFeed()
                val targetStoryId = storyId ?: contentId
                if (!targetStoryId.isNullOrBlank()) {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(400)
                        val story = _socialStories.value.find { it.id == targetStoryId }
                        if (story != null) {
                            openStoryViewer(story)
                        }
                    }
                }
            }
            "gift", "gift_received", "wallet" -> {
                if (!conversationId.isNullOrBlank()) {
                    val conv = _conversations.value.find { it.id == conversationId }
                    if (conv != null) {
                        openConversation(conv)
                        return
                    }
                }
                _currentScreen.value = Screen.WALLET
            }
            "system", "admin", "notification" -> {
                _currentScreen.value = Screen.NOTIFICATIONS
            }
            else -> {
                _currentScreen.value = Screen.HOME
            }
        }
    }

    fun markNotificationAsRead(notificationId: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == notificationId) it.copy(isRead = true) else it
        }
        viewModelScope.launch {
            dataService.markNotificationAsRead(notificationId)
        }
    }

    fun loadInitialData() {
        _isRestoringSession.value = true
        _startupError.value = null
        viewModelScope.launch {
            try {
                // 1. Authoritatively restore or refresh the Supabase session
                val sessionValid = authService.restoreOrRefreshSession()
                if (!sessionValid) {
                    sessionManager.clearSession()
                    _isRestoringSession.value = false
                    return@launch
                }

                // Sync FCM Token with backend upon valid session
                syncFcmToken()

                // 2. Concurrently fetch all primary user and startup data from Supabase
                coroutineScope {
                    val profileDeferred = async { authService.fetchCurrentUserProfile() }
                    val walletDeferred = async { dataService.fetchWallet() }
                    val partnersDeferred = async { dataService.getAvailablePartners() }
                    val giftsDeferred = async { dataService.fetchGifts() }
                    val packagesDeferred = async { dataService.fetchCoinPackages() }
                    val transactionsDeferred = async { dataService.fetchTransactions() }
                    val convDeferred = async { dataService.fetchConversations() }
                    val callsDeferred = async { dataService.fetchRecentCalls() }
                    val notifDeferred = async { dataService.fetchNotifications() }
                    val storiesDeferred = async { dataService.getSocialStories() }
                    val feedDeferred = async { dataService.getSocialFeed(page = 0, limit = 30) }
                    val membershipDeferred = async { membershipRepository.refreshMembership() }

                    val partnersRes = partnersDeferred.await()
                    val giftsRes = giftsDeferred.await()
                    val packagesRes = packagesDeferred.await()
                    val transactionsRes = transactionsDeferred.await()
                    val convRes = convDeferred.await()
                    val callsRes = callsDeferred.await()
                    val notifRes = notifDeferred.await()
                    val storiesRes = storiesDeferred.await()
                    val feedRes = feedDeferred.await()
                    profileDeferred.await()
                    walletDeferred.await()
                    membershipDeferred.await()

                    partnersRes.onSuccess { _availablePartners.value = it }
                    giftsRes.onSuccess { _gifts.value = it }
                    packagesRes.onSuccess { _coinPackages.value = it }
                    transactionsRes.onSuccess { _transactions.value = it }
                    convRes.onSuccess { _conversations.value = it }
                    callsRes.onSuccess { _recentCalls.value = it }
                    notifRes.onSuccess { _notifications.value = it }
                    storiesRes.onSuccess { _socialStories.value = it }
                    feedRes.onSuccess { _socialPosts.value = it }
                }

                val currentUserId = sessionManager.userId.value ?: ""
                if (currentUserId.isNotBlank()) {
                    dataService.getSocialProfile(currentUserId).onSuccess { profile ->
                        val postsRes = dataService.getUserSocialPosts(currentUserId).getOrDefault(emptyList())
                        val storiesRes = dataService.getUserSocialStories(currentUserId).getOrDefault(emptyList())
                        _mySocialProfile.value = profile.copy(
                            posts = postsRes,
                            stories = storiesRes
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e("BaatlyViewModel", "Initial data loading error: ${e.message}", e)
                if (sessionManager.currentUser.value == null && sessionManager.wallet.value == null) {
                    _startupError.value = "Failed to connect to server. Please check your internet connection."
                }
            } finally {
                _isRestoringSession.value = false
                val pending = pendingNotification
                if (pending != null) {
                    pendingNotification = null
                    handleNotificationTap(pending.type, pending.extras)
                }
                // Check if there is an active pending UroPay payment to auto-verify
                val pendingPayment = sessionManager.getPendingPayment()
                if (pendingPayment != null) {
                    val age = System.currentTimeMillis() - pendingPayment.createdAt
                    if (age < 2 * 60 * 60 * 1000L) {
                        Log.d("BaatlyViewModel", "Resuming pending payment verification on startup: ${pendingPayment.paymentId}")
                        verifyPayment(
                            paymentId = pendingPayment.paymentId,
                            coins = pendingPayment.coins,
                            priceInr = pendingPayment.priceInr,
                            isAutoResume = true
                        )
                    } else {
                        sessionManager.clearPendingPayment()
                    }
                }
            }
        }
    }

    fun refreshPartners() {
        _isLoadingPartners.value = true
        viewModelScope.launch {
            dataService.getAvailablePartners().onSuccess {
                _availablePartners.value = it
            }
            _isLoadingPartners.value = false
        }
    }

    fun refreshGifts() {
        viewModelScope.launch {
            dataService.fetchGifts().onSuccess {
                _gifts.value = it
            }
        }
    }

    fun refreshCoinPackages() {
        viewModelScope.launch {
            dataService.fetchCoinPackages().onSuccess {
                _coinPackages.value = it
            }
        }
    }

    fun refreshTransactions() {
        viewModelScope.launch {
            dataService.fetchTransactions().onSuccess {
                _transactions.value = it
            }
        }
    }

    fun refreshConversations() {
        viewModelScope.launch {
            dataService.fetchConversations().onSuccess { realConvs ->
                val aiConvs = aiConversationSummaries.values.toList()
                val realPartnerIds = realConvs.mapNotNull { it.partnerId ?: it.partner?.id }.toSet()
                val filteredAiConvs = aiConvs.filter { (it.partnerId ?: it.partner?.id) !in realPartnerIds }
                _conversations.value = filteredAiConvs + realConvs
            }
        }
    }

    fun refreshRecentCalls() {
        viewModelScope.launch {
            dataService.fetchRecentCalls().onSuccess {
                _recentCalls.value = it
            }
        }
    }

    fun refreshNotifications() {
        viewModelScope.launch {
            dataService.fetchNotifications().onSuccess {
                _notifications.value = it
            }
        }
    }

    fun refreshWallet() {
        viewModelScope.launch {
            dataService.fetchWallet()
        }
    }

    // HOST ACTIONS
    fun openHostProfile(partner: PartnerProfile) {
        _selectedPartner.value = partner
        _currentScreen.value = Screen.HOST_PROFILE
        if (AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)) {
            Log.d("BaatlySecurity", "[AI_HOST] openHostProfile for AI host: ${partner.displayName} (${partner.id}) - skipping real getHostProfile")
            return
        }
        viewModelScope.launch {
            val res = dataService.getHostProfile(partner.id)
            res.onSuccess { authoritativeProfile ->
                _selectedPartner.value = authoritativeProfile
                _availablePartners.value = _availablePartners.value.map {
                    if (it.id == authoritativeProfile.id) authoritativeProfile else it
                }
            }
        }
    }

    fun toggleFollowHost(partner: PartnerProfile) {
        if (AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)) {
            val currentFollowing = partner.isFollowing
            val newFollowing = !currentFollowing
            val updatedPartner = partner.copy(
                isFollowing = newFollowing,
                followersCount = if (newFollowing) partner.followersCount + 1 else (partner.followersCount - 1).coerceAtLeast(0)
            )
            _selectedPartner.value = updatedPartner
            _availablePartners.value = _availablePartners.value.map {
                if (it.id == partner.id) updatedPartner else it
            }
            return
        }
        val targetId = partner.id.takeIf { it.isNotBlank() } ?: partner.userId ?: ""
        if (targetId.isNotBlank()) {
            toggleSocialFollow(targetId)
        }
    }

    // CALL FLOW
    private var callPollerJob: Job? = null

    fun requestCall(partner: PartnerProfile) {
        if (AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)) {
            _userMessage.value = "Voice calls with ${partner.displayName} are not available yet."
            return
        }

        if (!partner.isEligibleForAudioCall) {
            _userMessage.value = "This host is currently not available for audio calls."
            return
        }

        val currentBalance = wallet.value?.balance ?: 0
        val callCostPerMin = effectivePricing.value.callCoinsPerMinute
        if (currentBalance < callCostPerMin) {
            _userMessage.value = "You don't have enough coins ($callCostPerMin coins/min required). Please top up your wallet."
            _currentScreen.value = Screen.WALLET
            return
        }

        val estimatedMaxSeconds = BillingEngine.calculateMaxCallDurationSeconds(currentBalance, callCostPerMin)
        _activeCallPartner.value = partner
        _callState.value = CallState.REQUESTING
        _callRemainingSeconds.value = estimatedMaxSeconds
        _callElapsedSeconds.value = 0
        _currentScreen.value = Screen.ACTIVE_CALL

        viewModelScope.launch {
            val result = dataService.requestCall(partner.id)
            result.onSuccess { callRecord ->
                _activeCall.value = callRecord
                _callState.value = CallState.RINGING
                startCallStatePoller(callRecord, partner)
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Could not connect call."
                endCall()
            }
        }
    }

    private fun startCallStatePoller(initialCall: CallRecord, partner: PartnerProfile) {
        callPollerJob?.cancel()
        callPollerJob = viewModelScope.launch {
            var currentCall = initialCall
            var joinedAgora = false

            while (_callState.value != CallState.ENDED && _callState.value != CallState.IDLE) {
                delay(1500)
                val statusResult = dataService.getCallRecord(currentCall.id)
                if (statusResult.isSuccess) {
                    val updated = statusResult.getOrThrow()
                    currentCall = updated
                    _activeCall.value = updated

                    when (updated.status.lowercase()) {
                        "ringing" -> {
                            if (_callState.value != CallState.RINGING) {
                                _callState.value = CallState.RINGING
                            }
                        }
                        "accepted", "connected" -> {
                            val channelName = updated.agoraChannelId
                            if (!joinedAgora && !channelName.isNullOrBlank()) {
                                joinedAgora = true
                                android.util.Log.i("BaatlyViewModel", "Using authoritative calls.agora_channel_id: $channelName")
                                dataService.getAgoraToken(channelName).onSuccess { tokenResp ->
                                    android.util.Log.i("BaatlyViewModel", "Joining Agora with exact channel: $channelName, token channel: ${tokenResp.channelName}")
                                    agoraCallManager.joinChannel(tokenResp, channelName)
                                }.onFailure { err ->
                                    android.util.Log.e("BaatlyViewModel", "Failed to get Agora token for channel '$channelName': ${err.message}", err)
                                }

                                if (updated.status.lowercase() == "accepted") {
                                    dataService.updateCallState(updated.id, "connected")
                                }
                                _callState.value = CallState.CONNECTED

                                val maxSec = updated.maxDurationSeconds
                                    ?.takeIf { it > 0 }
                                    ?: BillingEngine.calculateMaxCallDurationSeconds(wallet.value?.balance ?: 0)
                                startCallCountdown(maxSec)
                            }
                        }
                        "completed", "ended", "cancelled", "rejected", "missed" -> {
                            val statusLower = updated.status.lowercase()
                            val msg = when (statusLower) {
                                "rejected" -> "Host declined the call."
                                "missed" -> "No answer. Call was missed."
                                else -> "Call ended."
                            }
                            _userMessage.value = msg
                            handleCallTerminated(statusLower)
                            break
                        }
                    }
                }
            }
        }
    }

    private fun handleCallTerminated(status: String) {
        callPollerJob?.cancel()
        callTimerJob?.cancel()
        agoraCallManager.leaveChannel()

        val call = _activeCall.value
        val wasConnected = _callState.value == CallState.CONNECTED
        if (call != null && wasConnected && status != "missed" && status != "rejected" && status != "cancelled" && status != "failed") {
            viewModelScope.launch {
                dataService.updateCallState(call.id, "completed")
                dataService.settleCall(call.id)
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        } else if (call != null) {
            viewModelScope.launch {
                val finalStatus = when (status) {
                    "missed" -> "missed"
                    "rejected" -> "rejected"
                    else -> "cancelled"
                }
                dataService.updateCallState(call.id, finalStatus)
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        } else {
            viewModelScope.launch {
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        }

        _callState.value = CallState.ENDED
        _activeCall.value = null
        if (_currentScreen.value == Screen.ACTIVE_CALL) {
            _currentScreen.value = Screen.HOME
        }
    }

    private fun startCallCountdown(maxDurationSec: Int) {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            var remaining = maxDurationSec
            var elapsed = 0
            _callRemainingSeconds.value = remaining
            _callElapsedSeconds.value = elapsed

            while (remaining > 0 && _callState.value == CallState.CONNECTED) {
                delay(1000)
                remaining--
                elapsed++
                _callRemainingSeconds.value = remaining
                _callElapsedSeconds.value = elapsed
            }
            if (remaining <= 0 && _callState.value == CallState.CONNECTED) {
                _userMessage.value = "Call ended: Maximum duration reached based on your coin balance."
                endCall()
            }
        }
    }

    fun endCall() {
        callPollerJob?.cancel()
        callTimerJob?.cancel()
        agoraCallManager.leaveChannel()

        val call = _activeCall.value
        val wasConnected = _callState.value == CallState.CONNECTED
        if (call != null) {
            viewModelScope.launch {
                if (wasConnected) {
                    dataService.updateCallState(call.id, "completed")
                    dataService.settleCall(call.id)
                } else {
                    dataService.updateCallState(call.id, "cancelled")
                }
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        }

        _callState.value = CallState.ENDED
        _activeCall.value = null
        if (_currentScreen.value == Screen.ACTIVE_CALL) {
            _currentScreen.value = Screen.HOME
        }
    }

    // CHAT FLOW
    fun openChatWithHost(partner: PartnerProfile) {
        val isAi = AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)
        if (isAi) {
            Log.d("BaatlySecurity", "[AI_CHAT] starting conversation for host: ${partner.displayName} (${partner.id})")
            _chatPartner.value = partner
            _currentScreen.value = Screen.DIRECT_CHAT
            _isChatBlocked.value = false

            val existingConvId = aiConversationIdByHostId[partner.id] ?: ("ai_conv_" + partner.id)
            val existingMessages = aiMessagesByHostId[partner.id] ?: emptyList()
            _activeConversation.value = ConversationSummary(
                id = existingConvId,
                partnerId = partner.id,
                partner = partner,
                lastMessageText = existingMessages.lastOrNull()?.messageText,
                lastMessageAt = existingMessages.lastOrNull()?.createdAt
            )
            _messages.value = existingMessages
            return
        }

        _chatPartner.value = partner
        _currentScreen.value = Screen.DIRECT_CHAT

        // Check if we already have an active conversation with this partner
        val existingConv = _conversations.value.find {
            it.partnerId == partner.id || it.partner?.id == partner.id || it.partner?.userId == partner.userId
        }
        if (existingConv != null) {
            _activeConversation.value = existingConv
            _isChatBlocked.value = existingConv.userBlocked || existingConv.partnerBlocked
            if (existingConv.lastMessageId != null) {
                val cached = conversationMessagesCache[existingConv.id]
                if (!cached.isNullOrEmpty()) {
                    _messages.value = cached
                } else {
                    _messages.value = emptyList()
                }
            } else {
                _messages.value = emptyList()
            }
            loadMessages(existingConv.id)
            subscribeToChatRealtime(existingConv.id)
        } else {
            _isChatBlocked.value = false
            _messages.value = emptyList()
        }

        viewModelScope.launch {
            // Fetch authoritative host profile via get_host_profile RPC
            dataService.getHostProfile(partner.id).onSuccess { hostProfile ->
                _chatPartner.value = hostProfile
                _activeConversation.value?.let { conv ->
                    _activeConversation.value = conv.copy(partner = hostProfile)
                }
            }

            dataService.startChatWithHost(partner.id).onSuccess { convId ->
                val currentP = _chatPartner.value ?: partner
                val currentConv = _activeConversation.value
                if (currentConv == null || currentConv.id != convId) {
                    _activeConversation.value = ConversationSummary(
                        id = convId,
                        partnerId = partner.id,
                        partner = currentP
                    )
                }
                loadMessages(convId)
                subscribeToChatRealtime(convId)
            }
        }
    }

    fun openConversation(conversation: ConversationSummary) {
        val convWithZeroUnread = conversation.copy(unreadCount = 0)
        _activeConversation.value = convWithZeroUnread
        _chatPartner.value = conversation.partner
        _isChatBlocked.value = conversation.userBlocked || conversation.partnerBlocked
        _currentScreen.value = Screen.DIRECT_CHAT

        val partner = conversation.partner
        val partnerId = conversation.partnerId ?: partner?.id ?: ""
        if (AiHostRegistry.isAiHost(partnerId) || AiHostRegistry.isAiHost(partner?.userId)) {
            Log.d("BaatlySecurity", "[AI_CHAT] openConversation for AI host: $partnerId")
            val cached = aiMessagesByHostId[partnerId] ?: emptyList()
            _messages.value = cached
            return
        }

        // Immediately clear unread badge in conversation list locally
        if (conversation.unreadCount > 0) {
            _conversations.value = _conversations.value.map {
                if (it.id == conversation.id) it.copy(unreadCount = 0) else it
            }
        }

        // Restore cached messages only if conversation has active messages
        if (conversation.lastMessageId != null) {
            val cached = conversationMessagesCache[conversation.id]
            if (!cached.isNullOrEmpty()) {
                _messages.value = cached
            } else {
                _messages.value = emptyList()
            }
        } else {
            _messages.value = emptyList()
        }

        if (!partnerId.isNullOrBlank()) {
            viewModelScope.launch {
                dataService.getHostProfile(partnerId).onSuccess { hostProfile ->
                    _chatPartner.value = hostProfile
                    _activeConversation.value = _activeConversation.value?.copy(partner = hostProfile)
                }
            }
        }

        loadMessages(conversation.id)
        subscribeToChatRealtime(conversation.id)
    }

    fun ensureChatLoaded() {
        val currentConv = _activeConversation.value
        val currentPartner = _chatPartner.value
        val partnerId = currentPartner?.id ?: currentConv?.partnerId

        if (AiHostRegistry.isAiHost(partnerId) || AiHostRegistry.isAiHost(currentPartner?.userId)) {
            Log.d("BaatlySecurity", "[AI_CHAT] ensureChatLoaded for AI host: $partnerId - skipping real host load")
            return
        }

        if (!partnerId.isNullOrBlank()) {
            viewModelScope.launch {
                dataService.getHostProfile(partnerId).onSuccess { hostProfile ->
                    _chatPartner.value = hostProfile
                    _activeConversation.value?.let { conv ->
                        _activeConversation.value = conv.copy(partner = hostProfile)
                    }
                }
            }
        }

        if (currentConv != null && currentConv.id.isNotBlank()) {
            _isChatBlocked.value = currentConv.userBlocked || currentConv.partnerBlocked
            if (currentConv.lastMessageId != null) {
                val cached = conversationMessagesCache[currentConv.id]
                if (!cached.isNullOrEmpty() && _messages.value.isEmpty()) {
                    _messages.value = cached
                }
            } else {
                _messages.value = emptyList()
            }
            loadMessages(currentConv.id)
            subscribeToChatRealtime(currentConv.id)
        } else if (!partnerId.isNullOrBlank()) {
            viewModelScope.launch {
                dataService.startChatWithHost(partnerId).onSuccess { convId ->
                    val currentP = _chatPartner.value ?: currentPartner
                    _activeConversation.value = ConversationSummary(
                        id = convId,
                        partnerId = partnerId,
                        partner = currentP
                    )
                    loadMessages(convId)
                    subscribeToChatRealtime(convId)
                }
            }
        }
    }

    private fun subscribeToChatRealtime(conversationId: String) {
        val currentPartner = _chatPartner.value
        val convPartnerId = _activeConversation.value?.partnerId
        if (AiHostRegistry.isAiHost(currentPartner?.id) || AiHostRegistry.isAiHost(currentPartner?.userId) ||
            AiHostRegistry.isAiHost(convPartnerId)) {
            return
        }
        realtimeManager.subscribeToConversation(
            conversationId = conversationId,
            onNewMessage = { newMsg -> onRealtimeMessageReceived(newMsg) },
            onResync = { loadMessages(conversationId) }
        )
    }

    private fun onRealtimeMessageReceived(newMsg: ChatMessage) {
        val convId = newMsg.conversationId.ifBlank { _activeConversation.value?.id ?: "" }
        val isInActiveChat = _currentScreen.value == Screen.DIRECT_CHAT && _activeConversation.value?.id == convId
        val currentUserId = sessionManager.userId.value
        val isFromOther = newMsg.senderId != currentUserId

        val msgToAdd = if (isInActiveChat && isFromOther) {
            newMsg.copy(isRead = true)
        } else {
            newMsg
        }

        val currentList = _messages.value
        if (currentList.none { it.id == msgToAdd.id }) {
            val updated = currentList + msgToAdd
            _messages.value = updated
            if (convId.isNotBlank()) {
                conversationMessagesCache[convId] = updated
            }
        }

        if (isInActiveChat && isFromOther && convId.isNotBlank()) {
            markConversationAsRead(convId)
        } else {
            refreshConversations()
        }
    }

    fun markConversationAsRead(conversationId: String) {
        if (conversationId.isBlank()) return
        if (!sessionManager.isLoggedIn) return

        viewModelScope.launch {
            dataService.markConversationRead(conversationId).onSuccess {
                // Immediately update local UI state so the Chat list and active conversation do not show old unread badge
                _conversations.value = _conversations.value.map { conv ->
                    if (conv.id == conversationId) {
                        conv.copy(unreadCount = 0)
                    } else {
                        conv
                    }
                }
                _activeConversation.value?.let { curr ->
                    if (curr.id == conversationId) {
                        _activeConversation.value = curr.copy(unreadCount = 0)
                    }
                }
                // Mark received messages in local state as read
                val currentUserId = sessionManager.userId.value
                _messages.value = _messages.value.map { msg ->
                    if (msg.conversationId == conversationId && msg.senderId != currentUserId && !msg.isRead) {
                        msg.copy(isRead = true)
                    } else {
                        msg
                    }
                }
                // Update message cache for this conversation if present
                conversationMessagesCache[conversationId]?.let { cached ->
                    conversationMessagesCache[conversationId] = cached.map { msg ->
                        if (msg.senderId != currentUserId && !msg.isRead) msg.copy(isRead = true) else msg
                    }
                }
            }.onFailure { err ->
                Log.e("BaatlyViewModel", "Failed to mark conversation $conversationId as read: ${err.message}", err)
            }
        }
    }

    fun refreshCurrentChat() {
        val convId = _activeConversation.value?.id
        val partnerId = _chatPartner.value?.id ?: _activeConversation.value?.partnerId
        if (AiHostRegistry.isAiHost(partnerId) || AiHostRegistry.isAiHost(_chatPartner.value?.userId)) {
            return
        }
        viewModelScope.launch {
            if (!partnerId.isNullOrBlank()) {
                dataService.getHostProfile(partnerId).onSuccess { hostProfile ->
                    _chatPartner.value = hostProfile
                    _activeConversation.value?.let { conv ->
                        _activeConversation.value = conv.copy(partner = hostProfile)
                    }
                }
            }
            if (!convId.isNullOrBlank()) {
                loadMessages(convId)
                subscribeToChatRealtime(convId)
            }
        }
    }

    fun closeChatScreen() {
        val partner = _chatPartner.value
        val isAi = AiHostRegistry.isAiHost(partner?.id) || AiHostRegistry.isAiHost(partner?.userId) ||
                   AiHostRegistry.isAiHost(_activeConversation.value?.partnerId)

        if (isAi && partner != null) {
            if (_messages.value.isNotEmpty()) {
                aiMessagesByHostId[partner.id] = _messages.value
            }
            audioPlayerManager.stop()
            _activeConversation.value = null
            _chatPartner.value = null
            _currentScreen.value = Screen.CHAT_LIST
            refreshConversations()
            return
        }

        val convId = _activeConversation.value?.id
        if (!convId.isNullOrBlank() && _messages.value.isNotEmpty()) {
            conversationMessagesCache[convId] = _messages.value
        }
        realtimeManager.unsubscribe()
        audioPlayerManager.stop()
        _activeConversation.value = null
        _chatPartner.value = null
        _currentScreen.value = Screen.CHAT_LIST
        refreshConversations()
    }

    fun loadMessages(conversationId: String) {
        if (conversationId.isBlank()) return
        val currentPartner = _chatPartner.value
        if (AiHostRegistry.isAiHost(currentPartner?.id) || AiHostRegistry.isAiHost(currentPartner?.userId) ||
            AiHostRegistry.isAiHost(_activeConversation.value?.partnerId)) {
            return
        }
        val currentConv = _activeConversation.value
        if (currentConv != null && currentConv.id == conversationId && currentConv.lastMessageId != null) {
            val cached = conversationMessagesCache[conversationId]
            if (!cached.isNullOrEmpty() && _messages.value.isEmpty()) {
                _messages.value = cached
            }
        }

        viewModelScope.launch {
            // Re-fetch conversation state for authoritative block & clear flags
            dataService.fetchConversationDetails(conversationId).onSuccess { freshConv ->
                val blocked = freshConv.userBlocked || freshConv.partnerBlocked
                _isChatBlocked.value = blocked
                _activeConversation.value?.let { curr ->
                    if (curr.id == freshConv.id) {
                        _activeConversation.value = curr.copy(
                            userBlocked = freshConv.userBlocked,
                            partnerBlocked = freshConv.partnerBlocked,
                            lastMessageId = freshConv.lastMessageId,
                            lastMessageAt = freshConv.lastMessageAt,
                            lastMessageText = freshConv.lastMessageText
                        )
                    }
                }
            }

            dataService.fetchMessages(conversationId).onSuccess { fetchedList ->
                // Server is authoritative!
                _messages.value = fetchedList
                if (fetchedList.isEmpty()) {
                    conversationMessagesCache.remove(conversationId)
                } else {
                    conversationMessagesCache[conversationId] = fetchedList
                }
            }.onFailure { err ->
                Log.e("BaatlyViewModel", "loadMessages error: ${err.message}", err)
            }

            markConversationAsRead(conversationId)
        }
    }

    fun playVoiceMessage(mediaUrl: String) {
        viewModelScope.launch {
            val playableUrl = dataService.getSignedMediaUrl(mediaUrl, com.example.data.network.SupabaseConfig.BUCKET_CHAT_MEDIA)
            audioPlayerManager.play(playableUrl)
        }
    }

    fun sendTextMessage(content: String, onResult: ((Boolean) -> Unit)? = null) {
        val trimmed = content.trim()
        if (trimmed.isBlank()) return

        // Contact Number Moderation check
        if (BillingEngine.containsForbiddenNumberContent(trimmed)) {
            _userMessage.value = "Number or contact-sharing content is not allowed."
            onResult?.invoke(false)
            return
        }

        val partner = _chatPartner.value
        if (partner == null) {
            _userMessage.value = "Host not found. Please re-open the chat."
            onResult?.invoke(false)
            return
        }

        val isAi = AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)
        if (isAi) {
            sendAiTextMessage(partner, trimmed, onResult)
            return
        }

        val currentBalance = wallet.value?.balance ?: 0
        val msgCost = effectivePricing.value.messageCoinsPerMessage
        if (currentBalance < msgCost) {
            _userMessage.value = "You don't have enough coins. Messaging costs $msgCost coin${if (msgCost > 1) "s" else ""}."
            onResult?.invoke(false)
            return
        }

        viewModelScope.launch {
            // Resolve or initialize conversation ID if missing
            var convId = _activeConversation.value?.id
            if (convId.isNullOrBlank()) {
                val startRes = dataService.startChatWithHost(partner.id)
                if (startRes.isSuccess) {
                    convId = startRes.getOrNull()
                    if (!convId.isNullOrBlank()) {
                        _activeConversation.value = ConversationSummary(
                            id = convId,
                            partnerId = partner.id,
                            partner = partner
                        )
                        subscribeToChatRealtime(convId)
                    }
                } else {
                    val err = startRes.exceptionOrNull()?.message ?: "Could not start chat conversation."
                    _userMessage.value = err
                    onResult?.invoke(false)
                    return@launch
                }
            }

            if (convId.isNullOrBlank()) {
                _userMessage.value = "Failed to open conversation."
                onResult?.invoke(false)
                return@launch
            }

            val sendResult = dataService.sendMessage(
                conversationId = convId,
                receiverId = partner.id,
                messageType = "text",
                content = trimmed
            )

            sendResult.onSuccess { newMsg ->
                _isChatBlocked.value = false
                _activeConversation.value = _activeConversation.value?.copy(
                    userBlocked = false,
                    partnerBlocked = false
                )
                val currentList = _messages.value
                if (currentList.none { it.id == newMsg.id }) {
                    val updated = currentList + newMsg
                    _messages.value = updated
                    conversationMessagesCache[convId] = updated
                }
                dataService.fetchWallet()
                refreshConversations()
                onResult?.invoke(true)
            }.onFailure { err ->
                val msg = err.message ?: "Failed to send message."
                if (msg.contains("cannot message", ignoreCase = true) || msg.contains("blocked", ignoreCase = true)) {
                    _isChatBlocked.value = true
                }
                _userMessage.value = msg
                onResult?.invoke(false)
            }
        }
    }

    private fun sendAiTextMessage(partner: PartnerProfile, messageText: String, onResult: ((Boolean) -> Unit)?) {
        val currentUserId = currentUser.value?.id ?: sessionManager.userId.value ?: "user"
        val existingConvId = aiConversationIdByHostId[partner.id]
        val convId = existingConvId ?: ("ai_conv_" + partner.id)

        val nowIso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }.format(java.util.Date())

        val userMsg = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            conversationId = convId,
            senderId = currentUserId,
            receiverId = partner.id,
            messageType = "text",
            messageText = messageText,
            createdAt = nowIso,
            isRead = true
        )

        val updatedWithUser = _messages.value + userMsg
        _messages.value = updatedWithUser
        aiMessagesByHostId[partner.id] = updatedWithUser

        aiConversationSummaries[partner.id] = ConversationSummary(
            id = convId,
            partnerId = partner.id,
            partner = partner,
            lastMessageText = messageText,
            lastMessageAt = nowIso,
            unreadCount = 0
        )

        onResult?.invoke(true)

        viewModelScope.launch {
            Log.d("BaatlySecurity", "[AI_CHAT] sending message to host: ${partner.displayName} (${partner.id})")
            val result = aiChatService.sendMessage(
                hostId = partner.id,
                message = messageText,
                conversationId = existingConvId
            )

            result.onSuccess { response ->
                val serverConvId = response.conversationId
                if (!serverConvId.isNullOrBlank()) {
                    aiConversationIdByHostId[partner.id] = serverConvId
                    Log.d("BaatlySecurity", "[AI_CHAT] conversation_id: $serverConvId")
                    _activeConversation.value = _activeConversation.value?.copy(id = serverConvId)
                    aiConversationSummaries[partner.id] = aiConversationSummaries[partner.id]?.copy(id = serverConvId)
                        ?: ConversationSummary(id = serverConvId, partnerId = partner.id, partner = partner)
                }

                val newAiMessages = mutableListOf<ChatMessage>()
                val replyIso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }.format(java.util.Date())

                if (response.reply.isNotBlank()) {
                    val aiTextMsg = ChatMessage(
                        id = java.util.UUID.randomUUID().toString(),
                        conversationId = serverConvId ?: convId,
                        senderId = partner.id,
                        receiverId = currentUserId,
                        messageType = "text",
                        messageText = response.reply,
                        createdAt = replyIso,
                        isRead = true
                    )
                    newAiMessages.add(aiTextMsg)
                }

                if (response.sendPhoto) {
                    val resolvedPhotoUrl = if (!response.photoUrl.isNullOrBlank()) {
                        dataService.resolveAiHostMediaUrl(response.photoUrl)
                    } else {
                        Log.w("BaatlySecurity", "[AI_CHAT] sendPhoto=true but photoUrl is empty")
                        null
                    }

                    if (!resolvedPhotoUrl.isNullOrBlank()) {
                        Log.d("BaatlySecurity", "[AI_CHAT] appending AI photo message with url: $resolvedPhotoUrl")
                        val photoTimestamp = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).apply {
                            timeZone = java.util.TimeZone.getTimeZone("UTC")
                        }.format(java.util.Date(System.currentTimeMillis() + 50))

                        val aiPhotoMsg = ChatMessage(
                            id = java.util.UUID.randomUUID().toString(),
                            conversationId = serverConvId ?: convId,
                            senderId = partner.id,
                            receiverId = currentUserId,
                            messageType = "image",
                            messageText = null,
                            mediaUrl = resolvedPhotoUrl,
                            createdAt = photoTimestamp,
                            isRead = true
                        )
                        newAiMessages.add(aiPhotoMsg)
                    }
                }

                if (newAiMessages.isNotEmpty()) {
                    val updatedWithAi = _messages.value + newAiMessages
                    _messages.value = updatedWithAi
                    aiMessagesByHostId[partner.id] = updatedWithAi

                    val lastMsg = newAiMessages.last()
                    val previewText = if (lastMsg.messageType == "image") "📷 Photo" else (lastMsg.messageText ?: "Message")
                    aiConversationSummaries[partner.id] = (aiConversationSummaries[partner.id] ?: ConversationSummary(
                        id = serverConvId ?: convId,
                        partnerId = partner.id,
                        partner = partner
                    )).copy(
                        lastMessageText = previewText,
                        lastMessageAt = lastMsg.createdAt
                    )
                }
            }.onFailure { err ->
                Log.e("BaatlySecurity", "Failed to receive AI reply: ${err.message}", err)
                val friendlyError = err.message ?: "Could not reach AI host. Please try again."
                _userMessage.value = friendlyError
            }
        }
    }

    fun sendImageMessage(file: File) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        if (AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)) {
            _userMessage.value = "${partner.displayName} currently only supports text messages."
            return
        }

        val currentBalance = wallet.value?.balance ?: 0
        val msgCost = effectivePricing.value.messageCoinsPerMessage
        if (currentBalance < msgCost) {
            _userMessage.value = "You don't have enough coins. Messaging costs $msgCost coin${if (msgCost > 1) "s" else ""}."
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = false).onSuccess { mediaUrl ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "image",
                    mediaUrl = mediaUrl
                ).onSuccess { newMsg ->
                    _isChatBlocked.value = false
                    _activeConversation.value = _activeConversation.value?.copy(
                        userBlocked = false,
                        partnerBlocked = false
                    )
                    if (_messages.value.none { it.id == newMsg.id }) {
                        val updated = _messages.value + newMsg
                        _messages.value = updated
                        conversationMessagesCache[conv.id] = updated
                    }
                    dataService.fetchWallet()
                    refreshConversations()
                }.onFailure { err ->
                    _userMessage.value = err.message ?: "Failed to send image."
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to upload image."
            }
        }
    }

    fun sendVoiceMessage(file: File, durationSec: Int) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        if (AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)) {
            _userMessage.value = "${partner.displayName} currently only supports text messages."
            return
        }

        val currentBalance = wallet.value?.balance ?: 0
        val msgCost = effectivePricing.value.messageCoinsPerMessage
        if (currentBalance < msgCost) {
            _userMessage.value = "You don't have enough coins. Messaging costs $msgCost coin${if (msgCost > 1) "s" else ""}."
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = true).onSuccess { mediaUrl ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "voice",
                    mediaUrl = mediaUrl,
                    mediaDurationSeconds = durationSec
                ).onSuccess { newMsg ->
                    _isChatBlocked.value = false
                    _activeConversation.value = _activeConversation.value?.copy(
                        userBlocked = false,
                        partnerBlocked = false
                    )
                    if (_messages.value.none { it.id == newMsg.id }) {
                        val updated = _messages.value + newMsg
                        _messages.value = updated
                        conversationMessagesCache[conv.id] = updated
                    }
                    dataService.fetchWallet()
                    refreshConversations()
                }.onFailure { err ->
                    _userMessage.value = err.message ?: "Failed to send voice note."
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to upload voice note."
            }
        }
    }

    fun sendGift(gift: GiftItem, targetPartnerId: String? = null, conversationId: String? = null, callId: String? = null) {
        val partnerId = targetPartnerId
            ?: _chatPartner.value?.id
            ?: _activeCallPartner.value?.id
            ?: _selectedPartner.value?.id
            ?: return

        if (AiHostRegistry.isAiHost(partnerId) || AiHostRegistry.isAiHost(_chatPartner.value?.userId)) {
            _userMessage.value = "Gifts are not available for this host."
            return
        }

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < gift.coinPrice) {
            _userMessage.value = "You don't have enough coins to send ${gift.name}."
            return
        }

        viewModelScope.launch {
            val convId = conversationId ?: _activeConversation.value?.id
            dataService.sendGift(
                giftId = gift.id,
                receiverId = partnerId,
                conversationId = convId,
                callId = callId ?: _activeCall.value?.id
            ).onSuccess {
                _userMessage.value = "Sent ${gift.name} successfully!"
                _recentGiftAnimation.value = gift
                _showGiftSheet.value = false
                dataService.fetchWallet()
                // If in active chat, append gift message
                if (_activeConversation.value != null) {
                    val giftMsg = ChatMessage(
                        id = java.util.UUID.randomUUID().toString(),
                        conversationId = _activeConversation.value!!.id,
                        senderId = currentUser.value?.id ?: "",
                        receiverId = partnerId,
                        messageType = "gift",
                        giftId = gift.id,
                        gift = gift,
                        createdAt = "Just now"
                    )
                    if (_messages.value.none { it.id == giftMsg.id }) {
                        val updated = _messages.value + giftMsg
                        _messages.value = updated
                        convId?.let { cid -> conversationMessagesCache[cid] = updated }
                    }
                }
                refreshConversations()
                delay(3000)
                _recentGiftAnimation.value = null
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to send gift."
            }
        }
    }

    fun clearCurrentConversation() {
        val conv = _activeConversation.value ?: return
        // 1. Immediately clear visible messages, cache, last message preview, unread count
        _messages.value = emptyList()
        conversationMessagesCache.remove(conv.id)
        _activeConversation.value = conv.copy(
            lastMessageId = null,
            lastMessageAt = null,
            lastMessageText = null,
            unreadCount = 0
        )
        _conversations.value = _conversations.value.map {
            if (it.id == conv.id) {
                it.copy(
                    lastMessageId = null,
                    lastMessageAt = null,
                    lastMessageText = null,
                    unreadCount = 0
                )
            } else it
        }

        // 2. Call backend clear_my_conversation RPC
        viewModelScope.launch {
            dataService.clearMyConversation(conv.id).onSuccess {
                _messages.value = emptyList()
                conversationMessagesCache.remove(conv.id)
                _userMessage.value = "Chat cleared."
                refreshConversations()
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to clear chat."
            }
        }
    }

    fun blockCurrentHost(reason: String = "User requested block") {
        val partner = _chatPartner.value ?: _activeConversation.value?.partner ?: return
        viewModelScope.launch {
            dataService.blockUser(partner.id, reason).onSuccess {
                _isChatBlocked.value = true
                _activeConversation.value = _activeConversation.value?.copy(userBlocked = true)
                _userMessage.value = "Host blocked. You can no longer send messages."
                refreshConversations()
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to block host."
            }
        }
    }

    fun unblockCurrentHost() {
        val partner = _chatPartner.value ?: _activeConversation.value?.partner ?: return
        viewModelScope.launch {
            dataService.unblockUser(partner.id).onSuccess {
                _isChatBlocked.value = false
                _activeConversation.value = _activeConversation.value?.copy(
                    userBlocked = false,
                    partnerBlocked = false
                )
                _userMessage.value = "Host unblocked."
                refreshCurrentChat()
                refreshConversations()
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to unblock host."
            }
        }
    }

    // ====================================================
    // UROPAY PRODUCTION COIN PURCHASE & VERIFICATION
    // ====================================================

    fun purchaseCoinPackage(pkg: CoinPackage, context: Context? = null, activity: Activity? = null) {
        if (_isProcessingPayment.value) {
            Log.d("BaatlyViewModel", "Payment already in progress. Ignoring tap.")
            return
        }

        val currentUserId = sessionManager.userId.value
        if (currentUserId.isNullOrBlank()) {
            _userMessage.value = "Please log in to purchase coins."
            return
        }

        val playProductId = com.example.data.billing.GooglePlayProductMapper.getGooglePlayProductIdForCoinPackage(pkg.id)

        if (activity != null && billingManager.isReady.value && !playProductId.isNullOrBlank()) {
            currentPurchaseTarget = PendingPurchaseTarget.Coins(pkg, context)
            viewModelScope.launch {
                val launched = billingManager.launchBillingFlow(activity, playProductId, isSubscription = false)
                if (!launched) {
                    Log.d("BaatlyViewModel", "Google Play billing flow not launched, falling back to direct UroPay checkout")
                    val state = _userSelectedIndianState.value
                    purchaseCoinPackageInternal(pkg, context, externalTransactionToken = null, administrativeArea = state)
                }
            }
        } else {
            val state = _userSelectedIndianState.value
            purchaseCoinPackageInternal(pkg, context, externalTransactionToken = null, administrativeArea = state)
        }
    }

    private fun purchaseCoinPackageInternal(
        pkg: CoinPackage,
        context: Context?,
        externalTransactionToken: String?,
        administrativeArea: String?
    ) {
        val currentUserId = sessionManager.userId.value ?: return
        val now = System.currentTimeMillis()
        val existingPending = sessionManager.getPendingPayment()
        if (existingPending != null && existingPending.packageId == pkg.id && (now - existingPending.createdAt) < 15 * 60 * 1000L) {
            Log.d("BaatlyViewModel", "Reusing existing recent pending payment: ${existingPending.paymentId}")
            if (!existingPending.openUrl.isNullOrBlank() && context != null) {
                _uroPayPaymentState.value = UroPayPaymentUiState.OpeningCheckout(
                    paymentId = existingPending.paymentId,
                    openUrl = existingPending.openUrl,
                    coins = existingPending.coins,
                    priceInr = existingPending.priceInr
                )
                launchCheckoutUrl(context, existingPending.openUrl)
                return
            }
        }

        // Generate unique tenant_order_ref: BAATLY-<USER_ID_SHORT>-<TIMESTAMP>-<RANDOM>
        val shortUserId = currentUserId.replace("-", "").take(6).uppercase()
        val randomSuffix = (1000..9999).random()
        val tenantOrderRef = "BAATLY-$shortUserId-$now-$randomSuffix"

        orderCreationJob?.cancel()
        orderCreationJob = viewModelScope.launch {
            _isProcessingPayment.value = true
            _uroPayPaymentState.value = UroPayPaymentUiState.CreatingOrder(pkg)

            var calculatedTaxBreakdown: com.example.data.billing.TaxBreakdown? = null
            val clientPaymentId = java.util.UUID.randomUUID().toString()

            // If Google Play Alternative Billing token is present, prepare MUST happen BEFORE UroPay order creation
            if (!externalTransactionToken.isNullOrBlank()) {
                if (administrativeArea.isNullOrBlank() || !com.example.data.billing.IndiaAdministrativeAreas.isValid(administrativeArea)) {
                    val err = "A valid Indian state or union territory is required for Google Play Alternative Billing."
                    Log.e("BaatlyViewModel", err)
                    _isProcessingPayment.value = false
                    _uroPayPaymentState.value = UroPayPaymentUiState.Failed(err)
                    return@launch
                }

                val taxRes = com.example.data.billing.BaatlyTaxConfig.calculateTaxBreakdown(
                    totalAmount = pkg.priceInr,
                    explicitTaxRatePercent = pkg.taxRatePercent,
                    explicitPreTaxAmount = pkg.preTaxAmountInr,
                    explicitTaxAmount = pkg.taxAmountInr
                )
                if (taxRes.isFailure) {
                    val err = taxRes.exceptionOrNull()?.message ?: "Tax calculation failed for coin package."
                    Log.e("BaatlyViewModel", "Tax configuration error: $err")
                    _isProcessingPayment.value = false
                    _uroPayPaymentState.value = UroPayPaymentUiState.Failed(err)
                    return@launch
                }

                val taxBreakdown = taxRes.getOrThrow()
                calculatedTaxBreakdown = taxBreakdown

                val prepRes = dataService.prepareGooglePlayExternalTransaction(
                    paymentId = clientPaymentId,
                    externalTransactionToken = externalTransactionToken,
                    administrativeArea = administrativeArea,
                    preTaxAmountInr = taxBreakdown.preTaxAmountFormatted,
                    taxAmountInr = taxBreakdown.taxAmountFormatted
                )
                if (prepRes.isFailure) {
                    val err = prepRes.exceptionOrNull()?.message ?: "Failed to prepare Google Play Alternative Billing transaction."
                    Log.e("BaatlyViewModel", "prepareGooglePlayExternalTransaction coins failed: $err")
                    _isProcessingPayment.value = false
                    _uroPayPaymentState.value = UroPayPaymentUiState.Failed(err)
                    return@launch
                }
                Log.d("BaatlyViewModel", "prepareGooglePlayExternalTransaction coins succeeded for payment: $clientPaymentId")
            }

            val orderRes = dataService.createUroPayOrder(packageId = pkg.id, tenantOrderRef = tenantOrderRef, paymentId = clientPaymentId)
            orderRes.onSuccess { result ->
                if (result.success && !result.openUrl.isNullOrBlank() && !result.paymentId.isNullOrBlank()) {
                    val authCoins = if (result.coins > 0) result.coins else pkg.coins
                    val authPrice = if (result.amountInr > 0) result.amountInr else pkg.priceInr

                    val pending = PendingUroPayPayment(
                        paymentId = result.paymentId,
                        orderId = result.orderId,
                        tenantOrderRef = result.tenantOrderRef ?: tenantOrderRef,
                        packageId = pkg.id,
                        coins = authCoins,
                        priceInr = authPrice,
                        openUrl = result.openUrl,
                        createdAt = now,
                        isMembership = false,
                        externalTransactionToken = externalTransactionToken,
                        administrativeArea = administrativeArea,
                        preTaxAmountInr = calculatedTaxBreakdown?.preTaxAmount,
                        taxAmountInr = calculatedTaxBreakdown?.taxAmount,
                        taxRatePercent = pkg.taxRatePercent,
                        googleReportStatus = if (!externalTransactionToken.isNullOrBlank()) "pending" else null
                    )
                    sessionManager.savePendingPayment(pending)

                    _uroPayPaymentState.value = UroPayPaymentUiState.OpeningCheckout(
                        paymentId = result.paymentId,
                        openUrl = result.openUrl,
                        coins = authCoins,
                        priceInr = authPrice
                    )

                    if (context != null) {
                        launchCheckoutUrl(context, result.openUrl)
                    }
                } else {
                    val errorMsg = result.error ?: result.message ?: "Failed to generate payment checkout."
                    _uroPayPaymentState.value = UroPayPaymentUiState.Failed(errorMsg)
                }
            }.onFailure { err ->
                Log.e("BaatlyViewModel", "purchaseCoinPackage failed: ${err.message}", err)
                if (err is SessionExpiredException) {
                    _uroPayPaymentState.value = UroPayPaymentUiState.SessionExpired(
                        err.message ?: "Your session has expired. Please sign in again."
                    )
                } else if (err is PaymentNetworkException) {
                    _uroPayPaymentState.value = UroPayPaymentUiState.Failed(
                        err.message ?: "Connection problem. Please check your internet connection and try again."
                    )
                } else {
                    _uroPayPaymentState.value = UroPayPaymentUiState.Failed(
                        err.message ?: "Unable to create payment order. Please try again."
                    )
                }
            }
            _isProcessingPayment.value = false
        }
    }

    fun launchCheckoutUrl(context: Context, openUrl: String) {
        try {
            val customTabsIntent = androidx.browser.customtabs.CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
            customTabsIntent.launchUrl(context, android.net.Uri.parse(openUrl))
        } catch (e: Exception) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(openUrl)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (ex: Exception) {
                _uroPayPaymentState.value = UroPayPaymentUiState.Failed("Unable to launch checkout browser: ${ex.message}")
            }
        }
    }

    fun verifyPayment(paymentId: String, coins: Int, priceInr: Double, isAutoResume: Boolean = false) {
        if (_isProcessingPayment.value && _uroPayPaymentState.value is UroPayPaymentUiState.Verifying) {
            return
        }

        verificationJob?.cancel()
        verificationJob = viewModelScope.launch {
            _isProcessingPayment.value = true
            val maxAttempts = 3
            var finalResult: UroPayVerifyPaymentResult? = null

            for (attempt in 1..maxAttempts) {
                _uroPayPaymentState.value = UroPayPaymentUiState.Verifying(
                    paymentId = paymentId,
                    coins = coins,
                    priceInr = priceInr,
                    attempt = attempt
                )

                val res = dataService.verifyUroPayPayment(paymentId)
                if (res.isSuccess) {
                    val result = res.getOrNull()!!
                    finalResult = result
                    when (result.status) {
                        "success" -> break
                        "failed", "cancelled", "expired" -> break
                        "pending" -> {
                            if (attempt < maxAttempts) {
                                val delayMs = when (attempt) {
                                    1 -> 2000L
                                    2 -> 3000L
                                    else -> 5000L
                                }
                                delay(delayMs)
                            }
                        }
                    }
                } else {
                    if (attempt < maxAttempts) {
                        delay(2000L)
                    }
                }
            }

            _isProcessingPayment.value = false

            if (finalResult != null) {
                when (finalResult.status) {
                    "success" -> {
                        val pending = sessionManager.getPendingPayment()
                        if (pending != null && pending.paymentId == paymentId && !pending.externalTransactionToken.isNullOrBlank()) {
                            val reportRes = dataService.reportGooglePlayExternalTransaction(paymentId = paymentId)
                            val isReportSuccess = reportRes.isSuccess && (reportRes.getOrNull()?.optBoolean("success", false) == true)
                            if (isReportSuccess) {
                                Log.d("BaatlyViewModel", "reportGooglePlayExternalTransaction coins succeeded for payment: $paymentId")
                                sessionManager.clearPendingPayment()
                            } else {
                                // CRITICAL: DO NOT clear pending payment context on temporary Google reporting failure.
                                // Allow server retry queue to process it; preserve all payment and Google token context.
                                Log.w("BaatlyViewModel", "reportGooglePlayExternalTransaction coins failed or queued. Preserving payment context for retry.")
                                sessionManager.savePendingPayment(pending.copy(googleReportStatus = "failed"))
                            }
                        } else {
                            sessionManager.clearPendingPayment()
                        }
                        _currentScreen.value = Screen.WALLET
                        // Authoritative backend refresh of wallet and transaction history
                        dataService.fetchWallet()
                        dataService.fetchTransactions().onSuccess { _transactions.value = it }
                        val currentWallet = sessionManager.wallet.value
                        val creditedCoins = if (finalResult.coins > 0) finalResult.coins else coins
                        _uroPayPaymentState.value = UroPayPaymentUiState.Success(
                            paymentId = paymentId,
                            coinsCredited = creditedCoins,
                            updatedBalance = currentWallet?.balance ?: creditedCoins
                        )
                    }
                    "failed" -> {
                        sessionManager.clearPendingPayment()
                        _currentScreen.value = Screen.WALLET
                        _uroPayPaymentState.value = UroPayPaymentUiState.Failed(
                            finalResult.message ?: finalResult.error ?: "Payment verification failed."
                        )
                    }
                    "cancelled" -> {
                        sessionManager.clearPendingPayment()
                        _currentScreen.value = Screen.WALLET
                        _uroPayPaymentState.value = UroPayPaymentUiState.Cancelled(
                            finalResult.message ?: "Payment was cancelled."
                        )
                    }
                    "expired" -> {
                        sessionManager.clearPendingPayment()
                        _currentScreen.value = Screen.WALLET
                        _uroPayPaymentState.value = UroPayPaymentUiState.Expired(
                            finalResult.message ?: "Payment session expired. Please start a new purchase."
                        )
                    }
                    else -> {
                        // Pending
                        _currentScreen.value = Screen.WALLET
                        _uroPayPaymentState.value = UroPayPaymentUiState.Pending(
                            paymentId = paymentId,
                            coins = coins,
                            priceInr = priceInr,
                            message = finalResult.message ?: "Payment is being verified... You can check again shortly."
                        )
                    }
                }
            } else {
                _currentScreen.value = Screen.WALLET
                _uroPayPaymentState.value = UroPayPaymentUiState.Pending(
                    paymentId = paymentId,
                    coins = coins,
                    priceInr = priceInr,
                    message = "Payment is being verified... You can check again shortly."
                )
            }
        }
    }

    fun handlePaymentReturnDeepLink(uri: Uri?) {
        if (uri == null) return
        Log.d("BaatlyViewModel", "handlePaymentReturnDeepLink: uri=$uri")

        val scheme = uri.scheme?.lowercase() ?: ""
        val host = uri.host?.lowercase() ?: ""
        val path = uri.path?.lowercase() ?: ""

        val isPaymentReturn = (scheme == "baatly" && host == "payment") ||
            (scheme == "https" && (path.startsWith("/payment/uropay/return") || path.startsWith("/payment/return") || path.contains("uropay-return"))) ||
            (path.contains("uropay") && path.contains("return"))

        if (!isPaymentReturn) {
            Log.d("BaatlyViewModel", "handlePaymentReturnDeepLink: Not a payment return uri: $uri")
            return
        }

        // Navigate to Wallet Screen
        _currentScreen.value = Screen.WALLET

        // Extract parameters from return URL if provided
        val queryPaymentId = uri.getQueryParameter("payment_id")
            ?: uri.getQueryParameter("paymentId")
            ?: uri.getQueryParameter("payment")
        val queryOrderId = uri.getQueryParameter("order_id")
            ?: uri.getQueryParameter("orderId")
            ?: uri.getQueryParameter("order")
        val queryTenantRef = uri.getQueryParameter("tenant_order_ref")
            ?: uri.getQueryParameter("tenantOrderRef")
            ?: uri.getQueryParameter("ref")
        val queryStatus = uri.getQueryParameter("status")

        Log.d("BaatlyViewModel", "Payment return deep link params: paymentId=$queryPaymentId, orderId=$queryOrderId, ref=$queryTenantRef, status=$queryStatus")

        val pending = sessionManager.getPendingPayment()
        val now = System.currentTimeMillis()

        if (pending != null && (now - pending.createdAt < 2 * 60 * 60 * 1000L)) {
            val targetPaymentId = if (!queryPaymentId.isNullOrBlank()) queryPaymentId else pending.paymentId
            if (pending.isMembership) {
                Log.d("BaatlyViewModel", "Triggering authoritative server-side verification for membership payment: $targetPaymentId")
                viewModelScope.launch {
                    membershipRepository.verifyMembershipPayment(targetPaymentId)
                }
            } else {
                Log.d("BaatlyViewModel", "Triggering authoritative server-side verification for return payment: $targetPaymentId")
                verifyPayment(
                    paymentId = targetPaymentId,
                    coins = pending.coins,
                    priceInr = pending.priceInr,
                    isAutoResume = false
                )
            }
        } else if (!queryPaymentId.isNullOrBlank()) {
            Log.d("BaatlyViewModel", "No local pending payment but query payment_id present: $queryPaymentId. Verifying...")
            verifyPayment(
                paymentId = queryPaymentId,
                coins = 0,
                priceInr = 0.0,
                isAutoResume = false
            )
        } else {
            Log.d("BaatlyViewModel", "Payment returned without pending payment. Refreshing wallet balance and membership.")
            viewModelScope.launch {
                dataService.fetchWallet()
                dataService.fetchTransactions().onSuccess { _transactions.value = it }
                membershipRepository.refreshMembership()
            }
        }
    }

    fun onAppResumed() {
        val pending = sessionManager.getPendingPayment()
        if (pending != null) {
            val now = System.currentTimeMillis()
            if (now - pending.createdAt < 2 * 60 * 60 * 1000L) {
                // Check if this pending payment already succeeded but failed Google reporting earlier
                if (pending.googleReportStatus == "failed" && !pending.externalTransactionToken.isNullOrBlank()) {
                    Log.d("BaatlyViewModel", "App resumed with pending un-reported Google Play transaction: ${pending.paymentId}. Retrying reporting.")
                    viewModelScope.launch {
                        val reportRes = dataService.reportGooglePlayExternalTransaction(paymentId = pending.paymentId)
                        if (reportRes.isSuccess && reportRes.getOrNull()?.optBoolean("success", false) == true) {
                            Log.d("BaatlyViewModel", "Retry reporting succeeded for payment: ${pending.paymentId}")
                            sessionManager.clearPendingPayment()
                        }
                    }
                    return
                }

                if (pending.isMembership) {
                    Log.d("BaatlyViewModel", "App resumed with pending membership payment: ${pending.paymentId}. Triggering verification.")
                    viewModelScope.launch {
                        membershipRepository.verifyMembershipPayment(pending.paymentId)
                    }
                } else {
                    val currentState = _uroPayPaymentState.value
                    if (currentState is UroPayPaymentUiState.OpeningCheckout ||
                        currentState is UroPayPaymentUiState.Pending ||
                        currentState is UroPayPaymentUiState.Idle) {
                        Log.d("BaatlyViewModel", "App resumed with pending payment: ${pending.paymentId}. Triggering verification.")
                        verifyPayment(
                            paymentId = pending.paymentId,
                            coins = pending.coins,
                            priceInr = pending.priceInr,
                            isAutoResume = true
                        )
                    }
                }
            } else {
                sessionManager.clearPendingPayment()
            }
        }
        // Always refresh membership on resume
        viewModelScope.launch {
            membershipRepository.refreshMembership()
        }
    }

    fun dismissPaymentState() {
        val state = _uroPayPaymentState.value
        if (state is UroPayPaymentUiState.Success ||
            state is UroPayPaymentUiState.Failed ||
            state is UroPayPaymentUiState.Cancelled ||
            state is UroPayPaymentUiState.Expired ||
            state is UroPayPaymentUiState.SessionExpired) {
            val pending = sessionManager.getPendingPayment()
            if (pending?.googleReportStatus != "failed") {
                sessionManager.clearPendingPayment()
            }
        }
        _uroPayPaymentState.value = UroPayPaymentUiState.Idle
        _isProcessingPayment.value = false
    }

    // ====================================================
    // SOCIAL MEDIA MODULE ACTIONS
    // ====================================================

    fun refreshSocialFeed(isRefresh: Boolean = false) {
        if (isRefresh) {
            _isRefreshingSocial.value = true
        } else {
            _isLoadingSocial.value = true
        }

        viewModelScope.launch {
            try {
                dataService.ensureSocialProfile()

                val storiesResult = dataService.getSocialStories()
                storiesResult.onSuccess { stories ->
                    _socialStories.value = stories
                }

                val feedResult = dataService.getSocialFeed(page = 0, limit = 30)
                feedResult.onSuccess { posts ->
                    _socialPosts.value = posts
                }

                val currentUserId = sessionManager.userId.value ?: ""
                if (currentUserId.isNotBlank()) {
                    dataService.getSocialProfile(currentUserId).onSuccess { profile ->
                        val postsRes = dataService.getUserSocialPosts(currentUserId).getOrDefault(emptyList())
                        val storiesRes = dataService.getUserSocialStories(currentUserId).getOrDefault(emptyList())
                        _mySocialProfile.value = profile.copy(
                            posts = postsRes,
                            stories = storiesRes
                        )
                    }
                }
                dataService.fetchWallet()
            } catch (e: Exception) {
                Log.e("BaatlyViewModel", "Error refreshing social feed: ${e.message}", e)
            } finally {
                _isLoadingSocial.value = false
                _isRefreshingSocial.value = false
            }
        }
    }

    fun loadMySocialProfile() {
        val currentUserId = sessionManager.userId.value ?: return
        viewModelScope.launch {
            dataService.ensureSocialProfile()
            dataService.getSocialProfile(currentUserId).onSuccess { profile ->
                val postsRes = dataService.getUserSocialPosts(currentUserId).getOrDefault(emptyList())
                val storiesRes = dataService.getUserSocialStories(currentUserId).getOrDefault(emptyList())
                _mySocialProfile.value = profile.copy(
                    posts = postsRes,
                    stories = storiesRes
                )
            }
        }
    }

    fun openSocialProfile(userId: String) {
        val currentUserId = sessionManager.userId.value ?: ""
        val targetId = if (userId.isBlank()) currentUserId else userId
        _isLoadingSocialProfile.value = true
        _currentScreen.value = Screen.SOCIAL_PROFILE

        viewModelScope.launch {
            dataService.getSocialProfile(targetId).onSuccess { profile ->
                val postsRes = dataService.getUserSocialPosts(targetId).getOrDefault(emptyList())
                val storiesRes = dataService.getUserSocialStories(targetId).getOrDefault(emptyList())
                val completeProfile = profile.copy(
                    posts = if (profile.posts.isNotEmpty()) profile.posts else postsRes,
                    stories = if (profile.stories.isNotEmpty()) profile.stories else storiesRes
                )
                _viewedSocialProfile.value = completeProfile
                if (targetId == currentUserId) {
                    _mySocialProfile.value = completeProfile
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Could not load social profile."
            }
            _isLoadingSocialProfile.value = false
        }
    }

    fun closeSocialProfile() {
        _viewedSocialProfile.value = null
        _currentScreen.value = Screen.SOCIAL
    }

    fun updateMySocialProfile(
        bio: String,
        hobbies: String,
        avatarFile: File?,
        onComplete: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = dataService.updateSocialProfile(bio, hobbies, avatarFile)
            result.onSuccess {
                loadMySocialProfile()
                _userMessage.value = "Social Profile updated successfully!"
                onComplete(true, null)
            }.onFailure { err ->
                val msg = err.message ?: "Failed to update social profile"
                _userMessage.value = msg
                onComplete(false, msg)
            }
        }
    }

    fun searchSocialUser(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) {
            _socialSearchError.value = "Please enter a User ID"
            return
        }
        _isSearchingSocial.value = true
        _socialSearchError.value = null
        _socialSearchResult.value = null

        viewModelScope.launch {
            val res = dataService.searchSocialProfile(clean)
            res.onSuccess { result ->
                _socialSearchResult.value = result
            }.onFailure { err ->
                _socialSearchError.value = err.message ?: "No host found with this User ID."
            }
            _isSearchingSocial.value = false
        }
    }

    fun clearSocialSearch() {
        _socialSearchResult.value = null
        _socialSearchError.value = null
        _isSearchingSocial.value = false
    }

    fun openStoryViewer(story: SocialStory) {
        if (!story.isStoryActiveAndValid) {
            _userMessage.value = "This story has expired or is no longer available."
            refreshSocialFeed()
            return
        }
        _activeStoryViewer.value = story
        // Track view
        viewModelScope.launch {
            dataService.viewSocialContent("story", story.id)
            dataService.fetchWallet() // Authoritative balance update
            // Mark story as viewed locally
            _socialStories.value = _socialStories.value.map {
                if (it.id == story.id) it.copy(isViewed = true, viewsCount = it.viewsCount + 1) else it
            }
        }
    }

    fun closeStoryViewer() {
        _activeStoryViewer.value = null
    }

    fun createStory(
        mediaFile: File,
        caption: String,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < 10) {
            _userMessage.value = "You need 10 coins to post a Story. Please top up."
            _currentScreen.value = Screen.WALLET
            onComplete(false, "Insufficient balance (10 coins required)")
            return
        }

        viewModelScope.launch {
            val res = dataService.createSocialContent("story", mediaFile, caption)
            res.onSuccess {
                dataService.fetchWallet()
                refreshSocialFeed()
                loadMySocialProfile()
                _userMessage.value = "Story posted successfully! (10 Coins)"
                onComplete(true, null)
            }.onFailure { err ->
                val msg = err.message ?: "Failed to create story"
                _userMessage.value = msg
                onComplete(false, msg)
            }
        }
    }

    fun createPost(
        mediaFile: File,
        caption: String,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < 20) {
            _userMessage.value = "You need 20 coins to create a Post. Please top up."
            _currentScreen.value = Screen.WALLET
            onComplete(false, "Insufficient balance (20 coins required)")
            return
        }

        viewModelScope.launch {
            val res = dataService.createSocialContent("post", mediaFile, caption)
            res.onSuccess {
                dataService.fetchWallet()
                refreshSocialFeed()
                loadMySocialProfile()
                _userMessage.value = "Post created successfully! (20 Coins)"
                onComplete(true, null)
            }.onFailure { err ->
                val msg = err.message ?: "Failed to create post"
                _userMessage.value = msg
                onComplete(false, msg)
            }
        }
    }

    fun toggleLikePost(post: SocialPost) {
        val currentlyLiked = post.isLiked
        val newLiked = !currentlyLiked
        val delta = if (newLiked) 1 else -1

        // Optimistic UI update
        val updatedPost = post.copy(isLiked = newLiked, likesCount = maxOf(0, post.likesCount + delta))
        _socialPosts.value = _socialPosts.value.map {
            if (it.id == post.id) updatedPost else it
        }
        if (_activePostViewer.value?.id == post.id) {
            _activePostViewer.value = updatedPost
        }

        viewModelScope.launch {
            val res = dataService.toggleSocialLike("post", post.id)
            if (res.isSuccess) {
                dataService.fetchWallet()
            }
        }
    }

    fun toggleLikeStory(story: SocialStory) {
        val currentlyLiked = story.isLiked
        val newLiked = !currentlyLiked
        val delta = if (newLiked) 1 else -1

        // Optimistic UI update
        val updatedStory = story.copy(isLiked = newLiked, likesCount = maxOf(0, story.likesCount + delta))
        _activeStoryViewer.value = updatedStory
        _socialStories.value = _socialStories.value.map {
            if (it.id == story.id) updatedStory else it
        }

        viewModelScope.launch {
            val res = dataService.toggleSocialLike("story", story.id)
            if (res.isSuccess) {
                dataService.fetchWallet()
            }
        }
    }

    fun openPostViewer(post: SocialPost) {
        _activePostViewer.value = post
        val currentUserId = sessionManager.userId.value ?: ""
        val canView = post.isUnlocked || !post.isOwnerHost || post.ownerId == currentUserId
        if (post.resolvedMediaUrl.isNullOrBlank() && !post.mediaPath.isNullOrBlank() && canView) {
            viewModelScope.launch {
                val freshUrl = dataService.resolveSocialMediaUrl(post.mediaPath)
                if (freshUrl.isNotBlank()) {
                    val updated = post.copy(resolvedMediaUrl = freshUrl)
                    if (_activePostViewer.value?.id == post.id) {
                        _activePostViewer.value = updated
                    }
                    _socialPosts.value = _socialPosts.value.map {
                        if (it.id == post.id) updated else it
                    }
                    _viewedSocialProfile.value = _viewedSocialProfile.value?.let { prof ->
                        prof.copy(posts = prof.posts.map { if (it.id == post.id) updated else it })
                    }
                    _mySocialProfile.value = _mySocialProfile.value?.let { prof ->
                        prof.copy(posts = prof.posts.map { if (it.id == post.id) updated else it })
                    }
                }
            }
        }
    }

    fun closePostViewer() {
        _activePostViewer.value = null
    }

    fun unlockPost(post: SocialPost) {
        val currentBalance = wallet.value?.balance ?: 0
        val postCost = effectivePricing.value.postViewCoins
        if (currentBalance < postCost) {
            _userMessage.value = "You need $postCost coin${if (postCost > 1) "s" else ""} to unlock this post. Please top up."
            _currentScreen.value = Screen.WALLET
            return
        }

        viewModelScope.launch {
            val res = dataService.unlockSocialPost(post.id)
            res.onSuccess {
                dataService.fetchWallet()
                // Re-resolve media URL with newly acquired storage authorization
                val freshMediaUrl = dataService.resolveSocialMediaUrl(post.mediaPath)
                val unlockedPost = post.copy(
                    isUnlocked = true,
                    resolvedMediaUrl = freshMediaUrl.ifBlank { post.resolvedMediaUrl }
                )
                _socialPosts.value = _socialPosts.value.map {
                    if (it.id == post.id) unlockedPost else it
                }
                _viewedSocialProfile.value = _viewedSocialProfile.value?.let { prof ->
                    prof.copy(posts = prof.posts.map { if (it.id == post.id) unlockedPost else it })
                }
                _mySocialProfile.value = _mySocialProfile.value?.let { prof ->
                    prof.copy(posts = prof.posts.map { if (it.id == post.id) unlockedPost else it })
                }
                _userMessage.value = "Post unlocked! ($postCost Coin${if (postCost > 1) "s" else ""})"
                // Immediately open in full screen image viewer with the FRESH unlocked post containing resolvedMediaUrl
                _activePostViewer.value = unlockedPost
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to unlock post."
            }
        }
    }

    fun deleteSocialPost(post: SocialPost) {
        val currentUserId = sessionManager.userId.value ?: ""
        if (post.ownerId != currentUserId) {
            _userMessage.value = "You can only delete your own posts."
            return
        }

        viewModelScope.launch {
            val res = dataService.deleteSocialPost(post.id)
            res.onSuccess {
                // 5. Remove the deleted post immediately from the local Social feed state
                _socialPosts.value = _socialPosts.value.filterNot { it.id == post.id }
                _viewedSocialProfile.value = _viewedSocialProfile.value?.let { prof ->
                    prof.copy(posts = prof.posts.filterNot { it.id == post.id })
                }
                _mySocialProfile.value = _mySocialProfile.value?.let { prof ->
                    prof.copy(posts = prof.posts.filterNot { it.id == post.id })
                }
                // 6. If the deleted post is currently open in a viewer: close that viewer
                if (_activePostViewer.value?.id == post.id) {
                    _activePostViewer.value = null
                }
                if (_activeCommentsPost.value?.id == post.id) {
                    _activeCommentsPost.value = null
                    _socialComments.value = emptyList()
                }
                _userMessage.value = "Post deleted successfully."
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to delete post."
            }
        }
    }

    // 15c. Authoritative Post Renewal (Owner only, during 5-day grace period)
    fun renewPost(post: SocialPost) {
        if (_isRenewingPost.value != null) return // Debounce / prevent duplicate concurrent attempts
        if (!post.canBeRenewed) {
            _userMessage.value = "This post is not eligible for renewal."
            return
        }

        _isRenewingPost.value = post.id
        viewModelScope.launch {
            try {
                val res = dataService.renewSocialPost(post.id)
                res.onSuccess {
                    _userMessage.value = "Post renewed successfully!"
                    refreshSocialFeed()
                    loadMySocialProfile()
                    dataService.fetchWallet()
                }.onFailure { err ->
                    _userMessage.value = err.message ?: "Failed to renew post."
                }
            } finally {
                _isRenewingPost.value = null
            }
        }
    }

    fun openCommentsForPost(post: SocialPost) {
        _activeCommentsPost.value = post
        _activeCommentsStory.value = null
        _socialComments.value = emptyList()
        _isLoadingComments.value = true

        viewModelScope.launch {
            dataService.getSocialComments("post", post.id).onSuccess { list ->
                _socialComments.value = list
            }
            _isLoadingComments.value = false
        }
    }

    fun openCommentsForStory(story: SocialStory) {
        _activeCommentsStory.value = story
        _activeCommentsPost.value = null
        _socialComments.value = emptyList()
        _isLoadingComments.value = true

        viewModelScope.launch {
            dataService.getSocialComments("story", story.id).onSuccess { list ->
                _socialComments.value = list
            }
            _isLoadingComments.value = false
        }
    }

    fun closeComments() {
        _activeCommentsPost.value = null
        _activeCommentsStory.value = null
        _socialComments.value = emptyList()
    }

    fun addCommentToActivePost(commentText: String) {
        val post = _activeCommentsPost.value ?: return
        val currentBalance = wallet.value?.balance ?: 0
        val commentCost = effectivePricing.value.postCommentCoins
        if (currentBalance < commentCost) {
            _userMessage.value = "You need $commentCost coin${if (commentCost > 1) "s" else ""} to comment. Please top up."
            _currentScreen.value = Screen.WALLET
            return
        }

        viewModelScope.launch {
            val res = dataService.addSocialComment("post", post.id, commentText)
            res.onSuccess { newComment ->
                dataService.fetchWallet()
                _socialComments.value = _socialComments.value + newComment
                _socialPosts.value = _socialPosts.value.map {
                    if (it.id == post.id) it.copy(commentsCount = it.commentsCount + 1) else it
                }
                _userMessage.value = "Comment posted! ($commentCost Coin${if (commentCost > 1) "s" else ""})"
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to post comment."
            }
        }
    }

    fun addCommentToActiveStory(commentText: String) {
        val story = _activeCommentsStory.value ?: _activeStoryViewer.value ?: return
        val trimmed = commentText.trim()
        if (trimmed.isBlank()) return

        val currentBalance = wallet.value?.balance ?: 0
        val storyCost = effectivePricing.value.storyReplyCoins
        if (currentBalance < storyCost) {
            _userMessage.value = "You need $storyCost coin${if (storyCost > 1) "s" else ""} to reply to a story. Please top up."
            _currentScreen.value = Screen.WALLET
            return
        }

        val currentUserId = sessionManager.userId.value ?: ""
        var hostReceiverId = story.ownerId.takeIf { it.isNotBlank() }
            ?: story.ownerPartner?.id?.takeIf { it.isNotBlank() }
            ?: story.ownerPartner?.userId?.takeIf { it.isNotBlank() }
            ?: return

        if (hostReceiverId == currentUserId) {
            _userMessage.value = "Cannot reply to your own story."
            return
        }

        viewModelScope.launch {
            // Use dedicated RPC send_story_reply which does single coin deduction, attaches story reference, and creates chat message + social comment atomically
            val sendResult = dataService.sendStoryReply(storyId = story.id, messageText = trimmed)

            sendResult.onSuccess { newMsg ->
                val convId = newMsg.conversationId ?: ""
                val currentList = _messages.value
                if (convId.isNotBlank() && _activeConversation.value?.id == convId) {
                    if (currentList.none { it.id == newMsg.id }) {
                        val updated = currentList + newMsg
                        _messages.value = updated
                        conversationMessagesCache[convId] = updated
                    }
                } else if (convId.isNotBlank()) {
                    val cached = conversationMessagesCache[convId]
                    if (cached != null && cached.none { it.id == newMsg.id }) {
                        conversationMessagesCache[convId] = cached + newMsg
                    }
                }

                // Add to social comments list if modal is open
                val newComment = SocialComment(
                    id = newMsg.id,
                    contentId = story.id,
                    contentType = "story",
                    userId = currentUserId,
                    comment = trimmed,
                    createdAt = "Just now",
                    displayName = sessionManager.currentUser.value?.displayName ?: "Me",
                    avatarUrl = sessionManager.currentUser.value?.avatarUrl
                )
                _socialComments.value = _socialComments.value + newComment

                dataService.fetchWallet()
                refreshConversations()
                _userMessage.value = "Reply sent! (3 Coins)"
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to send reply."
            }
        }
    }

    fun toggleSocialFollow(targetUserId: String) {
        val cleanTargetId = targetUserId.trim()
        if (cleanTargetId.isBlank()) return

        viewModelScope.launch {
            val res = dataService.toggleSocialFollow(cleanTargetId)
            res.onSuccess { isFollowing ->
                // 1. Update viewed social profile if matching
                _viewedSocialProfile.value?.let { currentProfile ->
                    if (currentProfile.userId == cleanTargetId || currentProfile.partner?.id == cleanTargetId || currentProfile.partner?.userId == cleanTargetId) {
                        _viewedSocialProfile.value = currentProfile.copy(
                            isFollowing = isFollowing,
                            followersCount = if (isFollowing) currentProfile.followersCount + 1 else maxOf(0, currentProfile.followersCount - 1),
                            partner = currentProfile.partner?.copy(
                                isFollowing = isFollowing,
                                followersCount = if (isFollowing) currentProfile.partner.followersCount + 1 else maxOf(0, currentProfile.partner.followersCount - 1)
                            )
                        )
                    }
                }
                // 2. Update selected partner if matching
                _selectedPartner.value?.let { currentPartner ->
                    if (currentPartner.id == cleanTargetId || currentPartner.userId == cleanTargetId) {
                        _selectedPartner.value = currentPartner.copy(
                            isFollowing = isFollowing,
                            followersCount = if (isFollowing) currentPartner.followersCount + 1 else maxOf(0, currentPartner.followersCount - 1)
                        )
                    }
                }
                // 3. Update partners list if matching
                _availablePartners.value = _availablePartners.value.map { p ->
                    if (p.id == cleanTargetId || p.userId == cleanTargetId) {
                        p.copy(
                            isFollowing = isFollowing,
                            followersCount = if (isFollowing) p.followersCount + 1 else maxOf(0, p.followersCount - 1)
                        )
                    } else p
                }

                // 4. Background synchronize authoritative data from backend
                if (_selectedPartner.value?.id == cleanTargetId || _selectedPartner.value?.userId == cleanTargetId) {
                    dataService.getHostProfile(cleanTargetId).onSuccess { authoritativeHost ->
                        _selectedPartner.value = authoritativeHost
                        _availablePartners.value = _availablePartners.value.map {
                            if (it.id == authoritativeHost.id) authoritativeHost else it
                        }
                    }
                }
                if (_viewedSocialProfile.value?.userId == cleanTargetId) {
                    dataService.getSocialProfile(cleanTargetId).onSuccess { authoritativeSocial ->
                        _viewedSocialProfile.value = _viewedSocialProfile.value?.copy(
                            isFollowing = authoritativeSocial.isFollowing,
                            followersCount = authoritativeSocial.followersCount,
                            followingCount = authoritativeSocial.followingCount
                        )
                    }
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to update follow status."
            }
        }
    }

    fun startCallFromSocial(partner: PartnerProfile) {
        requestCall(partner)
    }

    // ==========================================
    // ISOLATED AI CALL FLOW (NEHA & AI HOSTS)
    // ==========================================

    fun startAiCall(host: PartnerProfile) {
        if (isStartingAiCall) return
        isStartingAiCall = true

        val hostId = host.id.takeIf { it.isNotBlank() } ?: host.userId ?: AiHostRegistry.NEHA_HOST_ID
        _aiCallHost.value = host
        _aiCallHostId.value = hostId
        _aiCallVoiceId.value = "ritu"
        _aiCallState.value = AiCallUiState.CONNECTING
        _aiCallElapsedSeconds.value = 0
        _aiCallTranscript.value = ""
        _aiCallReply.value = ""
        _aiCallError.value = null
        _aiCallIsRecording.value = false
        _aiCallIsProcessing.value = false
        _aiCallIsSpeaking.value = false

        // Navigate immediately to the dedicated AI Call Screen
        _currentScreen.value = Screen.AI_CALL

        viewModelScope.launch {
            try {
                val result = aiCallService.startCall(hostId)
                result.onSuccess { startResp ->
                    _aiCallSessionId.value = startResp.sessionId
                    _aiCallVoiceId.value = startResp.voiceId
                    _aiCallState.value = AiCallUiState.LISTENING
                    startAiCallTimer()
                }.onFailure { err ->
                    Log.e("BaatlyAiCall", "Failed to start AI call: ${err.message}")
                    _aiCallError.value = err.message ?: "Could not start call. Please try again."
                    _aiCallState.value = AiCallUiState.ERROR
                }
            } catch (e: Exception) {
                Log.e("BaatlyAiCall", "Exception starting AI call: ${e.message}")
                _aiCallError.value = "Connection issue, please try again"
                _aiCallState.value = AiCallUiState.ERROR
            } finally {
                isStartingAiCall = false
            }
        }
    }

    private fun startAiCallTimer() {
        aiCallTimerJob?.cancel()
        aiCallTimerJob = viewModelScope.launch {
            var elapsed = 0
            _aiCallElapsedSeconds.value = elapsed
            while (_aiCallState.value != AiCallUiState.ENDED && _aiCallState.value != AiCallUiState.ENDING) {
                delay(1000)
                elapsed++
                _aiCallElapsedSeconds.value = elapsed
            }
        }
    }

    fun startAiTurnRecording(): Boolean {
        if (_aiCallState.value == AiCallUiState.NEHA_SPEAKING ||
            _aiCallState.value == AiCallUiState.PROCESSING ||
            _aiCallState.value == AiCallUiState.ENDING ||
            _aiCallState.value == AiCallUiState.ENDED ||
            isProcessingAiTurn
        ) {
            return false
        }

        try {
            audioPlayerManager.stop()
            val recordedFile = audioRecorderManager.startRecording()
            if (recordedFile != null) {
                currentAiAudioFile = recordedFile
                _aiCallIsRecording.value = true
                _aiCallState.value = AiCallUiState.RECORDING
                _aiCallError.value = null
                return true
            } else {
                _aiCallError.value = "Could not access microphone."
                _aiCallState.value = AiCallUiState.LISTENING
                return false
            }
        } catch (e: Exception) {
            Log.e("BaatlyAiCall", "Error starting turn recording: ${e.message}")
            _aiCallError.value = "Recording failed, please try again."
            _aiCallState.value = AiCallUiState.LISTENING
            return false
        }
    }

    fun stopAiTurnRecordingAndSend() {
        if (!_aiCallIsRecording.value && _aiCallState.value != AiCallUiState.RECORDING) {
            return
        }

        val (file, durationSec) = audioRecorderManager.stopRecording()
        _aiCallIsRecording.value = false

        val targetFile = file ?: currentAiAudioFile
        if (targetFile == null || !targetFile.exists() || targetFile.length() < 500L) {
            _aiCallError.value = "Could not hear you, please try again"
            _aiCallState.value = AiCallUiState.LISTENING
            try { targetFile?.delete() } catch (_: Exception) {}
            currentAiAudioFile = null
            return
        }

        val activeSessionId = _aiCallSessionId.value
        val hostId = _aiCallHostId.value ?: AiHostRegistry.NEHA_HOST_ID

        if (activeSessionId.isNullOrBlank()) {
            _aiCallError.value = "Session not ready. Please try again."
            _aiCallState.value = AiCallUiState.LISTENING
            try { targetFile.delete() } catch (_: Exception) {}
            currentAiAudioFile = null
            return
        }

        sendAiTurn(activeSessionId, hostId, targetFile)
    }

    fun cancelAiTurnRecording() {
        audioRecorderManager.cancelRecording()
        _aiCallIsRecording.value = false
        try { currentAiAudioFile?.delete() } catch (_: Exception) {}
        currentAiAudioFile = null
        if (_aiCallState.value == AiCallUiState.RECORDING) {
            _aiCallState.value = AiCallUiState.LISTENING
        }
    }

    private fun sendAiTurn(sessionId: String, hostId: String, audioFile: File) {
        if (isProcessingAiTurn) {
            try { audioFile.delete() } catch (_: Exception) {}
            return
        }
        isProcessingAiTurn = true
        _aiCallIsProcessing.value = true
        _aiCallState.value = AiCallUiState.PROCESSING
        _aiCallError.value = null

        aiTurnJob?.cancel()
        aiTurnJob = viewModelScope.launch {
            try {
                val result = aiCallService.sendAudioTurn(
                    sessionId = sessionId,
                    hostId = hostId,
                    audioFile = audioFile,
                    mimeType = "audio/mp4"
                )

                // Clean up the recorded user audio file after sending
                try { audioFile.delete() } catch (_: Exception) {}
                currentAiAudioFile = null

                result.onSuccess { turnResp ->
                    _aiCallTranscript.value = turnResp.transcript
                    _aiCallReply.value = turnResp.reply
                    _aiCallVoiceId.value = turnResp.voiceId

                    val base64Audio = turnResp.audioBase64
                    if (!base64Audio.isNullOrBlank()) {
                        playAiAudioResponse(base64Audio)
                    } else {
                        // In case audio wasn't generated but reply text is available, return to listening
                        _aiCallState.value = AiCallUiState.LISTENING
                    }
                }.onFailure { err ->
                    Log.e("BaatlyAiCall", "Turn failed: ${err.message}")
                    _aiCallError.value = "Could not hear you, please try again"
                    _aiCallState.value = AiCallUiState.LISTENING
                }
            } catch (e: Exception) {
                Log.e("BaatlyAiCall", "Exception sending turn: ${e.message}")
                _aiCallError.value = "Connection issue, please try again"
                _aiCallState.value = AiCallUiState.LISTENING
            } finally {
                isProcessingAiTurn = false
                _aiCallIsProcessing.value = false
            }
        }
    }

    private fun playAiAudioResponse(base64Audio: String) {
        aiPlaybackJob?.cancel()
        aiPlaybackJob = viewModelScope.launch {
            try {
                // Cancel any ongoing playback and clean up previous playback temp file
                audioPlayerManager.stop()
                try { currentAiPlaybackFile?.delete() } catch (_: Exception) {}
                currentAiPlaybackFile = null

                if (base64Audio.isBlank()) {
                    _aiCallIsSpeaking.value = false
                    if (_aiCallState.value == AiCallUiState.NEHA_SPEAKING || _aiCallState.value == AiCallUiState.PROCESSING) {
                        _aiCallState.value = AiCallUiState.LISTENING
                    }
                    return@launch
                }

                val decodedBytes = try {
                    android.util.Base64.decode(base64Audio, android.util.Base64.DEFAULT)
                } catch (e: Exception) {
                    Log.e("BaatlyAiCall", "Failed to decode base64 audio: ${e.message}")
                    null
                }

                if (decodedBytes == null || decodedBytes.isEmpty()) {
                    Log.e("BaatlyAiCall", "Decoded audio bytes are empty")
                    _aiCallIsSpeaking.value = false
                    if (_aiCallState.value == AiCallUiState.NEHA_SPEAKING || _aiCallState.value == AiCallUiState.PROCESSING) {
                        _aiCallState.value = AiCallUiState.LISTENING
                    }
                    return@launch
                }

                val tempFile = File(getApplication<Application>().cacheDir, "neha_reply_${System.currentTimeMillis()}.mp3")
                tempFile.writeBytes(decodedBytes)
                currentAiPlaybackFile = tempFile

                _aiCallIsSpeaking.value = true
                _aiCallState.value = AiCallUiState.NEHA_SPEAKING

                var playbackEnded = false

                audioPlayerManager.playLocalFile(
                    file = tempFile,
                    onCompletion = {
                        playbackEnded = true
                    },
                    onError = { err ->
                        Log.e("BaatlyAiCall", "Local playback error: $err")
                        playbackEnded = true
                    }
                )

                // Wait until playback completes or call state transitions away
                while (!playbackEnded && _aiCallState.value == AiCallUiState.NEHA_SPEAKING) {
                    delay(100)
                }

                audioPlayerManager.stop()
                try { tempFile.delete() } catch (_: Exception) {}
                currentAiPlaybackFile = null
                _aiCallIsSpeaking.value = false

                if (_aiCallState.value == AiCallUiState.NEHA_SPEAKING) {
                    _aiCallState.value = AiCallUiState.LISTENING
                }
            } catch (e: Exception) {
                Log.e("BaatlyAiCall", "Error during AI audio playback: ${e.message}")
                audioPlayerManager.stop()
                try { currentAiPlaybackFile?.delete() } catch (_: Exception) {}
                currentAiPlaybackFile = null
                _aiCallIsSpeaking.value = false
                if (_aiCallState.value == AiCallUiState.NEHA_SPEAKING || _aiCallState.value == AiCallUiState.PROCESSING) {
                    _aiCallState.value = AiCallUiState.LISTENING
                }
            }
        }
    }

    fun endAiCall() {
        val activeSessionId = _aiCallSessionId.value
        _aiCallState.value = AiCallUiState.ENDING

        // Cancel running turn request, playback, and timer
        aiTurnJob?.cancel()
        aiPlaybackJob?.cancel()
        aiCallTimerJob?.cancel()

        // Stop recorder and playback immediately
        audioRecorderManager.cancelRecording()
        audioPlayerManager.stop()
        _aiCallIsRecording.value = false
        _aiCallIsProcessing.value = false
        _aiCallIsSpeaking.value = false
        isProcessingAiTurn = false

        try { currentAiAudioFile?.delete() } catch (_: Exception) {}
        try { currentAiPlaybackFile?.delete() } catch (_: Exception) {}
        currentAiAudioFile = null
        currentAiPlaybackFile = null

        viewModelScope.launch {
            if (!activeSessionId.isNullOrBlank()) {
                try {
                    aiCallService.endCall(activeSessionId)
                } catch (e: Exception) {
                    Log.e("BaatlyAiCall", "Error notifying ai-call-end: ${e.message}")
                }
            }
            _aiCallState.value = AiCallUiState.ENDED
            _aiCallSessionId.value = null
            _aiCallHost.value = null
            _aiCallHostId.value = null

            // Return to host profile or home screen
            if (_currentScreen.value == Screen.AI_CALL) {
                _currentScreen.value = if (_selectedPartner.value != null) Screen.HOST_PROFILE else Screen.HOME
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        callTimerJob?.cancel()
        aiCallTimerJob?.cancel()
        aiTurnJob?.cancel()
        aiPlaybackJob?.cancel()
        realtimeManager.destroy()
        agoraCallManager.destroy()
        audioPlayerManager.stop()
        audioRecorderManager.release()
        try { currentAiAudioFile?.delete() } catch (_: Exception) {}
        try { currentAiPlaybackFile?.delete() } catch (_: Exception) {}
    }
}

enum class Screen {
    AUTH,
    HOME,
    HOST_PROFILE,
    ACTIVE_CALL,
    AI_CALL,
    DIRECT_CHAT,
    BAATLY_SYSTEM_CHAT,
    CHAT_LIST,
    WALLET,
    MEMBERSHIP,
    RECENT_CALLS,
    PROFILE,
    NOTIFICATIONS,
    SOCIAL,
    SOCIAL_PROFILE,
    LEGAL_DETAIL
}

enum class HomeMode {
    CALL,
    CHAT
}

enum class CallState {
    IDLE,
    REQUESTING,
    RINGING,
    CONNECTED,
    ENDED
}

