package com.example.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PartnerProfile
import com.example.data.model.MembershipState
import com.example.ui.BaatlyViewModel
import com.example.ui.HomeMode
import com.example.ui.Screen
import com.example.ui.components.BaatlyTopBar
import com.example.ui.components.HostCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(viewModel: BaatlyViewModel) {
    val homeMode by viewModel.homeMode.collectAsState()
    val availablePartners by viewModel.availablePartners.collectAsState()
    val isLoadingPartners by viewModel.isLoadingPartners.collectAsState()
    val wallet by viewModel.wallet.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val membershipState by viewModel.membershipState.collectAsState()
    val effectivePricing by viewModel.effectivePricing.collectAsState()

    // Filter hosts per prompt requirements
    val displayedPartners = remember(availablePartners, homeMode) {
        if (homeMode == HomeMode.CALL) {
            availablePartners.filter {
                it.isPartner &&
                it.approvalStatus == "approved" &&
                it.isAvailable &&
                it.isOnline &&
                it.audioEnabled &&
                it.accountStatus != "deleted"
            }
        } else {
            availablePartners.filter {
                it.isPartner &&
                it.approvalStatus == "approved" &&
                it.chatEnabled &&
                it.accountStatus != "deleted"
            }
        }
    }

    Scaffold(
        topBar = {
            BaatlyTopBar(
                coinBalance = wallet?.balance ?: 0,
                onCoinClick = { viewModel.setScreen(Screen.WALLET) },
                onNotificationClick = { viewModel.setScreen(Screen.NOTIFICATIONS) },
                unreadNotifications = notifications.count { !it.isRead },
                onRefreshClick = {
                    viewModel.refreshPartners()
                    viewModel.refreshWallet()
                    viewModel.refreshMembership()
                },
                membershipState = membershipState,
                onMembershipClick = { viewModel.setScreen(Screen.MEMBERSHIP) }
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Segmented Primary Choice: [ CALL | CHAT ]
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp)
                ) {
                    SegmentButton(
                        title = "CALL",
                        icon = Icons.Filled.Call,
                        selected = homeMode == HomeMode.CALL,
                        modifier = Modifier.weight(1f),
                        testTag = "tab_call_mode",
                        selectedColor = VibrantPink,
                        onClick = { viewModel.setHomeMode(HomeMode.CALL) }
                    )
                    SegmentButton(
                        title = "CHAT",
                        icon = Icons.AutoMirrored.Filled.Chat,
                        selected = homeMode == HomeMode.CHAT,
                        modifier = Modifier.weight(1f),
                        testTag = "tab_chat_mode",
                        selectedColor = VibrantPink,
                        onClick = { viewModel.setHomeMode(HomeMode.CHAT) }
                    )
                }
            }

            // Membership Promo / Active Status Banner
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (effectivePricing.isMember) Color(0xFF221C0E) else DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (effectivePricing.isMember) Color(0xFFFFD54F).copy(alpha = 0.5f) else DarkBorderSubtle
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clickable { viewModel.setScreen(Screen.MEMBERSHIP) }
                    .testTag("home_membership_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "👑",
                            fontSize = 18.sp
                        )
                        Column {
                            if (effectivePricing.isMember) {
                                val active = membershipState as? MembershipState.Active
                                val timeLeft = active?.let { "${it.remainingHours}h ${it.remainingMinutes % 60}m left" } ?: "24-Hour Active"
                                Text(
                                    text = "VIP Pass Active • $timeLeft",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFFD54F)
                                    )
                                )
                                Text(
                                    text = "50% off calls (3 coins/min) • 66% off chat (1 coin/msg)",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                            } else {
                                Text(
                                    text = "Get 24-Hour Membership for ₹100",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                                Text(
                                    text = "Cut call rates in half: 6 → 3 coins/min • Chat: 3 → 1 coin",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }

                    Text(
                        text = if (effectivePricing.isMember) "VIEW" else "JOIN",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (effectivePricing.isMember) Color(0xFFFFD54F) else PrimaryLavender
                        )
                    )
                }
            }

            // Available Hosts List
            if (isLoadingPartners) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PrimaryLavender)
                }
            } else if (displayedPartners.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (homeMode == HomeMode.CALL) "No hosts available for audio calls right now" else "No hosts available for chat right now",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedButton(
                            onClick = { viewModel.refreshPartners() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryLavender),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = PrimaryLavender)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Refresh", color = PrimaryLavender)
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 20.dp)
                ) {
                    items(displayedPartners, key = { it.id }) { partner ->
                        HostCard(
                            partner = partner,
                            homeMode = homeMode,
                            onCardClick = { viewModel.openHostProfile(partner) },
                            onActionClick = {
                                if (homeMode == HomeMode.CALL) {
                                    viewModel.requestCall(partner)
                                } else {
                                    viewModel.openChatWithHost(partner)
                                }
                            },
                            onFollowClick = { viewModel.toggleFollowHost(partner) },
                            dataService = viewModel.dataService,
                            effectivePricing = effectivePricing
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SegmentButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    testTag: String,
    selectedColor: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) selectedColor else Color.Transparent,
        modifier = modifier
            .testTag(testTag)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) Color.White else TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontSize = 14.sp,
                    color = if (selected) Color.White else TextSecondary
                )
            )
        }
    }
}
