package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.browser.customtabs.CustomTabsIntent
import com.example.data.billing.IndiaAdministrativeAreas
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.network.SupabaseDataService
import com.example.util.BaatlyAnalytics
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MembershipRepository(
    private val dataService: SupabaseDataService,
    private val sessionManager: SessionManager,
    private val repositoryScope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {
    private val _membershipState = MutableStateFlow<MembershipState>(MembershipState.Loading)
    val membershipState: StateFlow<MembershipState> = _membershipState.asStateFlow()

    private val _effectivePricing = MutableStateFlow(EffectiveUserPricing.DEFAULT_NON_MEMBER)
    val effectivePricing: StateFlow<EffectiveUserPricing> = _effectivePricing.asStateFlow()

    private val _activePlan = MutableStateFlow(MembershipPlan())
    val activePlan: StateFlow<MembershipPlan> = _activePlan.asStateFlow()

    private val _purchaseUiState = MutableStateFlow<MembershipPurchaseUiState>(MembershipPurchaseUiState.Idle)
    val purchaseUiState: StateFlow<MembershipPurchaseUiState> = _purchaseUiState.asStateFlow()

    private var countdownJob: Job? = null

    init {
        startCountdownTimer()
    }

    private fun startCountdownTimer() {
        countdownJob?.cancel()
        countdownJob = repositoryScope.launch {
            while (isActive) {
                delay(1000)
                val current = _membershipState.value
                if (current is MembershipState.Active) {
                    val now = System.currentTimeMillis()
                    val remaining = current.expiresAtEpochMs - now
                    if (remaining <= 0) {
                        Log.i(TAG, "Membership countdown reached 0. Transitioning to Expired state.")
                        BaatlyAnalytics.logMembershipExpired(sessionManager.userId.value)
                        _membershipState.value = MembershipState.Expired(current.membership)
                        _effectivePricing.value = EffectiveUserPricing.DEFAULT_NON_MEMBER
                        // Authoritatively sync with server
                        repositoryScope.launch {
                            dataService.expireMemberships()
                            refreshMembership()
                        }
                    } else {
                        _membershipState.value = current.copy(remainingMillis = remaining)
                    }
                }
            }
        }
    }

    suspend fun refreshMembership() {
        val userId = sessionManager.userId.value
        if (userId.isNullOrBlank()) {
            _membershipState.value = MembershipState.Inactive
            _effectivePricing.value = EffectiveUserPricing.DEFAULT_NON_MEMBER
            return
        }

        try {
            // 1. Fetch active plan
            val planRes = dataService.fetchActiveMembershipPlan()
            if (planRes.isSuccess) {
                planRes.getOrNull()?.let { _activePlan.value = it }
            }

            // 2. Fetch membership record
            val memRes = dataService.fetchUserMembership(userId)
            val membership = memRes.getOrNull()

            val now = System.currentTimeMillis()
            var isActiveMembership = false

            if (membership != null && membership.status.equals("active", ignoreCase = true)) {
                val expiresMs = parseIsoTimestamp(membership.expiresAt)
                if (expiresMs != null && expiresMs > now) {
                    isActiveMembership = true
                    val remaining = expiresMs - now
                    _membershipState.value = MembershipState.Active(
                        membership = membership,
                        expiresAtEpochMs = expiresMs,
                        remainingMillis = remaining
                    )
                } else {
                    _membershipState.value = MembershipState.Expired(membership)
                }
            } else if (membership != null && membership.status.equals("expired", ignoreCase = true)) {
                _membershipState.value = MembershipState.Expired(membership)
            } else {
                _membershipState.value = MembershipState.Inactive
            }

            // 3. Fetch authoritative effective pricing
            val pricingRes = dataService.getEffectiveUserPricing(userId, isMemberFallback = isActiveMembership)
            val pricing = pricingRes.getOrNull() ?: if (isActiveMembership) EffectiveUserPricing.DEFAULT_MEMBER else EffectiveUserPricing.DEFAULT_NON_MEMBER
            _effectivePricing.value = pricing

            Log.d(TAG, "Membership refreshed: state=${_membershipState.value::class.simpleName}, isMember=${pricing.isMember}")
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing membership: ${e.message}", e)
        }
    }

    fun resetPurchaseUiState() {
        _purchaseUiState.value = MembershipPurchaseUiState.Idle
    }

    suspend fun startMembershipPurchase(
        context: Context,
        externalTransactionToken: String? = null,
        administrativeArea: String? = null
    ) {
        val userId = sessionManager.userId.value
        if (userId.isNullOrBlank()) {
            _purchaseUiState.value = MembershipPurchaseUiState.Failed("Please sign in to get membership.")
            return
        }

        // Validate if already active
        val current = _membershipState.value
        if (current is MembershipState.Active) {
            _purchaseUiState.value = MembershipPurchaseUiState.Failed("You already have an active 24-Hour Membership!", canRetry = false)
            return
        }

        val plan = _activePlan.value
        BaatlyAnalytics.logMembershipPurchaseStarted(userId, plan.id, plan.priceInr)
        _purchaseUiState.value = MembershipPurchaseUiState.CreatingPayment

        try {
            // 1. Call Supabase RPC create_membership_payment
            val paymentRes = dataService.createMembershipPayment(plan.id)
            if (paymentRes.isFailure) {
                val err = paymentRes.exceptionOrNull()?.message ?: "Failed to initiate membership payment."
                BaatlyAnalytics.logMembershipPaymentFailed(null, err)
                _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                return
            }

            val paymentId = paymentRes.getOrThrow()
            val tenantOrderRef = "MB_${System.currentTimeMillis()}_${(1000..9999).random()}"
            BaatlyAnalytics.logMembershipPaymentCreated(paymentId, tenantOrderRef)

            var calculatedTaxBreakdown: com.example.data.billing.TaxBreakdown? = null

            // 1b. If Google Play Alternative Billing token is present, prepare must happen BEFORE UroPay order creation
            if (!externalTransactionToken.isNullOrBlank()) {
                if (administrativeArea.isNullOrBlank() || !IndiaAdministrativeAreas.isValid(administrativeArea)) {
                    val err = "A valid Indian state or union territory is required for Google Play Alternative Billing."
                    Log.e(TAG, err)
                    _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                    return
                }

                val taxRes = com.example.data.billing.BaatlyTaxConfig.calculateTaxBreakdown(
                    totalAmount = plan.priceInr,
                    explicitTaxRatePercent = plan.taxRatePercent,
                    explicitPreTaxAmount = plan.preTaxAmountInr,
                    explicitTaxAmount = plan.taxAmountInr
                )
                if (taxRes.isFailure) {
                    val err = taxRes.exceptionOrNull()?.message ?: "Tax calculation failed for membership."
                    Log.e(TAG, "Tax configuration error: $err")
                    _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                    return
                }

                val taxBreakdown = taxRes.getOrThrow()
                calculatedTaxBreakdown = taxBreakdown

                val prepRes = dataService.prepareGooglePlayExternalTransaction(
                    paymentId = paymentId,
                    externalTransactionToken = externalTransactionToken,
                    administrativeArea = administrativeArea,
                    preTaxAmountInr = taxBreakdown.preTaxAmountFormatted,
                    taxAmountInr = taxBreakdown.taxAmountFormatted
                )
                if (prepRes.isFailure) {
                    val err = prepRes.exceptionOrNull()?.message ?: "Failed to prepare Google Play Alternative Billing transaction."
                    Log.e(TAG, "prepareGooglePlayExternalTransaction failed: $err")
                    _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                    return
                }
                Log.d(TAG, "prepareGooglePlayExternalTransaction succeeded for membership payment: $paymentId")
            }

            // 2. Call create-uropay-order Edge Function (ONLY after prepare succeeds if token is present)
            val orderRes = dataService.createMembershipUroPayOrder(paymentId, plan.id, tenantOrderRef)
            if (orderRes.isFailure) {
                val err = orderRes.exceptionOrNull()?.message ?: "Failed to open UroPay payment checkout."
                BaatlyAnalytics.logMembershipPaymentFailed(paymentId, err)
                _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                return
            }

            val orderResult = orderRes.getOrThrow()
            val openUrl = orderResult.openUrl
            if (openUrl.isNullOrBlank()) {
                val err = "Invalid payment checkout link received."
                BaatlyAnalytics.logMembershipPaymentFailed(paymentId, err)
                _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                return
            }

            // 3. Save pending payment in SessionManager with full tax and reporting context
            sessionManager.savePendingPayment(
                PendingUroPayPayment(
                    paymentId = paymentId,
                    orderId = orderResult.orderId,
                    tenantOrderRef = tenantOrderRef,
                    packageId = plan.id,
                    coins = 0,
                    priceInr = plan.priceInr,
                    openUrl = openUrl,
                    createdAt = System.currentTimeMillis(),
                    isMembership = true,
                    externalTransactionToken = externalTransactionToken,
                    administrativeArea = administrativeArea,
                    preTaxAmountInr = calculatedTaxBreakdown?.preTaxAmount,
                    taxAmountInr = calculatedTaxBreakdown?.taxAmount,
                    taxRatePercent = plan.taxRatePercent,
                    googleReportStatus = if (!externalTransactionToken.isNullOrBlank()) "pending" else null
                )
            )

            // 4. Update UI State & open checkout
            _purchaseUiState.value = MembershipPurchaseUiState.OpeningCheckout(paymentId, openUrl)
            BaatlyAnalytics.logMembershipCheckoutOpened(paymentId)

            withContext(Dispatchers.Main) {
                try {
                    val customTabsIntent = CustomTabsIntent.Builder().build()
                    customTabsIntent.launchUrl(context, Uri.parse(openUrl))
                } catch (_: Exception) {
                    val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(openUrl)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(fallbackIntent)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "startMembershipPurchase error: ${e.message}", e)
            BaatlyAnalytics.logMembershipPaymentFailed(null, e.message ?: "Unknown error")
            _purchaseUiState.value = MembershipPurchaseUiState.Failed(e.message ?: "Could not complete payment setup.")
        }
    }

    suspend fun verifyMembershipPayment(paymentId: String): Boolean {
        _purchaseUiState.value = MembershipPurchaseUiState.Verifying(paymentId)
        val res = dataService.verifyUroPayPayment(paymentId)
        if (res.isSuccess) {
            val result = res.getOrThrow()
            BaatlyAnalytics.logMembershipPaymentVerified(paymentId, result.success, result.status)

            if (result.success || result.status == "success") {
                // Finalize payment in backend RPC
                val finalizeRes = dataService.finalizeUroPayPayment(
                    paymentRowId = paymentId,
                    providerPaymentId = result.orderId
                )
                if (finalizeRes.isFailure) {
                    val err = finalizeRes.exceptionOrNull()?.message ?: "Failed to finalize membership payment."
                    Log.e(TAG, "finalizeUroPayPayment failed: $err", finalizeRes.exceptionOrNull())
                    BaatlyAnalytics.logMembershipPaymentFailed(paymentId, err)
                    _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
                    return false
                }

                // Refresh membership from Supabase immediately so user gets benefits without waiting
                refreshMembership()

                val currentMem = (_membershipState.value as? MembershipState.Active)?.membership
                    ?: UserMembership(status = "active", planId = _activePlan.value.id)

                BaatlyAnalytics.logMembershipActivated(
                    userId = sessionManager.userId.value,
                    planId = currentMem.planId,
                    expiresAt = currentMem.expiresAt
                )

                // Report Google Play External Transaction if token exists
                val pending = sessionManager.getPendingPayment()
                if (pending != null && pending.paymentId == paymentId && !pending.externalTransactionToken.isNullOrBlank()) {
                    val reportRes = dataService.reportGooglePlayExternalTransaction(paymentId = paymentId)
                    val reportSuccess = reportRes.isSuccess && (reportRes.getOrNull()?.optBoolean("success", false) == true)
                    if (reportSuccess) {
                        Log.d(TAG, "reportGooglePlayExternalTransaction membership succeeded for payment: $paymentId")
                        sessionManager.clearPendingPayment()
                    } else {
                        // CRITICAL: DO NOT clear pending payment context on temporary Google reporting failure.
                        // Allow server retry queue to process it; preserve all payment and Google token context.
                        Log.w(TAG, "reportGooglePlayExternalTransaction membership failed or queued. Preserving payment context for retry.")
                        sessionManager.savePendingPayment(pending.copy(googleReportStatus = "failed"))
                    }
                } else {
                    sessionManager.clearPendingPayment()
                }

                _purchaseUiState.value = MembershipPurchaseUiState.Success(currentMem)
                return true
            } else if (result.status == "pending" || result.status == "created" || result.status == "in_progress") {
                _purchaseUiState.value = MembershipPurchaseUiState.Pending(
                    paymentId,
                    "Payment is being verified. Your membership will activate automatically once confirmed."
                )
                return false
            } else if (result.status == "cancelled") {
                sessionManager.clearPendingPayment()
                _purchaseUiState.value = MembershipPurchaseUiState.Cancelled("Payment was cancelled. No amount was charged.")
                return false
            } else {
                sessionManager.clearPendingPayment()
                _purchaseUiState.value = MembershipPurchaseUiState.Failed(
                    result.error ?: result.message ?: "Payment verification failed (${result.status})."
                )
                return false
            }
        } else {
            val err = res.exceptionOrNull()?.message ?: "Network error verifying payment."
            _purchaseUiState.value = MembershipPurchaseUiState.Failed(err)
            return false
        }
    }

    fun handlePaymentCancelled() {
        sessionManager.clearPendingPayment()
        _purchaseUiState.value = MembershipPurchaseUiState.Cancelled("Payment cancelled. No amount was added as membership.")
    }

    companion object {
        private const val TAG = "MembershipRepository"
    }
}
