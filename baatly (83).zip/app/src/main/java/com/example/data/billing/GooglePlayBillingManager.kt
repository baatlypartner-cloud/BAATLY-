package com.example.data.billing

import android.app.Activity
import android.content.Context
import android.util.Log
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.UserChoiceBillingListener
import com.android.billingclient.api.UserChoiceDetails
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Manages Google Play Billing Library with User Choice Billing (Alternative Billing) enabled
 * for eligible India users alongside UroPay.
 */
class GooglePlayBillingManager(
    private val context: Context,
    private val coroutineScope: CoroutineScope
) : PurchasesUpdatedListener, UserChoiceBillingListener, BillingClientStateListener {

    companion object {
        private const val TAG = "PlayBillingManager"
    }

    private var billingClient: BillingClient? = null

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _userChoiceEvents = MutableSharedFlow<UserChoiceEvent>(extraBufferCapacity = 10)
    val userChoiceEvents: SharedFlow<UserChoiceEvent> = _userChoiceEvents.asSharedFlow()

    private val _googlePurchases = MutableSharedFlow<List<Purchase>>(extraBufferCapacity = 10)
    val googlePurchases: SharedFlow<List<Purchase>> = _googlePurchases.asSharedFlow()

    private val _billingErrors = MutableSharedFlow<String>(extraBufferCapacity = 10)
    val billingErrors: SharedFlow<String> = _billingErrors.asSharedFlow()

    sealed class UserChoiceEvent {
        data class AlternativeBillingSelected(
            val externalTransactionToken: String,
            val products: List<UserChoiceDetails.Product>
        ) : UserChoiceEvent()
    }

    init {
        initializeClient()
    }

    private fun initializeClient() {
        try {
            billingClient = BillingClient.newBuilder(context)
                .setListener(this)
                .enablePendingPurchases(
                    PendingPurchasesParams.newBuilder()
                        .enableOneTimeProducts()
                        .build()
                )
                .enableUserChoiceBilling(this)
                .build()

            startConnection()
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing BillingClient: ${e.message}", e)
        }
    }

    private fun startConnection() {
        billingClient?.startConnection(this)
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
            Log.d(TAG, "Billing client setup successful.")
            _isReady.value = true
        } else {
            Log.w(TAG, "Billing setup failed: code=${billingResult.responseCode}, msg=${billingResult.debugMessage}")
            _isReady.value = false
        }
    }

    override fun onBillingServiceDisconnected() {
        Log.w(TAG, "Billing client disconnected. Retrying in background...")
        _isReady.value = false
    }

    override fun userSelectedAlternativeBilling(userChoiceDetails: UserChoiceDetails) {
        val token = userChoiceDetails.externalTransactionToken
        val products = userChoiceDetails.products
        Log.d(TAG, "userSelectedAlternativeBilling: tokenReceived=${!token.isNullOrBlank()}, products=${products.map { it.id }}")
        coroutineScope.launch {
            _userChoiceEvents.emit(
                UserChoiceEvent.AlternativeBillingSelected(
                    externalTransactionToken = token,
                    products = products
                )
            )
        }
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
        when (billingResult.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                if (purchases != null) {
                    coroutineScope.launch {
                        _googlePurchases.emit(purchases)
                    }
                }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> {
                Log.d(TAG, "User canceled Google Play purchase flow.")
            }
            else -> {
                Log.w(TAG, "onPurchasesUpdated error: code=${billingResult.responseCode}, msg=${billingResult.debugMessage}")
                coroutineScope.launch {
                    _billingErrors.emit(billingResult.debugMessage.ifBlank { "Google Play purchase was not completed." })
                }
            }
        }
    }

    /**
     * Attempts to launch the Google Play Billing flow which displays the User Choice dialog in India.
     * Returns true if the flow was successfully launched with Google Play,
     * or false if Google Play Billing is unavailable (in which case caller can proceed with direct UroPay).
     */
    suspend fun launchBillingFlow(
        activity: Activity,
        productId: String,
        isSubscription: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        val client = billingClient
        if (client == null || !_isReady.value) {
            Log.w(TAG, "BillingClient is not ready, cannot launch billing flow.")
            return@withContext false
        }

        try {
            val productType = if (isSubscription) {
                BillingClient.ProductType.SUBS
            } else {
                BillingClient.ProductType.INAPP
            }

            val queryParams = QueryProductDetailsParams.newBuilder()
                .setProductList(
                    listOf(
                        QueryProductDetailsParams.Product.newBuilder()
                            .setProductId(productId)
                            .setProductType(productType)
                            .build()
                    )
                )
                .build()

            val (billingResult, productDetailsList) = kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
                client.queryProductDetailsAsync(queryParams) { res, list ->
                    if (continuation.isActive) {
                        continuation.resumeWith(Result.success(Pair(res, list)))
                    }
                }
            }

            if (billingResult.responseCode != BillingClient.BillingResponseCode.OK || productDetailsList.isEmpty()) {
                Log.w(TAG, "queryProductDetails failed for $productId: code=${billingResult.responseCode}, msg=${billingResult.debugMessage}")
                return@withContext false
            }

            val details = productDetailsList.firstOrNull() ?: return@withContext false

            val detailsParamsBuilder = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(details)

            if (isSubscription) {
                val offerToken = details.subscriptionOfferDetails?.firstOrNull()?.offerToken
                if (!offerToken.isNullOrBlank()) {
                    detailsParamsBuilder.setOfferToken(offerToken)
                }
            }

            val productDetailsParamsList = listOf(detailsParamsBuilder.build())

            val flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(productDetailsParamsList)
                .build()

            withContext(Dispatchers.Main) {
                val result = client.launchBillingFlow(activity, flowParams)
                if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                    Log.w(TAG, "launchBillingFlow failed: code=${result.responseCode}, msg=${result.debugMessage}")
                    false
                } else {
                    true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during launchBillingFlow: ${e.message}", e)
            false
        }
    }

    suspend fun consumeOrAcknowledgePurchase(purchase: Purchase): Boolean = withContext(Dispatchers.IO) {
        val client = billingClient ?: return@withContext false
        try {
            if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                val consumeParams = com.android.billingclient.api.ConsumeParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()
                val consumeResult = kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
                    client.consumeAsync(consumeParams) { result, _ ->
                        if (continuation.isActive) continuation.resumeWith(Result.success(result))
                    }
                }
                if (consumeResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    return@withContext true
                }

                if (!purchase.isAcknowledged) {
                    val ackParams = com.android.billingclient.api.AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.purchaseToken)
                        .build()
                    val ackResult = kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
                        client.acknowledgePurchase(ackParams) { result ->
                            if (continuation.isActive) continuation.resumeWith(Result.success(result))
                        }
                    }
                    return@withContext (ackResult.responseCode == BillingClient.BillingResponseCode.OK)
                }
                return@withContext true
            }
            false
        } catch (e: Exception) {
            Log.e(TAG, "consumeOrAcknowledgePurchase error: ${e.message}", e)
            false
        }
    }

    fun endConnection() {
        try {
            billingClient?.endConnection()
        } catch (e: Exception) {
            Log.w(TAG, "Error ending billing connection: ${e.message}")
        }
    }
}
