package com.example.data.billing

/**
 * Valid Indian States and Union Territories for Google Play Alternative Billing reporting.
 * These correspond to official administrative area values recognized by Google Play Developer API
 * for region_code = "IN".
 */
object IndiaAdministrativeAreas {

    val STATES_AND_UTS = listOf(
        "Andaman and Nicobar Islands",
        "Andhra Pradesh",
        "Arunachal Pradesh",
        "Assam",
        "Bihar",
        "Chandigarh",
        "Chhattisgarh",
        "Dadra and Nagar Haveli and Daman and Diu",
        "Delhi",
        "Goa",
        "Gujarat",
        "Haryana",
        "Himachal Pradesh",
        "Jammu and Kashmir",
        "Jharkhand",
        "Karnataka",
        "Kerala",
        "Ladakh",
        "Lakshadweep",
        "Madhya Pradesh",
        "Maharashtra",
        "Manipur",
        "Meghalaya",
        "Mizoram",
        "Nagaland",
        "Odisha",
        "Puducherry",
        "Punjab",
        "Rajasthan",
        "Sikkim",
        "Tamil Nadu",
        "Telangana",
        "Tripura",
        "Uttar Pradesh",
        "Uttarakhand",
        "West Bengal"
    )

    fun isValid(name: String?): Boolean {
        if (name.isNullOrBlank()) return false
        return STATES_AND_UTS.any { it.equals(name.trim(), ignoreCase = true) }
    }

    fun normalize(name: String?): String? {
        if (name.isNullOrBlank()) return null
        return STATES_AND_UTS.firstOrNull { it.equals(name.trim(), ignoreCase = true) }
    }
}
