package com.example.data.billing

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

/**
 * Baatly Tax Configuration for Google Play Alternative Billing.
 *
 * CRITICAL RULE:
 * Do NOT invent or hardcode a tax rate unless explicitly configured by Baatly business rules.
 * If no tax rate is configured, the reporting flow will surface a clean configuration error,
 * keeping the payment amount unchanged and refusing to fake values.
 */
object BaatlyTaxConfig {

    /**
     * Explicit tax rate percentage (e.g., 18.0 for 18% GST if applicable).
     * Defaults to null if not configured in the business environment.
     * Can be set at runtime or configured via build/backend.
     */
    @Volatile
    var configuredTaxRatePercent: Double? = null

    /**
     * Whether displayed prices in Baatly are tax-inclusive.
     * True means the displayed package price already includes tax:
     * total = pre_tax + tax
     */
    var isTaxInclusive: Boolean = true

    /**
     * Calculates tax breakdown for an amount, ensuring:
     * pre_tax_amount + tax_amount = total_amount
     */
    fun calculateTaxBreakdown(
        totalAmount: Double,
        explicitTaxRatePercent: Double? = null,
        explicitPreTaxAmount: Double? = null,
        explicitTaxAmount: Double? = null
    ): Result<TaxBreakdown> {
        // If explicit pre-tax and tax amounts are provided from backend
        if (explicitPreTaxAmount != null && explicitTaxAmount != null) {
            val totalBd = BigDecimal.valueOf(totalAmount).setScale(2, RoundingMode.HALF_UP)
            val preTaxBd = BigDecimal.valueOf(explicitPreTaxAmount).setScale(2, RoundingMode.HALF_UP)
            val taxBd = totalBd.subtract(preTaxBd).setScale(2, RoundingMode.HALF_UP)
            return Result.success(
                TaxBreakdown(
                    totalAmount = totalBd.toDouble(),
                    preTaxAmount = preTaxBd.toDouble(),
                    taxAmount = taxBd.toDouble()
                )
            )
        }

        val rate = explicitTaxRatePercent ?: configuredTaxRatePercent
        if (rate == null || rate <= 0.0) {
            return Result.failure(
                TaxConfigurationException(
                    "Tax breakdown configuration is required for Google Play Alternative Billing reporting. " +
                        "No tax rate is configured in BaatlyTaxConfig or product metadata. " +
                        "Please configure the applicable tax rate or provide tax breakdown from backend."
                )
            )
        }

        val totalBd = BigDecimal.valueOf(totalAmount).setScale(2, RoundingMode.HALF_UP)
        val rateBd = BigDecimal.valueOf(rate)

        val taxBd: BigDecimal
        val preTaxBd: BigDecimal

        if (isTaxInclusive) {
            // total = pre_tax * (1 + rate/100) => pre_tax = total / (1 + rate/100)
            // tax = total - pre_tax
            val divisor = BigDecimal.ONE.add(rateBd.divide(BigDecimal.valueOf(100), 6, RoundingMode.HALF_UP))
            preTaxBd = totalBd.divide(divisor, 2, RoundingMode.HALF_UP)
            taxBd = totalBd.subtract(preTaxBd) // Guarantees pre_tax + tax == total
        } else {
            taxBd = totalBd.multiply(rateBd.divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_UP))
                .setScale(2, RoundingMode.HALF_UP)
            preTaxBd = totalBd
        }

        return Result.success(
            TaxBreakdown(
                totalAmount = totalBd.toDouble(),
                preTaxAmount = preTaxBd.toDouble(),
                taxAmount = taxBd.toDouble()
            )
        )
    }
}

data class TaxBreakdown(
    val totalAmount: Double,
    val preTaxAmount: Double,
    val taxAmount: Double
) {
    val preTaxAmountFormatted: String
        get() = String.format(Locale.US, "%.2f", preTaxAmount)

    val taxAmountFormatted: String
        get() = String.format(Locale.US, "%.2f", taxAmount)

    val totalAmountFormatted: String
        get() = String.format(Locale.US, "%.2f", totalAmount)

    init {
        val sum = BigDecimal.valueOf(preTaxAmount).add(BigDecimal.valueOf(taxAmount)).setScale(2, RoundingMode.HALF_UP)
        val tot = BigDecimal.valueOf(totalAmount).setScale(2, RoundingMode.HALF_UP)
        require(sum == tot) {
            "Tax calculation invariant violated: pre_tax ($preTaxAmount) + tax ($taxAmount) != total ($totalAmount)"
        }
    }
}

class TaxConfigurationException(message: String) : Exception(message)
