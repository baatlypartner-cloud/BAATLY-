package com.example.data.billing

/**
 * Deterministic mapping layer between Baatly catalog entities (coin packages, membership plans)
 * and Google Play Console product identifiers.
 *
 * CRITICAL RULE (Requirement 11):
 * Do NOT assume Baatly Supabase UUIDs are Google Play Product IDs.
 * The mapping must be deterministic.
 * If a valid Google Play product ID is missing:
 * - do not launch Google billing
 * - do not silently use Supabase UUID
 * - fail with a configuration error
 * Do not invent product IDs.
 */
object GooglePlayProductMapper {

    // Configured mappings between Baatly Coin Package IDs/Keys and Google Play In-App Product IDs
    private val coinPackageToPlayProduct = mutableMapOf<String, String>()

    // Configured mappings between Baatly Membership Plan IDs and Google Play Subscription Product IDs
    private val membershipPlanToPlayProduct = mutableMapOf<String, String>(
        "membership_24h" to "baatly_membership_24h"
    )

    fun registerCoinPackageMapping(baatlyPackageId: String, googlePlayProductId: String) {
        require(baatlyPackageId.isNotBlank()) { "baatlyPackageId cannot be blank" }
        require(googlePlayProductId.isNotBlank()) { "googlePlayProductId cannot be blank" }
        coinPackageToPlayProduct[baatlyPackageId.trim()] = googlePlayProductId.trim()
    }

    fun registerMembershipPlanMapping(baatlyPlanId: String, googlePlayProductId: String) {
        require(baatlyPlanId.isNotBlank()) { "baatlyPlanId cannot be blank" }
        require(googlePlayProductId.isNotBlank()) { "googlePlayProductId cannot be blank" }
        membershipPlanToPlayProduct[baatlyPlanId.trim()] = googlePlayProductId.trim()
    }

    fun getGooglePlayProductIdForCoinPackage(packageId: String): String? {
        return coinPackageToPlayProduct[packageId.trim()]
    }

    fun getGooglePlayProductIdForMembershipPlan(planId: String): String? {
        return membershipPlanToPlayProduct[planId.trim()]
    }

    fun hasCoinPackageMapping(packageId: String): Boolean {
        return !coinPackageToPlayProduct[packageId.trim()].isNullOrBlank()
    }

    fun hasMembershipPlanMapping(planId: String): Boolean {
        return !membershipPlanToPlayProduct[planId.trim()].isNullOrBlank()
    }
}
