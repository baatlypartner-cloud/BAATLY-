package com.example.domain

object BillingEngine {
    const val USER_COINS_PER_MINUTE = 6
    const val MEMBER_COINS_PER_MINUTE = 3
    const val CHAT_COINS_PER_MESSAGE = 3
    const val MEMBER_CHAT_COINS_PER_MESSAGE = 1
    const val STORY_VIEW_COINS = 3
    const val MEMBER_STORY_VIEW_COINS = 1
    const val POST_VIEW_COINS = 3
    const val MEMBER_POST_VIEW_COINS = 1
    const val STORY_REPLY_COINS = 3
    const val MEMBER_STORY_REPLY_COINS = 1
    const val POST_COMMENT_COINS = 3
    const val MEMBER_POST_COMMENT_COINS = 1
    const val LIKE_COINS = 1
    const val POST_CREATE_COINS = 20
    const val STORY_CREATE_COINS = 10
    const val POST_RENEW_COINS = 20
    const val MEMBERSHIP_PRICE_INR = 100.0
    const val MEMBERSHIP_VALIDITY_HOURS = 24

    const val HOST_EARNING_PER_CHAT_MESSAGE_INR = 0.50
    const val PARTNER_GIFT_PERCENTAGE = 0.50

    /**
     * Calculates maximum allowed call duration in seconds based on coin balance and call rate.
     * full_minutes = floor(current_coin_balance / coinsPerMinute)
     * max_duration_seconds = full_minutes * 60
     */
    fun calculateMaxCallDurationSeconds(coinBalance: Int, coinsPerMinute: Int = USER_COINS_PER_MINUTE): Int {
        val rate = if (coinsPerMinute > 0) coinsPerMinute else USER_COINS_PER_MINUTE
        if (coinBalance < rate) return 0
        val fullMinutes = coinBalance / rate
        return fullMinutes * 60
    }

    /**
     * Calculates user coins charged for a given duration in seconds.
     * E.g. 1 sec..60 sec -> rate coins, 61..120 sec -> 2 * rate coins.
     */
    fun calculateUserCallCostCoins(durationSeconds: Int, maxCoinsAllowed: Int? = null, coinsPerMinute: Int = USER_COINS_PER_MINUTE): Int {
        if (durationSeconds <= 0) return 0
        val rate = if (coinsPerMinute > 0) coinsPerMinute else USER_COINS_PER_MINUTE
        val startedMinutes = (durationSeconds + 59) / 60
        val totalCoins = startedMinutes * rate
        return if (maxCoinsAllowed != null) minOf(totalCoins, maxCoinsAllowed) else totalCoins
    }

    /**
     * Calculates host earning in INR for call duration.
     * Minimum earning duration is 60 seconds.
     * < 60 sec: ₹0
     * 1-2 min (60-120s): ₹1.00/min
     * 3-10 min (121-600s): ₹1.50/min
     * 11-25 min (601-1500s): ₹1.90/min
     * 26+ min: ₹2.50/min
     */
    fun calculateHostEarningsInr(durationSeconds: Int): Double {
        if (durationSeconds < 60) return 0.0
        val completedMinutes = durationSeconds / 60
        var earnings = 0.0

        for (minute in 1..completedMinutes) {
            when {
                minute <= 2 -> earnings += 1.00
                minute <= 10 -> earnings += 1.50
                minute <= 25 -> earnings += 1.90
                else -> earnings += 2.50
            }
        }
        return earnings
    }

    /**
     * Checks whether text content contains contact or number-sharing attempts.
     * Matches 4+ digit numeric sequences or English/Hindi number words.
     */
    fun containsForbiddenNumberContent(text: String): Boolean {
        if (text.isBlank()) return false
        val clean = text.lowercase()

        // Match 4+ digits even if separated by spaces or dots/hyphens
        val digitsOnly = clean.filter { it.isDigit() }
        if (digitsOnly.length >= 4) {
            // Check if 4 or more digits appear in sequence or close pattern
            val consecutiveDigitsRegex = Regex("""\b\d{4,}\b|\d[\s\-_.,]*\d[\s\-_.,]*\d[\s\-_.,]*\d""")
            if (consecutiveDigitsRegex.find(clean) != null) {
                return true
            }
        }

        // Check for common Indian 10-digit mobile number patterns
        val phoneRegex = Regex("""(?:\+?91)?[6-9]\d{9}""")
        if (phoneRegex.find(digitsOnly) != null) {
            return true
        }

        // Check for number words in sequence
        val numberWords = listOf(
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
            "shunya", "ek", "do", "teen", "chaar", "char", "paanch", "panch", "chheh", "chhe", "saat", "aath", "ath", "nau", "das"
        )

        val words = clean.split(Regex("""[\s,.\-_/]+"""))
        var consecutiveWordNumberCount = 0
        for (w in words) {
            if (numberWords.contains(w) || w.all { it.isDigit() }) {
                consecutiveWordNumberCount++
                if (consecutiveWordNumberCount >= 4) {
                    return true
                }
            } else {
                consecutiveWordNumberCount = 0
            }
        }

        return false
    }
}
