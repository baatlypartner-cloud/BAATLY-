package com.example.data.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.SurfaceView
import androidx.core.content.ContextCompat
import com.example.data.model.AgoraTokenResponse
import com.example.data.network.SupabaseConfig
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import io.agora.rtc2.video.VideoCanvas
import io.agora.rtc2.video.VideoEncoderConfiguration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AgoraCallManager(private val context: Context?) {

    private val tagNetwork = "BAATLY_AGORA_NETWORK"
    private val tagAudio = "BAATLY_AGORA_AUDIO"
    private val tagVideo = "BAATLY_AGORA_VIDEO"
    private val tagConnection = "BAATLY_AGORA_CONNECTION"
    private val tag = "AgoraCallManager"

    private var rtcEngine: RtcEngine? = null
    private val audioManager = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isSpeakerOn = MutableStateFlow(true)
    val isSpeakerOn: StateFlow<Boolean> = _isSpeakerOn.asStateFlow()

    private val _isInChannel = MutableStateFlow(false)
    val isInChannel: StateFlow<Boolean> = _isInChannel.asStateFlow()

    private val _remoteUserJoined = MutableStateFlow(false)
    val remoteUserJoined: StateFlow<Boolean> = _remoteUserJoined.asStateFlow()

    private val _remoteAudioPlaying = MutableStateFlow(false)
    val remoteAudioPlaying: StateFlow<Boolean> = _remoteAudioPlaying.asStateFlow()

    private val _remoteUid = MutableStateFlow<Int?>(null)
    val remoteUid: StateFlow<Int?> = _remoteUid.asStateFlow()

    private val _isVideoCall = MutableStateFlow(false)
    val isVideoCall: StateFlow<Boolean> = _isVideoCall.asStateFlow()

    private val _isLocalVideoMuted = MutableStateFlow(false)
    val isLocalVideoMuted: StateFlow<Boolean> = _isLocalVideoMuted.asStateFlow()

    private val _isRemoteVideoMuted = MutableStateFlow(false)
    val isRemoteVideoMuted: StateFlow<Boolean> = _isRemoteVideoMuted.asStateFlow()

    private val _isFrontCamera = MutableStateFlow(true)
    val isFrontCamera: StateFlow<Boolean> = _isFrontCamera.asStateFlow()

    private val _localCameraReady = MutableStateFlow(false)
    val localCameraReady: StateFlow<Boolean> = _localCameraReady.asStateFlow()

    private val _remoteVideoSubscribed = MutableStateFlow(false)
    val remoteVideoSubscribed: StateFlow<Boolean> = _remoteVideoSubscribed.asStateFlow()

    private val _remoteFirstFrameReceived = MutableStateFlow(false)
    val remoteFirstFrameReceived: StateFlow<Boolean> = _remoteFirstFrameReceived.asStateFlow()

    private val _networkQuality = MutableStateFlow(1)
    val networkQuality: StateFlow<Int> = _networkQuality.asStateFlow()

    private val _connectionState = MutableStateFlow("CONNECTED")
    val connectionState: StateFlow<String> = _connectionState.asStateFlow()

    var onCallConnected: (() -> Unit)? = null
    var onCallEnded: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    // Throttling timestamps for frequent callbacks to prevent Logcat spam
    private var lastNetworkQualityLogTime = 0L
    private var lastRtcStatsLogTime = 0L
    private var lastRemoteAudioStatsLogTime = 0L
    private var lastRecoveryAttemptTime = 0L

    private fun qualityToString(quality: Int): String {
        return when (quality) {
            Constants.QUALITY_EXCELLENT -> "EXCELLENT (1)"
            Constants.QUALITY_GOOD -> "GOOD (2)"
            Constants.QUALITY_POOR -> "POOR (3)"
            Constants.QUALITY_BAD -> "BAD (4)"
            Constants.QUALITY_VBAD -> "VERY_BAD (5)"
            Constants.QUALITY_DOWN -> "DOWN (6)"
            Constants.QUALITY_UNSUPPORTED -> "UNSUPPORTED (7)"
            Constants.QUALITY_DETECTING -> "DETECTING (8)"
            else -> "UNKNOWN ($quality)"
        }
    }

    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            Log.i(tagConnection, "ON_JOIN_CHANNEL_SUCCESS: channel=$channel, uid=$uid, elapsed=${elapsed}ms")
            _isInChannel.value = true
            _connectionState.value = "CONNECTED"
            setSpeakerphoneOn(_isSpeakerOn.value)
            onCallConnected?.invoke()
        }

        override fun onUserJoined(uid: Int, elapsed: Int) {
            Log.i(tagConnection, "REMOTE_USER_JOINED: uid=$uid, elapsed=${elapsed}ms")
            Log.i(tagVideo, "VIDEO_REMOTE_UID=$uid")
            _remoteUserJoined.value = true
            _remoteUid.value = uid
            try {
                // Subscribe to remote audio stream and set standard playback volume
                rtcEngine?.muteRemoteAudioStream(uid, false)
                rtcEngine?.adjustUserPlaybackSignalVolume(uid, 100)
                if (_isVideoCall.value) {
                    val muteRes = rtcEngine?.muteRemoteVideoStream(uid, false)
                    Log.i(tagVideo, "VIDEO_REMOTE_SUBSCRIBE=true (res=$muteRes)")
                    _remoteVideoSubscribed.value = true
                }
            } catch (e: Exception) {
                Log.w(tagAudio, "Error configuring remote stream for uid=$uid: ${e.message}")
            }
            if (_isVideoCall.value) {
                bindRemoteVideoIfReady()
            }
            onCallConnected?.invoke()
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            val reasonDesc = when (reason) {
                Constants.USER_OFFLINE_QUIT -> "USER_QUIT (0)"
                Constants.USER_OFFLINE_DROPPED -> "USER_DROPPED (1)"
                Constants.USER_OFFLINE_BECOME_AUDIENCE -> "BECOME_AUDIENCE (2)"
                else -> "REASON ($reason)"
            }
            Log.i(tagConnection, "REMOTE_USER_OFFLINE: uid=$uid, reason=$reasonDesc")
            if (_remoteUid.value == uid) {
                detachRemoteRenderer()
                _remoteUid.value = null
            }
            _remoteUserJoined.value = false
            _remoteAudioPlaying.value = false
            _remoteFirstFrameReceived.value = false
            _remoteVideoSubscribed.value = false
            _isRemoteVideoMuted.value = true
            onCallEnded?.invoke()
        }

        override fun onFirstRemoteVideoFrame(uid: Int, width: Int, height: Int, elapsed: Int) {
            Log.i(tagVideo, "VIDEO_REMOTE_FIRST_FRAME=true: uid=$uid, ${width}x${height}, elapsed=${elapsed}ms")
            _remoteUid.value = uid
            _remoteFirstFrameReceived.value = true
            _remoteVideoSubscribed.value = true
            _isRemoteVideoMuted.value = false
            bindRemoteVideoIfReady()
        }

        override fun onRemoteVideoStateChanged(uid: Int, state: Int, reason: Int, elapsed: Int) {
            Log.i(tagVideo, "ON_REMOTE_VIDEO_STATE_CHANGED: uid=$uid, state=$state, reason=$reason")
            when (state) {
                Constants.REMOTE_VIDEO_STATE_DECODING, Constants.REMOTE_VIDEO_STATE_STARTING -> {
                    _remoteUid.value = uid
                    _remoteVideoSubscribed.value = true
                    _isRemoteVideoMuted.value = false
                    try {
                        rtcEngine?.muteRemoteVideoStream(uid, false)
                    } catch (_: Exception) {}
                    bindRemoteVideoIfReady()
                }
                Constants.REMOTE_VIDEO_STATE_STOPPED, Constants.REMOTE_VIDEO_STATE_FAILED -> {
                    _isRemoteVideoMuted.value = true
                    _remoteFirstFrameReceived.value = false
                }
            }
        }

        override fun onConnectionStateChanged(state: Int, reason: Int) {
            val stateName = when (state) {
                Constants.CONNECTION_STATE_DISCONNECTED -> "DISCONNECTED (1)"
                Constants.CONNECTION_STATE_CONNECTING -> "CONNECTING (2)"
                Constants.CONNECTION_STATE_CONNECTED -> "CONNECTED (3)"
                Constants.CONNECTION_STATE_RECONNECTING -> "RECONNECTING (4)"
                Constants.CONNECTION_STATE_FAILED -> "FAILED (5)"
                else -> "UNKNOWN ($state)"
            }
            val reasonName = when (reason) {
                Constants.CONNECTION_CHANGED_CONNECTING -> "CONNECTING (0)"
                Constants.CONNECTION_CHANGED_JOIN_SUCCESS -> "JOIN_SUCCESS (1)"
                Constants.CONNECTION_CHANGED_INTERRUPTED -> "INTERRUPTED (2)"
                Constants.CONNECTION_CHANGED_BANNED_BY_SERVER -> "BANNED_BY_SERVER (3)"
                Constants.CONNECTION_CHANGED_JOIN_FAILED -> "JOIN_FAILED (4)"
                Constants.CONNECTION_CHANGED_LEAVE_CHANNEL -> "LEAVE_CHANNEL (5)"
                Constants.CONNECTION_CHANGED_INVALID_APP_ID -> "INVALID_APP_ID (6)"
                Constants.CONNECTION_CHANGED_INVALID_CHANNEL_NAME -> "INVALID_CHANNEL_NAME (7)"
                Constants.CONNECTION_CHANGED_INVALID_TOKEN -> "INVALID_TOKEN (8)"
                Constants.CONNECTION_CHANGED_TOKEN_EXPIRED -> "TOKEN_EXPIRED (9)"
                Constants.CONNECTION_CHANGED_REJECTED_BY_SERVER -> "REJECTED_BY_SERVER (10)"
                Constants.CONNECTION_CHANGED_SETTING_PROXY_SERVER -> "SETTING_PROXY_SERVER (11)"
                Constants.CONNECTION_CHANGED_RENEW_TOKEN -> "RENEW_TOKEN (12)"
                Constants.CONNECTION_CHANGED_CLIENT_IP_ADDRESS_CHANGED -> "CLIENT_IP_ADDRESS_CHANGED (13)"
                Constants.CONNECTION_CHANGED_KEEP_ALIVE_TIMEOUT -> "KEEP_ALIVE_TIMEOUT (14)"
                Constants.CONNECTION_CHANGED_REJOIN_SUCCESS -> "REJOIN_SUCCESS (15)"
                else -> "REASON ($reason)"
            }

            Log.i(tagConnection, "CONNECTION_STATE_CHANGED: state=$stateName, reason=$reasonName")

            when (state) {
                Constants.CONNECTION_STATE_CONNECTED -> {
                    _isInChannel.value = true
                }
                Constants.CONNECTION_STATE_RECONNECTING -> {
                    // Under temporary mobile/Wi-Fi handover or short latency spikes, Agora auto-reconnects.
                    // Keep channel state intact to prevent disrupting call timers or billing.
                    Log.w(tagNetwork, "Network fluctuating: Agora is auto-reconnecting to optimal edge server...")
                }
                Constants.CONNECTION_STATE_FAILED -> {
                    Log.e(tagConnection, "Agora connection failed: reason=$reasonName")
                }
                else -> {}
            }
        }

        override fun onNetworkQuality(uid: Int, txQuality: Int, rxQuality: Int) {
            val now = SystemClock.elapsedRealtime()
            // Sample/throttle logging to once every 6 seconds to keep main loop fast
            if (now - lastNetworkQualityLogTime > 6000L) {
                lastNetworkQualityLogTime = now
                val target = if (uid == 0) "LOCAL_USER" else "REMOTE_UID($uid)"
                Log.d(
                    tagNetwork,
                    "NETWORK_QUALITY: $target | uplink=${qualityToString(txQuality)}, downlink=${qualityToString(rxQuality)}"
                )
            }
        }

        override fun onRemoteAudioStateChanged(uid: Int, state: Int, reason: Int, elapsed: Int) {
            val stateName = when (state) {
                Constants.REMOTE_AUDIO_STATE_STOPPED -> "STOPPED (0)"
                Constants.REMOTE_AUDIO_STATE_STARTING -> "STARTING (1)"
                Constants.REMOTE_AUDIO_STATE_DECODING -> "DECODING/PLAYING (2)"
                Constants.REMOTE_AUDIO_STATE_FROZEN -> "FROZEN (3)"
                Constants.REMOTE_AUDIO_STATE_FAILED -> "FAILED (4)"
                else -> "UNKNOWN ($state)"
            }
            val reasonName = when (reason) {
                Constants.REMOTE_AUDIO_REASON_INTERNAL -> "INTERNAL (0)"
                Constants.REMOTE_AUDIO_REASON_NETWORK_CONGESTION -> "NETWORK_CONGESTION (1)"
                Constants.REMOTE_AUDIO_REASON_NETWORK_RECOVERY -> "NETWORK_RECOVERY (2)"
                Constants.REMOTE_AUDIO_REASON_LOCAL_MUTED -> "LOCAL_MUTED (3)"
                Constants.REMOTE_AUDIO_REASON_LOCAL_UNMUTED -> "LOCAL_UNMUTED (4)"
                Constants.REMOTE_AUDIO_REASON_REMOTE_MUTED -> "REMOTE_MUTED (5)"
                Constants.REMOTE_AUDIO_REASON_REMOTE_UNMUTED -> "REMOTE_UNMUTED (6)"
                Constants.REMOTE_AUDIO_REASON_REMOTE_OFFLINE -> "REMOTE_OFFLINE (7)"
                else -> "REASON ($reason)"
            }

            Log.i(tagAudio, "REMOTE_AUDIO_STATE: uid=$uid, state=$stateName, reason=$reasonName, elapsed=${elapsed}ms")

            when (state) {
                Constants.REMOTE_AUDIO_STATE_DECODING -> {
                    _remoteAudioPlaying.value = true
                    if (reason == Constants.REMOTE_AUDIO_REASON_NETWORK_RECOVERY) {
                        Log.i(tagAudio, "REMOTE_AUDIO_RECOVERED: uid=$uid audio successfully resumed after network recovery")
                    }
                }
                Constants.REMOTE_AUDIO_STATE_FROZEN -> {
                    // Temporary packet loss or bandwidth dip: do not leave channel.
                    // Agora's jitter buffer and PLC (Packet Loss Concealment) will automatically conceal and recover.
                    Log.w(tagAudio, "REMOTE_AUDIO_FROZEN: uid=$uid stream temporarily frozen (reason=$reasonName). Awaiting packet recovery...")
                }
                Constants.REMOTE_AUDIO_STATE_STOPPED -> {
                    if (reason == Constants.REMOTE_AUDIO_REASON_REMOTE_OFFLINE) {
                        _remoteUserJoined.value = false
                    }
                    _remoteAudioPlaying.value = false
                }
                Constants.REMOTE_AUDIO_STATE_FAILED -> {
                    _remoteAudioPlaying.value = false
                    // Non-disruptive audio recovery: if remote stream failed without user going offline,
                    // nudge stream subscription once without tearing down channel
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastRecoveryAttemptTime > 4000L && _isInChannel.value) {
                        lastRecoveryAttemptTime = now
                        Log.w(tagAudio, "Attempting non-disruptive remote audio stream resubscription for uid=$uid...")
                        try {
                            rtcEngine?.muteRemoteAudioStream(uid, false)
                            rtcEngine?.adjustUserPlaybackSignalVolume(uid, 100)
                        } catch (e: Exception) {
                            Log.w(tagAudio, "Failed non-disruptive audio recovery: ${e.message}")
                        }
                    }
                }
            }
        }

        override fun onRtcStats(stats: RtcStats?) {
            val now = SystemClock.elapsedRealtime()
            if (stats != null && now - lastRtcStatsLogTime > 8000L) {
                lastRtcStatsLogTime = now
                Log.d(
                    tagNetwork,
                    "RTC_STATS: rtt=${stats.lastmileDelay}ms, txLoss=${stats.txPacketLossRate}%, rxLoss=${stats.rxPacketLossRate}%, users=${stats.users}, cpuUsage=${stats.cpuTotalUsage}%"
                )
            }
        }

        override fun onRemoteAudioStats(stats: RemoteAudioStats?) {
            val now = SystemClock.elapsedRealtime()
            if (stats != null && now - lastRemoteAudioStatsLogTime > 8000L) {
                lastRemoteAudioStatsLogTime = now
                Log.d(
                    tagAudio,
                    "REMOTE_AUDIO_STATS: uid=${stats.uid}, jitterDelay=${stats.jitterBufferDelay}ms, transportDelay=${stats.networkTransportDelay}ms, lossRate=${stats.audioLossRate}%, bitrate=${stats.receivedBitrate}kbps, frozenRate=${stats.frozenRate}%"
                )
            }
        }

        override fun onTokenPrivilegeWillExpire(token: String?) {
            Log.w(tagConnection, "Agora token privilege will expire soon")
        }

        override fun onRequestToken() {
            Log.w(tagConnection, "Agora token expired, token refresh required")
        }

        override fun onAudioRouteChanged(routing: Int) {
            val routeDesc = when (routing) {
                -1 -> "DEFAULT (-1)"
                0 -> "HEADSET (0)"
                1 -> "EARPIECE (1)"
                2 -> "HEADSET_NO_MIC (2)"
                3 -> "SPEAKERPHONE (3)"
                4 -> "LOUDSPEAKER (4)"
                5 -> "BLUETOOTH (5)"
                else -> "ROUTE ($routing)"
            }
            Log.i(tagAudio, "Audio route changed to: $routeDesc")
            _isSpeakerOn.value = (routing == 3 || routing == 4)
        }

        override fun onUserMuteAudio(uid: Int, muted: Boolean) {
            Log.i(tagAudio, "Remote user uid=$uid mute state changed: muted=$muted")
        }

        override fun onLeaveChannel(stats: RtcStats?) {
            Log.i(tagConnection, "Left Agora channel")
            _isInChannel.value = false
            _remoteUserJoined.value = false
            _remoteAudioPlaying.value = false
        }

        override fun onError(err: Int) {
            Log.e(tagConnection, "Agora RTC onError: code=$err")
            onError?.invoke("Code $err")
        }
    }

    fun hasCameraPermission(): Boolean {
        val ctx = context ?: return false
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        Log.i(tagVideo, "VIDEO_PERMISSION_CAMERA=${if (granted) "GRANTED" else "DENIED"}")
        return granted
    }

    fun hasMicPermission(): Boolean {
        val ctx = context ?: return false
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        Log.i(tagAudio, "LOCAL_MIC_PERMISSION=${if (granted) "GRANTED" else "DENIED"}")
        return granted
    }

    private fun checkMicPermission(): Boolean {
        return hasMicPermission()
    }

    private fun requestAudioFocus(): Boolean {
        val am = audioManager ?: return false
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val playbackAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(playbackAttributes)
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener { focusChange ->
                        Log.d(tagAudio, "Audio focus changed: $focusChange")
                    }
                    .build()
                audioFocusRequest = request
                am.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    { focusChange -> Log.d(tagAudio, "Audio focus changed: $focusChange") },
                    AudioManager.STREAM_VOICE_CALL,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        } catch (e: Exception) {
            Log.w(tagAudio, "Error requesting audio focus: ${e.message}")
            false
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (e: Exception) {
            Log.w(tagAudio, "Error abandoning audio focus: ${e.message}")
        }
    }

    private fun setupRtcEngine() {
        if (rtcEngine != null) return
        val appContext = context?.applicationContext ?: context ?: run {
            Log.w(tag, "Context is null, skipping Agora setup")
            return
        }
        val appId = SupabaseConfig.agoraAppId
        if (appId.isBlank()) {
            Log.w(tag, "Agora App ID is empty, skipping Agora setup")
            return
        }
        try {
            val config = RtcEngineConfig().apply {
                mContext = appContext
                mAppId = appId
                mEventHandler = rtcEventHandler
                // 1-on-1 real-time voice call communication profile
                mChannelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                mAudioScenario = Constants.AUDIO_SCENARIO_DEFAULT
            }
            rtcEngine = RtcEngine.create(config)
            Log.i(tagConnection, "AUDIO_ENGINE_CREATED: status=${rtcEngine != null}")

            rtcEngine?.let { engine ->
                // Enable audio subsystem
                val enableAudioRes = engine.enableAudio()
                Log.i(tagAudio, "ENABLE_AUDIO_RESULT: code=$enableAudioRes")
                if (enableAudioRes != 0) {
                    Log.e(tagAudio, "Agora enableAudio() returned error code $enableAudioRes")
                }

                // Explicitly set speech-standard audio profile:
                // 32 kHz sampling rate, mono, speech encoding (approx 18 kbps).
                // Highly resilient against high packet loss and mobile network fluctuation.
                val profileRes = engine.setAudioProfile(
                    Constants.AUDIO_PROFILE_SPEECH_STANDARD,
                    Constants.AUDIO_SCENARIO_DEFAULT
                )
                Log.i(tagAudio, "SET_AUDIO_PROFILE (SPEECH_STANDARD): code=$profileRes")

                // Enable local audio capture
                val enableLocalAudioRes = engine.enableLocalAudio(true)
                Log.i(tagAudio, "LOCAL_AUDIO_ENABLED: code=$enableLocalAudioRes")

                // Set speakerphone as default for social voice calls
                engine.setDefaultAudioRoutetoSpeakerphone(true)
                val speakerRes = engine.setEnableSpeakerphone(_isSpeakerOn.value)
                Log.i(tagAudio, "SPEAKERPHONE_STATE: result=$speakerRes, on=${_isSpeakerOn.value}")

                // Ensure local mic is unmuted
                val muteRes = engine.muteLocalAudioStream(false)
                _isMuted.value = false
                Log.i(tagAudio, "LOCAL_AUDIO_MUTED: false (result=$muteRes)")

                // Standard signal volumes
                engine.adjustPlaybackSignalVolume(100)
                engine.adjustRecordingSignalVolume(100)
            }
        } catch (e: Throwable) {
            Log.e(tagConnection, "Failed to initialize Agora RtcEngine: ${e.message}", e)
        }
    }

    private var remoteSurfaceView: SurfaceView? = null
    private var boundRemoteUid: Int? = null
    private var localSurfaceView: SurfaceView? = null

    fun joinChannel(tokenResponse: AgoraTokenResponse, channelName: String, isVideo: Boolean = false) {
        if (_isInChannel.value) {
            Log.i(tagConnection, "Already in channel '$channelName', skipping redundant join")
            return
        }

        // Hard-fail if permissions are missing before calling Agora join
        if (isVideo) {
            if (!hasCameraPermission()) {
                Log.e(tagVideo, "VIDEO_PERMISSION_CAMERA=DENIED Cannot join video call without CAMERA permission")
                onError?.invoke("Camera permission is required for video calls.")
                return
            }
            if (!hasMicPermission()) {
                Log.e(tagAudio, "LOCAL_MIC_PERMISSION=DENIED Cannot join call without RECORD_AUDIO permission")
                onError?.invoke("Microphone permission is required for calls.")
                return
            }
        } else {
            if (!hasMicPermission()) {
                Log.e(tagAudio, "LOCAL_MIC_PERMISSION=DENIED Cannot join call without RECORD_AUDIO permission")
                onError?.invoke("Microphone permission is required for calls.")
                return
            }
        }

        if (rtcEngine == null) {
            setupRtcEngine()
        }

        _isVideoCall.value = isVideo
        requestAudioFocus()

        try {
            val engine = rtcEngine ?: run {
                Log.e(tagConnection, "RtcEngine is null, cannot join channel")
                return
            }

            // Ensure audio subsystem is active before joining
            engine.enableAudio()
            engine.enableLocalAudio(true)
            engine.muteLocalAudioStream(false)
            _isMuted.value = false

            if (isVideo) {
                // Video Engine Initialization (Part 4)
                val enableVideoRes = engine.enableVideo()
                Log.i(tagVideo, "VIDEO_ENGINE_ENABLED=true (res=$enableVideoRes)")

                // Target 720p HD (1280x720, 15fps) for high clarity & mobile resilience
                val videoConfig = VideoEncoderConfiguration(
                    VideoEncoderConfiguration.VD_1280x720,
                    VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_15,
                    VideoEncoderConfiguration.STANDARD_BITRATE,
                    VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_ADAPTIVE
                )
                val setConfigRes = engine.setVideoEncoderConfiguration(videoConfig)
                Log.i(tagVideo, "SET_VIDEO_ENCODER_CONFIG (res=$setConfigRes)")

                val enableLocalVideoRes = engine.enableLocalVideo(true)
                Log.i(tagVideo, "ENABLE_LOCAL_VIDEO (res=$enableLocalVideoRes)")

                val enableLocalAudioRes = engine.enableLocalAudio(true)
                Log.i(tagAudio, "ENABLE_LOCAL_AUDIO (res=$enableLocalAudioRes)")

                val muteLocalVideoRes = engine.muteLocalVideoStream(false)
                Log.i(tagVideo, "VIDEO_LOCAL_PUBLISH=true (res=$muteLocalVideoRes)")
                _isLocalVideoMuted.value = false

                val startPreviewRes = engine.startPreview()
                Log.i(tagVideo, "START_PREVIEW (res=$startPreviewRes)")
                _localCameraReady.value = true
            }

            val options = ChannelMediaOptions().apply {
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                autoSubscribeAudio = true
                publishMicrophoneTrack = true
                if (isVideo) {
                    publishCameraTrack = true
                    autoSubscribeVideo = true
                }
            }

            // Consistent 32-bit unsigned representation between backend & SDK
            val uid = (tokenResponse.uid.toLong() and 0xFFFFFFFFL).toInt()
            val token = tokenResponse.token.takeIf { !it.isNullOrBlank() }

            val joinRes = engine.joinChannel(token, channelName, uid, options)
            Log.i(tagConnection, "JOIN_CHANNEL_RESULT: code=$joinRes, channel=$channelName, uid=$uid, isVideo=$isVideo")

            setSpeakerphoneOn(_isSpeakerOn.value)
        } catch (e: Exception) {
            Log.e(tagConnection, "Error joining Agora channel: ${e.message}", e)
        }
    }

    fun attachRemoteRenderer(surfaceView: SurfaceView) {
        if (remoteSurfaceView != surfaceView) {
            detachRemoteRenderer()
            remoteSurfaceView = surfaceView
            boundRemoteUid = null
            bindRemoteVideoIfReady()
        }
    }

    fun detachRemoteRenderer() {
        try {
            val oldUid = boundRemoteUid ?: _remoteUid.value
            if (oldUid != null) {
                rtcEngine?.setupRemoteVideo(VideoCanvas(null, VideoCanvas.RENDER_MODE_FIT, oldUid))
            }
        } catch (e: Exception) {
            Log.w(tagVideo, "Error detaching remote renderer: ${e.message}")
        }
        remoteSurfaceView = null
        boundRemoteUid = null
    }

    fun bindRemoteVideoIfReady() {
        val sv = remoteSurfaceView ?: return
        val uid = _remoteUid.value ?: return
        if (boundRemoteUid == uid) return // already bound deterministically once
        try {
            val canvas = VideoCanvas(sv, VideoCanvas.RENDER_MODE_FIT, uid)
            val res = rtcEngine?.setupRemoteVideo(canvas) ?: -1
            boundRemoteUid = uid
            Log.i(tagVideo, "SETUP_REMOTE_VIDEO_SUCCESS: uid=$uid (res=$res)")
        } catch (e: Exception) {
            Log.e(tagVideo, "Error setting up remote video: ${e.message}")
        }
    }

    fun attachLocalRenderer(surfaceView: SurfaceView) {
        if (localSurfaceView != surfaceView) {
            localSurfaceView = surfaceView
            try {
                val engine = rtcEngine ?: return
                engine.enableVideo()
                engine.startPreview()
                val canvas = VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_FIT, 0)
                val res = engine.setupLocalVideo(canvas)
                Log.i(tagVideo, "SETUP_LOCAL_VIDEO_SUCCESS (res=$res)")
            } catch (e: Exception) {
                Log.e(tagVideo, "Error setting up local video: ${e.message}")
            }
        }
    }

    fun detachLocalRenderer() {
        try {
            rtcEngine?.setupLocalVideo(VideoCanvas(null, VideoCanvas.RENDER_MODE_FIT, 0))
        } catch (_: Exception) {}
        localSurfaceView = null
    }

    fun setupLocalVideo(surfaceView: SurfaceView) {
        attachLocalRenderer(surfaceView)
    }

    fun setupRemoteVideo(surfaceView: SurfaceView, uid: Int) {
        if (_remoteUid.value != uid) {
            _remoteUid.value = uid
        }
        attachRemoteRenderer(surfaceView)
    }

    fun switchCamera() {
        try {
            rtcEngine?.switchCamera()
            _isFrontCamera.value = !_isFrontCamera.value
            Log.i(tagVideo, "Switched camera. FrontCamera=${_isFrontCamera.value}")
        } catch (e: Exception) {
            Log.e(tagVideo, "Error switching camera: ${e.message}")
        }
    }

    fun toggleLocalVideoMute() {
        val newMute = !_isLocalVideoMuted.value
        _isLocalVideoMuted.value = newMute
        try {
            val res = rtcEngine?.muteLocalVideoStream(newMute) ?: -1
            Log.i(tagVideo, "LOCAL_VIDEO_MUTED: $newMute (result=$res)")
        } catch (e: Exception) {
            Log.e(tagVideo, "Error toggling local video mute: ${e.message}")
        }
    }

    fun leaveChannel() {
        detachRemoteRenderer()
        detachLocalRenderer()
        try {
            if (_isVideoCall.value) {
                rtcEngine?.stopPreview()
                rtcEngine?.disableVideo()
            }
            rtcEngine?.leaveChannel()
        } catch (e: Exception) {
            Log.e(tagConnection, "Error leaving channel: ${e.message}", e)
        }
        _isInChannel.value = false
        _remoteUserJoined.value = false
        _remoteAudioPlaying.value = false
        _remoteUid.value = null
        _isVideoCall.value = false
        _isLocalVideoMuted.value = false
        _isRemoteVideoMuted.value = false
        _localCameraReady.value = false
        _remoteVideoSubscribed.value = false
        _remoteFirstFrameReceived.value = false
        boundRemoteUid = null
        abandonAudioFocus()
        try {
            audioManager?.mode = AudioManager.MODE_NORMAL
            audioManager?.isSpeakerphoneOn = false
        } catch (_: Exception) {}
    }

    fun toggleMute() {
        val newMute = !_isMuted.value
        _isMuted.value = newMute
        try {
            val res = rtcEngine?.muteLocalAudioStream(newMute) ?: -1
            Log.i(tagAudio, "LOCAL_AUDIO_MUTED: $newMute (result=$res)")
        } catch (e: Exception) {
            Log.e(tagAudio, "Error toggling mute: ${e.message}")
        }
    }

    fun toggleSpeaker() {
        val newSpeaker = !_isSpeakerOn.value
        setSpeakerphoneOn(newSpeaker)
    }

    fun setSpeakerphoneOn(on: Boolean) {
        _isSpeakerOn.value = on
        try {
            val res = rtcEngine?.setEnableSpeakerphone(on) ?: -1
            Log.i(tagAudio, "SPEAKERPHONE_STATE: result=$res, on=$on")
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager?.isSpeakerphoneOn = on
        } catch (e: Exception) {
            Log.e(tagAudio, "Error setting speakerphone: ${e.message}")
        }
    }

    fun startCall(tokenResponse: AgoraTokenResponse, channelName: String, isVideo: Boolean = false) {
        joinChannel(tokenResponse, channelName, isVideo)
    }

    fun startCall(channelName: String, token: String, uid: Int, isVideo: Boolean = false) {
        joinChannel(AgoraTokenResponse(token = token, channelName = channelName, uid = uid), channelName, isVideo)
    }

    fun endCall() {
        leaveChannel()
    }

    fun destroy() {
        try {
            leaveChannel()
            RtcEngine.destroy()
            rtcEngine = null
        } catch (e: Exception) {
            Log.e(tagConnection, "Error destroying RtcEngine: ${e.message}")
        }
    }
}



