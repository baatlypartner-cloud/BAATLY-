package com.example.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioPlayerManager(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null

    private val _currentlyPlayingMessageId = MutableStateFlow<String?>(null)
    val currentlyPlayingMessageId: StateFlow<String?> = _currentlyPlayingMessageId.asStateFlow()

    private val _currentlyPlayingUrl = MutableStateFlow<String?>(null)
    val currentlyPlayingUrl: StateFlow<String?> = _currentlyPlayingUrl.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f)
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    fun playVoice(
        messageId: String,
        resolvedUrlOrLocalPath: String,
        onError: ((String, Int) -> Unit)? = null,
        onCompletion: (() -> Unit)? = null
    ) {
        if (_currentlyPlayingMessageId.value == messageId && mediaPlayer != null) {
            if (mediaPlayer?.isPlaying == true) {
                pause()
            } else {
                mediaPlayer?.start()
                _isPlaying.value = true
            }
            return
        }

        stop()

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                val uri = if (resolvedUrlOrLocalPath.startsWith("/")) {
                    Uri.fromFile(java.io.File(resolvedUrlOrLocalPath))
                } else {
                    Uri.parse(resolvedUrlOrLocalPath)
                }
                setDataSource(context, uri)
                setOnPreparedListener { mp ->
                    mp.start()
                    _isPlaying.value = true
                    _currentlyPlayingMessageId.value = messageId
                    _currentlyPlayingUrl.value = resolvedUrlOrLocalPath
                }
                setOnCompletionListener {
                    _isPlaying.value = false
                    _currentlyPlayingMessageId.value = null
                    _currentlyPlayingUrl.value = null
                    _playbackProgress.value = 1f
                    onCompletion?.invoke()
                }
                setOnErrorListener { _, what, extra ->
                    _isPlaying.value = false
                    _currentlyPlayingMessageId.value = null
                    _currentlyPlayingUrl.value = null
                    onError?.invoke("MediaPlayer error: what=$what extra=$extra", what)
                    true
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            _isPlaying.value = false
            _currentlyPlayingMessageId.value = null
            _currentlyPlayingUrl.value = null
            onError?.invoke("Failed to initialize player: ${e.message}", -1)
        }
    }

    fun play(mediaUrl: String) {
        playVoice(
            messageId = mediaUrl,
            resolvedUrlOrLocalPath = mediaUrl
        )
    }

    /**
     * Dedicated method for playing local audio files (such as AI audio responses).
     * Uses Uri.fromFile(file) safely without exposing public file URIs outside the application.
     */
    fun playLocalFile(
        file: java.io.File,
        onCompletion: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        stop()

        if (!file.exists() || file.length() == 0L) {
            onError?.invoke("Audio file is empty or missing")
            return
        }

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(context, Uri.fromFile(file))
                setOnPreparedListener { mp ->
                    try {
                        mp.start()
                        _isPlaying.value = true
                        _currentlyPlayingUrl.value = file.absolutePath
                    } catch (e: Exception) {
                        _isPlaying.value = false
                        _currentlyPlayingUrl.value = null
                        onError?.invoke("Playback start failed: ${e.message}")
                    }
                }
                setOnCompletionListener {
                    _isPlaying.value = false
                    _playbackProgress.value = 1f
                    _currentlyPlayingUrl.value = null
                    onCompletion?.invoke()
                }
                setOnErrorListener { _, what, extra ->
                    _isPlaying.value = false
                    _currentlyPlayingUrl.value = null
                    onError?.invoke("MediaPlayer error: what=$what extra=$extra")
                    true // error handled
                }
                prepareAsync()
            }
            mediaPlayer = player
        } catch (e: Exception) {
            _isPlaying.value = false
            _currentlyPlayingUrl.value = null
            onError?.invoke("Preparation failed: ${e.message}")
        }
    }

    fun pause() {
        mediaPlayer?.pause()
        _isPlaying.value = false
    }

    fun stop() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
        _isPlaying.value = false
        _currentlyPlayingUrl.value = null
        _playbackProgress.value = 0f
    }
}
