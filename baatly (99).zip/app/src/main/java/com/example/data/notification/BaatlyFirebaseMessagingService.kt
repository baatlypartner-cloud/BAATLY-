package com.example.data.notification

import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.network.SupabaseClient
import com.example.data.network.SupabaseDataService
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class BaatlyFirebaseMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        try {
            Log.d(TAG, "FCM onNewToken received: ${token.take(10)}...")

            val sessionManager = SessionManager(applicationContext)
            sessionManager.saveFcmToken(token)

            // If user is currently logged in, register immediately with Supabase
            if (sessionManager.isLoggedIn && !sessionManager.userId.value.isNullOrBlank()) {
                serviceScope.launch {
                    try {
                        val client = SupabaseClient(sessionManager)
                        val dataService = SupabaseDataService(client, sessionManager)
                        dataService.registerFcmToken(token)
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to register new FCM token: ${e.message}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error processing onNewToken: ${e.message}")
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        try {
            Log.d(TAG, "FCM onMessageReceived from: ${remoteMessage.from}")

            val data = remoteMessage.data
            var title = remoteMessage.notification?.title
            var body = remoteMessage.notification?.body

            if (title.isNullOrBlank()) {
                title = data["title"]
            }
            if (body.isNullOrBlank()) {
                body = data["body"] ?: data["message"]
            }

            // Show local notification with rich routing data
            NotificationHelper.showNotification(
                context = applicationContext,
                title = title,
                body = body,
                data = data
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error handling FCM message: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "BaatlyFCMService"
    }
}
