package com.example.data.model

import java.io.Serializable

data class UserSession(
    val accessToken: String,
    val refreshToken: String?,
    val user: AuthUser
) : Serializable

data class AuthUser(
    val id: String,
    val email: String?,
    val phone: String? = null,
    val role: String? = null
) : Serializable

data class UserProfile(
    val id: String = "",
    val userId: String = "",
    val username: String = "",
    val displayName: String = "",
    val avatarUrl: String? = null,
    val bio: String? = null,
    val gender: String = "",
    val language: String = "",
    val accountStatus: String = "active",
    val isOnline: Boolean = false,
    val mobileNumber: String = "",
    val referralCode: String = "",
    val referralCodeUsed: String = "",
    val rating: Double = 5.0,
    val reviewsCount: Int = 0,
    val totalCalls: Int = 0,
    val audioEnabled: Boolean = true,
    val videoEnabled: Boolean = true,
    val chatEnabled: Boolean = true,
    val createdAt: String = ""
) : Serializable

data class PartnerProfile(
    val id: String = "",
    val userId: String = "",
    val partnerDisplayName: String = "",
    val businessUserId: String? = null,
    val age: Int = 0,
    val bio: String? = null,
    val hobbies: String? = null,
    val language: String? = null,
    val avatarUrl: String? = null,
    val isAvailable: Boolean = true,
    val isOnline: Boolean = false,
    val voiceVerified: Boolean = false,
    val audioEnabled: Boolean = true,
    val videoCallAccess: Boolean = false,
    val videoEnabled: Boolean = false,
    val chatEnabled: Boolean = true,
    val rating: Double = 5.0,
    val reviewsCount: Int = 0,
    val totalCalls: Int = 0,
    val lastActiveAt: String? = null
) : Serializable {
    val displayName: String
        get() = partnerDisplayName.ifBlank { "Partner" }

    val hobbiesList: List<String>
        get() = hobbies?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() } ?: emptyList()

    val publicHandle: String
        get() = businessUserId?.takeIf { it.isNotBlank() } ?: userId.take(8)
}

data class CallRecord(
    val id: String = "",
    val userId: String = "",
    val partnerId: String = "",
    val channelName: String = "",
    val callType: String = "audio", // "audio", "video"
    val status: String = "requested", // "requested", "ringing", "accepted", "connected", "completed", "rejected", "cancelled"
    val startedAt: String? = null,
    val connectedAt: String? = null,
    val endedAt: String? = null,
    val durationSeconds: Int = 0,
    val totalAmountRupees: Double = 0.0,
    val partnerName: String? = null,
    val partnerAvatarUrl: String? = null,
    val createdAt: String = "",
    val reservedCallRupees: Double = 0.0,
    val maxDurationSeconds: Int = 0,
    val userChargeRupees: Double = 0.0,
    val partnerEarningRupees: Double = 0.0,
    val partnerEarningRateRupeesPerMinute: Double = 0.0,
    val pricingTier: String? = null,
    val pricingVersion: String? = null,
    val billingStatus: String? = null
) : Serializable {
    val rupeesSpent: Double get() = totalAmountRupees
    val partner: PartnerProfile?
        get() = if (!partnerName.isNullOrBlank()) {
            PartnerProfile(
                id = partnerId,
                userId = partnerId,
                partnerDisplayName = partnerName,
                avatarUrl = partnerAvatarUrl
            )
        } else null
}

data class AgoraTokenResponse(
    val token: String,
    val channelName: String,
    val uid: Int,
    val role: String? = null,
    val expireAt: Long? = null
) : Serializable

data class ConversationSummary(
    val id: String = "",
    val partnerId: String = "",
    val partnerName: String = "",
    val partnerAvatar: String? = null,
    val isOnline: Boolean = false,
    val unreadCount: Int = 0,
    val lastMessage: String = "",
    val lastMessageTime: String = "",
    val lastMessageType: String = "text",
    val lastMessageId: String? = null,
    val lastMessageSenderId: String? = null,
    val lastMessageSeenAt: String? = null,
    val lastMessageDeliveredAt: String? = null
) : Serializable {
    val avatarUrl: String? get() = partnerAvatar
    val lastMessageText: String get() = lastMessage
    val lastMessageAt: String get() = lastMessageTime
    val partner: PartnerProfile
        get() = PartnerProfile(
            id = partnerId,
            userId = partnerId,
            partnerDisplayName = partnerName,
            avatarUrl = partnerAvatar
        )
}

data class ChatMessage(
    val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val messageType: String = "text", // "text", "image", "voice", "gift"
    val messageText: String? = null,
    val mediaUrl: String? = null,
    val mediaDurationSeconds: Int? = null,
    val isRead: Boolean = false,
    val isDelivered: Boolean = false,
    val isSeen: Boolean = false,
    val gift: GiftItem? = null,
    val giftId: String? = null,
    val deliveredAt: String? = null,
    val seenAt: String? = null,
    val createdAt: String = ""
) : Serializable {
    val isVoiceMessage: Boolean
        get() = messageType.equals("voice", ignoreCase = true) || (!mediaUrl.isNullOrBlank() && mediaUrl.endsWith(".m4a", ignoreCase = true))

    val isImageMessage: Boolean
        get() = messageType.equals("image", ignoreCase = true) || (!mediaUrl.isNullOrBlank() && (mediaUrl.endsWith(".jpg", ignoreCase = true) || mediaUrl.endsWith(".jpeg", ignoreCase = true) || mediaUrl.endsWith(".png", ignoreCase = true)))

    val isGiftMessage: Boolean
        get() = messageType.equals("gift", ignoreCase = true) || gift != null
}

data class GiftItem(
    val id: String = "",
    val name: String = "",
    val description: String? = null,
    val priceRupees: Double = 0.0,
    val iconUrl: String? = null,
    val isActive: Boolean = true,
    val displayOrder: Int = 0
) : Serializable

data class GiftTransaction(
    val id: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val giftId: String = "",
    val conversationId: String? = null,
    val callId: String? = null,
    val priceRupees: Double = 0.0,
    val createdAt: String = ""
) : Serializable

data class WalletSummary(
    val balanceRupees: Double = 0.0,
    val callReservedRupees: Double = 0.0,
    val availableBalanceRupees: Double = 0.0,
    val earningBalanceRupees: Double = 0.0,
    val withdrawalReservedRupees: Double = 0.0,
    val availableEarningBalanceRupees: Double = 0.0
) : Serializable {
    val balance: Double get() = balanceRupees
}

data class WalletInfo(
    val userId: String = "",
    val balanceRupees: Double = 0.0,
    val availableBalanceRupees: Double = 0.0,
    val updatedAt: String = ""
) : Serializable

data class WalletRechargePackage(
    val id: String = "",
    val amountRupees: Double = 0.0,
    val displayOrder: Int = 0,
    val isActive: Boolean = true
) : Serializable {
    val priceInr: Double get() = amountRupees
    val sortOrder: Int get() = displayOrder
}

data class WalletTransaction(
    val id: String = "",
    val userId: String = "",
    val transactionType: String = "",
    val amountRupees: Double = 0.0,
    val balanceAfterRupees: Double = 0.0,
    val referenceId: String? = null,
    val description: String = "",
    val status: String = "completed",
    val createdAt: String = ""
) : Serializable

data class CallBalanceEnforcementResult(
    val status: String = "ok",
    val remainingSeconds: Int = 0,
    val isAllowed: Boolean = true,
    val message: String = "",
    val balanceRupees: Double = 0.0
) : Serializable

data class EffectiveUserPricing(
    val callRateRupeesPerMinute: Double = 5.0,
    val videoCallRateRupeesPerMinute: Double = 20.0,
    val messageRateRupees: Double = 2.0
) : Serializable {
    companion object {
        val DEFAULT = EffectiveUserPricing(5.0, 20.0, 2.0)
        val EMPTY = DEFAULT
    }
}

data class TransactionItem(
    val id: String = "",
    val type: String = "",
    val amountRupees: Double = 0.0,
    val description: String = "",
    val timestamp: String = "",
    val status: String = "completed"
) : Serializable {
    val createdAt: String get() = timestamp
    val message: String get() = description
}

data class UroPayCreateOrderResult(
    val orderId: String = "",
    val paymentId: String = "",
    val tenantOrderRef: String = "",
    val amountRupees: Double = 0.0,
    val openUrl: String? = null,
    val status: String = "created"
) : Serializable

data class UroPayVerifyPaymentResult(
    val paymentId: String = "",
    val verified: Boolean = false,
    val status: String = "",
    val amountRupees: Double = 0.0,
    val activeCallExtendedSeconds: Int = 0,
    val message: String = ""
) : Serializable

data class PendingUroPayPayment(
    val paymentId: String,
    val orderId: String? = null,
    val tenantOrderRef: String,
    val packageId: String,
    val amountRupees: Double,
    val openUrl: String? = null,
    val targetCallId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

class SessionExpiredException(message: String = "Your session has expired. Please sign in again.") : Exception(message)
class PaymentNetworkException(message: String) : Exception(message)
class UroPayOrderException(message: String) : Exception(message)

sealed class SessionResult {
    data class Valid(val accessToken: String, val userId: String) : SessionResult()
    data class AuthRequired(val message: String = "Authentication required") : SessionResult()
    data class NetworkError(val message: String) : SessionResult()
    data class ServerError(val message: String, val code: Int = 500) : SessionResult()
}

sealed class AuthState {
    object Unauthenticated : AuthState()
    object Restoring : AuthState()
    data class Authenticated(val userId: String, val profile: UserProfile? = null) : AuthState()
}

sealed class UroPayPaymentUiState {
    object Idle : UroPayPaymentUiState()
    data class CreatingOrder(val amountRupees: Double) : UroPayPaymentUiState()
    data class OpeningCheckout(val paymentId: String, val openUrl: String, val amountRupees: Double = 0.0, val pkg: WalletRechargePackage? = null) : UroPayPaymentUiState() {
        val checkoutUrl: String get() = openUrl
    }
    data class Verifying(val paymentId: String, val amountRupees: Double = 0.0, val attempt: Int = 1) : UroPayPaymentUiState()
    data class Success(val paymentId: String, val amountRupees: Double, val newBalanceRupees: Double) : UroPayPaymentUiState() {
        val amountCredited: Double get() = amountRupees
        val updatedBalance: Double get() = newBalanceRupees
    }
    data class Pending(val paymentId: String, val amountRupees: Double, val message: String = "Payment is processing...") : UroPayPaymentUiState()
    data class Failed(val paymentId: String?, val errorMessage: String, val canRetry: Boolean = true, val amountRupees: Double = 0.0) : UroPayPaymentUiState() {
        val reason: String get() = errorMessage
        val message: String get() = errorMessage
    }
    object SessionExpired : UroPayPaymentUiState() {
        val message: String = "Your session has expired. Please sign in again."
    }
    object Cancelled : UroPayPaymentUiState() {
        val message: String = "Payment was cancelled."
    }
    data class Expired(val paymentId: String?) : UroPayPaymentUiState() {
        val message: String = "Order has expired. Please try again."
    }
}

data class AppNotification(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = "system",
    val isRead: Boolean = false,
    val data: Map<String, String> = emptyMap(),
    val createdAt: String = ""
) : Serializable {
    val notificationType: String get() = type
}

data class PublicUserRating(
    val averageRating: Double = 5.0,
    val totalReviews: Int = 0,
    val fiveStarCount: Int = 0,
    val fourStarCount: Int = 0,
    val threeStarCount: Int = 0,
    val twoStarCount: Int = 0,
    val oneStarCount: Int = 0
) : Serializable {
    val hasRatings: Boolean get() = totalReviews > 0
    val rating: Double get() = averageRating
    val totalRatings: Int get() = totalReviews
}

data class CallRatingEligibility(
    val isEligible: Boolean = false,
    val callId: String = "",
    val partnerId: String = "",
    val reason: String = ""
) : Serializable

data class PendingRatingCall(
    val callId: String,
    val partnerId: String,
    val partnerName: String,
    val partnerAvatar: String?,
    val durationSeconds: Int,
    val callType: String = "audio",
    val isRatingHost: Boolean = true
) : Serializable {
    val partner: PartnerProfile
        get() = PartnerProfile(
            id = partnerId,
            userId = partnerId,
            partnerDisplayName = partnerName,
            avatarUrl = partnerAvatar
        )
}

data class ActiveReportTarget(
    val targetUserId: String,
    val targetUserName: String,
    val targetAvatarUrl: String? = null
) : Serializable {
    val reportedUserId: String get() = targetUserId
    val targetDisplayName: String get() = targetUserName
}

data class RecentCallItem(
    val id: String = "",
    val partnerId: String = "",
    val partnerName: String = "Partner",
    val partnerAvatar: String? = null,
    val callType: String = "audio",
    val status: String = "completed",
    val durationSeconds: Int = 0,
    val totalAmountRupees: Double = 0.0,
    val startedAt: String = "",
    val createdAt: String = ""
) : Serializable {
    val partner: PartnerProfile
        get() = PartnerProfile(
            id = partnerId,
            userId = partnerId,
            partnerDisplayName = partnerName,
            avatarUrl = partnerAvatar
        )
    val avatarUrl: String? get() = partnerAvatar
    val rupeesSpent: Double get() = totalAmountRupees
}

data class ParticipantProfileResult(
    val userId: String,
    val displayName: String?,
    val avatarUrl: String?
) : Serializable

data class UserBlockStatus(
    val blocked: Boolean,
    val blockedByMe: Boolean,
    val blockedMe: Boolean
) : Serializable

enum class MessageDeliveryState { SENT, DELIVERED, SEEN }

fun getMessageDeliveryState(deliveredAt: String?, seenAt: String?): MessageDeliveryState {
    return if (!seenAt.isNullOrBlank() && !seenAt.equals("null", ignoreCase = true)) {
        MessageDeliveryState.SEEN
    } else if (!deliveredAt.isNullOrBlank() && !deliveredAt.equals("null", ignoreCase = true)) {
        MessageDeliveryState.DELIVERED
    } else {
        MessageDeliveryState.SENT
    }
}

fun parseNullableTimestamp(json: org.json.JSONObject, key: String): String? {
    if (!json.has(key) || json.isNull(key)) return null
    val value = json.optString(key)
    if (value.isBlank() || value.equals("null", ignoreCase = true)) return null
    return value
}

