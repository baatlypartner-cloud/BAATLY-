package com.example.ui

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AgoraCallManager
import com.example.data.audio.AudioPlayerManager
import com.example.data.audio.AudioRecorderManager
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.network.SupabaseAuthService
import com.example.data.network.SupabaseClient
import com.example.data.network.SupabaseDataService
import com.example.data.notification.NotificationHelper
import com.example.domain.BillingEngine
import com.example.ui.payment.UroPayCheckoutLauncher
import com.example.util.BaatlyAnalytics
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class Screen {
    AUTH,
    HOME,
    HOST_PROFILE,
    ACTIVE_CALL,
    DIRECT_CHAT,
    BAATLY_SYSTEM_CHAT,
    CHAT_LIST,
    WALLET,
    RECENT_CALLS,
    PROFILE,
    NOTIFICATIONS,
    LEGAL_DETAIL
}

enum class HomeMode {
    CALL,
    VIDEO,
    CHAT
}

enum class CallState {
    IDLE,
    REQUESTING,
    RINGING,
    CONNECTED,
    ENDED,
    REJECTED
}

class BaatlyViewModel(application: Application) : AndroidViewModel(application) {

    val sessionManager = SessionManager(application)
    private val supabaseClient = SupabaseClient(sessionManager)
    val authService = SupabaseAuthService(supabaseClient, sessionManager)
    val dataService = SupabaseDataService(supabaseClient, sessionManager)

    private val _effectivePricing = MutableStateFlow<EffectiveUserPricing>(EffectiveUserPricing.DEFAULT)
    val effectivePricing: StateFlow<EffectiveUserPricing> = _effectivePricing.asStateFlow()

    private val _previousScreen = MutableStateFlow<Screen>(Screen.HOME)
    val previousScreen: StateFlow<Screen> = _previousScreen.asStateFlow()

    val agoraCallManager = AgoraCallManager(application)
    val audioRecorderManager = AudioRecorderManager(application)
    val audioPlayerManager = AudioPlayerManager(application)
    val realtimeManager = com.example.data.network.SupabaseRealtimeManager(supabaseClient.okHttpClient, sessionManager)

    // User & Auth State
    val isLoggedIn = sessionManager.accessToken
    val currentUser = sessionManager.currentUser
    val wallet = sessionManager.wallet
    val isOnboardingCompleted = sessionManager.isOnboardingCompletedFlow

    fun completeOnboarding() {
        sessionManager.setOnboardingCompleted(true)
    }

    private val _isRestoringSession = MutableStateFlow(sessionManager.isLoggedIn && sessionManager.currentUser.value == null)
    val isRestoringSession: StateFlow<Boolean> = _isRestoringSession.asStateFlow()

    private val _startupError = MutableStateFlow<String?>(null)
    val startupError: StateFlow<String?> = _startupError.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _userIdAvailable = MutableStateFlow<Boolean?>(null)
    val userIdAvailable: StateFlow<Boolean?> = _userIdAvailable.asStateFlow()

    // Navigation & Screen State
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _homeMode = MutableStateFlow(HomeMode.CALL)
    val homeMode: StateFlow<HomeMode> = _homeMode.asStateFlow()

    // Partners State
    private val _availablePartners = MutableStateFlow<List<PartnerProfile>>(emptyList())
    val availablePartners: StateFlow<List<PartnerProfile>> = _availablePartners.asStateFlow()

    private val _isLoadingPartners = MutableStateFlow(false)
    val isLoadingPartners: StateFlow<Boolean> = _isLoadingPartners.asStateFlow()

    private val _selectedPartner = MutableStateFlow<PartnerProfile?>(null)
    val selectedPartner: StateFlow<PartnerProfile?> = _selectedPartner.asStateFlow()

    // Call State
    private val _activeCall = MutableStateFlow<CallRecord?>(null)
    val activeCall: StateFlow<CallRecord?> = _activeCall.asStateFlow()

    private val _activeCallPartner = MutableStateFlow<PartnerProfile?>(null)
    val activeCallPartner: StateFlow<PartnerProfile?> = _activeCallPartner.asStateFlow()

    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _callRemainingSeconds = MutableStateFlow(0)
    val callRemainingSeconds: StateFlow<Int> = _callRemainingSeconds.asStateFlow()

    private val _callElapsedSeconds = MutableStateFlow(0)
    val callElapsedSeconds: StateFlow<Int> = _callElapsedSeconds.asStateFlow()

    private var callTimerJob: Job? = null
    private var callEnforcementJob: Job? = null

    // Chat State
    private val _conversations = MutableStateFlow<List<ConversationSummary>>(emptyList())
    val conversations: StateFlow<List<ConversationSummary>> = _conversations.asStateFlow()

    private val _activeConversation = MutableStateFlow<ConversationSummary?>(null)
    val activeConversation: StateFlow<ConversationSummary?> = _activeConversation.asStateFlow()

    private val _chatPartner = MutableStateFlow<PartnerProfile?>(null)
    val chatPartner: StateFlow<PartnerProfile?> = _chatPartner.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isChatBlocked = MutableStateFlow(false)
    val isChatBlocked: StateFlow<Boolean> = _isChatBlocked.asStateFlow()

    private val _chatBlockStatus = MutableStateFlow<com.example.data.model.UserBlockStatus?>(null)
    val chatBlockStatus: StateFlow<com.example.data.model.UserBlockStatus?> = _chatBlockStatus.asStateFlow()

    // Gifts State
    private val _gifts = MutableStateFlow<List<GiftItem>>(emptyList())
    val gifts: StateFlow<List<GiftItem>> = _gifts.asStateFlow()

    private val _showGiftSheet = MutableStateFlow(false)
    val showGiftSheet: StateFlow<Boolean> = _showGiftSheet.asStateFlow()

    private val _recentGiftAnimation = MutableStateFlow<GiftItem?>(null)
    val recentGiftAnimation: StateFlow<GiftItem?> = _recentGiftAnimation.asStateFlow()

    // Wallet & Payments State
    private val _walletSummary = MutableStateFlow(WalletSummary())
    val walletSummary: StateFlow<WalletSummary> = _walletSummary.asStateFlow()

    private val _isWalletLoading = MutableStateFlow(false)
    val isWalletLoading: StateFlow<Boolean> = _isWalletLoading.asStateFlow()

    private val _walletError = MutableStateFlow<String?>(null)
    val walletError: StateFlow<String?> = _walletError.asStateFlow()

    private val _isWalletInitialized = MutableStateFlow(false)
    val isWalletInitialized: StateFlow<Boolean> = _isWalletInitialized.asStateFlow()

    private val _rechargePackages = MutableStateFlow<List<WalletRechargePackage>>(emptyList())
    val rechargePackages: StateFlow<List<WalletRechargePackage>> = _rechargePackages.asStateFlow()

    private val _uropayPaymentState = MutableStateFlow<UroPayPaymentUiState>(UroPayPaymentUiState.Idle)
    val uropayPaymentState: StateFlow<UroPayPaymentUiState> = _uropayPaymentState.asStateFlow()
    val uroPayPaymentState: StateFlow<UroPayPaymentUiState> = _uropayPaymentState.asStateFlow()

    private val _showRechargePopup = MutableStateFlow(false)
    val showRechargePopup: StateFlow<Boolean> = _showRechargePopup.asStateFlow()

    private val _transactions = MutableStateFlow<List<TransactionItem>>(emptyList())
    val transactions: StateFlow<List<TransactionItem>> = _transactions.asStateFlow()

    private val _walletTransactions = MutableStateFlow<List<WalletTransaction>>(emptyList())
    val walletTransactions: StateFlow<List<WalletTransaction>> = _walletTransactions.asStateFlow()

    private val _recentCalls = MutableStateFlow<List<CallRecord>>(emptyList())
    val recentCalls: StateFlow<List<CallRecord>> = _recentCalls.asStateFlow()

    // Notifications State
    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _unreadNotificationsCount = MutableStateFlow(0)
    val unreadNotificationsCount: StateFlow<Int> = _unreadNotificationsCount.asStateFlow()

    // Ratings & Reviews State
    private val _pendingRatingCall = MutableStateFlow<PendingRatingCall?>(null)
    val pendingRatingCall: StateFlow<PendingRatingCall?> = _pendingRatingCall.asStateFlow()

    private val _isSubmittingRating = MutableStateFlow(false)
    val isSubmittingRating: StateFlow<Boolean> = _isSubmittingRating.asStateFlow()

    private val _hostPublicRatings = MutableStateFlow<Map<String, PublicUserRating>>(emptyMap())
    val hostPublicRatings: StateFlow<Map<String, PublicUserRating>> = _hostPublicRatings.asStateFlow()

    // Report User State
    private val _activeReportTarget = MutableStateFlow<ActiveReportTarget?>(null)
    val activeReportTarget: StateFlow<ActiveReportTarget?> = _activeReportTarget.asStateFlow()

    private val _isSubmittingReport = MutableStateFlow(false)
    val isSubmittingReport: StateFlow<Boolean> = _isSubmittingReport.asStateFlow()

    // Legal Page State
    private val _activeLegalPage = MutableStateFlow<com.example.ui.legal.LegalPage?>(null)
    val activeLegalPage: StateFlow<com.example.ui.legal.LegalPage?> = _activeLegalPage.asStateFlow()

    // User Message / Toast
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        restoreSessionOnStartup()
        initAgoraCallbacks()
    }

    private fun initAgoraCallbacks() {
        agoraCallManager.onCallConnected = {
            _callState.value = CallState.CONNECTED
            startCallTimer()
            startCallBalanceEnforcement()
        }
        agoraCallManager.onCallEnded = {
            handleCallEndedLocally()
        }
        agoraCallManager.onError = { err ->
            showUserMessage("Call Error: $err")
            handleCallEndedLocally()
        }
    }

    fun onAppResumed() {
        val pendingPayment = sessionManager.getPendingPayment()
        if (pendingPayment != null) {
            val elapsed = System.currentTimeMillis() - pendingPayment.createdAt
            if (elapsed < 15 * 60 * 1000L) {
                // After return from external browser checkout: transition OpeningCheckout to Verifying
                if (_uropayPaymentState.value is UroPayPaymentUiState.OpeningCheckout) {
                    _uropayPaymentState.value = UroPayPaymentUiState.Verifying(pendingPayment.paymentId, 0.0)
                }
                verifyUroPayPayment(pendingPayment.paymentId)
            } else {
                sessionManager.clearPendingPayment()
            }
        }
        if (sessionManager.isLoggedIn) {
            refreshWallet()
            refreshNotifications()
        }
    }

    private fun restoreSessionOnStartup() {
        viewModelScope.launch {
            if (sessionManager.hasPersistedSessionCredentials) {
                _isRestoringSession.value = true
                val restored = authService.restoreOrRefreshSession()
                if (restored) {
                    authService.fetchCurrentUserProfile()
                    val uid = sessionManager.userId.value
                    if (uid != null) {
                        refreshPricing()
                        refreshWallet()
                        refreshRechargePackages()
                        refreshPartners()
                        refreshGifts()
                        refreshNotifications()
                        refreshFcmToken()
                    }
                }
                _isRestoringSession.value = false
            } else {
                _isRestoringSession.value = false
            }
        }
    }

    fun retryStartup() {
        _startupError.value = null
        restoreSessionOnStartup()
    }

    fun refreshPricing() {
        val uid = sessionManager.userId.value ?: return
        viewModelScope.launch {
            dataService.getEffectiveUserPricing(uid).onSuccess { pricing ->
                _effectivePricing.value = pricing
            }
        }
    }

    // ==========================================
    // AUTHENTICATION
    // ==========================================

    fun clearAuthError() {
        _authError.value = null
    }

    fun checkUserIdAvailable(userId: String) {
        if (userId.length < 3) {
            _userIdAvailable.value = null
            return
        }
        viewModelScope.launch {
            val available = authService.checkUserIdAvailable(userId)
            _userIdAvailable.value = available
        }
    }

    fun checkUserIdAvailability(userId: String) {
        checkUserIdAvailable(userId)
    }

    fun signIn(userId: String, pass: String) {
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            authService.signIn(userId, pass)
                .onSuccess {
                    _isAuthLoading.value = false
                    _currentScreen.value = Screen.HOME
                    refreshPricing()
                    refreshWallet()
                    refreshRechargePackages()
                    refreshPartners()
                    refreshGifts()
                    refreshNotifications()
                    refreshFcmToken()
                }
                .onFailure { e ->
                    _isAuthLoading.value = false
                    _authError.value = e.message ?: "Sign in failed"
                }
        }
    }

    fun signUp(
        userId: String,
        pass: String,
        displayName: String,
        mobile: String,
        avatar: File? = null,
        referral: String? = null
    ) {
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            authService.signUp(userId, pass, displayName, mobile, avatar, referral)
                .onSuccess {
                    _isAuthLoading.value = false
                    _currentScreen.value = Screen.HOME
                    refreshPricing()
                    refreshWallet()
                    refreshRechargePackages()
                    refreshPartners()
                    refreshGifts()
                    refreshNotifications()
                    refreshFcmToken()
                }
                .onFailure { e ->
                    _isAuthLoading.value = false
                    _authError.value = e.message ?: "Registration failed"
                }
        }
    }

    fun signUp(
        userId: String,
        password: String,
        displayName: String,
        mobileNumber: String,
        referralCode: String? = null,
        avatarFile: File? = null
    ) {
        signUp(
            userId = userId,
            pass = password,
            displayName = displayName,
            mobile = mobileNumber,
            avatar = avatarFile,
            referral = referralCode
        )
    }

    fun signOut() {
        viewModelScope.launch {
            val token = sessionManager.fcmToken.value
            if (!token.isNullOrBlank()) {
                dataService.unregisterFcmToken(token)
            }
            authService.signOut()
            _currentScreen.value = Screen.AUTH
            _availablePartners.value = emptyList()
            _conversations.value = emptyList()
            _messages.value = emptyList()
            _walletSummary.value = WalletSummary()
        }
    }

    fun updateProfile(displayName: String, bio: String?, avatar: File?) {
        viewModelScope.launch {
            authService.updateProfile(displayName, bio, avatar)
                .onSuccess {
                    showUserMessage("Profile updated successfully")
                }
                .onFailure { e ->
                    showUserMessage("Update failed: ${e.message}")
                }
        }
    }

    fun updateUserProfile(
        displayName: String,
        bio: String?,
        avatarFile: File?,
        onComplete: ((Boolean, String?) -> Unit)? = null
    ) {
        viewModelScope.launch {
            authService.updateProfile(displayName, bio, avatarFile)
                .onSuccess {
                    authService.fetchCurrentUserProfile()
                    showUserMessage("Profile updated successfully")
                    onComplete?.invoke(true, null)
                }
                .onFailure { e ->
                    val err = e.message ?: "Update failed"
                    showUserMessage(err)
                    onComplete?.invoke(false, err)
                }
        }
    }

    fun requestAccountDeletion(onComplete: ((Boolean, String?) -> Unit)? = null) {
        viewModelScope.launch {
            authService.requestAccountDeletion()
                .onSuccess {
                    onComplete?.invoke(true, null)
                    signOut()
                    showUserMessage("Account deletion requested successfully")
                }
                .onFailure { e ->
                    val err = e.message ?: "Could not delete account"
                    onComplete?.invoke(false, err)
                    showUserMessage(err)
                }
        }
    }

    // ==========================================
    // NAVIGATION
    // ==========================================

    fun setScreen(screen: Screen) {
        if (_currentScreen.value != screen) {
            _previousScreen.value = _currentScreen.value
            _currentScreen.value = screen
        }
        if (screen == Screen.WALLET) {
            refreshWallet()
            refreshRechargePackages()
            fetchTransactions()
        }
        if (screen == Screen.RECENT_CALLS) {
            fetchRecentCalls()
        }
    }

    fun setHomeMode(mode: HomeMode) {
        _homeMode.value = mode
    }

    fun goBack() {
        if (_currentScreen.value == Screen.HOST_PROFILE || _currentScreen.value == Screen.RECENT_CALLS ||
            _currentScreen.value == Screen.WALLET || _currentScreen.value == Screen.PROFILE ||
            _currentScreen.value == Screen.NOTIFICATIONS
        ) {
            _currentScreen.value = Screen.HOME
        } else if (_currentScreen.value == Screen.DIRECT_CHAT) {
            closeChatScreen()
        } else if (_currentScreen.value == Screen.BAATLY_SYSTEM_CHAT) {
            _currentScreen.value = Screen.CHAT_LIST
        } else if (_currentScreen.value == Screen.LEGAL_DETAIL) {
            closeLegalPage()
        } else {
            _currentScreen.value = _previousScreen.value
        }
    }

    fun openLegalPage(page: com.example.ui.legal.LegalPage) {
        _activeLegalPage.value = page
        setScreen(Screen.LEGAL_DETAIL)
    }

    fun closeLegalPage() {
        _activeLegalPage.value = null
        setScreen(Screen.PROFILE)
    }

    // ==========================================
    // PARTNERS & PROFILES
    // ==========================================

    fun refreshPartners() {
        _isLoadingPartners.value = true
        viewModelScope.launch {
            dataService.getAvailablePartners()
                .onSuccess { list ->
                    _availablePartners.value = list
                    _isLoadingPartners.value = false
                }
                .onFailure {
                    _isLoadingPartners.value = false
                }
        }
    }

    fun selectPartner(partner: PartnerProfile) {
        _selectedPartner.value = partner
        setScreen(Screen.HOST_PROFILE)
    }

    fun openPartnerProfile(partner: PartnerProfile) {
        selectPartner(partner)
    }

    fun openHostProfile(partner: PartnerProfile) {
        selectPartner(partner)
    }

    fun loadPublicRatingForUser(userId: String) {
        if (userId.isBlank()) return
        viewModelScope.launch {
            dataService.getPublicUserRating(userId).onSuccess { rating ->
                val current = _hostPublicRatings.value.toMutableMap()
                current[userId] = rating
                _hostPublicRatings.value = current
            }
        }
    }

    // ==========================================
    // CALLS
    // ==========================================

    fun requestCall(partner: PartnerProfile) {
        startCall(partner, isVideo = false)
    }

    fun requestVideoCall(partner: PartnerProfile) {
        startCall(partner, isVideo = true)
    }

    fun toggleGiftSheet(show: Boolean? = null) {
        val next = show ?: !_showGiftSheet.value
        _showGiftSheet.value = next
        if (next) refreshGifts()
    }

    fun startCall(partner: PartnerProfile, isVideo: Boolean = false) {
        val minRequired = if (isVideo) effectivePricing.value.videoCallRateRupeesPerMinute else effectivePricing.value.callRateRupeesPerMinute
        if (_walletSummary.value.availableBalanceRupees < minRequired) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance to start call. Minimum ₹${minRequired.toInt()} required.")
            return
        }

        _activeCallPartner.value = partner
        _callState.value = CallState.REQUESTING
        _callElapsedSeconds.value = 0
        setScreen(Screen.ACTIVE_CALL)

        var hasTokenBeenRequested = false

        viewModelScope.launch {
            val callResult = if (isVideo) {
                dataService.requestVideoCall(partner.id)
            } else {
                dataService.requestCall(partner.id)
            }

            callResult.onSuccess { record ->
                _activeCall.value = record
                _callState.value = CallState.RINGING

                // Listen to Realtime updates for call status
                realtimeManager.subscribeToCall(record.id) { updatedRecord ->
                    _activeCall.value = updatedRecord
                    when (updatedRecord.status.lowercase()) {
                        "accepted" -> {
                            if (!hasTokenBeenRequested) {
                                hasTokenBeenRequested = true
                                viewModelScope.launch {
                                    dataService.getAgoraToken(updatedRecord.channelName)
                                        .onSuccess { agoraToken ->
                                            agoraCallManager.onCallConnected = {
                                                _callState.value = CallState.CONNECTED
                                                viewModelScope.launch {
                                                    dataService.getCallRecord(updatedRecord.id).onSuccess { freshRecord ->
                                                        _activeCall.value = freshRecord
                                                        val initialMax = if (freshRecord.maxDurationSeconds > 0) freshRecord.maxDurationSeconds else com.example.domain.BillingEngine.calculateMaxCallDurationSeconds(
                                                            _walletSummary.value.availableBalanceRupees,
                                                            if (isVideo) effectivePricing.value.videoCallRateRupeesPerMinute else effectivePricing.value.callRateRupeesPerMinute
                                                        )
                                                        _callRemainingSeconds.value = initialMax
                                                    }
                                                }
                                                startCallTimer()
                                                startCallBalanceEnforcement()
                                            }
                                            agoraCallManager.onError = { errorMsg ->
                                                showUserMessage("Call connection failed: $errorMsg")
                                                endCall()
                                            }
                                            agoraCallManager.startCall(
                                                channelName = updatedRecord.channelName,
                                                token = agoraToken.token,
                                                uid = agoraToken.uid,
                                                isVideo = isVideo
                                            )
                                        }
                                        .onFailure { e ->
                                            showUserMessage("Could not connect call audio/video: ${e.message}")
                                            endCall()
                                        }
                                }
                            }
                        }
                        "rejected", "cancelled", "completed", "failed", "missed" -> {
                            showUserMessage("Call ${updatedRecord.status}.")
                            endCall()
                        }
                    }
                }
            }.onFailure { e ->
                showUserMessage("Call request failed: ${e.message}")
                _callState.value = CallState.IDLE
                _activeCall.value = null
                _activeCallPartner.value = null
                setScreen(Screen.HOME)
            }
        }
    }

    fun endCall() {
        val call = _activeCall.value
        callTimerJob?.cancel()
        callEnforcementJob?.cancel()
        com.example.data.audio.BaatlyRingtoneManager.stopRingtone()
        agoraCallManager.endCall()
        realtimeManager.unsubscribe()

        if (call != null) {
            viewModelScope.launch {
                dataService.updateCallState(call.id, "completed")
                dataService.settleCall(call.id)
                checkCallRatingEligibility(call.id, _activeCallPartner.value?.id ?: call.partnerId)
                refreshWallet()
            }
        }

        _callState.value = CallState.ENDED
        viewModelScope.launch {
            delay(1000)
            _activeCall.value = null
            _activeCallPartner.value = null
            _callState.value = CallState.IDLE
            setScreen(Screen.HOME)
        }
    }

    fun acceptIncomingCall(callId: String, partnerId: String, isVideo: Boolean) {
        com.example.data.audio.BaatlyRingtoneManager.stopRingtone()
        _callState.value = CallState.RINGING
        _callElapsedSeconds.value = 0
        setScreen(Screen.ACTIVE_CALL)

        viewModelScope.launch {
            // 1. Resolve partner profile
            dataService.getHostProfile(partnerId).onSuccess { profile ->
                _activeCallPartner.value = profile
            }.onFailure {
                _activeCallPartner.value = PartnerProfile(
                    id = partnerId,
                    userId = partnerId,
                    partnerDisplayName = "Baatly Host",
                    avatarUrl = null,
                    isOnline = true
                )
            }

            // 2. Fetch call record
            dataService.getCallRecord(callId).onSuccess { callRecord ->
                _activeCall.value = callRecord

                // 3. Update state to accepted
                dataService.updateCallState(callId, "accepted").onSuccess {
                    // 4. Retrieve Agora Token
                    dataService.getAgoraToken(callRecord.channelName).onSuccess { tokenRes ->
                        // 5. Setup callbacks and join Agora
                        agoraCallManager.onCallConnected = {
                            _callState.value = CallState.CONNECTED
                            viewModelScope.launch {
                                dataService.getCallRecord(callId).onSuccess { freshRecord ->
                                    _activeCall.value = freshRecord
                                    val initialMax = if (freshRecord.maxDurationSeconds > 0) {
                                        freshRecord.maxDurationSeconds
                                    } else {
                                        BillingEngine.calculateMaxCallDurationSeconds(
                                            _walletSummary.value.availableBalanceRupees,
                                            if (isVideo) effectivePricing.value.videoCallRateRupeesPerMinute else effectivePricing.value.callRateRupeesPerMinute
                                        )
                                    }
                                    _callRemainingSeconds.value = initialMax
                                }
                            }
                            startCallTimer()
                            startCallBalanceEnforcement()
                        }
                        agoraCallManager.onError = { errorMsg ->
                            showUserMessage("Call connection failed: $errorMsg")
                            endCall()
                        }

                        // Subscribe to live call updates (e.g. completes/cancellations)
                        realtimeManager.subscribeToCall(callId) { updatedRecord ->
                            _activeCall.value = updatedRecord
                            val status = updatedRecord.status.lowercase()
                            if (status == "rejected" || status == "cancelled" || status == "completed" || status == "failed" || status == "missed") {
                                endCall()
                            }
                        }

                        // Start Agora join
                        agoraCallManager.startCall(
                            channelName = callRecord.channelName,
                            token = tokenRes.token,
                            uid = tokenRes.uid,
                            isVideo = isVideo
                        )
                    }.onFailure { e ->
                        showUserMessage("Could not connect call audio/video: ${e.message}")
                        endCall()
                    }
                }.onFailure { e ->
                    showUserMessage("Could not accept call: ${e.message}")
                    endCall()
                }
            }.onFailure { e ->
                showUserMessage("Call validation failed: ${e.message}")
                endCall()
            }
        }
    }

    private fun handleCallEndedLocally() {
        endCall()
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _callElapsedSeconds.value += 1
                val maxDur = _activeCall.value?.maxDurationSeconds ?: 0
                if (maxDur > 0) {
                    val rem = (maxDur - _callElapsedSeconds.value).coerceAtLeast(0)
                    _callRemainingSeconds.value = rem
                    if (rem <= 0 && _callState.value == CallState.CONNECTED) {
                        showUserMessage("Call duration limit reached.")
                        endCall()
                        break
                    }
                } else if (_callRemainingSeconds.value > 0) {
                    _callRemainingSeconds.value = (_callRemainingSeconds.value - 1).coerceAtLeast(0)
                    if (_callRemainingSeconds.value <= 0 && _callState.value == CallState.CONNECTED) {
                        showUserMessage("Call duration limit reached.")
                        endCall()
                        break
                    }
                }
            }
        }
    }

    private fun startCallBalanceEnforcement() {
        callEnforcementJob?.cancel()
        callEnforcementJob = viewModelScope.launch {
            while (true) {
                delay(15000) // Check every 15 seconds
                val call = _activeCall.value ?: break
                dataService.enforceCallBalanceLimit(call.id).onSuccess { res ->
                    _callRemainingSeconds.value = res.remainingSeconds
                    if (!res.isAllowed || res.remainingSeconds <= 0) {
                        showUserMessage("Call balance depleted.")
                        endCall()
                        break
                    }
                }
            }
        }
    }

    fun fetchRecentCalls() {
        viewModelScope.launch {
            dataService.fetchRecentCalls().onSuccess { list ->
                _recentCalls.value = list
            }
        }
    }

    // ==========================================
    // CHAT & MESSAGING
    // ==========================================

    fun openChatWithHost(partner: PartnerProfile) {
        _chatPartner.value = partner
        _chatBlockStatus.value = null // Set loading
        _isChatBlocked.value = false
        setScreen(Screen.DIRECT_CHAT)
        viewModelScope.launch {
            val partnerId = partner.id
            dataService.isUserBlocked(partnerId).onSuccess { status ->
                _chatBlockStatus.value = status
                _isChatBlocked.value = status.blockedByMe
            }.onFailure {
                _chatBlockStatus.value = com.example.data.model.UserBlockStatus(blocked = false, blockedByMe = false, blockedMe = false)
                _isChatBlocked.value = false
            }

            dataService.startChatWithHost(partnerId).onSuccess { convId ->
                val conv = ConversationSummary(
                    id = convId,
                    partnerId = partnerId,
                    partnerName = partner.displayName,
                    partnerAvatar = partner.avatarUrl,
                    isOnline = partner.isOnline
                )
                _activeConversation.value = conv
                subscribeToActiveConversationRealtime(convId)
                loadMessagesForConversation(convId)
            }
        }
    }

    fun openConversation(conv: ConversationSummary) {
        _activeConversation.value = conv
        _chatBlockStatus.value = null // Set loading
        _isChatBlocked.value = false
        setScreen(Screen.DIRECT_CHAT)
        subscribeToActiveConversationRealtime(conv.id)
        viewModelScope.launch {
            val partnerId = conv.partnerId
            dataService.isUserBlocked(partnerId).onSuccess { status ->
                _chatBlockStatus.value = status
                _isChatBlocked.value = status.blockedByMe
            }.onFailure {
                _chatBlockStatus.value = com.example.data.model.UserBlockStatus(blocked = false, blockedByMe = false, blockedMe = false)
                _isChatBlocked.value = false
            }

            // First try get_conversation_participant_profile RPC
            dataService.getConversationParticipantProfile(conv.id, partnerId).onSuccess { res ->
                val name = res.displayName?.takeIf { it.isNotBlank() } ?: conv.partnerName
                val avatar = res.avatarUrl?.takeIf { it.isNotBlank() } ?: conv.partnerAvatar
                val updatedConv = conv.copy(partnerName = name, partnerAvatar = avatar)
                _activeConversation.value = updatedConv
                _chatPartner.value = PartnerProfile(
                    id = res.userId,
                    userId = res.userId,
                    partnerDisplayName = name,
                    avatarUrl = avatar ?: "",
                    isOnline = conv.isOnline
                )
            }.onFailure {
                // Fallback to getHostProfile
                dataService.getHostProfile(partnerId).onSuccess { profile ->
                    _chatPartner.value = profile
                    _activeConversation.value = conv.copy(
                        partnerName = profile.displayName,
                        partnerAvatar = profile.avatarUrl?.takeIf { it.isNotBlank() } ?: conv.partnerAvatar
                    )
                }.onFailure {
                    // Final fallback to the conv values
                    _chatPartner.value = PartnerProfile(
                        id = partnerId,
                        userId = partnerId,
                        partnerDisplayName = conv.partnerName,
                        avatarUrl = conv.partnerAvatar ?: "",
                        isOnline = conv.isOnline
                    )
                }
            }
            loadMessagesForConversation(conv.id)
        }
    }

    fun closeChatScreen() {
        realtimeManager.unsubscribe()
        _activeConversation.value = null
        _chatPartner.value = null
        _messages.value = emptyList()
        _isChatBlocked.value = false
        _chatBlockStatus.value = null
        setScreen(Screen.CHAT_LIST)
    }

    fun refreshConversations() {
        viewModelScope.launch {
            dataService.fetchConversations().onSuccess { list ->
                _conversations.value = list
            }
        }
    }

    private fun loadMessagesForConversation(convId: String) {
        viewModelScope.launch {
            dataService.fetchMessages(convId).onSuccess { list ->
                val currentUserId = sessionManager.userId.value ?: ""
                _messages.value = list

                // Identify incoming undelivered and unseen messages
                val incomingUndelivered = list.filter { it.receiverId == currentUserId && it.deliveredAt.isNullOrBlank() }.map { it.id }
                val incomingUnseen = list.filter { it.receiverId == currentUserId && it.seenAt.isNullOrBlank() }.map { it.id }

                if (incomingUndelivered.isNotEmpty() || incomingUnseen.isNotEmpty()) {
                    if (incomingUndelivered.isNotEmpty()) {
                        dataService.markMessagesDelivered(convId, incomingUndelivered)
                    }
                    if (incomingUnseen.isNotEmpty()) {
                        dataService.markMessagesSeen(convId, incomingUnseen)
                    }
                    dataService.markConversationRead(convId)
                    
                    // Re-fetch accurate verified timestamps from database
                    dataService.fetchMessages(convId).onSuccess { updatedList ->
                        _messages.value = updatedList
                    }
                } else {
                    dataService.markConversationRead(convId)
                }
                
                refreshConversations()
            }
        }
    }

    private fun subscribeToActiveConversationRealtime(conversationId: String) {
        realtimeManager.subscribeToConversation(
            conversationId = conversationId,
            onNewMessage = { msg ->
                handleIncomingRealtimeMessage(msg)
            },
            onMessageUpdated = { msg ->
                handleUpdatedRealtimeMessage(msg)
            },
            onResync = {
                loadMessagesForConversation(conversationId)
                refreshConversations()
            }
        )
    }

    private fun handleIncomingRealtimeMessage(msg: ChatMessage) {
        val currentUserId = sessionManager.userId.value ?: ""
        val activeConv = _activeConversation.value
        
        // Ignore duplicate message IDs
        if (_messages.value.any { it.id == msg.id }) return

        if (activeConv != null && msg.conversationId == activeConv.id) {
            _messages.value = _messages.value + msg
            if (msg.receiverId == currentUserId) {
                viewModelScope.launch {
                    dataService.markMessagesDelivered(activeConv.id, listOf(msg.id))
                    dataService.markMessagesSeen(activeConv.id, listOf(msg.id))
                    dataService.markConversationRead(activeConv.id)
                    // Load latest with exact backend verification timestamp
                    dataService.fetchMessages(activeConv.id).onSuccess { updatedList ->
                        _messages.value = updatedList
                    }
                }
            }
        } else {
            if (msg.receiverId == currentUserId) {
                viewModelScope.launch {
                    dataService.markMessagesDelivered(msg.conversationId, listOf(msg.id))
                    refreshConversations()
                }
            }
        }
        refreshConversations()
    }

    private fun handleUpdatedRealtimeMessage(msg: ChatMessage) {
        val activeConv = _activeConversation.value
        if (activeConv != null && msg.conversationId == activeConv.id) {
            _messages.value = _messages.value.map { existing ->
                if (existing.id == msg.id) {
                    existing.copy(
                        deliveredAt = msg.deliveredAt,
                        seenAt = msg.seenAt,
                        isRead = msg.isRead,
                        isDelivered = msg.deliveredAt != null,
                        isSeen = msg.seenAt != null
                    )
                } else {
                    existing
                }
            }
        }
        // Update corresponding conversation summary in the exact same state transition
        _conversations.value = _conversations.value.map { conv ->
            if (conv.id == msg.conversationId && conv.lastMessageId == msg.id) {
                conv.copy(
                    lastMessageSeenAt = msg.seenAt,
                    lastMessageDeliveredAt = msg.deliveredAt
                )
            } else {
                conv
            }
        }
        refreshConversations()
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val msgCost = effectivePricing.value.messageRateRupees
        if (_walletSummary.value.availableBalanceRupees < msgCost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance for message. ₹${msgCost.toInt()} required.")
            return
        }

        viewModelScope.launch {
            dataService.sendMessage(
                conversationId = conv.id,
                receiverId = partner.id,
                messageType = "text",
                messageText = text.trim()
            ).onSuccess { msg ->
                // Do not append duplicated message if already received via realtime
                if (!_messages.value.any { it.id == msg.id }) {
                    _messages.value = _messages.value + msg
                }
                refreshWallet()
                refreshConversations()
            }.onFailure { e ->
                showUserMessage("Failed to send: ${e.message}")
            }
        }
    }

    fun sendImageMessage(file: File) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val msgCost = effectivePricing.value.messageRateRupees
        if (_walletSummary.value.availableBalanceRupees < msgCost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance for image message. ₹${msgCost.toInt()} required.")
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = false).onSuccess { mediaPath ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "image",
                    mediaUrl = mediaPath
                ).onSuccess { msg ->
                    _messages.value = _messages.value + msg
                    refreshWallet()
                }.onFailure { e ->
                    showUserMessage("Failed to send image: ${e.message}")
                }
            }.onFailure { e ->
                showUserMessage("Failed to upload image: ${e.message}")
            }
        }
    }

    fun sendVoiceMessage(file: File, durationSeconds: Int) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val msgCost = effectivePricing.value.messageRateRupees
        if (_walletSummary.value.availableBalanceRupees < msgCost) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance for voice message. ₹${msgCost.toInt()} required.")
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = true).onSuccess { mediaPath ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "voice",
                    mediaUrl = mediaPath,
                    mediaDurationSeconds = durationSeconds
                ).onSuccess { msg ->
                    _messages.value = _messages.value + msg
                    refreshWallet()
                }.onFailure { e ->
                    showUserMessage("Failed to send voice message: ${e.message}")
                }
            }.onFailure { e ->
                showUserMessage("Failed to upload voice note: ${e.message}")
            }
        }
    }

    // ==========================================
    // GIFTS
    // ==========================================

    fun openGiftSheet() {
        _showGiftSheet.value = true
        refreshGifts()
    }

    fun closeGiftSheet() {
        _showGiftSheet.value = false
    }

    fun refreshGifts() {
        viewModelScope.launch {
            dataService.fetchGifts().onSuccess { list ->
                _gifts.value = list
            }
        }
    }

    fun sendGift(gift: GiftItem) {
        val receiverId = _activeCallPartner.value?.id ?: _chatPartner.value?.id ?: return
        val convId = _activeConversation.value?.id
        val callId = _activeCall.value?.id

        if (_walletSummary.value.availableBalanceRupees < gift.priceRupees) {
            _showRechargePopup.value = true
            showUserMessage("Insufficient balance for gift. ₹${gift.priceRupees.toInt()} required.")
            return
        }

        viewModelScope.launch {
            dataService.sendGift(gift.id, receiverId, convId, callId)
                .onSuccess {
                    _recentGiftAnimation.value = gift
                    closeGiftSheet()
                    refreshWallet()
                    delay(3500)
                    _recentGiftAnimation.value = null
                }
                .onFailure { e ->
                    showUserMessage("Gift failed: ${e.message}")
                }
        }
    }

    // ==========================================
    // WALLET & UROPAY RECHARGE
    // ==========================================

    private var walletRefreshJob: Job? = null

    fun refreshWallet() {
        val currentUid = sessionManager.userId.value ?: ""
        walletRefreshJob?.cancel()
        walletRefreshJob = viewModelScope.launch {
            _isWalletLoading.value = true
            _walletError.value = null
            Log.d("WalletRefresh", "UID: $currentUid | Refresh STARTED")
            dataService.fetchWalletSummary().fold(
                onSuccess = { summary ->
                    _walletSummary.value = summary
                    _isWalletInitialized.value = true
                    _isWalletLoading.value = false
                    _walletError.value = null
                    Log.d(
                        "WalletRefresh",
                        "UID: $currentUid | Refresh SUCCESS | balance_rupees: ${summary.balanceRupees} | available_balance_rupees: ${summary.availableBalanceRupees}"
                    )
                },
                onFailure = { e ->
                    _isWalletLoading.value = false
                    val errMsg = e.message ?: "Failed to fetch wallet summary"
                    _walletError.value = errMsg
                    Log.e("WalletRefresh", "UID: $currentUid | Refresh FAILURE | error: $errMsg", e)
                }
            )
        }
    }

    fun refreshRechargePackages() {
        viewModelScope.launch {
            dataService.fetchWalletRechargePackages().onSuccess { list ->
                _rechargePackages.value = list
            }
        }
    }

    fun showRechargeModal() {
        _showRechargePopup.value = true
        refreshRechargePackages()
    }

    fun dismissRechargePopup() {
        _showRechargePopup.value = false
    }

    fun closeRechargePopup() {
        dismissRechargePopup()
    }

    fun startUroPayRecharge(pkg: WalletRechargePackage, targetCallId: String? = null, isCallRecharge: Boolean = false) {
        val effectiveCallId = targetCallId ?: _activeCall.value?.id
        if (isCallRecharge && effectiveCallId.isNullOrBlank()) {
            _uropayPaymentState.value = UroPayPaymentUiState.Failed(null, "No active call found for in-call recharge", true, pkg.amountRupees)
            return
        }
        _uropayPaymentState.value = UroPayPaymentUiState.CreatingOrder(pkg.amountRupees)
        val tenantRef = "BAATLY_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"

        viewModelScope.launch {
            dataService.createUroPayOrder(pkg.id, tenantRef, effectiveCallId)
                .onSuccess { orderRes ->
                    val pending = PendingUroPayPayment(
                        paymentId = orderRes.paymentId,
                        orderId = orderRes.orderId,
                        tenantOrderRef = tenantRef,
                        packageId = pkg.id,
                        amountRupees = pkg.amountRupees,
                        openUrl = orderRes.openUrl,
                        targetCallId = effectiveCallId
                    )
                    sessionManager.savePendingPayment(pending)
                    if (!orderRes.openUrl.isNullOrBlank()) {
                        _uropayPaymentState.value = UroPayPaymentUiState.OpeningCheckout(orderRes.paymentId, orderRes.openUrl)
                    } else {
                        _uropayPaymentState.value = UroPayPaymentUiState.Failed(orderRes.paymentId, "No checkout URL returned", true, pkg.amountRupees)
                    }
                }
                .onFailure { e ->
                    _uropayPaymentState.value = UroPayPaymentUiState.Failed(null, e.message ?: "Failed to create order", true, pkg.amountRupees)
                }
        }
    }

    fun verifyUroPayPayment(paymentId: String) {
        val pending = sessionManager.getPendingPayment()
        val targetCallIdToRefresh = pending?.targetCallId ?: _activeCall.value?.id

        _uropayPaymentState.value = UroPayPaymentUiState.Verifying(paymentId, 0.0)
        viewModelScope.launch {
            dataService.verifyUroPayPayment(paymentId)
                .onSuccess { res ->
                    if (res.verified && res.status.equals("success", ignoreCase = true) && res.amountRupees > 0.0) {
                        sessionManager.clearPendingPayment()
                        _showRechargePopup.value = false
                        viewModelScope.launch {
                            dataService.fetchWalletSummary().fold(
                                onSuccess = { freshSummary ->
                                    _walletSummary.value = freshSummary
                                    _isWalletInitialized.value = true
                                    _isWalletLoading.value = false
                                    _walletError.value = null
                                    _uropayPaymentState.value = UroPayPaymentUiState.Success(paymentId, res.amountRupees, freshSummary.balanceRupees)
                                },
                                onFailure = {
                                    refreshWallet()
                                    _uropayPaymentState.value = UroPayPaymentUiState.Success(paymentId, res.amountRupees, _walletSummary.value.balanceRupees + res.amountRupees)
                                }
                            )
                        }

                        if (!targetCallIdToRefresh.isNullOrBlank()) {
                            dataService.getCallRecord(targetCallIdToRefresh).onSuccess { freshCall ->
                                val status = freshCall.status.lowercase()
                                if (status == "connected" || status == "accepted" || status == "ringing") {
                                    _activeCall.value = freshCall
                                    val newMax = freshCall.maxDurationSeconds
                                    if (newMax > 0) {
                                        val newRemaining = (newMax - _callElapsedSeconds.value).coerceAtLeast(0)
                                        _callRemainingSeconds.value = newRemaining
                                    }
                                    showUserMessage("Recharge successful! Call duration extended.")
                                }
                            }
                        }
                    } else {
                        sessionManager.clearPendingPayment()
                        val statusLower = res.status.lowercase()
                        when {
                            statusLower.contains("cancel") -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Cancelled
                            }
                            statusLower.contains("fail") -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Failed(
                                    paymentId = paymentId,
                                    errorMessage = "Payment failed.",
                                    canRetry = true,
                                    amountRupees = res.amountRupees
                                )
                            }
                            statusLower.contains("expire") -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Expired(paymentId)
                            }
                            statusLower.contains("pending") || statusLower.contains("process") -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Pending(
                                    paymentId = paymentId,
                                    amountRupees = res.amountRupees,
                                    message = "Payment is still processing."
                                )
                            }
                            else -> {
                                _uropayPaymentState.value = UroPayPaymentUiState.Failed(
                                    paymentId = paymentId,
                                    errorMessage = res.message.ifBlank { "Payment was not completed." },
                                    canRetry = true,
                                    amountRupees = res.amountRupees
                                )
                            }
                        }
                    }
                }
                .onFailure { e ->
                    _uropayPaymentState.value = UroPayPaymentUiState.Failed(paymentId, e.message ?: "Verification request failed")
                }
        }
    }

    fun closeInAppCheckout() {
        val pending = sessionManager.getPendingPayment()
        if (pending != null) {
            verifyUroPayPayment(pending.paymentId)
        } else {
            _uropayPaymentState.value = UroPayPaymentUiState.Idle
        }
    }

    fun resetPaymentState() {
        _uropayPaymentState.value = UroPayPaymentUiState.Idle
    }

    fun handlePaymentReturnDeepLink(uri: Uri) {
        val paymentId = uri.getQueryParameter("payment_id") ?: sessionManager.getPendingPayment()?.paymentId
        if (!paymentId.isNullOrBlank()) {
            verifyUroPayPayment(paymentId)
        }
    }

    fun fetchTransactions() {
        viewModelScope.launch {
            dataService.fetchTransactions().onSuccess { list ->
                _transactions.value = list
            }
            dataService.fetchWalletTransactions().onSuccess { list ->
                _walletTransactions.value = list
            }
        }
    }

    // ==========================================
    // NOTIFICATIONS & FCM
    // ==========================================

    private fun refreshFcmToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful && task.result != null) {
                val token = task.result
                sessionManager.saveFcmToken(token)
                viewModelScope.launch {
                    dataService.registerFcmToken(token)
                }
            }
        }
    }

    fun refreshNotifications() {
        viewModelScope.launch {
            dataService.fetchNotifications().onSuccess { list ->
                _notifications.value = list
                _unreadNotificationsCount.value = list.count { !it.isRead }
            }
        }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            dataService.markNotificationAsRead(id)
            refreshNotifications()
        }
    }

    fun handleNotificationTap(type: String?, data: Map<String, String?>) {
        when (type) {
            "call", "incoming_call" -> {
                val callId = data["call_id"]
                if (!callId.isNullOrBlank()) {
                    setScreen(Screen.ACTIVE_CALL)
                }
            }
            "chat", "message" -> {
                val convId = data["conversation_id"]
                val partnerId = data["partner_id"]
                if (!convId.isNullOrBlank() || !partnerId.isNullOrBlank()) {
                    setScreen(Screen.CHAT_LIST)
                }
            }
            "recharge", "wallet" -> {
                setScreen(Screen.WALLET)
            }
            else -> {
                setScreen(Screen.NOTIFICATIONS)
            }
        }
    }

    // ==========================================
    // RATINGS & REVIEWS
    // ==========================================

    private fun checkCallRatingEligibility(callId: String, partnerId: String) {
        viewModelScope.launch {
            dataService.getCallRatingEligibility(callId).onSuccess { elig ->
                if (elig.isEligible) {
                    val partnerName = _activeCallPartner.value?.displayName ?: "Host"
                    val partnerAvatar = _activeCallPartner.value?.avatarUrl
                    _pendingRatingCall.value = PendingRatingCall(
                        callId = callId,
                        partnerId = partnerId,
                        partnerName = partnerName,
                        partnerAvatar = partnerAvatar,
                        durationSeconds = _callElapsedSeconds.value
                    )
                }
            }
        }
    }

    fun submitCallRating(rating: Int, reviewText: String?) {
        val pending = _pendingRatingCall.value ?: return
        _isSubmittingRating.value = true
        viewModelScope.launch {
            dataService.submitCallRating(pending.callId, pending.partnerId, rating, reviewText)
                .onSuccess {
                    _isSubmittingRating.value = false
                    _pendingRatingCall.value = null
                    showUserMessage("Thank you for your rating!")
                }
                .onFailure { e ->
                    _isSubmittingRating.value = false
                    showUserMessage("Rating submission failed: ${e.message}")
                }
        }
    }

    fun dismissRatingPopup() {
        _pendingRatingCall.value = null
    }

    // ==========================================
    // BLOCK & REPORT USER
    // ==========================================

    fun blockUser(partnerId: String) {
        viewModelScope.launch {
            dataService.blockUser(partnerId).onSuccess { rpcSuccess ->
                if (rpcSuccess) {
                    dataService.isUserBlocked(partnerId).onSuccess { verifyStatus ->
                        if (verifyStatus.blockedByMe) {
                            _chatBlockStatus.value = verifyStatus
                            _isChatBlocked.value = true
                            showUserMessage("User blocked")
                            refreshPartners()
                        } else {
                            showUserMessage("Block verification failed on backend")
                            dataService.isUserBlocked(partnerId).onSuccess { s ->
                                _chatBlockStatus.value = s
                                _isChatBlocked.value = s.blockedByMe
                            }
                        }
                    }.onFailure { e ->
                        showUserMessage("Block verification error: ${e.message}")
                        dataService.isUserBlocked(partnerId).onSuccess { s ->
                            _chatBlockStatus.value = s
                            _isChatBlocked.value = s.blockedByMe
                        }
                    }
                } else {
                    showUserMessage("Block request was not acknowledged by backend")
                }
            }.onFailure { e ->
                showUserMessage("Could not block user: ${e.message}")
            }
        }
    }

    fun unblockUser(partnerId: String) {
        viewModelScope.launch {
            dataService.unblockUser(partnerId).onSuccess { rpcSuccess ->
                if (rpcSuccess) {
                    dataService.isUserBlocked(partnerId).onSuccess { verifyStatus ->
                        if (!verifyStatus.blockedByMe) {
                            _chatBlockStatus.value = verifyStatus
                            _isChatBlocked.value = false
                            showUserMessage("User unblocked")
                            refreshPartners()
                        } else {
                            showUserMessage("Unblock verification failed on backend")
                            dataService.isUserBlocked(partnerId).onSuccess { s ->
                                _chatBlockStatus.value = s
                                _isChatBlocked.value = s.blockedByMe
                            }
                        }
                    }.onFailure { e ->
                        showUserMessage("Unblock verification error: ${e.message}")
                        dataService.isUserBlocked(partnerId).onSuccess { s ->
                            _chatBlockStatus.value = s
                            _isChatBlocked.value = s.blockedByMe
                        }
                    }
                } else {
                    showUserMessage("Unblock request was not acknowledged by backend")
                }
            }.onFailure { e ->
                showUserMessage("Could not unblock user: ${e.message}")
            }
        }
    }

    fun openReportDialog(targetUserId: String, targetUserName: String, targetAvatarUrl: String? = null) {
        _activeReportTarget.value = ActiveReportTarget(targetUserId, targetUserName, targetAvatarUrl)
    }

    fun openReportDialog(reportedUserId: String, targetDisplayName: String) {
        _activeReportTarget.value = ActiveReportTarget(reportedUserId, targetDisplayName, null)
    }

    fun dismissReportDialog() {
        _activeReportTarget.value = null
    }

    fun closeReportDialog() {
        dismissReportDialog()
    }

    fun submitUserReport(category: String, description: String?, callId: String? = null, messageId: String? = null, priority: String = "normal") {
        val target = _activeReportTarget.value ?: return
        _isSubmittingReport.value = true
        viewModelScope.launch {
            val effectiveCallId = callId ?: _activeCall.value?.id
            dataService.submitUserReport(
                reportedUserId = target.targetUserId,
                category = category,
                description = description ?: "",
                callId = effectiveCallId,
                messageId = messageId,
                priority = priority
            )
                .onSuccess {
                    _isSubmittingReport.value = false
                    _activeReportTarget.value = null
                    showUserMessage("Report submitted. Thank you.")
                }
                .onFailure { e ->
                    _isSubmittingReport.value = false
                    showUserMessage("Report failed: ${e.message}")
                }
        }
    }

    // ==========================================
    // UTILS
    // ==========================================

    fun showUserMessage(msg: String) {
        _userMessage.value = msg
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }
}
