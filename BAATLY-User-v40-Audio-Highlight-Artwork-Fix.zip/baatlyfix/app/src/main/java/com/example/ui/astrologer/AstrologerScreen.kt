package com.example.ui.astrologer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val AstroPlum = Color(0xFFF5EEFF)       // bright foreground on the cosmic dark theme
private val AstroCream = Color(0xFF151321)      // dark plum/navy canvas
private val AstroPink = Color(0xFFFF4D91)
private val AstroGold = Color(0xFFFFC86B)
private val AstroLilac = Color(0xFF9B82FF)
private val AstroCard = Color(0xFF211B31)
private val AstroMuted = Color(0xFFB9AEC9)
private val AstroBorder = Color(0xFF463452)

private data class ZodiacSign(val name: String, val glyph: String)

@Composable
fun AstrologerScreen(viewModel: BaatlyViewModel) {
    val signs = remember {
        listOf(
            ZodiacSign("Aries", "♈"), ZodiacSign("Taurus", "♉"), ZodiacSign("Gemini", "♊"),
            ZodiacSign("Cancer", "♋"), ZodiacSign("Leo", "♌"), ZodiacSign("Virgo", "♍"),
            ZodiacSign("Libra", "♎"), ZodiacSign("Scorpio", "♏"), ZodiacSign("Sagittarius", "♐"),
            ZodiacSign("Capricorn", "♑"), ZodiacSign("Aquarius", "♒"), ZodiacSign("Pisces", "♓")
        )
    }
    var selectedZodiac by remember { mutableStateOf("Aries") }
    val selectedGlyph = signs.firstOrNull { it.name == selectedZodiac }?.glyph ?: "♈"

    Column(
        modifier = Modifier.fillMaxSize().background(AstroCream).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("BAATLY", color = AstroPlum, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 0.4.sp)
                Text("A S T R O L O G E R", color = AstroPink, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
            }
            Surface(shape = CircleShape, color = AstroCard, shadowElevation = 2.dp) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = "Astrology", tint = AstroGold, modifier = Modifier.padding(12.dp).size(23.dp))
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Your cosmic guide ✨", color = AstroPlum, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("Explore the moving zodiac and Vedic cosmos.", color = AstroMuted, fontSize = 13.sp, lineHeight = 19.sp)
        }

        AstrologyOrbitArtwork(
            modifier = Modifier.fillMaxWidth().height(226.dp),
            selectedGlyph = selectedGlyph
        )

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = AstroCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, AstroBorder),
            shadowElevation = 1.dp
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF3A263D)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.NightsStay, contentDescription = null, tint = AstroPink, modifier = Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Vedic astrology", color = AstroPlum, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Birth charts and daily guidance are coming soon.", color = AstroMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
                Surface(color = Color(0xFF3B2B37), shape = RoundedCornerShape(9.dp)) {
                    Text("SOON", color = AstroGold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                }
            }
        }

        Text("Choose your zodiac", color = AstroPlum, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            signs.forEach { sign ->
                val active = selectedZodiac == sign.name
                Surface(
                    shape = RoundedCornerShape(17.dp),
                    color = if (active) AstroPink else AstroCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (active) AstroPink else AstroBorder),
                    modifier = Modifier.width(80.dp).clickable { selectedZodiac = sign.name }
                ) {
                    Column(Modifier.padding(vertical = 10.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(sign.glyph, fontSize = 24.sp, color = if (active) Color.White else AstroPlum)
                        Text(sign.name, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (active) Color.White else AstroPlum, maxLines = 1)
                    }
                }
            }
        }

        Text("Astrology services", color = AstroPlum, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        AstroServiceCard("Daily Vedic Horoscope", "Your sign’s daily cosmic outlook.", "SOON") {
            viewModel.showUserMessage("Daily horoscope will be available when the verified astrology engine launches.")
        }
        AstroServiceCard("Birth Chart", "A personal chart built around your birth details.", "SOON") {
            viewModel.showUserMessage("Kundali calculations are being prepared.")
        }
        AstroServiceCard("Compatibility", "Cosmic compatibility for two charts.", "SOON") {
            viewModel.showUserMessage("Kundali Milan is coming soon.")
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun AstrologyOrbitArtwork(modifier: Modifier, selectedGlyph: String) {
    val motion = rememberInfiniteTransition(label = "solar-system-motion")
    val orbitOne by motion.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Restart),
        label = "inner-planet"
    )
    val orbitTwo by motion.animateFloat(
        initialValue = 190f, targetValue = 550f,
        animationSpec = infiniteRepeatable(tween(27000, easing = LinearEasing), RepeatMode.Restart),
        label = "outer-planet"
    )
    val orbitThree by motion.animateFloat(
        initialValue = 80f, targetValue = 440f,
        animationSpec = infiniteRepeatable(tween(34000, easing = LinearEasing), RepeatMode.Restart),
        label = "middle-planet"
    )
    Box(
        modifier.clip(RoundedCornerShape(28.dp)).background(
            Brush.linearGradient(listOf(Color(0xFF171525), Color(0xFF291B3B), Color(0xFF3A2048), Color(0xFF171525)))
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.53f
            val base = min(size.width * 0.145f, size.height * 0.205f)
            val center = Offset(cx, cy)
            // Cosmic haze and subtle stars; all artwork is drawn natively, not a pasted photo.
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0x557F49D8), Color(0x223D2A67), Color.Transparent), center, size.width * 0.54f),
                radius = size.width * 0.54f, center = center
            )
            for (i in 0 until 70) {
                val x = ((i * 73 + 31) % 997) / 997f * size.width
                val y = ((i * 137 + 17) % 991) / 991f * size.height
                val alpha = if (i % 5 == 0) 0.9f else 0.36f
                drawCircle(if (i % 7 == 0) AstroGold.copy(alpha = alpha) else Color.White.copy(alpha = alpha), radius = (if (i % 7 == 0) 1.8f else 1.0f).dp.toPx(), center = Offset(x, y))
            }
            val orbitSpecs = listOf(1.4f to 0.8f, 2.0f to 1.16f, 2.58f to 1.48f)
            orbitSpecs.forEachIndexed { index, pair ->
                val rx = base * pair.first
                val ry = base * pair.second
                drawOval(
                    color = listOf(AstroLilac, AstroPink, AstroGold)[index].copy(alpha = 0.47f),
                    topLeft = Offset(cx - rx, cy - ry), size = Size(rx * 2f, ry * 2f),
                    style = Stroke(width = (1.0f + index * 0.25f).dp.toPx())
                )
            }
            // Glowing sun.
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF2C5), Color(0xFFFFB45F), Color(0xFFFF4E96), Color(0xFF8D43CE)), center, base * 1.45f), base, center)
            drawCircle(Color.White.copy(alpha = 0.48f), base * 0.13f, Offset(cx - base * 0.28f, cy - base * 0.34f))
            val planets = listOf(
                Triple(orbitOne, base * 1.4f, Color(0xFF7BE3FF)),
                Triple(orbitTwo, base * 2.0f, AstroGold),
                Triple(orbitThree, base * 2.58f, Color(0xFFFF75B8))
            )
            planets.forEachIndexed { i, planet ->
                val radians = Math.toRadians(planet.first.toDouble())
                val rx = planet.second
                val ry = when (i) { 0 -> base * 0.8f; 1 -> base * 1.16f; else -> base * 1.48f }
                val pos = Offset(cx + (rx * cos(radians)).toFloat(), cy + (ry * sin(radians)).toFloat())
                drawCircle(planet.third.copy(alpha = 0.25f), radius = (if (i == 1) 11f else 8f).dp.toPx(), center = pos)
                drawCircle(planet.third, radius = (if (i == 1) 5.5f else 4.1f).dp.toPx(), center = pos)
            }
            // Soft zodiac markers around the outer orbit.
            for (i in 0 until 12) {
                val angle = Math.toRadians((i * 30.0 - 90.0).toDouble())
                val x = cx + (base * 2.88f * cos(angle)).toFloat()
                val y = cy + (base * 1.65f * sin(angle)).toFloat()
                drawCircle(if (i % 3 == 0) AstroGold.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.55f), radius = if (i % 3 == 0) 2.5f.dp.toPx() else 1.2f.dp.toPx(), center = Offset(x, y))
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 13.dp),
            color = Color(0xCC20182D), shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
        ) {
            Text("SOLAR SYSTEM  ·  ZODIAC", color = AstroGold, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp))
        }
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
            color = Color(0xEE21172F), shape = CircleShape,
            border = androidx.compose.foundation.BorderStroke(1.dp, AstroPink.copy(alpha = 0.45f))
        ) {
            Text("Selected sign  $selectedGlyph", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 15.dp, vertical = 7.dp))
        }
    }
}

@Composable
private fun AstroServiceCard(title: String, description: String, tag: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = AstroCard,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, AstroBorder)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF3A263D)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.WbSunny, contentDescription = null, tint = AstroPink, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = AstroPlum, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(description, color = AstroMuted, fontSize = 11.sp, lineHeight = 16.sp)
            }
            Text(tag, color = AstroGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}
