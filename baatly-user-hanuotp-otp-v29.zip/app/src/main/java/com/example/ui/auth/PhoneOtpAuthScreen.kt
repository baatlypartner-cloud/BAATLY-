package com.example.ui.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.outlined.AlternateEmail
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BaatlyViewModel
import com.example.ui.theme.*

@Composable
fun AuthScreen(viewModel: BaatlyViewModel) {
    var showLegacyLogin by remember { mutableStateOf(false) }
    if (showLegacyLogin) {
        LegacyAuthScreen(
            viewModel = viewModel,
            allowSignUp = false,
            onUsePhoneOtp = {
                viewModel.clearAuthError()
                showLegacyLogin = false
            }
        )
        return
    }

    var step by remember { mutableStateOf(PhoneOtpStep.PHONE) }
    var mobileNumber by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var userId by remember { mutableStateOf("") }
    var referralCode by remember { mutableStateOf("") }
    var ageConfirmed by remember { mutableStateOf(false) }
    var ageError by remember { mutableStateOf<String?>(null) }

    val authError by viewModel.authError.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()
    val userIdAvailable by viewModel.userIdAvailable.collectAsState()
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    Surface(color = DarkBackground, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(PrimaryGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Chat,
                    contentDescription = "BAATLY",
                    tint = Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "BAATLY",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp,
                    color = TextPrimary
                )
            )
            Text(
                "Real Conversations • Instant Audio Calls",
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
            )
            Spacer(Modifier.height(14.dp))

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DarkSurfaceVariant,
                border = BorderStroke(1.dp, DarkCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        when (step) {
                            PhoneOtpStep.PHONE -> "Continue with your phone"
                            PhoneOtpStep.OTP -> "Verify your phone number"
                            PhoneOtpStep.PROFILE -> "Complete your profile"
                        },
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        when (step) {
                            PhoneOtpStep.PHONE -> "We’ll send you a one-time code by SMS."
                            PhoneOtpStep.OTP -> "Enter the 6-digit code sent to +91 $mobileNumber."
                            PhoneOtpStep.PROFILE -> "Your phone is verified. Choose your public BAATLY User ID."
                        },
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            if (!authError.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DangerRed.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, DangerRed),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = DangerRed)
                        Text(authError.orEmpty(), color = DangerRed, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            when (step) {
                PhoneOtpStep.PHONE -> {
                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = { value ->
                            mobileNumber = value.filter { it.isDigit() }.take(10)
                            viewModel.clearAuthError()
                        },
                        label = { Text("Mobile Number") },
                        prefix = { Text("+91 ", color = TextSecondary) },
                        leadingIcon = { Icon(Icons.Outlined.Phone, contentDescription = null, tint = TextSecondary) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = phoneAuthFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("otp_mobile")
                    )
                    Spacer(Modifier.height(16.dp))
                    PhoneOtpActionButton(
                        text = "SEND OTP",
                        enabled = !isAuthLoading && mobileNumber.matches(Regex("^[6-9][0-9]{9}$")),
                        loading = isAuthLoading,
                        testTag = "btn_send_phone_otp"
                    ) {
                        focusManager.clearFocus()
                        viewModel.sendPhoneOtp(mobileNumber) { sent ->
                            if (sent) {
                                otp = ""
                                viewModel.clearAuthError()
                                step = PhoneOtpStep.OTP
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    TextButton(
                        onClick = {
                            viewModel.clearAuthError()
                            showLegacyLogin = true
                        },
                        modifier = Modifier.testTag("btn_existing_account_login")
                    ) {
                        Text("Existing account? Sign in with User ID & Password", color = VibrantPink)
                    }
                }

                PhoneOtpStep.OTP -> {
                    OutlinedTextField(
                        value = otp,
                        onValueChange = { value ->
                            otp = value.filter { it.isDigit() }.take(6)
                            viewModel.clearAuthError()
                        },
                        label = { Text("6-digit OTP") },
                        leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null, tint = TextSecondary) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = phoneAuthFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("otp_code")
                    )
                    Spacer(Modifier.height(16.dp))
                    PhoneOtpActionButton(
                        text = "VERIFY & CONTINUE",
                        enabled = !isAuthLoading && otp.length == 6,
                        loading = isAuthLoading,
                        testTag = "btn_verify_phone_otp"
                    ) {
                        focusManager.clearFocus()
                        viewModel.verifyPhoneOtp(mobileNumber, otp) { verified, needsProfile ->
                            if (verified && needsProfile) {
                                viewModel.clearAuthError()
                                step = PhoneOtpStep.PROFILE
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = {
                            viewModel.clearAuthError()
                            otp = ""
                            step = PhoneOtpStep.PHONE
                        }) { Text("Change number", color = TextSecondary) }
                        TextButton(
                            enabled = !isAuthLoading,
                            onClick = { viewModel.sendPhoneOtp(mobileNumber) }
                        ) { Text("Resend OTP", color = VibrantPink) }
                    }
                }

                PhoneOtpStep.PROFILE -> {
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(OnlineGreen.copy(alpha = 0.12f)).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = OnlineGreen)
                        Text("Phone verified: +91 $mobileNumber", color = OnlineGreen, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Display Name") },
                        leadingIcon = { Icon(Icons.Outlined.Person, contentDescription = null, tint = TextSecondary) },
                        singleLine = true,
                        colors = phoneAuthFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("otp_signup_display_name")
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = userId,
                        onValueChange = {
                            userId = it.lowercase().trim().filter { ch -> ch.isLetterOrDigit() || ch == '.' || ch == '_' || ch == '-' }.take(30)
                            viewModel.checkUserIdAvailability(userId)
                            viewModel.clearAuthError()
                        },
                        label = { Text("Choose User ID") },
                        supportingText = {
                            Text(
                                when (userIdAvailable) {
                                    true -> "User ID available"
                                    false -> "User ID already taken"
                                    null -> "3–30 characters: letters, numbers, dot, underscore or hyphen"
                                },
                                color = when (userIdAvailable) {
                                    true -> OnlineGreen
                                    false -> DangerRed
                                    null -> TextTertiary
                                }
                            )
                        },
                        trailingIcon = {
                            if (userIdAvailable == true) Icon(Icons.Filled.CheckCircle, contentDescription = "Available", tint = OnlineGreen)
                        },
                        leadingIcon = { Icon(Icons.Outlined.AlternateEmail, contentDescription = null, tint = TextSecondary) },
                        singleLine = true,
                        colors = phoneAuthFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("otp_signup_user_id")
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = referralCode,
                        onValueChange = { referralCode = it.uppercase().take(40) },
                        label = { Text("Referral Code (Optional)") },
                        leadingIcon = { Icon(Icons.Outlined.CardGiftcard, contentDescription = null, tint = SecondaryAmber) },
                        singleLine = true,
                        colors = phoneAuthFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("otp_signup_referral")
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { ageConfirmed = !ageConfirmed; ageError = null }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Checkbox(
                            checked = ageConfirmed,
                            onCheckedChange = { ageConfirmed = it; ageError = null },
                            colors = CheckboxDefaults.colors(checkedColor = VibrantPink)
                        )
                        Text("I confirm that I am 18 years old or older", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                    if (ageError != null) {
                        Text(ageError.orEmpty(), color = DangerRed, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(14.dp))
                    PhoneOtpActionButton(
                        text = "CREATE BAATLY ACCOUNT",
                        enabled = !isAuthLoading && displayName.isNotBlank() && userId.matches(Regex("^[a-z0-9._-]{3,30}$")) && userIdAvailable != false,
                        loading = isAuthLoading,
                        testTag = "btn_complete_phone_signup"
                    ) {
                        focusManager.clearFocus()
                        if (!ageConfirmed) {
                            ageError = "Please confirm that you are 18 years old or older."
                        } else {
                            ageError = null
                            viewModel.completePhoneOtpSignup(userId, displayName, mobileNumber, referralCode)
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                "By continuing, you agree to use BAATLY in accordance with its terms and policies.",
                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            )
        }
    }
}

private enum class PhoneOtpStep { PHONE, OTP, PROFILE }

@Composable
private fun PhoneOtpActionButton(
    text: String,
    enabled: Boolean,
    loading: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (enabled) PrimaryGradient else SolidColor(DarkSurfaceVariant))
            .clickable(enabled = enabled, onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        if (loading) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(23.dp))
        } else {
            Text(
                text,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = if (enabled) Color.White else TextTertiary
            )
        }
    }
}

@Composable
private fun phoneAuthFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = VibrantPink,
    unfocusedBorderColor = DarkCardBorder,
    focusedLabelColor = VibrantPink,
    unfocusedLabelColor = TextSecondary,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    cursorColor = VibrantPink,
    focusedContainerColor = DarkSurface,
    unfocusedContainerColor = DarkSurface
)
