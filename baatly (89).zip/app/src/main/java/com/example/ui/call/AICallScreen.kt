package com.example.ui.call

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@Composable
fun AICallScreen(viewModel: BaatlyViewModel) {
    val context = LocalContext.current
    val host by viewModel.aiCallHost.collectAsState()
    val callState by viewModel.aiCallState.collectAsState()
    val elapsedSeconds by viewModel.aiCallElapsedSeconds.collectAsState()
    val transcript by viewModel.aiCallTranscript.collectAsState()
    val reply by viewModel.aiCallReply.collectAsState()
    val isRecording by viewModel.aiCallIsRecording.collectAsState()
    val isProcessing by viewModel.aiCallIsProcessing.collectAsState()
    val isSpeaking by viewModel.aiCallIsSpeaking.collectAsState()
    val errorMessage by viewModel.aiCallError.collectAsState()

    val resolvedAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(
        host?.avatarUrl,
        viewModel.dataService
    )

    // Permission launcher for microphone
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            viewModel.startAiTurnRecording()
        }
    }

    // Dynamic Pulsing Animation for Speaking/Recording visualizer
    val infiniteTransition = rememberInfiniteTransition(label = "ai_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = when (callState) {
            AiCallUiState.RECORDING -> 1.25f
            AiCallUiState.NEHA_SPEAKING -> 1.20f
            AiCallUiState.PROCESSING -> 1.12f
            else -> 1.05f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (callState) {
                    AiCallUiState.RECORDING -> 700
                    AiCallUiState.NEHA_SPEAKING -> 850
                    AiCallUiState.PROCESSING -> 600
                    else -> 1200
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ai_pulse_scale"
    )

    val hostDisplayName = host?.displayName ?: "Neha"

    Surface(
        color = DarkBackground,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Top Bar: Back / End affordance, Host Info & Demo Call Badge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.endAiCall() },
                        modifier = Modifier.testTag("btn_ai_call_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Leave Call",
                            tint = TextPrimary
                        )
                    }

                    // Free Demo Call Pill Badge
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = PrimaryLavenderContainer.copy(alpha = 0.25f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryLavender.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(OnlineGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "FREE AI DEMO CALL",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = PrimaryLavender,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    letterSpacing = 0.5.sp
                                )
                            )
                        }
                    }

                    // Invisible placeholder to balance top bar layout
                    Spacer(modifier = Modifier.size(48.dp))
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = hostDisplayName,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                val mins = elapsedSeconds / 60
                val secs = elapsedSeconds % 60
                val formattedTime = String.format("%02d:%02d", mins, secs)

                Text(
                    text = formattedTime,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Real-time State Label
                val statusText = when (callState) {
                    AiCallUiState.CONNECTING -> "Connecting to Neha..."
                    AiCallUiState.RECORDING -> "Listening to you... (Hold to speak)"
                    AiCallUiState.PROCESSING -> "Neha is thinking..."
                    AiCallUiState.NEHA_SPEAKING -> "Neha is speaking..."
                    AiCallUiState.LISTENING -> "Tap & hold mic to talk"
                    AiCallUiState.PAUSED -> "Call Paused"
                    AiCallUiState.ENDING, AiCallUiState.ENDED -> "Call Ended"
                    AiCallUiState.ERROR -> "Connection issue"
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when (callState) {
                        AiCallUiState.RECORDING -> Color(0xFFE53935).copy(alpha = 0.15f)
                        AiCallUiState.NEHA_SPEAKING -> PrimaryLavender.copy(alpha = 0.15f)
                        AiCallUiState.PROCESSING -> Color(0xFFFFB300).copy(alpha = 0.15f)
                        else -> DarkSurfaceVariant
                    },
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = when (callState) {
                                AiCallUiState.RECORDING -> Color(0xFFFF6E6E)
                                AiCallUiState.NEHA_SPEAKING -> PrimaryLavender
                                AiCallUiState.PROCESSING -> Color(0xFFFFD54F)
                                else -> TextSecondary
                            },
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }

            // 2. Center: Avatar with animated pulsing halo + Transcripts Card
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .padding(vertical = 12.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(240.dp)
                ) {
                    // Outer decorative pulse halo
                    Box(
                        modifier = Modifier
                            .size(220.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = when (callState) {
                                        AiCallUiState.RECORDING -> listOf(
                                            Color(0xFFE53935).copy(alpha = 0.35f),
                                            Color(0xFFE53935).copy(alpha = 0.05f),
                                            Color.Transparent
                                        )
                                        AiCallUiState.NEHA_SPEAKING -> listOf(
                                            PrimaryLavender.copy(alpha = 0.40f),
                                            PrimaryLavender.copy(alpha = 0.10f),
                                            Color.Transparent
                                        )
                                        AiCallUiState.PROCESSING -> listOf(
                                            Color(0xFFFFB300).copy(alpha = 0.30f),
                                            Color.Transparent
                                        )
                                        else -> listOf(
                                            PrimaryLavender.copy(alpha = 0.15f),
                                            Color.Transparent
                                        )
                                    }
                                )
                            )
                    )

                    // Middle boundary ring
                    Box(
                        modifier = Modifier
                            .size(176.dp)
                            .clip(CircleShape)
                            .border(
                                width = 2.dp,
                                color = when (callState) {
                                    AiCallUiState.RECORDING -> Color(0xFFFF5252).copy(alpha = 0.6f)
                                    AiCallUiState.NEHA_SPEAKING -> PrimaryLavender.copy(alpha = 0.7f)
                                    else -> PrimaryLavender.copy(alpha = 0.3f)
                                },
                                shape = CircleShape
                            )
                    )

                    // Avatar Image
                    Surface(
                        modifier = Modifier
                            .size(160.dp)
                            .clip(CircleShape),
                        color = DarkSurfaceVariant
                    ) {
                        if (!resolvedAvatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = resolvedAvatarUrl,
                                contentDescription = hostDisplayName,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(PrimaryLavenderContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = hostDisplayName.take(1).uppercase(),
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 54.sp
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Error message banner if any
                if (!errorMessage.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFD32F2F).copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD32F2F).copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color(0xFFFF8A80),
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Recent dialogue bubble (User transcript or Neha's reply)
                val displayDialogue = when {
                    callState == AiCallUiState.NEHA_SPEAKING && reply.isNotBlank() -> "Neha: \"$reply\""
                    callState == AiCallUiState.PROCESSING && transcript.isNotBlank() -> "You: \"$transcript\""
                    reply.isNotBlank() -> "Neha: \"$reply\""
                    transcript.isNotBlank() -> "You: \"$transcript\""
                    else -> "Hi! Press and hold the mic to speak to Neha."
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = displayDialogue,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            textAlign = TextAlign.Center
                        ),
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            // 3. Bottom Controls: Push-to-Talk Microphone & End Call Button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left: Push-to-Talk Mic Button
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .scale(if (isRecording) 1.15f else 1.0f)
                            .clip(CircleShape)
                            .background(
                                if (isRecording) {
                                    Color(0xFFE53935)
                                } else if (isProcessing || isSpeaking) {
                                    DarkSurfaceVariant
                                } else {
                                    PrimaryLavender
                                }
                            )
                            .pointerInput(hasMicPermission) {
                                detectTapGestures(
                                    onPress = {
                                        if (!hasMicPermission) {
                                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                            return@detectTapGestures
                                        }

                                        if (isProcessing || isSpeaking) {
                                            return@detectTapGestures
                                        }

                                        val started = viewModel.startAiTurnRecording()
                                        if (started) {
                                            tryAwaitRelease()
                                            viewModel.stopAiTurnRecordingAndSend()
                                        } else {
                                            tryAwaitRelease()
                                        }
                                    }
                                )
                            }
                            .testTag("btn_ai_mic_ptt"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Mic,
                            contentDescription = "Hold to Talk",
                            tint = if (isRecording) Color.White else if (isProcessing || isSpeaking) TextTertiary else Color(0xFF1C1C22),
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    // Right: End Call Button
                    FloatingActionButton(
                        onClick = { viewModel.endAiCall() },
                        containerColor = Color(0xFFD32F2F),
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(68.dp)
                            .testTag("btn_ai_call_end")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CallEnd,
                            contentDescription = "End Call",
                            tint = Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = if (isRecording) "Release to Send" else "Hold Mic to Talk • Tap Red to End",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextTertiary,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 0.3.sp
                    )
                )
            }
        }
    }
}
