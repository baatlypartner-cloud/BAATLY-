package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.GiftItem
import com.example.data.model.PartnerProfile
import com.example.data.model.PublicUserRating
import com.example.data.model.EffectiveUserPricing
import com.example.data.model.MembershipState
import com.example.data.network.AiHostRegistry
import com.example.domain.BillingEngine
import com.example.ui.HomeMode
import com.example.ui.Screen
import com.example.ui.theme.*

@Composable
fun BaatlyTopBar(
    coinBalance: Int,
    onCoinClick: () -> Unit,
    onNotificationClick: () -> Unit,
    unreadNotifications: Int = 0,
    onRefreshClick: (() -> Unit)? = null,
    membershipState: MembershipState? = null,
    onMembershipClick: (() -> Unit)? = null
) {
    Surface(
        color = DarkBackground,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Logo & Title
            Column {
                Text(
                    text = "BAATLY",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = Color.White,
                        fontSize = 22.sp
                    )
                )
                Text(
                    text = "USER APP",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.5.sp,
                        color = PrimaryLavender.copy(alpha = 0.85f),
                        fontSize = 9.sp
                    )
                )
            }

            // Right side: Refresh, Membership VIP Badge, Coins Pill & Notifications
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Top-bar Refresh Button if provided
                if (onRefreshClick != null) {
                    IconButton(
                        onClick = onRefreshClick,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceVariant)
                            .border(1.dp, DarkBorderSubtle, CircleShape)
                            .testTag("btn_topbar_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh",
                            tint = PrimaryLavender,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Membership VIP Pill
                if (onMembershipClick != null) {
                    val isMember = membershipState is MembershipState.Active
                    Surface(
                        shape = CircleShape,
                        color = if (isMember) Color(0xFF2A2210) else DarkSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isMember) Color(0xFFFFD54F) else DarkBorderSubtle
                        ),
                        modifier = Modifier
                            .testTag("topbar_membership_badge")
                            .clickable { onMembershipClick() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "👑",
                                fontSize = 12.sp
                            )
                            Text(
                                text = if (isMember) {
                                    val hours = (membershipState as MembershipState.Active).remainingHours
                                    if (hours > 0) "${hours}h VIP" else "VIP"
                                } else {
                                    "PASS"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMember) Color(0xFFFFD54F) else PrimaryLavender,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }

                // Vibrant Gold Coin Badge
                Surface(
                    shape = CircleShape,
                    color = DarkSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorderSubtle),
                    modifier = Modifier
                        .testTag("coin_balance_badge")
                        .clickable { onCoinClick() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(start = 6.dp, end = 14.dp, top = 5.dp, bottom = 5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(GoldGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MonetizationOn,
                                contentDescription = "Coins",
                                tint = Color(0xFF1B1402),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = "%,d".format(coinBalance),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SecondaryAmber,
                                fontSize = 13.sp
                            )
                        )
                    }
                }

                // Notification Bell
                IconButton(
                    onClick = onNotificationClick,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .border(1.dp, DarkBorderSubtle, CircleShape)
                        .testTag("btn_topbar_notifications")
                ) {
                    Box {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        if (unreadNotifications > 0) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(VibrantPink)
                                    .align(Alignment.TopEnd)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BaatlyBottomNavBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    Surface(
        color = DarkNavBackground,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(top = 10.dp, bottom = 12.dp, start = 4.dp, end = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                title = "HOME",
                icon = Icons.Filled.Home,
                selected = currentScreen == Screen.HOME,
                testTag = "nav_home",
                onClick = { onNavigate(Screen.HOME) }
            )
            BottomNavItem(
                title = "CHAT",
                icon = Icons.AutoMirrored.Filled.Chat,
                selected = currentScreen == Screen.DIRECT_CHAT || currentScreen == Screen.CHAT_LIST,
                testTag = "nav_chat",
                onClick = { onNavigate(Screen.CHAT_LIST) }
            )
            BottomNavItem(
                title = "SOCIAL",
                icon = Icons.Filled.Explore,
                selected = currentScreen == Screen.SOCIAL || currentScreen == Screen.SOCIAL_PROFILE,
                testTag = "nav_social",
                onClick = { onNavigate(Screen.SOCIAL) }
            )
            BottomNavItem(
                title = "RECENT",
                icon = Icons.Filled.Call,
                selected = currentScreen == Screen.RECENT_CALLS,
                testTag = "nav_recent_calls",
                onClick = { onNavigate(Screen.RECENT_CALLS) }
            )
            BottomNavItem(
                title = "PROFILE",
                icon = Icons.Filled.Person,
                selected = currentScreen == Screen.PROFILE,
                testTag = "nav_profile",
                onClick = { onNavigate(Screen.PROFILE) }
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (selected) VibrantPink else Color.White.copy(alpha = 0.4f),
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (selected) VibrantPink else Color.White.copy(alpha = 0.4f),
                fontSize = 10.sp,
                letterSpacing = 0.5.sp
            )
        )
    }
}

// =========================================================================
// Centralized Profile Avatar & Authenticated Media Resolvers
// =========================================================================
@Composable
fun rememberResolvedProfileImageUrl(
    rawPathOrUrl: String?,
    dataService: com.example.data.network.SupabaseDataService?
): State<String?> {
    val resolvedState = remember(rawPathOrUrl) { mutableStateOf<String?>(null) }
    LaunchedEffect(rawPathOrUrl, dataService) {
        if (rawPathOrUrl.isNullOrBlank() || rawPathOrUrl == "null") {
            resolvedState.value = null
        } else if (dataService != null) {
            val resolved = dataService.resolveProfileAvatarUrl(rawPathOrUrl)
            resolvedState.value = resolved.takeIf { it.isNotBlank() } ?: rawPathOrUrl
        } else {
            resolvedState.value = rawPathOrUrl
        }
    }
    return resolvedState
}

@Composable
fun ProfileAvatar(
    rawPathOrUrl: String?,
    displayName: String?,
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = CircleShape,
    fallbackGradient: Brush = HostAvatarGradient,
    fontSize: androidx.compose.ui.unit.TextUnit = 20.sp,
    dataService: com.example.data.network.SupabaseDataService? = null,
    onClick: (() -> Unit)? = null
) {
    val resolvedUrl by rememberResolvedProfileImageUrl(rawPathOrUrl, dataService)
    val isResolving = !rawPathOrUrl.isNullOrBlank() && rawPathOrUrl != "null" && resolvedUrl == null && dataService != null

    Box(
        modifier = modifier
            .clip(shape)
            .background(fallbackGradient)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        contentAlignment = Alignment.Center
    ) {
        if (!resolvedUrl.isNullOrBlank()) {
            AsyncImage(
                model = resolvedUrl,
                contentDescription = displayName ?: "Avatar",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else if (isResolving) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                color = PrimaryLavender,
                strokeWidth = 2.dp
            )
        } else {
            val initial = (displayName?.trim()?.take(1) ?: "H").uppercase()
            Text(
                text = initial,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = fontSize
                )
            )
        }
    }
}

@Composable
fun HostCard(
    partner: PartnerProfile,
    homeMode: HomeMode,
    onCardClick: () -> Unit,
    onActionClick: () -> Unit,
    onFollowClick: () -> Unit,
    dataService: com.example.data.network.SupabaseDataService? = null,
    effectivePricing: EffectiveUserPricing = EffectiveUserPricing.DEFAULT_NON_MEMBER,
    publicRating: PublicUserRating? = null
) {
    val resolvedAvatarUrl by rememberResolvedProfileImageUrl(partner.avatarUrl, dataService)
    val isResolving = !partner.avatarUrl.isNullOrBlank() && partner.avatarUrl != "null" && resolvedAvatarUrl == null && dataService != null

    Card(
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Host Avatar (Squircle 72dp) with online badge
            Box(
                modifier = Modifier.size(72.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(HostAvatarGradient),
                    contentAlignment = Alignment.Center
                ) {
                    if (!resolvedAvatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAvatarUrl,
                            contentDescription = partner.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (isResolving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = PrimaryLavender,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Text(
                            text = (partner.displayName?.take(1) ?: "H").uppercase(),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 28.sp
                            )
                        )
                    }
                }

                if (partner.isOnline) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(DarkBackground)
                            .align(Alignment.BottomEnd),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(OnlineGreen)
                        )
                    }
                }
            }

            // Info Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                // Name & Rating Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = partner.displayName ?: "Baatly Host",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    val realRating = publicRating
                    val legacyRating = partner.rating ?: 0.0
                    val hasRating = realRating != null && realRating.hasRatings && realRating.rating != null
                    val ratingDisplay = if (hasRating) {
                        val score = String.format(java.util.Locale.US, "%.1f", realRating!!.rating)
                        if (realRating.totalRatings > 0) "★ $score (${realRating.totalRatings})" else "★ $score"
                    } else if (legacyRating > 0.0) {
                        "★ ${String.format(java.util.Locale.US, "%.1f", legacyRating)}"
                    } else {
                        "No ratings yet"
                    }

                    Surface(
                        shape = CircleShape,
                        color = if (hasRating || legacyRating > 0.0) SecondaryAmber.copy(alpha = 0.15f) else DarkSurfaceVariant.copy(alpha = 0.6f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (hasRating || legacyRating > 0.0) SecondaryAmber.copy(alpha = 0.35f) else DarkCardBorder
                        )
                    ) {
                        Text(
                            text = ratingDisplay,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (hasRating || legacyRating > 0.0) SecondaryAmber else TextSecondary,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }

                    val isAi = AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)
                    if (isAi) {
                        Surface(
                            shape = CircleShape,
                            color = PrimaryLavender.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryLavender.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "FREE DEMO",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryLavender,
                                    fontSize = 9.sp
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Bio
                if (!partner.bio.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = partner.bio,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontSize = 12.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Stats: Age & Followers
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (partner.age != null && partner.age > 0) {
                        Column {
                            Text(
                                text = "AGE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    color = TextTertiary
                                )
                            )
                            Text(
                                text = "${partner.age}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    fontSize = 13.sp
                                )
                            )
                        }
                    }

                    Column {
                        Text(
                            text = "FOLLOWERS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp,
                                color = TextTertiary
                            )
                        )
                        Text(
                            text = "${partner.followersCount}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                fontSize = 13.sp
                            )
                        )
                    }
                }
            }

            // Quick Call/Chat Action CTA Button + Rate
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onActionClick,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(PrimaryGradient)
                        .testTag("btn_host_action_${partner.id}")
                ) {
                    Icon(
                        imageVector = if (homeMode == HomeMode.CALL) Icons.Filled.Call else Icons.AutoMirrored.Filled.Chat,
                        contentDescription = if (homeMode == HomeMode.CALL) "Call Host" else "Chat Host",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                val isAi = AiHostRegistry.isAiHost(partner.id) || AiHostRegistry.isAiHost(partner.userId)
                if (!isAi) {
                    if (homeMode == HomeMode.CALL) {
                        Text(
                            text = if (effectivePricing.isMember) "3c/min" else "6c/min",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = if (effectivePricing.isMember) FontWeight.Bold else FontWeight.Normal,
                                color = if (effectivePricing.isMember) Color(0xFFFFD54F) else TextSecondary
                            )
                        )
                    } else {
                        Text(
                            text = if (effectivePricing.isMember) "1c/msg" else "3c/msg",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = if (effectivePricing.isMember) FontWeight.Bold else FontWeight.Normal,
                                color = if (effectivePricing.isMember) Color(0xFFFFD54F) else TextSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GiftAnimationOverlay(gift: GiftItem) {
    val infiniteTransition = rememberInfiniteTransition(label = "gift_anim")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.scale(scale)
        ) {
            Surface(
                shape = CircleShape,
                color = DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(3.dp, SecondaryAmber),
                modifier = Modifier.size(120.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (!gift.iconUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = gift.iconUrl,
                            contentDescription = gift.name,
                            modifier = Modifier.size(80.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.CardGiftcard,
                            contentDescription = gift.name,
                            tint = SecondaryAmber,
                            modifier = Modifier.size(60.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Sent ${gift.name}!",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = SecondaryAmberLight
                )
            )
        }
    }
}
