package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.ActiveReportTarget
import com.example.data.model.PendingRatingCall
import com.example.data.model.PublicUserRating
import com.example.ui.theme.*

/**
 * Clean, modern badge displaying real public rating from backend.
 * Never hardcoded. Shows "No ratings yet" when no rating exists.
 */
@Composable
fun PublicRatingBadge(
    rating: PublicUserRating?,
    modifier: Modifier = Modifier,
    showCount: Boolean = true
) {
    val hasRatings = rating != null && rating.hasRatings && rating.rating != null
    val displayText = if (hasRatings) {
        val score = String.format(java.util.Locale.US, "%.1f", rating!!.rating)
        if (showCount && rating.totalRatings > 0) {
            "★ $score (${rating.totalRatings})"
        } else {
            "★ $score"
        }
    } else {
        "No ratings yet"
    }

    Surface(
        shape = CircleShape,
        color = if (hasRatings) SecondaryAmber.copy(alpha = 0.15f) else DarkSurfaceVariant.copy(alpha = 0.7f),
        border = BorderStroke(
            1.dp,
            if (hasRatings) SecondaryAmber.copy(alpha = 0.35f) else DarkCardBorder
        ),
        modifier = modifier.testTag("public_rating_badge")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                text = displayText,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = if (hasRatings) SecondaryAmber else TextSecondary,
                    fontSize = 11.sp
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Call-End Rating Dialog
 * Triggers ONLY after a completed call.
 * Verified via get_call_rating_eligibility(call_id).
 */
@Composable
fun CallRatingDialog(
    pendingCall: PendingRatingCall,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (rating: Int, reviewText: String?) -> Unit
) {
    var selectedRating by remember { mutableIntStateOf(0) }
    var reviewText by remember { mutableStateOf("") }

    val partnerName = pendingCall.partner?.displayName?.takeIf { it.isNotBlank() }
        ?: if (pendingCall.isRatingHost) "Host" else "User"

    val ratingLabel = when (selectedRating) {
        1 -> "Poor"
        2 -> "Fair"
        3 -> "Good"
        4 -> "Very Good"
        5 -> "Excellent"
        else -> "Tap a star to rate"
    }

    Dialog(
        onDismissRequest = {
            if (!isSubmitting) onDismiss()
        },
        properties = DialogProperties(
            dismissOnBackPress = !isSubmitting,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = DarkCard,
            border = BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .testTag("dialog_call_rating")
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Partner Avatar
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(HostAvatarGradient)
                        .border(2.dp, PrimaryLavender, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (!pendingCall.partner?.avatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = pendingCall.partner!!.avatarUrl,
                            contentDescription = partnerName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text(
                            text = partnerName.take(1).uppercase(),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Title
                Text(
                    text = "How was your experience?",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Rate your call with $partnerName",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // 5 Interactive Stars
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (star in 1..5) {
                        val isFilled = star <= selectedRating
                        IconButton(
                            onClick = {
                                if (!isSubmitting) selectedRating = star
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .testTag("star_rating_$star")
                        ) {
                            Icon(
                                imageVector = if (isFilled) Icons.Filled.Star else Icons.Outlined.StarOutline,
                                contentDescription = "$star Stars",
                                tint = if (isFilled) SecondaryAmber else TextSecondary.copy(alpha = 0.45f),
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Dynamic Rating Feedback
                Text(
                    text = ratingLabel,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = if (selectedRating > 0) SecondaryAmber else TextMuted
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Optional Review Text Field
                OutlinedTextField(
                    value = reviewText,
                    onValueChange = { if (it.length <= 300) reviewText = it },
                    placeholder = {
                        Text(
                            text = "Write a review (optional)...",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_rating_review"),
                    maxLines = 3,
                    minLines = 2,
                    enabled = !isSubmitting,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                        unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                        focusedBorderColor = PrimaryLavender,
                        unfocusedBorderColor = DarkCardBorder
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting,
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("btn_dismiss_rating")
                    ) {
                        Text(
                            text = "Not Now",
                            color = TextSecondary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = {
                            if (selectedRating in 1..5 && !isSubmitting) {
                                onSubmit(selectedRating, reviewText)
                            }
                        },
                        enabled = selectedRating in 1..5 && !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryLavender,
                            contentColor = Color.Black,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMuted
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(46.dp)
                            .testTag("btn_submit_rating")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.Black,
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            Text(
                                text = "Submit Rating",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Polished Report User/Host Dialog
 * Submits via authoritative submit_user_report RPC.
 * Never inserts directly into database tables.
 */
@Composable
fun ReportUserDialog(
    target: ActiveReportTarget,
    isSubmitting: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (category: String, description: String?) -> Unit
) {
    val categories = listOf(
        "Harassment",
        "Inappropriate Behavior",
        "Spam",
        "Scam/Fraud",
        "Abusive Content",
        "Other"
    )

    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var description by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = {
            if (!isSubmitting) onDismiss()
        },
        properties = DialogProperties(
            dismissOnBackPress = !isSubmitting,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = DarkCard,
            border = BorderStroke(1.dp, DarkCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
                .testTag("dialog_report_user")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Flag,
                            contentDescription = "Report",
                            tint = DangerRed,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "Report User",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Help us understand what happened with ${target.targetDisplayName}. Your report is confidential.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        fontSize = 12.sp
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Category Selection
                Text(
                    text = "SELECT A REASON *",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        fontSize = 11.sp
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { category ->
                        val isSelected = selectedCategory == category
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) PrimaryLavender.copy(alpha = 0.15f) else DarkSurfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) PrimaryLavender else DarkCardBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isSubmitting) {
                                    selectedCategory = category
                                }
                                .testTag("category_option_$category")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = category,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = if (isSelected) PrimaryLavender else TextPrimary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp
                                    )
                                )
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { if (!isSubmitting) selectedCategory = category },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = PrimaryLavender,
                                        unselectedColor = TextSecondary.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Optional Description
                Text(
                    text = "DESCRIPTION (OPTIONAL)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextMuted,
                        fontSize = 11.sp
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { if (it.length <= 500) description = it },
                    placeholder = {
                        Text(
                            text = "Provide additional details (optional)...",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_report_description"),
                    maxLines = 3,
                    minLines = 2,
                    enabled = !isSubmitting,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                        unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.5f),
                        focusedBorderColor = PrimaryLavender,
                        unfocusedBorderColor = DarkCardBorder
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("btn_cancel_report")
                    ) {
                        Text(
                            text = "Cancel",
                            color = TextSecondary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = {
                            val cat = selectedCategory
                            if (!cat.isNullOrBlank() && !isSubmitting) {
                                onSubmit(cat, description)
                            }
                        },
                        enabled = !selectedCategory.isNullOrBlank() && !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DangerRed,
                            contentColor = Color.White,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMuted
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.4f)
                            .height(44.dp)
                            .testTag("btn_submit_report")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "Submit Report",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
