package com.example.ui.call

enum class AiCallUiState {
    CONNECTING,
    LISTENING,
    RECORDING,
    PROCESSING,
    NEHA_SPEAKING,
    PAUSED,
    ENDING,
    ENDED,
    ERROR
}
