package com.example.ui.legal

object LegalContentData {

    const val SUPPORT_EMAIL = "baatly672@gmail.com"
    const val LAST_UPDATED_DATE = "08/08/2026"

    fun getContent(page: LegalPage): LegalPageContent {
        return when (page) {
            LegalPage.ABOUT_BAATLY -> aboutBaatlyContent
            LegalPage.SAFETY_SECURITY -> safetySecurityContent
            LegalPage.REFUND_CANCELLATION -> refundCancellationContent
            LegalPage.TERMS_CONDITIONS -> termsConditionsContent
            LegalPage.PRIVACY_POLICY -> privacyPolicyContent
        }
    }

    private val aboutBaatlyContent = LegalPageContent(
        page = LegalPage.ABOUT_BAATLY,
        openingText = "Baatly is a social communication platform created to make it easier for people to discover new connections, enjoy conversations and share moments in a safe and respectful environment.\n\nBaatly allows users to connect with Listeners through supported communication features and enjoy social experiences within the platform.",
        sections = listOf(
            LegalSection(
                heading = "Talk & Connect",
                intro = "Discover available Listeners and start one-to-one conversations through Baatly's supported chat and calling features."
            ),
            LegalSection(
                heading = "Voice & Video Conversations",
                intro = "Connect with Listeners through supported voice and video calling features and enjoy real-time conversations."
            ),
            LegalSection(
                heading = "Social",
                intro = "Discover posts and stories shared by the Baatly community.\n\nSocial content may be moderated before or after publication to help maintain a safe environment."
            ),
            LegalSection(
                heading = "Virtual Gifting",
                intro = "Users can send supported virtual gifts to Listeners using Baatly Coins during eligible interactions."
            ),
            LegalSection(
                heading = "Baatly Coins",
                intro = "Baatly Coins are virtual in-app credits that can be purchased through supported payment methods and used for eligible Baatly features.\n\nCoins are digital in-app credits and are not cash, currency, investments or deposits."
            ),
            LegalSection(
                heading = "Safety First",
                intro = "Baatly works continuously to maintain a respectful and safe platform through:",
                bullets = listOf(
                    "Content moderation",
                    "User reporting",
                    "Blocking tools",
                    "Fraud and abuse prevention",
                    "Account security measures",
                    "Community Guidelines",
                    "Investigation of reported violations"
                )
            ),
            LegalSection(
                heading = "What We Don't Allow",
                intro = "Baatly does not permit:",
                bullets = listOf(
                    "Sexual or pornographic content",
                    "Exploitation",
                    "Fraud or scams",
                    "Harassment",
                    "Impersonation",
                    "Illegal activities",
                    "Abuse",
                    "Malicious activity",
                    "Attempts to misuse the payment system"
                )
            ),
            LegalSection(
                heading = "Our Mission",
                intro = "Our mission is simple:\n\nMake conversations easier, connections better and online interactions safer.\n\nBaatly is built for people who want to communicate, discover and enjoy meaningful social interactions while respecting the people they connect with."
            )
        ),
        closingText = "Baatly\nBetter conversations. Better connections."
    )

    private val safetySecurityContent = LegalPageContent(
        page = LegalPage.SAFETY_SECURITY,
        openingText = "Safety comes first at Baatly.\n\nEvery person using Baatly is expected to behave respectfully and follow these guidelines.",
        sections = listOf(
            LegalSection(
                heading = "1. Sexual & Explicit Content",
                intro = "Baatly does not allow:",
                bullets = listOf(
                    "Pornographic content",
                    "Sexually explicit images or videos",
                    "Sexual exploitation",
                    "Explicit sexual solicitation",
                    "Content involving sexual abuse",
                    "Sexual content involving minors"
                ),
                outro = "Any content involving the sexual exploitation of minors is strictly prohibited and may be reported to appropriate authorities where legally required."
            ),
            LegalSection(
                heading = "2. Fraud & Scams",
                intro = "Do not use Baatly to:",
                bullets = listOf(
                    "Scam another user",
                    "Request money through deception",
                    "Promote fake investments",
                    "Send fraudulent payment requests",
                    "Pretend to be a Baatly employee",
                    "Manipulate users into making unauthorized payments",
                    "Collect money outside approved Baatly payment methods for Baatly services"
                )
            ),
            LegalSection(
                heading = "Payment Safety",
                intro = "Baatly will never ask you for:",
                bullets = listOf(
                    "OTP",
                    "UPI PIN",
                    "ATM PIN",
                    "Card PIN",
                    "Password"
                ),
                outro = "Never share these with another person."
            ),
            LegalSection(
                heading = "3. Harassment & Abuse",
                intro = "Do not:",
                bullets = listOf(
                    "Threaten another person",
                    "Bully or intimidate users",
                    "Repeatedly contact someone who does not want contact",
                    "Send abusive messages",
                    "Stalk another user",
                    "Encourage violence or harm"
                )
            ),
            LegalSection(
                heading = "4. Impersonation",
                intro = "Do not pretend to be:",
                bullets = listOf(
                    "Another user",
                    "A Listener",
                    "A Baatly employee",
                    "A Baatly administrator",
                    "Another public or private individual"
                )
            ),
            LegalSection(
                heading = "5. Illegal & Harmful Activities",
                intro = "Baatly cannot be used to facilitate illegal activities or distribute content that violates applicable law."
            ),
            LegalSection(
                heading = "6. Fake or Misleading Information",
                intro = "Do not deliberately create misleading profiles or provide false information for the purpose of:",
                bullets = listOf(
                    "Fraud",
                    "Impersonation",
                    "Financial deception",
                    "Evading safety controls",
                    "Abusing another person's identity"
                )
            ),
            LegalSection(
                heading = "7. Social Content",
                intro = "Users must only upload content they have the right to share.\n\nBaatly may remove or restrict posts, stories, comments or other content that violates our rules.\n\nContent may be reviewed using automated safety systems and/or human moderation."
            ),
            LegalSection(
                heading = "8. Report & Block",
                intro = "If you see something that violates Baatly's rules:\n\nReport → Select a reason → Submit\n\nUsers may also use the available Block feature to prevent unwanted interaction.\n\nReports may be reviewed by Baatly's safety and moderation systems."
            ),
            LegalSection(
                heading = "9. Enforcement",
                intro = "Depending on the violation, Baatly may:",
                bullets = listOf(
                    "Remove content",
                    "Restrict posting",
                    "Restrict chat",
                    "Restrict calls",
                    "Restrict other features",
                    "Suspend an account",
                    "Permanently terminate an account",
                    "Take other appropriate safety or legal action"
                ),
                outro = "Serious violations may result in immediate action."
            ),
            LegalSection(
                heading = "10. Account Security",
                intro = "Keep your account credentials secure.\n\nIf you believe someone has accessed your account without permission, contact Baatly Support immediately."
            )
        ),
        closingText = "Be respectful. Stay safe. Never share sensitive information."
    )

    private val refundCancellationContent = LegalPageContent(
        page = LegalPage.REFUND_CANCELLATION,
        openingText = null,
        sections = listOf(
            LegalSection(
                heading = "Please read before purchasing Coins",
                intro = "Baatly uses virtual Coins for eligible in-app features.\n\nBefore completing a purchase, users should review the package, price and applicable terms shown in the payment flow."
            ),
            LegalSection(
                heading = "1. Coin Purchases",
                intro = "Baatly Coins are digital in-app credits.\n\nOnce a Coin purchase has been successfully completed and the Coins have been credited to the user's account, the purchase is generally non-refundable, except where a refund is required by applicable law or approved by Baatly under its policies."
            ),
            LegalSection(
                heading = "2. Payment Deducted but Coins Not Received",
                intro = "If money is deducted from your payment method but Coins are not credited:\n\nDo not purchase the same package repeatedly.\n\nContact Baatly Support with:",
                bullets = listOf(
                    "User ID",
                    "Transaction/reference ID",
                    "Payment amount",
                    "Date and time",
                    "Screenshot/transaction proof, if available"
                ),
                outro = "Baatly will verify the payment status with the relevant payment infrastructure."
            ),
            LegalSection(
                heading = "3. Duplicate Payment",
                intro = "If the same purchase was charged more than once, contact Support.\n\nAfter verification, Baatly may process the appropriate correction or refund where applicable."
            ),
            LegalSection(
                heading = "4. Coins Already Used",
                intro = "Coins already used for completed eligible services or interactions, including:",
                bullets = listOf(
                    "Chat",
                    "Calls",
                    "Virtual gifts",
                    "Other paid Baatly features"
                ),
                outro = "are generally not refundable."
            ),
            LegalSection(
                heading = "5. Technical Failure",
                intro = "If a paid interaction fails because of a confirmed technical issue attributable to Baatly, Support may investigate the transaction.\n\nWhere appropriate, Baatly may restore the affected Coins or provide another suitable resolution according to the circumstances and applicable law."
            ),
            LegalSection(
                heading = "6. Account Suspension",
                intro = "If an account is suspended or terminated because of fraud, abuse or violation of Baatly rules, the suspension itself does not automatically create a refund entitlement.\n\nAny refund will be considered according to the relevant transaction, applicable policy and applicable law."
            ),
            LegalSection(
                heading = "7. Unauthorized Transaction",
                intro = "If you believe someone made a transaction using your account without authorization, contact Baatly Support immediately.\n\nNever send your OTP, UPI PIN, Card PIN or Password to anyone claiming to be Baatly Support."
            ),
            LegalSection(
                heading = "8. Cancellation",
                intro = "A completed digital Coin purchase generally cannot be cancelled after the Coins have been successfully credited, except where applicable law or Baatly's specific decision provides otherwise."
            ),
            LegalSection(
                heading = "9. Refund & Payment Support",
                intro = "Support Email: $SUPPORT_EMAIL\n\nInclude your User ID and transaction/reference ID."
            )
        ),
        closingText = "Nothing in this policy is intended to remove any consumer right or legal remedy that cannot lawfully be excluded."
    )

    private val termsConditionsContent = LegalPageContent(
        page = LegalPage.TERMS_CONDITIONS,
        openingText = "By creating an account or using Baatly, you agree to these Terms & Conditions, Privacy Policy, Refund & Cancellation Policy and Community Guidelines.",
        sections = listOf(
            LegalSection(
                heading = "1. Using Baatly",
                intro = "Baatly provides social communication and related in-app services.\n\nDepending on availability, Baatly may provide:",
                bullets = listOf(
                    "One-to-one chat",
                    "Voice calls",
                    "Video calls",
                    "Social posts",
                    "Stories",
                    "Virtual gifts",
                    "Virtual Coins",
                    "Other social and communication features"
                ),
                outro = "Features may change, be temporarily unavailable or be discontinued."
            ),
            LegalSection(
                heading = "2. Account Responsibility",
                intro = "You are responsible for your account and activity.\n\nYou must:",
                bullets = listOf(
                    "Provide accurate information",
                    "Keep your account secure",
                    "Protect your login credentials",
                    "Use the platform lawfully",
                    "Follow Baatly's rules"
                ),
                outro = "You must not allow another person to misuse your account."
            ),
            LegalSection(
                heading = "3. Users & Listeners",
                intro = "Baatly connects Users with Listeners through supported platform features.\n\nBaatly does not guarantee:",
                bullets = listOf(
                    "That a particular Listener will always be available",
                    "A particular response or interaction",
                    "A particular duration of availability",
                    "Any personal or emotional outcome from an interaction"
                )
            ),
            LegalSection(
                heading = "4. Baatly Coins",
                intro = "Baatly Coins are virtual in-app credits.\n\nCoins:",
                bullets = listOf(
                    "Are not legal tender",
                    "Are not bank deposits",
                    "Are not investments",
                    "Do not represent ownership in Baatly",
                    "Have no independent cash value outside Baatly",
                    "Cannot normally be withdrawn as cash by ordinary Users",
                    "May only be used for supported Baatly features"
                )
            ),
            LegalSection(
                heading = "5. Payments",
                intro = "Coin purchases must be made through Baatly's supported payment flow.\n\nA payment is considered successful only after Baatly receives and/or validates the appropriate transaction status from its payment infrastructure."
            ),
            LegalSection(
                heading = "6. Virtual Gifts",
                intro = "Users may use eligible Coins to send virtual gifts to Listeners through supported features.\n\nVirtual gifts are digital in-app items and do not represent physical goods."
            ),
            LegalSection(
                heading = "7. Social Content",
                intro = "Users may upload permitted content to Baatly.\n\nUsers must have the necessary rights to upload the content.\n\nUsers must not upload prohibited or unlawful material.\n\nBaatly may moderate, restrict or remove content that violates its policies."
            ),
            LegalSection(
                heading = "8. Prohibited Activities",
                intro = "Users must not use Baatly for:",
                bullets = listOf(
                    "Fraud",
                    "Scams",
                    "Sexual exploitation",
                    "Pornographic content",
                    "Harassment",
                    "Impersonation",
                    "Illegal activities",
                    "Unauthorized payment collection",
                    "Account theft",
                    "Malicious activity",
                    "Circumventing safety systems",
                    "Any activity prohibited by applicable law"
                )
            ),
            LegalSection(
                heading = "9. Safety & Moderation",
                intro = "Baatly may use automated systems and human review to identify potentially harmful or prohibited content and behavior.\n\nBaatly may take action when necessary to protect users, platform security or legal compliance."
            ),
            LegalSection(
                heading = "10. Reporting",
                intro = "Users can report content or behavior through available reporting tools.\n\nBaatly may investigate reports and take appropriate action."
            ),
            LegalSection(
                heading = "11. Account Suspension",
                intro = "Baatly may suspend or terminate accounts where reasonably necessary for:",
                bullets = listOf(
                    "Safety",
                    "Fraud prevention",
                    "Security",
                    "Policy enforcement",
                    "Legal compliance",
                    "Serious or repeated violations"
                )
            ),
            LegalSection(
                heading = "12. Third-Party Services",
                intro = "Baatly may use third-party providers for services such as:",
                bullets = listOf(
                    "Payments",
                    "Authentication",
                    "Cloud infrastructure",
                    "Notifications",
                    "Communication technology",
                    "Security",
                    "Analytics"
                ),
                outro = "Use of certain third-party services may also be subject to their own terms."
            ),
            LegalSection(
                heading = "13. Service Availability",
                intro = "Baatly aims to provide reliable service but does not guarantee uninterrupted or error-free operation.\n\nService may be temporarily affected by maintenance, network problems, technical failures, third-party outages, security incidents or events beyond reasonable control."
            ),
            LegalSection(
                heading = "14. Changes to Baatly",
                intro = "Baatly may modify its features, pricing, services or policies as the platform develops.\n\nWhere required, users will receive appropriate notice."
            ),
            LegalSection(
                heading = "15. Contact",
                intro = "Baatly Support:\n$SUPPORT_EMAIL"
            )
        ),
        closingText = null
    )

    private val privacyPolicyContent = LegalPageContent(
        page = LegalPage.PRIVACY_POLICY,
        openingText = "This Privacy Policy explains how Baatly may collect, use, store and protect information when you use the Baatly application and related services.",
        sections = listOf(
            LegalSection(
                heading = "1. Information We May Collect",
                intro = "Depending on the features you use, Baatly may process:\n\nAccount Information:",
                bullets = listOf(
                    "Name/display name",
                    "User ID",
                    "Mobile number",
                    "Account identifiers"
                ),
                outro = null
            ),
            LegalSection(
                heading = "Profile Information",
                intro = null,
                bullets = listOf(
                    "Profile photo",
                    "Bio",
                    "Other information you choose to provide"
                )
            ),
            LegalSection(
                heading = "Social Information",
                intro = null,
                bullets = listOf(
                    "Posts",
                    "Stories",
                    "Likes",
                    "Comments",
                    "Reports",
                    "Moderation records"
                )
            ),
            LegalSection(
                heading = "Communication Information",
                intro = "Depending on the feature and technical implementation, this may include information required to provide:",
                bullets = listOf(
                    "Chat",
                    "Voice calls",
                    "Video calls",
                    "Communication-related services"
                )
            ),
            LegalSection(
                heading = "Payment Information",
                intro = "Baatly may process information such as:",
                bullets = listOf(
                    "Transaction ID",
                    "Payment status",
                    "Amount",
                    "Coin package purchased",
                    "Coin transaction history",
                    "Refund/transaction status"
                ),
                outro = "Payment providers may separately process payment information according to their own policies."
            ),
            LegalSection(
                heading = "Technical Information",
                intro = "Baatly may process technical information needed to operate and secure the service, such as:",
                bullets = listOf(
                    "Device information",
                    "App version",
                    "IP/network information where collected",
                    "Diagnostic logs",
                    "Notification/push token",
                    "Security-related information"
                )
            ),
            LegalSection(
                heading = "2. How We Use Information",
                intro = "Information may be used to:",
                bullets = listOf(
                    "Create and manage accounts",
                    "Provide Baatly services",
                    "Enable chat and calls",
                    "Process Coin purchases",
                    "Maintain Coin balances",
                    "Process virtual gifts",
                    "Provide social features",
                    "Moderate content",
                    "Prevent fraud",
                    "Protect accounts",
                    "Detect abuse",
                    "Send service notifications",
                    "Provide customer support",
                    "Troubleshoot technical problems",
                    "Improve the platform",
                    "Meet legal and regulatory obligations"
                )
            ),
            LegalSection(
                heading = "3. Payments",
                intro = "Payments may be processed through third-party payment providers.\n\nBaatly may receive transaction information necessary to verify payments and provide purchased digital services.\n\nBaatly should not request or store your UPI PIN, ATM PIN, card PIN or other secret payment credentials."
            ),
            LegalSection(
                heading = "4. Social Content & Moderation",
                intro = "Content uploaded to Baatly may be processed for safety and moderation purposes.\n\nBaatly may use automated tools and/or human review to detect content that may violate Community Guidelines."
            ),
            LegalSection(
                heading = "5. Data Security",
                intro = "Baatly uses reasonable technical and organizational measures intended to protect personal information against unauthorized access, misuse, alteration, loss or disclosure.\n\nHowever, no online service can guarantee absolute security."
            ),
            LegalSection(
                heading = "6. Sharing Information",
                intro = "Information may be shared with service providers when reasonably necessary to operate Baatly, including providers supporting:",
                bullets = listOf(
                    "Cloud/database infrastructure",
                    "Authentication",
                    "Payments",
                    "Communication",
                    "Notifications",
                    "Security",
                    "Moderation",
                    "Analytics",
                    "Customer support"
                ),
                outro = "Information may also be disclosed where required or permitted by applicable law."
            ),
            LegalSection(
                heading = "7. Data Retention",
                intro = "Information may be retained for as long as reasonably necessary for:",
                bullets = listOf(
                    "Providing the service",
                    "Account management",
                    "Security",
                    "Fraud prevention",
                    "Transaction records",
                    "Dispute resolution",
                    "Legal obligations"
                ),
                outro = "Different categories of information may have different retention periods."
            ),
            LegalSection(
                heading = "8. Account Deletion",
                intro = "Users may request deletion of their Baatly account directly within the app under Profile > Delete Account.\n\nAccount deletion is permanent once your request is processed. Certain information may need to be retained where required or permitted for legitimate legal, security, fraud-prevention or financial-record purposes."
            ),
            LegalSection(
                heading = "9. Privacy Requests",
                intro = "Depending on applicable law, users may have rights concerning their personal information, including applicable rights relating to:",
                bullets = listOf(
                    "Access",
                    "Correction",
                    "Deletion",
                    "Consent withdrawal",
                    "Grievance handling"
                ),
                outro = "Requests can be made through the designated Baatly privacy/support channel."
            ),
            LegalSection(
                heading = "10. Children's Safety",
                intro = "Baatly is intended only for users who satisfy the applicable minimum age requirements.\n\nBaatly does not permit sexual content involving minors under any circumstances.\n\nBaatly may take appropriate action against accounts or content that violate age or child-safety requirements."
            ),
            LegalSection(
                heading = "11. Privacy & Grievance Contact",
                intro = "Privacy and Support Email:\n$SUPPORT_EMAIL"
            ),
            LegalSection(
                heading = "12. Policy Updates",
                intro = "Baatly may update this Privacy Policy when its services, technology, data practices or applicable legal requirements change.\n\nThe latest version will be made available through Baatly's application and/or website."
            )
        ),
        closingText = null
    )
}
