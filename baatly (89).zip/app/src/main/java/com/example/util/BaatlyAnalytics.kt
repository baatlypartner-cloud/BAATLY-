package com.example.util

import android.util.Log

object BaatlyAnalytics {
    private const val TAG = "BaatlyAnalytics"

    fun logEvent(eventName: String, params: Map<String, Any?> = emptyMap()) {
        val safeParams = params.filterKeys { key ->
            val lower = key.lowercase()
            !lower.contains("secret") && !lower.contains("key") && !lower.contains("token") && !lower.contains("password")
        }
        Log.i(TAG, "Event: $eventName | Params: $safeParams")
    }

    fun logMembershipScreenOpened(userId: String?, isMember: Boolean) {
        logEvent("membership_screen_opened", mapOf("user_id" to userId, "is_member" to isMember))
    }

    fun logMembershipPurchaseStarted(userId: String?, planId: String, priceInr: Double) {
        logEvent("membership_purchase_started", mapOf("user_id" to userId, "plan_id" to planId, "price_inr" to priceInr))
    }

    fun logMembershipPaymentCreated(paymentId: String, tenantOrderRef: String) {
        logEvent("membership_payment_created", mapOf("payment_id" to paymentId, "tenant_order_ref" to tenantOrderRef))
    }

    fun logMembershipCheckoutOpened(paymentId: String) {
        logEvent("membership_checkout_opened", mapOf("payment_id" to paymentId))
    }

    fun logMembershipPaymentVerified(paymentId: String, success: Boolean, status: String) {
        logEvent("membership_payment_verified", mapOf("payment_id" to paymentId, "success" to success, "status" to status))
    }

    fun logMembershipActivated(userId: String?, planId: String?, expiresAt: String?) {
        logEvent("membership_activated", mapOf("user_id" to userId, "plan_id" to planId, "expires_at" to expiresAt))
    }

    fun logMembershipPaymentFailed(paymentId: String?, reason: String) {
        logEvent("membership_payment_failed", mapOf("payment_id" to paymentId, "reason" to reason))
    }

    fun logMembershipExpired(userId: String?) {
        logEvent("membership_expired", mapOf("user_id" to userId))
    }
}
