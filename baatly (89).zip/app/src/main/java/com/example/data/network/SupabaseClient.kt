package com.example.data.network

import com.example.data.local.SessionManager
import com.example.data.model.SessionResult
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class SupabaseClient(private val sessionManager: SessionManager) {

    val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val refreshMutex = Mutex()

    private fun getBaseHeaders(url: String = "", tokenOverride: String? = null): Map<String, String> {
        val headers = mutableMapOf(
            "apikey" to SupabaseConfig.publishableKey,
            "Content-Type" to "application/json"
        )
        val isAuthEndpoint = url.contains("/auth/v1/token") || url.contains("/auth/v1/signup")
        val token = tokenOverride ?: sessionManager.accessToken.value
        if (!token.isNullOrBlank() && !isAuthEndpoint) {
            headers["Authorization"] = "Bearer $token"
        }
        return headers
    }

    suspend fun performTokenRefresh(staleToken: String? = null): SessionResult = withContext(Dispatchers.IO) {
        // Fast path: If caller passed a stale token and SessionManager already has a newer valid token, return it immediately
        val currentTokenBeforeLock = sessionManager.accessToken.value
        val currentUserIdBeforeLock = sessionManager.userId.value ?: ""
        if (staleToken != null && !currentTokenBeforeLock.isNullOrBlank() && currentTokenBeforeLock != staleToken &&
            !sessionManager.isTokenExpiredOrNearExpiry(currentTokenBeforeLock, bufferSeconds = 60)) {
            android.util.Log.d("SupabaseClient", "performTokenRefresh: SessionManager already has newer valid token. Skipping network refresh.")
            return@withContext SessionResult.Valid(currentTokenBeforeLock, currentUserIdBeforeLock)
        }

        refreshMutex.withLock {
            // Re-check state inside the lock to ensure single-flight execution
            val currentToken = sessionManager.accessToken.value
            val currentUserId = sessionManager.userId.value ?: ""

            // If another coroutine already completed the refresh while we waited for the lock:
            if (staleToken != null && !currentToken.isNullOrBlank() && currentToken != staleToken &&
                !sessionManager.isTokenExpiredOrNearExpiry(currentToken, bufferSeconds = 60)) {
                android.util.Log.d("SupabaseClient", "performTokenRefresh: Token was already refreshed by another coroutine.")
                return@withLock SessionResult.Valid(currentToken, currentUserId)
            }
            if (staleToken == null && !currentToken.isNullOrBlank() && !sessionManager.isTokenExpiredOrNearExpiry(currentToken, bufferSeconds = 60)) {
                android.util.Log.d("SupabaseClient", "performTokenRefresh: Current token is already valid and not near expiry.")
                return@withLock SessionResult.Valid(currentToken, currentUserId)
            }

            val currentRefresh = sessionManager.refreshToken.value
            if (currentRefresh.isNullOrBlank()) {
                android.util.Log.w("SupabaseClient", "performTokenRefresh: No refresh token present in SessionManager.")
                return@withLock SessionResult.AuthRequired("No active session found. Please sign in.")
            }

            android.util.Log.d("SupabaseClient", "performTokenRefresh: Executing single-flight refresh request to Supabase Auth...")
            try {
                val refreshUrl = "${SupabaseConfig.supabaseUrl}/auth/v1/token?grant_type=refresh_token"
                val body = JSONObject().apply { put("refresh_token", currentRefresh) }
                val request = Request.Builder()
                    .url(refreshUrl)
                    .addHeader("apikey", SupabaseConfig.publishableKey)
                    .addHeader("Content-Type", "application/json")
                    .post(body.toString().toRequestBody(jsonMediaType))
                    .build()

                val response = okHttpClient.newCall(request).execute()
                val respBody = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val json = JSONObject(respBody)
                    val newAccessToken = json.optString("access_token")
                    val newRefreshToken = json.optString("refresh_token").takeIf { it.isNotBlank() } ?: currentRefresh
                    val userId = json.optJSONObject("user")?.optString("id")
                        ?: json.optString("id").takeIf { it.isNotBlank() }
                        ?: sessionManager.userId.value
                        ?: ""
                    if (newAccessToken.isNotBlank() && userId.isNotBlank()) {
                        // Atomic update of both access and refresh tokens
                        sessionManager.saveSession(newAccessToken, userId, refreshToken = newRefreshToken)
                        android.util.Log.d("SupabaseClient", "Token refresh succeeded. Session updated atomically.")
                        SessionResult.Valid(newAccessToken, userId)
                    } else {
                        android.util.Log.e("SupabaseClient", "Unexpected response payload from auth refresh: $respBody")
                        SessionResult.ServerError("Unexpected response format from auth server.")
                    }
                } else {
                    android.util.Log.w("SupabaseClient", "Token refresh response code: ${response.code}, body: $respBody")
                    val lower = respBody.lowercase()

                    // Check if another concurrent refresh succeeded in parallel
                    val latestTokenNow = sessionManager.accessToken.value
                    if (!latestTokenNow.isNullOrBlank() && latestTokenNow != staleToken && latestTokenNow != currentToken &&
                        !sessionManager.isTokenExpiredOrNearExpiry(latestTokenNow, bufferSeconds = 60)) {
                        android.util.Log.d("SupabaseClient", "Refresh request returned ${response.code} but newer valid token found in SessionManager. Recovering.")
                        return@withLock SessionResult.Valid(latestTokenNow, sessionManager.userId.value ?: "")
                    }

                    // Strict classification of refresh failures:
                    // Only treat as permanently invalid if it is 400/401 AND explicitly indicates revoked/invalid grant
                    // AND SessionManager hasn't been updated concurrently.
                    val isDefinitivelyRevoked = (response.code == 400 || response.code == 401) &&
                        (lower.contains("token has been revoked") ||
                         lower.contains("user_not_found") ||
                         lower.contains("user not found") ||
                         (lower.contains("invalid_grant") && !lower.contains("already used")) ||
                         lower.contains("invalid refresh token: not found"))

                    if (isDefinitivelyRevoked) {
                        android.util.Log.w("SupabaseClient", "Refresh token is definitively invalid/revoked. Clearing session.")
                        sessionManager.clearSession()
                        SessionResult.AuthRequired("Your session has expired. Please sign in again.")
                    } else if (response.code in 400..499) {
                        // Transient 4xx or rotation race without definitive revocation - do NOT wipe session
                        android.util.Log.w("SupabaseClient", "Refresh returned client error ${response.code}. Preserving session.")
                        SessionResult.ServerError("Authentication service temporarily unavailable. Please try again.")
                    } else {
                        // 5xx or gateway errors - do NOT wipe session
                        android.util.Log.w("SupabaseClient", "Refresh returned server error ${response.code}. Preserving session.")
                        SessionResult.ServerError("Authentication service temporarily unavailable. Please try again.")
                    }
                }
            } catch (e: java.io.IOException) {
                android.util.Log.e("SupabaseClient", "Network error during token refresh: ${e.message}", e)
                SessionResult.NetworkError("Connection problem. Please check your internet connection and try again.")
            } catch (e: Exception) {
                android.util.Log.e("SupabaseClient", "Unexpected error during token refresh: ${e.message}", e)
                SessionResult.ServerError("Unable to refresh session right now. Please try again.")
            }
        }
    }

    suspend fun ensureValidSession(): SessionResult {
        val currentToken = sessionManager.accessToken.value
        val userId = sessionManager.userId.value ?: ""
        val isExpiredOrNear = sessionManager.isTokenExpiredOrNearExpiry(currentToken, bufferSeconds = 60)
        if (!currentToken.isNullOrBlank() && !isExpiredOrNear) {
            return SessionResult.Valid(currentToken, userId)
        }
        return performTokenRefresh(staleToken = currentToken)
    }

    private suspend fun executeWithAuthRetry(
        url: String,
        buildRequest: (token: String?) -> Request
    ): Response = withContext(Dispatchers.IO) {
        val isAuthEndpoint = url.contains("/auth/v1/token") || url.contains("/auth/v1/signup")
        val initialToken = sessionManager.accessToken.value
        var request = buildRequest(initialToken)
        var response = okHttpClient.newCall(request).execute()

        if (response.code == 401 && !isAuthEndpoint) {
            val currentToken = sessionManager.accessToken.value
            // 1. If the token in SessionManager is already newer than the one used in initial request:
            if (!currentToken.isNullOrBlank() && currentToken != initialToken) {
                android.util.Log.d("SupabaseClient", "Token was updated concurrently. Retrying with newer token immediately...")
                request = buildRequest(currentToken)
                response = okHttpClient.newCall(request).execute()
            }
            // 2. If still 401, perform single-flight synchronized refresh
            if (response.code == 401) {
                val latestStaleToken = sessionManager.accessToken.value
                android.util.Log.d("SupabaseClient", "Received 401 on $url. Performing single-flight token refresh...")
                val refreshResult = performTokenRefresh(staleToken = latestStaleToken)
                when (refreshResult) {
                    is SessionResult.Valid -> {
                        android.util.Log.d("SupabaseClient", "Token refreshed successfully. Retrying request once...")
                        request = buildRequest(refreshResult.accessToken)
                        response = okHttpClient.newCall(request).execute()
                    }
                    is SessionResult.NetworkError -> {
                        throw java.io.IOException(refreshResult.message)
                    }
                    is SessionResult.ServerError -> {
                        throw SupabaseException(refreshResult.message, 500, "")
                    }
                    is SessionResult.AuthRequired -> {
                        throw SupabaseException(refreshResult.message, 401, "unauthorized")
                    }
                }
            }
        }
        response
    }

    suspend fun get(url: String, params: Map<String, String> = emptyMap()): String = withContext(Dispatchers.IO) {
        val urlBuilder = StringBuilder(url)
        if (params.isNotEmpty()) {
            urlBuilder.append(if (url.contains("?")) "&" else "?")
            params.entries.forEachIndexed { index, entry ->
                if (index > 0) urlBuilder.append("&")
                urlBuilder.append(entry.key).append("=").append(entry.value)
            }
        }
        val fullUrl = urlBuilder.toString()
        val response = executeWithAuthRetry(fullUrl) { token ->
            val requestBuilder = Request.Builder().url(fullUrl)
            getBaseHeaders(fullUrl, token).forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            requestBuilder.build()
        }
        handleResponse(response, fullUrl)
    }

    suspend fun post(
        url: String,
        jsonBody: String = "{}",
        extraHeaders: Map<String, String> = emptyMap()
    ): String = withContext(Dispatchers.IO) {
        val requestBody = jsonBody.toRequestBody(jsonMediaType)
        val response = executeWithAuthRetry(url) { token ->
            val requestBuilder = Request.Builder().url(url).post(requestBody)
            getBaseHeaders(url, token).forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            extraHeaders.forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            requestBuilder.build()
        }
        handleResponse(response, url)
    }

    suspend fun patch(url: String, jsonBody: String = "{}"): String = withContext(Dispatchers.IO) {
        val requestBody = jsonBody.toRequestBody(jsonMediaType)
        val response = executeWithAuthRetry(url) { token ->
            val requestBuilder = Request.Builder().url(url).patch(requestBody)
            getBaseHeaders(url, token).forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            requestBuilder.addHeader("Prefer", "return=representation")
            requestBuilder.build()
        }
        handleResponse(response, url)
    }

    suspend fun rpc(rpcName: String, params: Map<String, Any?> = emptyMap()): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/rest/v1/rpc/$rpcName"
        val jsonObject = JSONObject()
        params.forEach { (k, v) ->
            if (v == null) {
                jsonObject.put(k, JSONObject.NULL)
            } else {
                jsonObject.put(k, v)
            }
        }
        val requestBody = jsonObject.toString().toRequestBody(jsonMediaType)
        val response = executeWithAuthRetry(url) { token ->
            val requestBuilder = Request.Builder().url(url).post(requestBody)
            getBaseHeaders(url, token).forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            requestBuilder.build()
        }
        handleResponse(response, url)
    }

    suspend fun callEdgeFunction(functionName: String, jsonBody: String = "{}"): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/functions/v1/$functionName"
        val requestBody = jsonBody.toRequestBody(jsonMediaType)
        val response = executeWithAuthRetry(url) { token ->
            val requestBuilder = Request.Builder().url(url).post(requestBody)
            getBaseHeaders(url, token).forEach { (k, v) -> requestBuilder.addHeader(k, v) }
            requestBuilder.build()
        }
        handleResponse(response, url)
    }

    suspend fun uploadFile(bucket: String, path: String, file: File, mimeType: String): String = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/storage/v1/object/$bucket/$path"
        val response = executeWithAuthRetry(url) { token ->
            val requestBody = RequestBody.create(mimeType.toMediaType(), file)
            val requestBuilder = Request.Builder()
                .url(url)
                .post(requestBody)
            getBaseHeaders(url, token).forEach { (k, v) ->
                if (k != "Content-Type") {
                    requestBuilder.addHeader(k, v)
                }
            }
            requestBuilder.addHeader("Content-Type", mimeType)
            requestBuilder.build()
        }
        if (response.isSuccessful) {
            "$bucket/$path"
        } else {
            handleResponse(response, url)
        }
    }

    suspend fun deleteStorageObject(bucket: String, path: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
            val url = "${SupabaseConfig.supabaseUrl}/storage/v1/object/$bucket/$cleanPath"
            val response = executeWithAuthRetry(url) { token ->
                val requestBuilder = Request.Builder().url(url).delete()
                getBaseHeaders(url, token).forEach { (k, v) -> requestBuilder.addHeader(k, v) }
                requestBuilder.build()
            }
            response.isSuccessful
        } catch (e: Exception) {
            android.util.Log.e("SupabaseClient", "deleteStorageObject failed for $bucket/$path: ${e.message}", e)
            false
        }
    }

    suspend fun createSignedUrl(bucket: String, path: String, expiresInSeconds: Int = 3600): String = withContext(Dispatchers.IO) {
        val cleanPath = path.removePrefix("$bucket/").removePrefix("/")
        val url = "${SupabaseConfig.supabaseUrl}/storage/v1/object/sign/$bucket/$cleanPath"
        val payload = JSONObject().apply { put("expiresIn", expiresInSeconds) }
        val responseStr = post(url, payload.toString())
        val json = JSONObject(responseStr)
        val signedUrlPath = json.optString("signedURL").ifBlank {
            json.optString("signedUrl").ifBlank {
                json.optString("url", "")
            }
        }
        if (signedUrlPath.isBlank()) {
            throw SupabaseException("Empty signedURL returned from Supabase storage sign for $bucket/$cleanPath", 500, responseStr)
        }
        val fullUrl = when {
            signedUrlPath.startsWith("http://") || signedUrlPath.startsWith("https://") -> signedUrlPath
            signedUrlPath.startsWith("/storage/v1/") -> "${SupabaseConfig.supabaseUrl}$signedUrlPath"
            signedUrlPath.startsWith("/") -> "${SupabaseConfig.supabaseUrl}/storage/v1$signedUrlPath"
            else -> "${SupabaseConfig.supabaseUrl}/storage/v1/$signedUrlPath"
        }
        fullUrl
    }

    private fun handleResponse(response: Response, url: String = ""): String {
        val responseBody = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            val userFriendlyError = parseFriendlyError(response.code, responseBody, url)
            throw SupabaseException(userFriendlyError, response.code, responseBody)
        }
        return responseBody
    }

    private fun parseFriendlyError(code: Int, body: String, url: String = ""): String {
        val lower = body.lowercase()
        val isLoginAuth = url.contains("/auth/v1/token") && !url.contains("grant_type=refresh_token")
        val isAuthUrl = url.contains("/auth/v1/")

        // Try to parse structured backend JSON error message first
        val jsonError = try {
            if (body.isNotBlank()) {
                val json = JSONObject(body)
                val msg = json.optString("error").takeIf { it.isNotBlank() }
                    ?: json.optString("message").takeIf { it.isNotBlank() }
                    ?: json.optString("error_description").takeIf { it.isNotBlank() }
                    ?: json.optString("msg").takeIf { it.isNotBlank() }
                    ?: json.optString("details").takeIf { it.isNotBlank() }
                msg
            } else null
        } catch (_: Exception) {
            null
        }

        return when {
            (isLoginAuth && (code == 400 || code == 401 || lower.contains("invalid login") || lower.contains("invalid_credentials"))) ->
                "Invalid User ID or Password. Please check your credentials."
            (isAuthUrl && (code == 401 || lower.contains("jwt expired") || lower.contains("token expired") || lower.contains("invalid token") || lower.contains("invalid jwt") || lower.contains("session expired"))) ->
                "Your session has expired. Please sign in again."
            code == 401 && (lower.contains("jwt expired") || lower.contains("token expired") || lower.contains("invalid_jwt") || lower.contains("jwt signature is invalid")) ->
                "Your session has expired. Please sign in again."
            lower.contains("user_id already exists") || (lower.contains("duplicate key") && lower.contains("user_id")) ->
                "This User ID is already taken."
            lower.contains("invalid referral code") || lower.contains("referral code not found") ->
                "Invalid referral code."
            lower.contains("insufficient") || lower.contains("not enough coins") || lower.contains("balance") ->
                "You don't have enough coins."
            lower.contains("host is not available") || lower.contains("partner not online") ->
                "This host is not available right now."
            lower.contains("blocked") || lower.contains("cannot message") ->
                "You cannot message this host."
            (lower.contains("duplicate key") && lower.contains("mobile_number")) || lower.contains("mobile_number already exists") ->
                "This mobile number is already registered."
            lower.contains("contact_sharing_violation") || lower.contains("number_sharing_violation") ->
                "Number or contact-sharing content is not allowed."
            // Payment specific errors:
            lower.contains("payment not found") ->
                "Payment not found. Please try initiating the purchase again."
            lower.contains("coin package not found") || lower.contains("package not found") ->
                "This coin package is no longer available. Please select another package."
            lower.contains("payment is not available for checkout") ->
                "This payment is no longer available for checkout. Please start a new purchase."
            lower.contains("belongs to another payment") ->
                "Payment reference conflict. Please try again."
            lower.contains("unable to validate coin package") ->
                "Unable to validate coin package with server."
            lower.contains("uropay unavailable") ->
                "Payment gateway is currently unavailable. Please try again in a moment."
            !jsonError.isNullOrBlank() -> jsonError
            code == 404 -> "Requested item not found."
            code >= 500 -> "Server temporarily busy. Please try again."
            else -> "Operation failed. Please try again."
        }
    }
}

class SupabaseException(
    override val message: String,
    val statusCode: Int,
    val rawBody: String
) : Exception(message)

