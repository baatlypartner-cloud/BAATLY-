package com.example.data.network

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class AiChatResponse(
    val conversationId: String?,
    val hostId: String?,
    val hostName: String?,
    val reply: String,
    val sendPhoto: Boolean = false,
    val photoUrl: String? = null,
    val photoId: String? = null,
    val photoRequestCount: Int? = null,
    val trialMetadata: Map<String, Any?> = emptyMap(),
    val rawJson: JSONObject? = null
)

/**
 * Isolated service for communicating with the deployed Supabase Edge Function "ai-chat".
 * Uses the authenticated user's session from SupabaseClient (Bearer token added automatically).
 */
class AiChatService(private val client: SupabaseClient) {

    companion object {
        private const val TAG = "BaatlySecurity"
        private const val EDGE_FUNCTION_NAME = "ai-chat"
    }

    suspend fun sendMessage(
        hostId: String,
        message: String,
        conversationId: String? = null
    ): Result<AiChatResponse> = withContext(Dispatchers.IO) {
        return@withContext try {
            val reqJson = JSONObject().apply {
                put("host_id", hostId)
                put("message", message)
                if (!conversationId.isNullOrBlank()) {
                    put("conversation_id", conversationId)
                }
            }

            Log.d(TAG, "[AI_CHAT] sending message to host: $hostId (length: ${message.length})")

            val responseBody = client.callEdgeFunction(EDGE_FUNCTION_NAME, reqJson.toString())
            Log.d(TAG, "[AI_CHAT] received response (length: ${responseBody.length})")

            val json = JSONObject(responseBody)

            val parsedConvId = listOf(
                json.optString("conversation_id"),
                json.optString("conversationId"),
                json.optString("id")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: conversationId

            Log.d(TAG, "[AI_CHAT] conversation_id: $parsedConvId")

            val parsedHostId = listOf(
                json.optString("host_id"),
                json.optString("hostId")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: hostId

            val parsedHostName = listOf(
                json.optString("host_name"),
                json.optString("hostName"),
                json.optString("name")
            ).firstOrNull { it.isNotBlank() && it != "null" }

            val replyText = listOf(
                json.optString("reply"),
                json.optString("message"),
                json.optString("content"),
                json.optString("response"),
                json.optString("text"),
                json.optString("ai_reply")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

            val trialMap = mutableMapOf<String, Any?>()
            val trialObj = json.optJSONObject("trial") ?: json.optJSONObject("trial_metadata")
            trialObj?.let {
                it.keys().forEach { key ->
                    trialMap[key] = it.opt(key)
                }
            }

            if (replyText.isBlank() && json.has("error")) {
                val errorMsg = json.optString("error", "AI host is currently unavailable.")
                return@withContext Result.failure(Exception(errorMsg))
            }

            val parsedSendPhoto = listOf("send_photo", "sendPhoto", "is_photo", "photo").any { key ->
                if (json.has(key)) {
                    val v = json.opt(key)
                    v == true || v == 1 || v.toString().equals("true", ignoreCase = true)
                } else false
            }

            val parsedPhotoUrl = listOf(
                json.optString("photo_url"),
                json.optString("photoUrl"),
                json.optString("image_url"),
                json.optString("imageUrl"),
                json.optString("media_url"),
                json.optString("mediaUrl")
            ).firstOrNull { it.isNotBlank() && it != "null" }

            val parsedPhotoId = listOf(
                json.optString("photo_id"),
                json.optString("photoId")
            ).firstOrNull { it.isNotBlank() && it != "null" }

            val parsedPhotoRequestCount = if (json.has("photo_request_count")) {
                json.optInt("photo_request_count")
            } else if (json.has("photoRequestCount")) {
                json.optInt("photoRequestCount")
            } else {
                null
            }

            Log.d(TAG, "[AI_CHAT] send_photo: $parsedSendPhoto, photo_url: $parsedPhotoUrl, photo_id: $parsedPhotoId, photo_request_count: $parsedPhotoRequestCount")

            Result.success(
                AiChatResponse(
                    conversationId = parsedConvId,
                    hostId = parsedHostId,
                    hostName = parsedHostName,
                    reply = replyText,
                    sendPhoto = parsedSendPhoto,
                    photoUrl = parsedPhotoUrl,
                    photoId = parsedPhotoId,
                    photoRequestCount = parsedPhotoRequestCount,
                    trialMetadata = trialMap,
                    rawJson = json
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error during AI chat edge function invocation: ${e.message}")
            Result.failure(e)
        }
    }
}
