package com.example.data.network

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

data class AiCallStartResponse(
    val sessionId: String,
    val hostId: String,
    val hostName: String?,
    val voiceId: String = "ritu",
    val language: String? = null,
    val memory: String? = null,
    val status: String = "active"
)

data class AiCallTurnResponse(
    val sessionId: String,
    val turnNo: Int = 1,
    val transcript: String = "",
    val reply: String = "",
    val voiceId: String = "ritu",
    val audioBase64: String? = null,
    val audioMimeType: String = "audio/mpeg"
)

data class AiCallEndResponse(
    val sessionId: String,
    val status: String = "ended",
    val durationSeconds: Int = 0,
    val turnCount: Int = 0
)

/**
 * Dedicated service for interacting with Supabase Edge Functions for AI Host Voice Calls:
 * 1. ai-call-start
 * 2. ai-call-turn
 * 3. ai-call-end
 *
 * All provider communication (Groq Whisper, GPT-OSS 120B, Sarvam Bulbul v3 TTS) happens
 * inside the server-side Supabase Edge Functions. No API keys or service role keys exist client-side.
 */
class AiCallService(private val client: SupabaseClient) {

    companion object {
        private const val TAG = "BaatlyAiCall"
        private const val FUNCTION_START = "ai-call-start"
        private const val FUNCTION_TURN = "ai-call-turn"
        private const val FUNCTION_END = "ai-call-end"
    }

    suspend fun startCall(hostId: String): Result<AiCallStartResponse> = withContext(Dispatchers.IO) {
        return@withContext try {
            val reqJson = JSONObject().apply {
                put("host_id", hostId)
            }

            Log.d(TAG, "[AI_CALL] Starting call with host: $hostId")
            val responseBody = client.callEdgeFunction(FUNCTION_START, reqJson.toString())
            Log.d(TAG, "[AI_CALL] ai-call-start response length: ${responseBody.length}")

            val json = JSONObject(responseBody)
            if (json.has("error") && !json.has("session_id")) {
                val errorMsg = json.optString("error", "Failed to start AI call session.")
                return@withContext Result.failure(Exception(errorMsg))
            }

            val sessionId = listOf(
                json.optString("session_id"),
                json.optString("sessionId"),
                json.optString("id")
            ).firstOrNull { it.isNotBlank() && it != "null" }
                ?: return@withContext Result.failure(Exception("No session_id returned by ai-call-start"))

            val returnedHostId = listOf(
                json.optString("host_id"),
                json.optString("hostId")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: hostId

            val hostName = listOf(
                json.optString("host_name"),
                json.optString("hostName"),
                json.optString("name")
            ).firstOrNull { it.isNotBlank() && it != "null" }

            val voiceId = listOf(
                json.optString("voice_id"),
                json.optString("voiceId")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: "ritu"

            val status = json.optString("status", "active")
            val language = json.optString("language", "hi-Hinglish")
            val memory = json.optString("memory", "")

            Result.success(
                AiCallStartResponse(
                    sessionId = sessionId,
                    hostId = returnedHostId,
                    hostName = hostName,
                    voiceId = voiceId,
                    language = language,
                    memory = memory,
                    status = status
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "[AI_CALL] Error starting AI call: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun sendAudioTurn(
        sessionId: String,
        hostId: String,
        audioFile: File,
        mimeType: String = "audio/mp4"
    ): Result<AiCallTurnResponse> = withContext(Dispatchers.IO) {
        return@withContext try {
            if (!audioFile.exists() || audioFile.length() == 0L) {
                return@withContext Result.failure(Exception("Audio file is empty or missing."))
            }

            val fileBytes = audioFile.readBytes()
            val audioBase64 = Base64.encodeToString(fileBytes, Base64.NO_WRAP)

            val reqJson = JSONObject().apply {
                put("session_id", sessionId)
                put("host_id", hostId)
                put("audio_base64", audioBase64)
                put("mime_type", mimeType)
            }

            Log.d(TAG, "[AI_CALL] Sending audio turn for session: $sessionId (bytes: ${fileBytes.size}, mime: $mimeType)")
            val responseBody = client.callEdgeFunction(FUNCTION_TURN, reqJson.toString())
            Log.d(TAG, "[AI_CALL] ai-call-turn response length: ${responseBody.length}")

            val json = JSONObject(responseBody)
            if (json.has("error") && !json.has("reply") && !json.has("audio_base64")) {
                val errorMsg = json.optString("error", "AI could not process your turn.")
                return@withContext Result.failure(Exception(errorMsg))
            }

            val returnedSessionId = json.optString("session_id", sessionId)
            val turnNo = json.optInt("turn_no", 1)
            val transcript = listOf(
                json.optString("transcript"),
                json.optString("user_transcript"),
                json.optString("text")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

            val reply = listOf(
                json.optString("reply"),
                json.optString("response"),
                json.optString("ai_reply"),
                json.optString("content")
            ).firstOrNull { it.isNotBlank() && it != "null" } ?: ""

            val voiceId = json.optString("voice_id", "ritu")

            val base64Audio = listOf(
                json.optString("audio_base64"),
                json.optString("audio"),
                json.optString("audioContent")
            ).firstOrNull { it.isNotBlank() && it != "null" }

            val audioMimeType = json.optString("audio_mime_type", "audio/mpeg")

            Result.success(
                AiCallTurnResponse(
                    sessionId = returnedSessionId,
                    turnNo = turnNo,
                    transcript = transcript,
                    reply = reply,
                    voiceId = voiceId,
                    audioBase64 = base64Audio,
                    audioMimeType = audioMimeType
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "[AI_CALL] Error during turn exchange: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun endCall(sessionId: String): Result<AiCallEndResponse> = withContext(Dispatchers.IO) {
        return@withContext try {
            val reqJson = JSONObject().apply {
                put("session_id", sessionId)
            }

            Log.d(TAG, "[AI_CALL] Ending AI call session: $sessionId")
            val responseBody = client.callEdgeFunction(FUNCTION_END, reqJson.toString())
            Log.d(TAG, "[AI_CALL] ai-call-end response length: ${responseBody.length}")

            val json = JSONObject(responseBody)
            val returnedSessionId = json.optString("session_id", sessionId)
            val status = json.optString("status", "ended")
            val durationSeconds = json.optInt("duration_seconds", 0)
            val turnCount = json.optInt("turn_count", 0)

            Result.success(
                AiCallEndResponse(
                    sessionId = returnedSessionId,
                    status = status,
                    durationSeconds = durationSeconds,
                    turnCount = turnCount
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "[AI_CALL] Error ending AI call: ${e.message}", e)
            Result.failure(e)
        }
    }
}
