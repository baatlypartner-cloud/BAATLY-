package com.example.data.network

import com.example.BuildConfig

object SupabaseConfig {
    const val DEFAULT_SUPABASE_URL = "https://qewhxsbrnlgunygghpez.supabase.co"
    const val DEFAULT_PUBLISHABLE_KEY = "sb_publishable_X05JHyvFNsJLfQ7k2iFp0w_ezNwN8Jj"
    const val DEFAULT_AGORA_APP_ID = "82771d17f30f40b09cb1790e9afc1e3f"

    val supabaseUrl: String
        get() = try {
            val key = BuildConfig.SUPABASE_URL
            if (key.isNullOrBlank()) DEFAULT_SUPABASE_URL else key
        } catch (_: Exception) {
            DEFAULT_SUPABASE_URL
        }

    val publishableKey: String
        get() = try {
            val key = BuildConfig.SUPABASE_PUBLISHABLE_KEY
            if (key.isNullOrBlank()) DEFAULT_PUBLISHABLE_KEY else key
        } catch (_: Exception) {
            DEFAULT_PUBLISHABLE_KEY
        }

    val agoraAppId: String
        get() = try {
            val key = BuildConfig.AGORA_APP_ID
            if (key.isNullOrBlank()) DEFAULT_AGORA_APP_ID else key
        } catch (_: Exception) {
            DEFAULT_AGORA_APP_ID
        }

    const val BUCKET_GIFT_MEDIA = "gift-media"
    const val BUCKET_PROFILE_MEDIA = "profile-media"
    const val BUCKET_CHAT_MEDIA = "chat-media"
    const val BUCKET_SOCIAL_MEDIA = "social-media"
    const val BUCKET_AI_HOST_MEDIA = "ai-host-media"

    fun getInternalAuthEmail(userId: String): String {
        val normalized = userId.trim().lowercase()
        return "$normalized@auth.baatly.app"
    }
}
