package com.example.data.network

import java.util.concurrent.ConcurrentHashMap

/**
 * Isolated registry and helper for identifying AI hosts across the application.
 * Manages an in-memory set of AI host IDs loaded from the isolated ai_hosts table,
 * initialized with Neha's canonical UUID.
 */
object AiHostRegistry {
    const val NEHA_HOST_ID = "53a82224-97a0-4df7-b3ef-e8b65c06dfdb"

    private val aiHostIds = ConcurrentHashMap.newKeySet<String>().apply {
        add(NEHA_HOST_ID)
    }

    /**
     * Registers an AI host ID (and userId if applicable).
     */
    fun registerAiHostId(id: String?) {
        if (!id.isNullOrBlank()) {
            aiHostIds.add(id.trim())
        }
    }

    /**
     * Registers a collection of AI host IDs.
     */
    fun registerAiHosts(ids: Collection<String>) {
        ids.filter { it.isNotBlank() }.forEach { aiHostIds.add(it.trim()) }
    }

    /**
     * Returns true if the given partner or user ID belongs to an isolated AI host.
     */
    fun isAiHost(id: String?): Boolean {
        if (id.isNullOrBlank()) return false
        val trimmed = id.trim()
        return aiHostIds.contains(trimmed) || trimmed.equals(NEHA_HOST_ID, ignoreCase = true)
    }

    /**
     * Returns all currently registered AI host IDs.
     */
    fun getAiHostIds(): Set<String> = aiHostIds.toSet()
}
