package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MembershipPlan(
    @Json(name = "id") val id: String,
    @Json(name = "name") val name: String,
    @Json(name = "price_inr") val priceInr: Double,
    @Json(name = "duration_hours") val durationHours: Int = 24,
    @Json(name = "is_active") val isActive: Boolean = true,
    @Json(name = "description") val description: String? = null,
    @Json(name = "pre_tax_amount_inr") val preTaxAmountInr: Double? = null,
    @Json(name = "tax_amount_inr") val taxAmountInr: Double? = null,
    @Json(name = "tax_rate_percent") val taxRatePercent: Double? = null
)

sealed class ActivePlanState {
    object Loading : ActivePlanState()
    data class ActivePlan(val plan: MembershipPlan) : ActivePlanState()
    object NoActivePlan : ActivePlanState()
    data class Error(val message: String) : ActivePlanState()
}

@JsonClass(generateAdapter = true)
data class UserMembership(
    @Json(name = "id") val id: String? = null,
    @Json(name = "user_id") val userId: String = "",
    @Json(name = "plan_id") val planId: String? = null,
    @Json(name = "status") val status: String = "inactive", // active, expired, inactive
    @Json(name = "starts_at") val startsAt: String? = null,
    @Json(name = "expires_at") val expiresAt: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

data class EffectiveUserPricing(
    val isMember: Boolean = false,
    val callCoinsPerMinute: Int = if (isMember) 3 else 6,
    val messageCoinsPerMessage: Int = if (isMember) 1 else 3,
    val postViewCoins: Int = if (isMember) 1 else 2,
    val postCommentCoins: Int = if (isMember) 1 else 2,
    val storyReplyCoins: Int = if (isMember) 1 else 2,
    val storyViewCoins: Int = if (isMember) 1 else 2,
    val likeCoins: Int = 1,
    val postCreateCoins: Int = 20,
    val storyCreateCoins: Int = 10,
    val postRenewCoins: Int = 20,
    val planId: String? = null,
    val planName: String? = null,
    val expiresAt: String? = null
) {
    companion object {
        val DEFAULT_NON_MEMBER = EffectiveUserPricing(isMember = false)
        val DEFAULT_MEMBER = EffectiveUserPricing(isMember = true)
    }
}

sealed class MembershipState {
    object Loading : MembershipState()
    object Inactive : MembershipState()
    data class Active(
        val membership: UserMembership,
        val expiresAtEpochMs: Long,
        val remainingMillis: Long
    ) : MembershipState() {
        val remainingHours: Long get() = java.util.concurrent.TimeUnit.MILLISECONDS.toHours(maxOf(0L, remainingMillis))
        val remainingMinutes: Long get() = java.util.concurrent.TimeUnit.MILLISECONDS.toMinutes(maxOf(0L, remainingMillis))
    }
    data class Expired(val lastMembership: UserMembership? = null) : MembershipState()
    data class PaymentPending(val paymentId: String, val message: String) : MembershipState()
    data class PaymentFailed(val message: String) : MembershipState()
}

sealed class MembershipPurchaseUiState {
    object Idle : MembershipPurchaseUiState()
    object CreatingPayment : MembershipPurchaseUiState()
    data class OpeningCheckout(val paymentId: String, val openUrl: String) : MembershipPurchaseUiState()
    data class Verifying(val paymentId: String, val attempt: Int = 1) : MembershipPurchaseUiState()
    data class Success(val membership: UserMembership) : MembershipPurchaseUiState()
    data class Pending(val paymentId: String, val message: String) : MembershipPurchaseUiState()
    data class Failed(val message: String, val canRetry: Boolean = true) : MembershipPurchaseUiState()
    data class Cancelled(val message: String) : MembershipPurchaseUiState()
}

fun parseIsoTimestamp(isoString: String?): Long? {
    if (isoString.isNullOrBlank()) return null
    return try {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            java.time.Instant.parse(isoString).toEpochMilli()
        } else {
            val clean = isoString.replace("Z", "+0000").replace("+00:00", "+0000")
            val format = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }
            format.parse(clean)?.time
        }
    } catch (_: Exception) {
        try {
            // Secondary regex/format attempt
            val clean = if (isoString.length >= 19) isoString.substring(0, 19) else isoString
            val format = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }
            format.parse(clean)?.time
        } catch (_: Exception) {
            null
        }
    }
}

private fun org.json.JSONObject.optIntCoerced(vararg keys: String, default: Int): Int {
    for (key in keys) {
        if (has(key) && !isNull(key)) {
            val v = opt(key)
            when (v) {
                is Number -> return v.toInt()
                is String -> v.trim().toIntOrNull()?.let { return it }
            }
        }
    }
    return default
}

private fun org.json.JSONObject.optBooleanCoerced(vararg keys: String, default: Boolean): Boolean {
    for (key in keys) {
        if (has(key) && !isNull(key)) {
            val v = opt(key)
            when (v) {
                is Boolean -> return v
                is Number -> return v.toInt() != 0
                is String -> {
                    val s = v.trim().lowercase()
                    if (s == "true" || s == "1" || s == "t") return true
                    if (s == "false" || s == "0" || s == "f") return false
                }
            }
        }
    }
    return default
}

private fun org.json.JSONObject.optStringClean(vararg keys: String): String? {
    for (key in keys) {
        if (has(key) && !isNull(key)) {
            val str = optString(key).trim()
            if (str.isNotBlank() && !str.equals("null", ignoreCase = true)) {
                return str
            }
        }
    }
    return null
}

fun parseEffectivePricingJson(rawJson: String, isMemberFallback: Boolean = false): EffectiveUserPricing {
    return try {
        val trimmed = rawJson.trim()
        val root = if (trimmed.startsWith("[")) {
            val arr = org.json.JSONArray(trimmed)
            if (arr.length() > 0) {
                val first = arr.get(0)
                if (first is org.json.JSONObject) first else org.json.JSONObject()
            } else org.json.JSONObject()
        } else {
            org.json.JSONObject(trimmed)
        }

        val json = root.optJSONObject("pricing") ?: root.optJSONObject("data") ?: root

        val isMember = json.optBooleanCoerced("membership_active", "is_member", "isMember", default = isMemberFallback)
        val defaultCall = if (isMember) 3 else 6
        val defaultMsg = if (isMember) 1 else 3
        val defaultPostView = if (isMember) 1 else 2
        val defaultPostComment = if (isMember) 1 else 2
        val defaultStoryReply = if (isMember) 1 else 2
        val defaultStoryView = if (isMember) 1 else 2

        EffectiveUserPricing(
            isMember = isMember,
            callCoinsPerMinute = json.optIntCoerced("call_rate_coins", "call_coins_per_minute", "callCoinsPerMinute", default = defaultCall),
            messageCoinsPerMessage = json.optIntCoerced("message_rate_coins", "message_coins_per_message", "messageCoinsPerMessage", default = defaultMsg),
            postViewCoins = json.optIntCoerced("post_view_coins", "postViewCoins", default = defaultPostView),
            postCommentCoins = json.optIntCoerced("post_comment_coins", "postCommentCoins", default = defaultPostComment),
            storyReplyCoins = json.optIntCoerced("story_reply_coins", "storyReplyCoins", default = defaultStoryReply),
            storyViewCoins = json.optIntCoerced("story_view_coins", "storyViewCoins", default = defaultStoryView),
            likeCoins = json.optIntCoerced("like_coins", default = 1),
            postCreateCoins = json.optIntCoerced("post_create_coins", default = 20),
            storyCreateCoins = json.optIntCoerced("story_create_coins", default = 10),
            postRenewCoins = json.optIntCoerced("post_renew_coins", default = 20),
            planId = json.optStringClean("plan_id", "planId"),
            planName = json.optStringClean("plan_name", "planName"),
            expiresAt = json.optStringClean("expires_at", "expiresAt")
        )
    } catch (_: Exception) {
        if (isMemberFallback) EffectiveUserPricing.DEFAULT_MEMBER else EffectiveUserPricing.DEFAULT_NON_MEMBER
    }
}
