# BAATLY User App — v54 Food & Cabs + R2 revision

Native Android application built with Kotlin and Jetpack Compose.

## v54 highlights

- Food & Cabs is a full-screen destination with premium light plum/purple styling, 3D vehicle artwork and a food hero image.
- Pickup, drop and delivery address selection use a full-screen search/map page, with tap-to-pin, current location, confirmation and Android back navigation.
- Food discovery includes restaurant/dish search, cuisine shortcuts and filters; restaurant menus include dish search, Veg/Non-Veg/Egg filters and categories. The cart is preserved when navigating back from a menu.
- Supplied 3D panda frames now animate through run → scan/search → run while a cab request is searching; the old static runner asset has been removed.
- Ride and food-order cancellation show a pending state and disable repeated taps while the existing mobility cancellation endpoints process the request.
- Profile avatars, chat images and chat voice notes upload to Cloudflare R2. Private media resolves through authenticated R2 signing and legacy profile/chat media is migrated on first authenticated access.
- Social feed/story media remains R2-only, including a one-time legacy-media copy when an old database key points to a missing R2 object.
- `versionCode = 54`; `versionName = 1.0.54`.

## Build

1. Open this project root in Android Studio.
2. Use the JDK version required by the installed Android Gradle Plugin (JDK 17 or newer where supported by the project toolchain).
3. Configure the existing Supabase, Google Maps and CI signing secrets using your own secure values.
4. Run `./gradlew :app:assembleRelease`.

Validation note: source and bundled image assets were checked, and the Kotlin parser scan emitted no syntax-specific diagnostics. A full Gradle build/APK could not run in the current environment because the Gradle 9.3.1 wrapper distribution at `services.gradle.org` was unreachable (DNS/network failure). This archive is an updated source project, not a verified APK. See `BAATLY_USER_APP_V54_FOOD_CABS_R2_FIX_REPORT.md` for backend deployment and testing details.
