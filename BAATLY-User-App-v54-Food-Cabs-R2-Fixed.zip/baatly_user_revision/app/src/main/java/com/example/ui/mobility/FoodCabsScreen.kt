package com.example.ui.mobility

import androidx.compose.animation.core.tween
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.data.mobility.*
import com.example.ui.BaatlyViewModel
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

private val MobilityNavy = Color(0xFFF7F5FB)
private val MobilityPanel = Color(0xFFFFFFFF)
private val MobilityPanel2 = Color(0xFFF0ECF7)
private val MobilityPurple = Color(0xFF682CC8)
private val MobilityPink = Color(0xFFEC5F9A)
private val MobilityGold = Color(0xFFB87912)
private val MobilityMint = Color(0xFF138B70)
private val MobilityWhite = Color(0xFF251D35)
private val MobilityMuted = Color(0xFF777086)

private enum class MobilityTab { CABS, FOOD }
private enum class CabCategory(val title: String, val category: String, val serviceType: String, val subtitle: String, val emoji: String) {
    AUTO("Auto", "auto", "cab", "Quick city rides", "🛺"),
    BIKE("Bike", "bike", "bike_taxi", "Beat the traffic", "🏍️"),
    MINI("Mini", "mini", "cab", "Everyday comfort", "🚗"),
    SEDAN("Sedan", "sedan", "cab", "Extra comfort", "🚘"),
    SUV("SUV", "suv", "cab", "Room for everyone", "🚙"),
    XL("XL", "xl", "cab", "More seats, more space", "🚐"),
    PREMIUM("Premium", "premium", "cab", "Premium city travel", "✨"),
    E_RICKSHAW("E-rickshaw", "erickshaw", "cab", "Short local trips", "🛺")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodCabsScreen(viewModel: BaatlyViewModel) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(MobilityTab.CABS) }
    var pickerTarget by remember { mutableStateOf<String?>(null) }
    var pickup by remember { mutableStateOf<MobilityPoint?>(null) }
    var drop by remember { mutableStateOf<MobilityPoint?>(null) }
    var category by remember { mutableStateOf(CabCategory.AUTO) }
    var quote by remember { mutableStateOf<MobilityCabQuote?>(null) }
    var quoteLoading by remember { mutableStateOf(false) }
    var cabBusy by remember { mutableStateOf(false) }
    var cabCancelling by remember { mutableStateOf(false) }
    var ride by remember { mutableStateOf<MobilityRide?>(null) }
    var tracking by remember { mutableStateOf<MobilityTrackingLocation?>(null) }
    var trackerStale by remember { mutableStateOf(false) }
    var foodCatalog by remember { mutableStateOf<List<FoodRestaurant>>(emptyList()) }
    var foodLoading by remember { mutableStateOf(false) }
    var foodError by remember { mutableStateOf<String?>(null) }
    var foodFilter by remember { mutableStateOf("All") }
    var selectedRestaurant by remember { mutableStateOf<FoodRestaurant?>(null) }
    var selectedBranch by remember { mutableStateOf<FoodBranch?>(null) }
    var menuItems by remember { mutableStateOf<List<FoodMenuItem>>(emptyList()) }
    var menuCategories by remember { mutableStateOf<List<FoodMenuCategory>>(emptyList()) }
    var selectedMenuCategory by remember { mutableStateOf<String?>(null) }
    var menuQuery by remember { mutableStateOf("") }
    var menuFoodFilter by remember { mutableStateOf("All") }
    var menuLoading by remember { mutableStateOf(false) }
    var cart = remember { mutableStateListOf<FoodCartLine>() }
    var deliveryPoint by remember { mutableStateOf<MobilityPoint?>(null) }
    var order by remember { mutableStateOf<FoodOrder?>(null) }
    var foodCancelling by remember { mutableStateOf(false) }
    var foodDestination by remember { mutableStateOf<MobilityPoint?>(null) }
    var foodTracking by remember { mutableStateOf<MobilityTrackingLocation?>(null) }
    var foodTrackerStale by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var showCart by remember { mutableStateOf(false) }
    var foodQuery by remember { mutableStateOf("") }
    var returnToCartAfterAddress by remember { mutableStateOf(false) }

    BackHandler(enabled = pickerTarget == null && showCart) { showCart = false }
    BackHandler(enabled = pickerTarget == null && !showCart && selectedRestaurant != null) {
        selectedRestaurant = null; selectedBranch = null
        menuItems = emptyList(); menuCategories = emptyList(); selectedMenuCategory = null
        menuQuery = ""; menuFoodFilter = "All"
    }
    BackHandler(enabled = pickerTarget == null && !showCart && selectedRestaurant == null && ride == null && order == null) {
        if (tab == MobilityTab.FOOD) tab = MobilityTab.CABS
    }

    LaunchedEffect(Unit) {
        runCatching { viewModel.mobilityService.loadActiveCabRide() }.getOrNull()?.let { ride = it }
        runCatching { viewModel.mobilityService.loadActiveFoodOrder() }.getOrNull()?.let { order = it }
    }
    LaunchedEffect(tab) {
        if (tab == MobilityTab.FOOD && foodCatalog.isEmpty() && !foodLoading) {
            foodLoading = true; foodError = null
            runCatching { viewModel.mobilityService.loadFoodCatalog() }
                .onSuccess { foodCatalog = it }
                .onFailure { foodError = it.message ?: "Unable to load food near you" }
            foodLoading = false
        }
    }
    LaunchedEffect(pickup, drop, category) {
        quote = null
        if (pickup != null && drop != null && pickup != drop) {
            quoteLoading = true
            delay(350)
            runCatching { viewModel.mobilityService.quoteCab(pickup!!, drop!!, category.category, category.serviceType) }
                .onSuccess { quote = it }
                .onFailure { statusMessage = it.message ?: "Route quote could not be calculated" }
            quoteLoading = false
        }
    }
    LaunchedEffect(ride?.id) {
        val id = ride?.id ?: return@LaunchedEffect
        while (isActive) {
            runCatching { viewModel.mobilityService.getCabRide(id) }.getOrNull()?.let { latest ->
                ride = latest.copy(rideCode = ride?.rideCode)
                if (latest.status in setOf("completed", "cancelled", "expired", "rejected", "no_partner_found")) {
                    tracking = null; trackerStale = false
                }
            }
            delay(3_000)
        }
    }
    LaunchedEffect(ride?.id, ride?.status) {
        val current = ride ?: return@LaunchedEffect
        if (current.status !in setOf("accepted", "driver_arriving", "arrived", "in_progress")) return@LaunchedEffect
        while (isActive) {
            runCatching { viewModel.mobilityService.trackingSnapshot("cab", current.id) }.getOrNull()?.let {
                tracking = it; trackerStale = it.stale
            }
            delay(5_000)
        }
    }
    DisposableEffect(ride?.id, ride?.status) {
        val current = ride
        val socket = if (current != null && current.status in setOf("accepted", "driver_arriving", "arrived", "in_progress")) {
            viewModel.mobilityService.connectTracking("cab", current.id, onLocation = { update ->
                scope.launch { tracking = update; trackerStale = false }
            }, onSocketClosed = { scope.launch { trackerStale = true } })
        } else null
        onDispose { socket?.close(1000, "Customer left tracking screen") }
    }
    LaunchedEffect(order?.id) {
        val id = order?.id ?: return@LaunchedEffect
        while (isActive) {
            runCatching { viewModel.mobilityService.getFoodOrder(id) }.getOrNull()?.let { latest ->
                order = latest.copy(deliveryCode = order?.deliveryCode, restaurantName = order?.restaurantName ?: latest.restaurantName)
                if (latest.status in setOf("delivered", "cancelled", "rejected")) foodTracking = null
            }
            delay(3_500)
        }
    }
    LaunchedEffect(order?.id, order?.status) {
        val current = order ?: return@LaunchedEffect
        if (current.status !in setOf("partner_assigned", "picked_up", "on_the_way")) return@LaunchedEffect
        while (isActive) {
            runCatching { viewModel.mobilityService.trackingSnapshot("food", current.id) }.getOrNull()?.let {
                foodTracking = it; foodTrackerStale = it.stale
            }
            delay(5_000)
        }
    }
    DisposableEffect(order?.id, order?.status) {
        val current = order
        val socket = if (current != null && current.status in setOf("partner_assigned", "picked_up", "on_the_way")) {
            viewModel.mobilityService.connectTracking("food", current.id, onLocation = { update ->
                scope.launch { foodTracking = update; foodTrackerStale = false }
            }, onSocketClosed = { scope.launch { foodTrackerStale = true } })
        } else null
        onDispose { socket?.close(1000, "Customer left food tracking") }
    }

    Box(Modifier.fillMaxSize().background(MobilityNavy)) {
      Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.setScreen(com.example.ui.Screen.SOCIAL) }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back to BAATLY", tint = MobilityPurple)
                }
                Column(Modifier.weight(1f)) {
                    Text("BAATLY", color = MobilityWhite, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("Move. Eat. Enjoy.", color = MobilityMuted, style = MaterialTheme.typography.bodySmall)
                }
                Surface(color = MobilityPanel, shape = CircleShape) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = MobilityMint, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp)); Text("Safe & easy", color = MobilityWhite, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MobilityPanel).padding(5.dp)) {
                MobilityTab.entries.forEach { item ->
                    val selected = tab == item
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .background(if (selected) Brush.horizontalGradient(listOf(MobilityPurple, MobilityPink)) else Brush.horizontalGradient(listOf(MobilityPanel, MobilityPanel)))
                            .clickable { tab = item }.padding(vertical = 13.dp),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                    ) {
                        val tabInk = if (selected) Color.White else MobilityMuted
                        Icon(if (item == MobilityTab.CABS) Icons.Default.DirectionsCar else Icons.Default.Fastfood, null, tint = tabInk, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp)); Text(if (item == MobilityTab.CABS) "Cabs" else "Food", color = tabInk, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        when (tab) {
            MobilityTab.CABS -> CabContent(
                pickup, drop, category, quote, quoteLoading, cabBusy, ride, tracking, trackerStale, cabCancelling,
                onPick = { pickerTarget = it },
                onCategory = { category = it },
                onBook = {
                    val start = pickup; val end = drop
                    if (start == null || end == null) { statusMessage = "Please choose pickup and drop locations first" }
                    else if (quote == null) { statusMessage = "Please wait while the route and fare are being checked" }
                    else {
                        cabBusy = true; statusMessage = null
                        scope.launch {
                            runCatching { viewModel.mobilityService.createCabBooking(start, end, category.category, category.serviceType) }
                                .onSuccess { created -> ride = created.copy(routeDistanceKm = quote?.distanceKm ?: 0.0, estimatedMinutes = quote?.durationMinutes ?: 0.0); tracking = null }
                                .onFailure { error ->
                                    // Dispatch can take longer than a normal HTTP request. If the request
                                    // times out after the booking was committed, recover it instead of
                                    // asking the customer to create a duplicate ride.
                                    val recovered = runCatching { viewModel.mobilityService.loadActiveCabRide() }.getOrNull()
                                    if (recovered != null) {
                                        ride = recovered.copy(routeDistanceKm = quote?.distanceKm ?: recovered.routeDistanceKm,
                                            estimatedMinutes = quote?.durationMinutes ?: recovered.estimatedMinutes)
                                        tracking = null
                                    } else statusMessage = error.message ?: "Booking could not be placed"
                                }
                            cabBusy = false
                        }
                    }
                },
                onCancel = { current ->
                    if (!cabCancelling) scope.launch {
                        cabCancelling = true
                        runCatching { viewModel.mobilityService.cancelCabRide(current.id, "Cancelled by customer") }
                            .onSuccess { result ->
                                val data = result.optJSONObject("data") ?: result
                                if (data.has("success") && !data.optBoolean("success", false)) {
                                    statusMessage = data.optString("error").ifBlank { "This ride can no longer be cancelled." }
                                } else {
                                    val due = data.optDouble("total_due", data.optDouble("customer_cancellation_fee", data.optDouble("cancellation_fee_amount", 0.0)))
                                    ride = null; tracking = null
                                    statusMessage = if (due > 0) "Your ride has been cancelled. Applicable cancellation fee: ₹${due.toInt()}." else "Your ride has been cancelled."
                                }
                            }
                            .onFailure { statusMessage = it.message ?: "This ride can no longer be cancelled" }
                        cabCancelling = false
                    }
                },
                onReset = { ride = null; tracking = null; pickup = null; drop = null; quote = null }
            )
            MobilityTab.FOOD -> FoodContent(
                catalog = foodCatalog, loading = foodLoading, error = foodError, filter = foodFilter, query = foodQuery, onQuery = { foodQuery = it },
                restaurant = selectedRestaurant, branch = selectedBranch, menuItems = menuItems, menuCategories = menuCategories,
                cancelling = foodCancelling,
                selectedMenuCategory = selectedMenuCategory, menuQuery = menuQuery, menuFoodFilter = menuFoodFilter,
                onMenuQuery = { menuQuery = it }, onMenuFoodFilter = { menuFoodFilter = it },
                menuLoading = menuLoading, mobilityService = viewModel.mobilityService,
                cart = cart, destination = deliveryPoint, order = order,
                foodDestination = foodDestination ?: order?.let { o ->
                    if (o.deliveryLatitude != null && o.deliveryLongitude != null) MobilityPoint("Delivery", o.deliveryAddress, o.deliveryLatitude, o.deliveryLongitude) else null
                },
                tracking = foodTracking, trackerStale = foodTrackerStale,
                onFilter = { foodFilter = it }, onSelectRestaurant = { restaurant, branch ->
                    selectedRestaurant = restaurant; selectedBranch = branch; menuLoading = true; menuItems = emptyList(); menuCategories = emptyList(); selectedMenuCategory = null
                    scope.launch {
                        runCatching { viewModel.mobilityService.loadMenuItems(restaurant.id, branch.id) }
                            .onSuccess { menuItems = it }.onFailure { foodError = it.message ?: "Menu unavailable" }
                        runCatching { viewModel.mobilityService.loadCategories(restaurant.id, branch.id) }
                            .onSuccess { menuCategories = it }
                        menuLoading = false
                    }
                },
                onBack = { selectedRestaurant = null; selectedBranch = null; menuItems = emptyList(); menuCategories = emptyList(); selectedMenuCategory = null; menuQuery = ""; menuFoodFilter = "All" },
                onMenuCategory = { selectedMenuCategory = it },
                onAdd = { item ->
                    val i = cart.indexOfFirst { it.item.id == item.id }
                    if (i < 0) cart.add(FoodCartLine(item, 1)) else cart[i] = cart[i].copy(quantity = cart[i].quantity + 1)
                },
                onRemove = { item ->
                    val i = cart.indexOfFirst { it.item.id == item.id }
                    if (i >= 0) { if (cart[i].quantity <= 1) cart.removeAt(i) else cart[i] = cart[i].copy(quantity = cart[i].quantity - 1) }
                },
                onSetDestination = { returnToCartAfterAddress = false; pickerTarget = "food" },
                onCancelOrder = { current ->
                    if (!foodCancelling) scope.launch {
                        foodCancelling = true
                        runCatching { viewModel.mobilityService.cancelFoodOrder(current.id, "Cancelled by customer") }
                            .onSuccess { result ->
                                val data = result.optJSONObject("data") ?: result
                                if (data.has("success") && !data.optBoolean("success", false)) {
                                    statusMessage = data.optString("error").ifBlank { "This order can no longer be cancelled." }
                                } else {
                                    val due = data.optDouble("total_due", data.optDouble("customer_cancellation_fee", data.optDouble("cancellation_fee_amount", 0.0)))
                                    order = null; foodTracking = null
                                    statusMessage = if (due > 0) "Your food order has been cancelled. Applicable cancellation fee: ₹${due.toInt()}." else "Your food order has been cancelled."
                                }
                            }
                            .onFailure { statusMessage = it.message ?: "This order can no longer be cancelled" }
                        foodCancelling = false
                    }
                },
                onShowCart = { showCart = true }, onResetOrder = { order = null; foodTracking = null }
            )
        }
      }

    pickerTarget?.let { target ->
        val initial = when (target) { "pickup" -> pickup; "drop" -> drop; else -> deliveryPoint }
        LocationPickerScreen(
            title = when (target) { "pickup" -> "Choose pickup point"; "drop" -> "Choose drop point"; else -> "Choose delivery address" },
            initial = initial,
            onDismiss = {
                pickerTarget = null
                if (returnToCartAfterAddress) { showCart = true; returnToCartAfterAddress = false }
            },
            onConfirm = { point ->
                when (target) { "pickup" -> pickup = point; "drop" -> drop = point; else -> deliveryPoint = point }
                pickerTarget = null
                if (target == "food" && returnToCartAfterAddress) { showCart = true; returnToCartAfterAddress = false }
            }
        )
    }
    if (showCart) {
        FoodCartScreen(
            cart = cart, destination = deliveryPoint, busy = cabBusy,
            onAddress = { if (!cabBusy) { returnToCartAfterAddress = true; showCart = false; pickerTarget = "food" } },
            onDismiss = { if (!cabBusy) showCart = false },
            onAdd = { item ->
                val index = cart.indexOfFirst { it.item.id == item.id }
                if (index >= 0) cart[index] = cart[index].copy(quantity = cart[index].quantity + 1)
            },
            onRemove = { item ->
                val index = cart.indexOfFirst { it.item.id == item.id }
                if (index >= 0) {
                    val line = cart[index]
                    if (line.quantity <= 1) cart.removeAt(index) else cart[index] = line.copy(quantity = line.quantity - 1)
                }
            },
            onPlaceOrder = {
            val restaurant = selectedRestaurant; val branch = selectedBranch; val point = deliveryPoint
            if (restaurant != null && branch != null && point != null && cart.isNotEmpty() && !cabBusy) {
                cabBusy = true
                scope.launch {
                    runCatching { viewModel.mobilityService.createFoodOrder(restaurant, branch, point, cart.toList()) }
                        .onSuccess { newOrder -> order = newOrder; foodDestination = point; foodTracking = null; cart.clear(); showCart = false }
                        .onFailure { statusMessage = it.message ?: "Food order could not be placed"; showCart = false }
                    cabBusy = false
                }
            }
        })
    }
    statusMessage?.let { message ->
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).padding(14.dp).fillMaxWidth().clickable { statusMessage = null },
            color = Color(0xFF34234F), shape = RoundedCornerShape(16.dp), shadowElevation = 8.dp
        ) {
            Text(message, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(16.dp))
        }
    }
    }
}

@Composable
private fun CabContent(
    pickup: MobilityPoint?, drop: MobilityPoint?, category: CabCategory, quote: MobilityCabQuote?, quoteLoading: Boolean,
    busy: Boolean, ride: MobilityRide?, tracking: MobilityTrackingLocation?, trackerStale: Boolean, cancelling: Boolean,
    onPick: (String) -> Unit, onCategory: (CabCategory) -> Unit, onBook: () -> Unit,
    onCancel: (MobilityRide) -> Unit, onReset: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CabHeroCard()
        if (busy && ride == null) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MobilityPanel).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                PandaSearchAnimation(Modifier.fillMaxWidth().height(182.dp))
                Text("Please wait while I'm finding a partner for you", color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("We're sending your request to nearby partners. This can take a few moments.", color = MobilityMuted, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp)); LinearProgressIndicator(Modifier.fillMaxWidth(), color = MobilityPurple, trackColor = MobilityPanel2)
            }
        } else if (ride != null) {
            RideStatusCard(ride, pickup, drop, tracking, trackerStale, cancelling, decodeGooglePolyline(quote?.encodedPolyline.orEmpty()), onCancel, onReset)
        } else {
            Text("Where should we pick you up?", color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Column(Modifier.clip(RoundedCornerShape(22.dp)).background(MobilityPanel).padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                LocationField("PICKUP", pickup?.address ?: "Choose your pickup point", MobilityMint, onClick = { onPick("pickup") })
                Box(Modifier.padding(start = 15.dp).width(1.dp).height(18.dp).background(MobilityMuted.copy(alpha = .5f)))
                LocationField("DROP", drop?.address ?: "Where do you want to go?", MobilityPink, onClick = { onPick("drop") })
                TextButton(onClick = { onPick("pickup") }, contentPadding = PaddingValues(0.dp)) {
                    Icon(Icons.Default.MyLocation, null, tint = MobilityMint, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Use map to pin an exact location", color = MobilityMuted, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (pickup != null && drop != null) {
                MobilityMap(
                    modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(22.dp)),
                    pickup = pickup, drop = drop, showRoute = true,
                    routePoints = decodeGooglePolyline(quote?.encodedPolyline.orEmpty())
                )
                quote?.let { route ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(MobilityPanel).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("YOUR ROUTE", color = MobilityMuted, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                            Text("${"%.1f".format(route.distanceKm)} km  •  ${route.durationMinutes.toInt()} min", color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Text("Verified route", color = MobilityMint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
            Text("Choose your ride", color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CabCategory.entries.forEach { item ->
                    val selected = item == category
                    Column(
                        Modifier.width(112.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (selected) MobilityPurple.copy(alpha = .24f) else MobilityPanel)
                            .border(1.dp, if (selected) MobilityPurple else Color.Transparent, RoundedCornerShape(18.dp))
                            .clickable { onCategory(item) }.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(item.emoji, fontSize = 28.sp); Spacer(Modifier.height(7.dp))
                        Text(item.title, color = MobilityWhite, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(item.subtitle, color = MobilityMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (quoteLoading) {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = MobilityPurple, trackColor = MobilityPanel)
            }
            quote?.let { q ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MobilityPanel2).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ESTIMATED FARE", color = MobilityMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text("₹${q.fare.toInt()}", color = MobilityWhite, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
                        Text("${"%.1f".format(q.distanceKm)} km  •  ${q.durationMinutes.toInt()} min approx.", color = MobilityMuted, fontSize = 12.sp)
                    }
                    Surface(color = MobilityMint.copy(alpha = .13f), shape = RoundedCornerShape(12.dp)) {
                        Text("CASH / COD", color = MobilityMint, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(10.dp))
                    }
                }
            }
            Button(onClick = onBook, enabled = pickup != null && drop != null && quote != null && !busy && !quoteLoading,
                modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MobilityPurple, disabledContainerColor = MobilityPanel2)) {
                if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = MobilityWhite, strokeWidth = 2.dp)
                else { Text("Find my ride", fontWeight = FontWeight.Bold, fontSize = 16.sp); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null, modifier = Modifier.size(18.dp)) }
            }
            Text("Your fare is calculated from the verified road route. Final fare may change with actual trip time and distance.", color = MobilityMuted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun RideStatusCard(
    ride: MobilityRide, pickup: MobilityPoint?, drop: MobilityPoint?, tracking: MobilityTrackingLocation?, trackerStale: Boolean, cancelling: Boolean, routePoints: List<LatLng>,
    onCancel: (MobilityRide) -> Unit, onReset: () -> Unit
) {
    val searching = ride.status == "searching"
    val active = ride.status in setOf("accepted", "driver_arriving", "arrived", "in_progress")
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MobilityPanel).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (searching) {
            PandaSearchAnimation(Modifier.fillMaxWidth().height(172.dp))
            Text("Please wait while I'm finding a partner for you", color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("We're checking nearby partners. Keep this screen open for live updates.", color = MobilityMuted, fontSize = 12.sp)
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(statusLabel(ride.status), color = MobilityWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("${ride.vehicleCategory.replaceFirstChar { it.uppercase() }} • ${ride.serviceType.replace('_', ' ')}", color = MobilityMuted, fontSize = 12.sp)
                }
                Text("₹${(ride.finalFare.takeIf { it > 0 } ?: ride.quotedFare).toInt()}", color = MobilityGold, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            }
            val pickupPoint = pickup ?: MobilityPoint("Pickup", ride.pickupAddress, ride.pickupLatitude, ride.pickupLongitude)
            val dropPoint = drop ?: MobilityPoint("Drop", ride.dropAddress, ride.dropLatitude, ride.dropLongitude)
            if (pickupPoint.latitude != 0.0 && pickupPoint.longitude != 0.0 && dropPoint.latitude != 0.0 && dropPoint.longitude != 0.0) {
                MobilityMap(Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(18.dp)), pickup = pickupPoint, drop = dropPoint,
                    driver = tracking?.let { LatLng(it.latitude, it.longitude) }, showRoute = true, routePoints = routePoints)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = MobilityPurple.copy(alpha = .18f), shape = CircleShape) { Text("${"%.2f".format(tracking?.distanceKm ?: 0.0)} km", color = MobilityPurple, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(8.dp))
                Text(if (trackerStale || tracking?.stale == true) "Waiting for partner GPS…" else "Live partner location", color = MobilityMuted, fontSize = 11.sp)
            }
            if (ride.rideCode != null && ride.status in setOf("accepted", "driver_arriving", "arrived")) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MobilityGold.copy(alpha = .11f)).padding(14.dp)) {
                    Text("YOUR RIDE START CODE", color = MobilityGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(ride.rideCode!!.chunked(1).joinToString(" "), color = MobilityWhite, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Text("Share this code with your partner only when you are at the pickup point.", color = MobilityMuted, fontSize = 11.sp)
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            StatusPoint("Pickup", ride.pickupAddress, MobilityMint)
            StatusPoint("Drop", ride.dropAddress, MobilityPink)
        }
        if (ride.status !in setOf("completed", "cancelled", "expired", "rejected", "no_partner_found")) {
            OutlinedButton(onClick = { onCancel(ride) }, enabled = !cancelling, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MobilityPink.copy(alpha = .65f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MobilityPink)) {
                if (cancelling) CircularProgressIndicator(Modifier.size(18.dp), color = MobilityPink, strokeWidth = 2.dp)
                else Text("Cancel ride", fontWeight = FontWeight.Bold)
            }
        } else {
            Button(onClick = onReset, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MobilityPurple)) { Text(if (ride.status == "no_partner_found") "Try another ride" else "Book another ride", fontWeight = FontWeight.Bold) }
        }
        if (active && tracking == null) Text("Partner tracking will appear as soon as their location is received.", color = MobilityMuted, fontSize = 11.sp)
    }
}

@Composable
private fun FoodContent(
    catalog: List<FoodRestaurant>, loading: Boolean, error: String?, filter: String, query: String, onQuery: (String) -> Unit,
    restaurant: FoodRestaurant?, branch: FoodBranch?, menuItems: List<FoodMenuItem>, menuCategories: List<FoodMenuCategory>,
    selectedMenuCategory: String?, menuQuery: String, menuFoodFilter: String,
    onMenuQuery: (String) -> Unit, onMenuFoodFilter: (String) -> Unit,
    menuLoading: Boolean, mobilityService: MobilityService,
    cart: SnapshotStateList<FoodCartLine>, destination: MobilityPoint?, order: FoodOrder?, cancelling: Boolean, foodDestination: MobilityPoint?,
    tracking: MobilityTrackingLocation?, trackerStale: Boolean,
    onFilter: (String) -> Unit, onSelectRestaurant: (FoodRestaurant, FoodBranch) -> Unit, onBack: () -> Unit,
    onMenuCategory: (String?) -> Unit, onAdd: (FoodMenuItem) -> Unit, onRemove: (FoodMenuItem) -> Unit, onSetDestination: () -> Unit,
    onCancelOrder: (FoodOrder) -> Unit, onShowCart: () -> Unit, onResetOrder: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        if (order != null) {
            FoodOrderStatus(order, foodDestination, tracking, trackerStale, cancelling, onCancelOrder, onResetOrder)
            return@Column
        }
        if (restaurant == null || branch == null) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                FoodHeroCard()
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(MobilityPanel).clickable(onClick = onSetDestination).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = MobilityPink)
                    Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) {
                        Text("DELIVER TO", color = MobilityMuted, fontSize = 10.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
                        Text(destination?.address ?: "Choose delivery address", color = MobilityWhite, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("Change", color = MobilityPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedTextField(
                    value = query, onValueChange = onQuery, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search restaurants, dishes and cuisines", color = MobilityMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MobilityPurple) },
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MobilityWhite, unfocusedTextColor = MobilityWhite,
                        focusedContainerColor = MobilityPanel, unfocusedContainerColor = MobilityPanel,
                        focusedBorderColor = MobilityPurple, unfocusedBorderColor = MobilityPanel2,
                        cursorColor = MobilityPurple
                    )
                )
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("🍔  Burgers" to "burger", "🍕  Pizza" to "pizza", "🍜  Chinese" to "chinese", "🥟  Momos" to "momos", "🍛  Biryani" to "biryani").forEach { (label, term) ->
                        Surface(
                            onClick = { onQuery(if (query.equals(term, ignoreCase = true)) "" else term) },
                            color = if (query.equals(term, ignoreCase = true)) MobilityPurple.copy(alpha = .12f) else MobilityPanel,
                            shape = RoundedCornerShape(15.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (query.equals(term, ignoreCase = true)) MobilityPurple else MobilityPanel2)
                        ) {
                            Text(label, color = MobilityWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp))
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("All", "Pure Veg", "Non-Veg", "Open now").forEach { value ->
                        val selected = value == filter
                        Surface(onClick = { onFilter(value) }, color = if (selected) MobilityPink else MobilityPanel,
                            shape = RoundedCornerShape(30.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MobilityPink else MobilityMuted.copy(alpha = .15f))) {
                            Text(value, color = if (selected) Color.White else MobilityWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp))
                        }
                    }
                }
                Text("Restaurants near you", color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                if (loading) repeat(3) { RestaurantPlaceholder() }
                if (!error.isNullOrBlank()) Text(error, color = MobilityPink)
                val visible = catalog.filter { r ->
                    val open = r.branches.any { it.isOpen }
                    val matchesFilter = when (filter) { "Open now" -> open; "Pure Veg" -> r.menuFoodTypes.any { it in setOf("veg", "vegetarian", "pure_veg", "pure veg") } && r.menuFoodTypes.none { it in setOf("non_veg", "nonveg", "non-veg", "non veg") }; "Non-Veg" -> r.menuFoodTypes.any { it in setOf("non_veg", "nonveg", "non-veg", "non veg", "egg") }; else -> true }
                    val term = query.trim().lowercase()
                    val matchesQuery = term.isBlank() || r.name.lowercase().contains(term) || r.cuisines.any { it.lowercase().contains(term) } || r.description.lowercase().contains(term) || r.menuItemNames.any { it.lowercase().contains(term) }
                    matchesFilter && matchesQuery
                }
                visible.forEach { item ->
                    val openBranch = item.branches.firstOrNull { it.isOpen && it.latitude != null && it.longitude != null } ?: item.branches.firstOrNull { it.isOpen }
                    RestaurantCard(item, openBranch, mobilityService, onClick = { if (openBranch?.isOpen == true && openBranch.latitude != null && openBranch.longitude != null) onSelectRestaurant(item, openBranch) })
                }
                if (!loading && visible.isEmpty() && error.isNullOrBlank()) EmptyState("No open restaurant found", "Try another filter or check back in a little while.", "🍽️")
                Spacer(Modifier.height(18.dp))
            }
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 10.dp)) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = MobilityWhite) }
                    Column(Modifier.weight(1f)) {
                        Text(restaurant.name, color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(branch.address, color = MobilityMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("${cart.sumOf { it.quantity }} items", color = MobilityPink, fontWeight = FontWeight.Bold)
                }
                if (menuLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = MobilityPurple)
                OutlinedTextField(
                    value = menuQuery, onValueChange = onMenuQuery, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search dishes in this restaurant", color = MobilityMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = MobilityPurple) },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MobilityWhite, unfocusedTextColor = MobilityWhite,
                        focusedContainerColor = MobilityPanel, unfocusedContainerColor = MobilityPanel,
                        focusedBorderColor = MobilityPurple, unfocusedBorderColor = MobilityPanel2,
                        cursorColor = MobilityPurple
                    )
                )
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("All", "Veg", "Non-Veg", "Egg") .forEach { value ->
                        val selected = menuFoodFilter == value
                        Surface(onClick = { onMenuFoodFilter(value) }, color = if (selected) MobilityPurple else MobilityPanel,
                            shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MobilityPurple else MobilityPanel2)) {
                            Text(value, color = if (selected) Color.White else MobilityWhite, fontSize = 11.sp,
                                fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp))
                        }
                    }
                }
                if (menuCategories.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        (listOf(null to "All") + menuCategories.map { it.id to it.name }).forEach { (id, label) ->
                            Surface(onClick = { onMenuCategory(id) }, color = if (selectedMenuCategory == id) MobilityPink else MobilityPanel,
                                shape = RoundedCornerShape(24.dp)) { Text(label, color = MobilityWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) }
                        }
                    }
                }
                val visibleMenuItems = menuItems.filter { item ->
                    val categoryMatch = selectedMenuCategory == null || item.categoryId == selectedMenuCategory
                    val food = item.foodType.lowercase().replace('-', '_').replace(' ', '_')
                    val foodMatch = when (menuFoodFilter) {
                        "Veg" -> food in setOf("veg", "vegetarian", "pure_veg")
                        "Non-Veg" -> food in setOf("non_veg", "nonveg", "nonvegetarian", "non_vegetarian")
                        "Egg" -> food == "egg"
                        else -> true
                    }
                    val term = menuQuery.trim().lowercase()
                    val searchMatch = term.isBlank() || item.name.lowercase().contains(term) || item.description.lowercase().contains(term)
                    categoryMatch && foodMatch && searchMatch
                }
                if (menuItems.isEmpty() && !menuLoading) EmptyState("Menu is being prepared", "This restaurant has no available items right now.", "🥡")
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 14.dp)) {
                    items(visibleMenuItems) { item -> MenuItemCard(item, cart.firstOrNull { it.item.id == item.id }?.quantity ?: 0, mobilityService,
                        onAdd = { onAdd(item) }, onRemove = { onRemove(item) }) }
                }
                if (cart.isNotEmpty()) {
                    Button(onClick = onShowCart, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).height(54.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = MobilityPink)) {
                        Text("View cart  •  ${cart.sumOf { it.quantity }} items  •  ₹${cart.sumOf { it.item.price * it.quantity }.toInt()}", color = MobilityWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun FoodOrderStatus(order: FoodOrder, destination: MobilityPoint?, tracking: MobilityTrackingLocation?, trackerStale: Boolean, cancelling: Boolean,
                            onCancel: (FoodOrder) -> Unit, onReset: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        HeroCard("Order placed.\nGood choice.", "We'll keep you posted at every step.", "🥡", Modifier.fillMaxWidth().height(132.dp), MobilityPink)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(MobilityPanel).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(statusLabel(order.status), color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(order.restaurantName, color = MobilityMuted, fontSize = 13.sp)
            Text("₹${order.customerTotal.toInt()}  •  Cash on delivery", color = MobilityGold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            PriceLine("Food subtotal", order.foodSubtotal)
            PriceLine("Delivery fee", order.deliveryFee)
            PriceLine("Packing fee", order.packingFee)
            PriceLine("Platform fee", order.platformFee)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MobilityPanel2).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("DELIVERY CODE", color = MobilityMuted, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
                    Text(order.deliveryCode?.chunked(1)?.joinToString(" ") ?: "Shown when order is placed", color = MobilityWhite, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                }
                Icon(Icons.Default.Shield, null, tint = MobilityMint, modifier = Modifier.size(28.dp))
            }
            Text("Share this code with the delivery partner only when your food arrives.", color = MobilityMuted, fontSize = 11.sp)
            if (destination != null) {
                MobilityMap(Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(18.dp)), drop = destination,
                    driver = tracking?.let { LatLng(it.latitude, it.longitude) })
                Text(if (tracking == null || trackerStale || tracking.stale) "Waiting for live delivery partner location…" else "Live delivery partner location • ${"%.2f".format(tracking.distanceKm)} km", color = MobilityMuted, fontSize = 11.sp)
            } else Text("We’ll show live delivery tracking when a partner is assigned.", color = MobilityMuted, fontSize = 12.sp)
            if (order.status in setOf("placed", "accepted", "preparing", "ready")) {
                OutlinedButton(onClick = { onCancel(order) }, enabled = !cancelling, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    if (cancelling) CircularProgressIndicator(Modifier.size(18.dp), color = MobilityPink, strokeWidth = 2.dp)
                    else Text("Cancel order", color = MobilityPink)
                }
            }
            if (order.status in setOf("delivered", "cancelled", "rejected")) Button(onClick = onReset, modifier = Modifier.fillMaxWidth()) { Text("Explore food again") }
        }
    }
}

@Composable
private fun FoodCartScreen(
    cart: List<FoodCartLine>, destination: MobilityPoint?, busy: Boolean,
    onAddress: () -> Unit, onDismiss: () -> Unit,
    onAdd: (FoodMenuItem) -> Unit, onRemove: (FoodMenuItem) -> Unit,
    onPlaceOrder: () -> Unit
) {
    val subtotal = cart.sumOf { it.item.price * it.quantity }
    val packing = if (cart.isEmpty()) 0.0 else 4.0
    val platform = if (cart.isEmpty()) 0.0 else 5.0
    BackHandler(onBack = onDismiss)
    Box(Modifier.fillMaxSize().background(MobilityNavy)) {
        Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Your cart", color = MobilityWhite, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null, tint = MobilityMuted) }
            }
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                cart.forEach { line ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MobilityPanel).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(line.item.name, color = MobilityWhite, fontWeight = FontWeight.Bold)
                            Text("${line.quantity} × ₹${line.item.price.toInt()}", color = MobilityMuted, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("₹${(line.quantity * line.item.price).toInt()}", color = MobilityWhite, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(MobilityPanel2)) {
                                IconButton(onClick = { onRemove(line.item) }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Remove, null, tint = MobilityPurple) }
                                Text(line.quantity.toString(), color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                IconButton(onClick = { onAdd(line.item) }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Add, null, tint = MobilityPurple) }
                            }
                        }
                    }
                }
            }
            HorizontalDivider(color = MobilityMuted.copy(alpha = .2f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("DELIVER TO", color = MobilityMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(destination?.address ?: "Choose your delivery address", color = MobilityWhite, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                TextButton(onClick = onAddress) { Text("Select") }
            }
            PriceLine("Food subtotal", subtotal)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Delivery fee", color = MobilityMuted, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text("Route-based", color = MobilityMint, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            PriceLine("Packing fee", packing)
            PriceLine("Platform fee", platform)
            HorizontalDivider(color = MobilityMuted.copy(alpha = .2f))
            PriceLine("Before route-based delivery fee", subtotal + packing + platform, emphasized = true)
            Button(onClick = onPlaceOrder, enabled = cart.isNotEmpty() && destination != null && !busy,
                modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = MobilityPink)) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Text("Place order • Cash on Delivery", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Text("Final payable amount is calculated by the server using the verified road distance.", color = MobilityMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PriceLine(label: String, value: Double, note: String? = null, emphasized: Boolean = false) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(label, color = if (emphasized) MobilityWhite else MobilityMuted, fontWeight = if (emphasized) FontWeight.Bold else FontWeight.Normal, fontSize = if (emphasized) 15.sp else 12.sp); note?.let { Text(it, color = MobilityMuted, fontSize = 9.sp) } }
        Text("₹${value.toInt()}", color = if (emphasized) MobilityGold else MobilityWhite, fontWeight = FontWeight.Bold, fontSize = if (emphasized) 18.sp else 12.sp)
    }
}

@Composable
private fun RestaurantCard(restaurant: FoodRestaurant, branch: FoodBranch?, mobilityService: MobilityService, onClick: () -> Unit) {
    var logoUrl by remember(restaurant.id, restaurant.logoObjectKey) { mutableStateOf<String?>(null) }
    var retryUsed by remember(restaurant.id) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(restaurant.logoObjectKey) {
        logoUrl = mobilityService.signedMenuImageUrl(restaurant.logoObjectKey).takeIf { it.isNotBlank() }
    }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MobilityPanel).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(92.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Color(0xFF46305D), Color(0xFFB95D83)))), contentAlignment = Alignment.Center) {
            if (!logoUrl.isNullOrBlank()) {
                AsyncImage(
                    model = logoUrl, contentDescription = restaurant.name,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
                    onError = {
                        if (!retryUsed) {
                            retryUsed = true
                            scope.launch { logoUrl = mobilityService.signedMenuImageUrl(restaurant.logoObjectKey).takeIf { it.isNotBlank() } }
                        }
                    }
                )
            } else Text(if (restaurant.cuisines.any { it.contains("pizza", true) }) "🍕" else "🍲", fontSize = 36.sp)
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(restaurant.name, color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(restaurant.cuisines.take(3).joinToString(" • ").ifBlank { restaurant.description.ifBlank { "Fresh food" } }, color = MobilityMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (branch?.isOpen == true) "OPEN NOW" else "CURRENTLY CLOSED", color = if (branch?.isOpen == true) MobilityMint else MobilityPink, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(branch?.address.orEmpty(), color = MobilityMuted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MenuItemCard(item: FoodMenuItem, quantity: Int, mobilityService: MobilityService, onAdd: () -> Unit, onRemove: () -> Unit) {
    var imageUrl by remember(item.id) { mutableStateOf<String?>(null) }
    var imageRetry by remember(item.id) { mutableStateOf(false) }
    val imageScope = rememberCoroutineScope()
    LaunchedEffect(item.imageObjectKey) {
        imageUrl = mobilityService.signedMenuImageUrl(item.imageObjectKey).takeIf { it.isNotBlank() }
    }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MobilityPanel).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(66.dp).clip(RoundedCornerShape(14.dp)).background(MobilityPanel2), contentAlignment = Alignment.Center) {
            if (!imageUrl.isNullOrBlank()) {
                AsyncImage(model = imageUrl, contentDescription = item.name, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(), onError = {
                        if (!imageRetry) {
                            imageRetry = true
                            imageScope.launch { imageUrl = mobilityService.signedMenuImageUrl(item.imageObjectKey).takeIf { it.isNotBlank() } }
                        }
                    })
            } else Text(if (item.foodType.contains("non", true)) "🍗" else "🥗", fontSize = 29.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (item.foodType.contains("non", true)) MobilityPink else MobilityMint))
                Spacer(Modifier.width(5.dp)); Text(item.name, color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(item.description.ifBlank { "Freshly prepared" }, color = MobilityMuted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("₹${item.price.toInt()}", color = MobilityGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        if (quantity == 0) {
            FilledTonalButton(onClick = onAdd, contentPadding = PaddingValues(horizontal = 13.dp, vertical = 6.dp)) { Text("ADD", fontWeight = FontWeight.Bold) }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(MobilityPanel2).padding(horizontal = 5.dp)) {
                IconButton(onClick = onRemove, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Remove, null, tint = MobilityWhite) }
                Text(quantity.toString(), color = MobilityWhite, fontWeight = FontWeight.Bold)
                IconButton(onClick = onAdd, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Add, null, tint = MobilityWhite) }
            }
        }
    }
}

@Composable
private fun LocationField(label: String, value: String, accent: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MobilityPanel2).clickable(onClick = onClick).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(accent))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
            Text(value, color = if (value.startsWith("Choose") || value.startsWith("Where")) MobilityMuted else MobilityWhite,
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.Search, null, tint = MobilityMuted)
    }
}

@Composable
private fun StatusPoint(label: String, value: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color)); Spacer(Modifier.width(9.dp))
        Text(label, color = MobilityMuted, fontSize = 10.sp, modifier = Modifier.width(48.dp))
        Text(value, color = MobilityWhite, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun HeroCard(title: String, subtitle: String, emoji: String, modifier: Modifier = Modifier, accent: Color) {
    Row(modifier.clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(accent.copy(alpha = .92f), Color(0xFF28254A), Color(0xFF172037)))).padding(19.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp, lineHeight = 25.sp)
            Text(subtitle, color = Color.White.copy(alpha = .84f), fontSize = 11.sp)
        }
        Text(emoji, fontSize = 48.sp)
    }
}

@Composable
private fun FoodHeroCard() {
    Box(
        Modifier.fillMaxWidth().height(154.dp).clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Color.White, Color(0xFFF6F0FF), Color(0xFFEDE3FC))))
    ) {
        Image(
            painter = painterResource(id = com.example.R.drawable.baatly_food_hero),
            contentDescription = "Burger, fries and noodles for BAATLY food delivery",
            contentScale = ContentScale.Fit,
            modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(190.dp)
        )
        Column(Modifier.align(Alignment.CenterStart).padding(start = 18.dp, end = 160.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("BAATLY FOOD", color = MobilityPurple, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
            Text("Cravings,\ndelivered.", color = Color(0xFF241A35), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 24.sp)
            Text("Order from nearby kitchens", color = Color(0xFF746A83), fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun CabHeroCard() {
    Box(
        Modifier.fillMaxWidth().height(158.dp).clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF100D19), Color(0xFF271341), Color(0xFF351B5B))))
    ) {
        Image(
            painter = painterResource(id = com.example.R.drawable.baatly_mobility_vehicles),
            contentDescription = "BAATLY bike, auto and cab rides",
            contentScale = ContentScale.Crop,
            modifier = Modifier.align(Alignment.CenterEnd).width(238.dp).fillMaxHeight()
        )
        Box(
            Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF100D19), Color(0xFF100D19).copy(alpha = .88f), Color.Transparent)))
        )
        Column(Modifier.align(Alignment.CenterStart).padding(start = 19.dp, end = 112.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("BAATLY RIDES", color = Color(0xFFBCA0FF), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.6.sp)
            Text("Your city.\nYour ride.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 25.sp)
            Text("Bike • Auto • Car • SUV", color = Color(0xFFE2D9F0), fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
        Surface(Modifier.align(Alignment.BottomStart).padding(start = 18.dp, bottom = 10.dp), color = Color(0xFF682CC8), shape = RoundedCornerShape(20.dp)) {
            Text("Book in minutes", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
        }
    }
}

@Composable
private fun PandaSearchAnimation(modifier: Modifier = Modifier) {
    // 12-frame original 3D panda GIF: run (0-3), scan with magnifier (4-9), run again (10-11).
    // This composable is only shown while the ride is in the searching state, so the animation
    // naturally stops the moment a partner is assigned or the request is cancelled.
    val frames = listOf(com.example.R.drawable.baatly_panda_search_00, com.example.R.drawable.baatly_panda_search_01, com.example.R.drawable.baatly_panda_search_02, com.example.R.drawable.baatly_panda_search_03, com.example.R.drawable.baatly_panda_search_04, com.example.R.drawable.baatly_panda_search_05, com.example.R.drawable.baatly_panda_search_06, com.example.R.drawable.baatly_panda_search_07, com.example.R.drawable.baatly_panda_search_08, com.example.R.drawable.baatly_panda_search_09, com.example.R.drawable.baatly_panda_search_10, com.example.R.drawable.baatly_panda_search_11)
    var frameIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(150)
            frameIndex = (frameIndex + 1) % frames.size
        }
    }
    Image(
        painter = painterResource(id = frames[frameIndex]),
        contentDescription = "3D BAATLY panda running and searching for a ride partner",
        contentScale = ContentScale.Fit,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
private fun RestaurantPlaceholder() {
    Row(Modifier.fillMaxWidth().height(105.dp).clip(RoundedCornerShape(18.dp)).background(MobilityPanel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(75.dp).clip(RoundedCornerShape(14.dp)).background(MobilityPanel2))
        Spacer(Modifier.width(12.dp)); Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(Modifier.fillMaxWidth(.62f).height(13.dp).clip(CircleShape).background(MobilityPanel2))
            Box(Modifier.fillMaxWidth(.88f).height(9.dp).clip(CircleShape).background(MobilityPanel2))
            Box(Modifier.fillMaxWidth(.48f).height(9.dp).clip(CircleShape).background(MobilityPanel2))
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String, emoji: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MobilityPanel).padding(25.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 36.sp); Spacer(Modifier.height(8.dp))
        Text(title, color = MobilityWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(body, color = MobilityMuted, fontSize = 12.sp)
    }
}

private fun decodeGooglePolyline(encoded: String): List<LatLng> {
    if (encoded.isBlank()) return emptyList()
    val result = mutableListOf<LatLng>()
    var index = 0; var lat = 0; var lng = 0
    while (index < encoded.length) {
        var shift = 0; var value = 0; var b: Int
        do {
            if (index >= encoded.length) return result
            b = encoded[index++].code - 63
            value = value or ((b and 0x1f) shl shift)
            shift += 5
        } while (b >= 0x20)
        val deltaLat = if ((value and 1) != 0) (value shr 1).inv() else value shr 1
        lat += deltaLat
        shift = 0; value = 0
        do {
            if (index >= encoded.length) return result
            b = encoded[index++].code - 63
            value = value or ((b and 0x1f) shl shift)
            shift += 5
        } while (b >= 0x20)
        val deltaLng = if ((value and 1) != 0) (value shr 1).inv() else value shr 1
        lng += deltaLng
        result += LatLng(lat / 1E5, lng / 1E5)
    }
    return result
}

private fun statusLabel(status: String): String = when (status.lowercase()) {
    "searching" -> "Finding your partner"
    "accepted", "partner_assigned" -> "Partner assigned"
    "driver_arriving" -> "Partner is on the way"
    "arrived" -> "Partner has arrived"
    "in_progress", "picked_up", "on_the_way" -> "On the way"
    "preparing" -> "Restaurant is preparing your order"
    "ready" -> "Your order is ready"
    "delivered", "completed" -> "Completed"
    "cancelled" -> "Cancelled"
    "rejected" -> "Not accepted"
    else -> status.replace('_', ' ').replaceFirstChar { it.uppercase() }
}
