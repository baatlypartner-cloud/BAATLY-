package com.example.ui.mobility

import android.Manifest
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.mobility.MobilityPoint
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val BaatlyMapStart = LatLng(28.6139, 77.2090)

@Composable
fun MobilityMap(
    modifier: Modifier = Modifier,
    pickup: MobilityPoint? = null,
    drop: MobilityPoint? = null,
    driver: LatLng? = null,
    pin: LatLng? = null,
    onMapTap: ((LatLng) -> Unit)? = null,
    showRoute: Boolean = false,
    routePoints: List<LatLng> = emptyList()
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var googleMap by remember { mutableStateOf<GoogleMap?>(null) }
    val mapView = remember(context) { MapView(context).apply { onCreate(Bundle()); onResume() } }

    DisposableEffect(lifecycle, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            runCatching { mapView.onPause(); mapView.onDestroy() }
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { view ->
            mapView.getMapAsync { map ->
                googleMap = map
                map.uiSettings.isMapToolbarEnabled = false
                map.uiSettings.isCompassEnabled = true
                map.uiSettings.isZoomControlsEnabled = false
                map.mapType = GoogleMap.MAP_TYPE_NORMAL
                onMapTap?.let { callback -> map.setOnMapClickListener { callback(it) } }
            }
            mapView
        },
        update = { view ->
            // The map instance is updated below through Compose state.
        }
    )

    LaunchedEffect(googleMap, pickup, drop, driver, pin, showRoute, routePoints) {
        val map = googleMap ?: return@LaunchedEffect
        map.clear()
        val points = mutableListOf<LatLng>()
        pickup?.let {
            val p = LatLng(it.latitude, it.longitude); points += p
            map.addMarker(MarkerOptions().position(p).title("Pickup"))
        }
        drop?.let {
            val p = LatLng(it.latitude, it.longitude); points += p
            map.addMarker(MarkerOptions().position(p).title("Drop"))
        }
        driver?.let {
            points += it
            map.addMarker(MarkerOptions().position(it).title("Your partner"))
        }
        pin?.let {
            points += it
            map.addMarker(MarkerOptions().position(it).draggable(false).title("Selected location"))
        }
        if (showRoute && points.size >= 2) {
            val roadPath = routePoints.ifEmpty { listOf(points[0], points[1]) }
            if (roadPath.size >= 2) map.addPolyline(PolylineOptions().addAll(roadPath).width(7f))
        }
        if (points.isEmpty()) points += BaatlyMapStart
        val update = if (points.size == 1) CameraUpdateFactory.newLatLngZoom(points.first(), 15f)
        else CameraUpdateFactory.newLatLngBounds(
            com.google.android.gms.maps.model.LatLngBounds.Builder().apply { points.forEach(::include) }.build(), 110
        )
        runCatching { map.animateCamera(update) }
    }
}

@Composable
fun LocationPickerScreen(
    title: String,
    initial: MobilityPoint?,
    onDismiss: () -> Unit,
    onConfirm: (MobilityPoint) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var selectedLatLng by remember {
        mutableStateOf(initial?.let { LatLng(it.latitude, it.longitude) } ?: BaatlyMapStart)
    }
    var label by remember { mutableStateOf(initial?.address.orEmpty()) }
    // Delhi is only the initial map camera. It is never accepted until the user
    // explicitly chooses current location, a search result, or a map pin.
    var hasSelection by remember { mutableStateOf(initial != null) }
    var searching by remember { mutableStateOf(false) }
    var locating by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var searchResults by remember { mutableStateOf<List<Address>>(emptyList()) }

    BackHandler(onBack = onDismiss)

    fun reverseGeocode(latLng: LatLng, fallback: String = "Pinned location") {
        scope.launch {
            val address = withContext(Dispatchers.IO) {
                runCatching {
                    @Suppress("DEPRECATION")
                    Geocoder(context, Locale.getDefault()).getFromLocation(latLng.latitude, latLng.longitude, 1)
                        ?.firstOrNull()?.getAddressLine(0)
                }.getOrNull()
            }
            label = address?.takeIf { it.isNotBlank() } ?: fallback
        }
    }

    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val allowed = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (allowed) {
            locating = true
            LocationServices.getFusedLocationProviderClient(context).lastLocation
                .addOnSuccessListener { location ->
                    locating = false
                    if (location != null) {
                        selectedLatLng = LatLng(location.latitude, location.longitude)
                        hasSelection = true
                        reverseGeocode(selectedLatLng, "Current location")
                    } else message = "Current location is not available. Search or pin it on the map."
                }
                .addOnFailureListener { locating = false; message = "Could not read current location." }
        } else message = "Location permission is needed for current location. You can still search or pin manually."
    }

    fun chooseCurrentLocation() {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) {
            locating = true
            LocationServices.getFusedLocationProviderClient(context).lastLocation
                .addOnSuccessListener { location ->
                    locating = false
                    if (location != null) {
                        selectedLatLng = LatLng(location.latitude, location.longitude)
                        hasSelection = true
                        reverseGeocode(selectedLatLng, "Current location")
                    } else message = "Current location is not available. Search or pin it on the map."
                }
                .addOnFailureListener { locating = false; message = "Could not read current location. Please pin it on the map." }
        } else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    val ink = Color(0xFF251D35)
    val purple = Color(0xFF682CC8)
    val muted = Color(0xFF777086)
    val canvas = Color(0xFFF7F5FB)
    val confirmLabel = when {
        title.contains("pickup", ignoreCase = true) -> "Confirm pickup"
        title.contains("drop", ignoreCase = true) -> "Confirm drop"
        else -> "Confirm delivery address"
    }

    Box(Modifier.fillMaxSize().background(canvas)) {
        Column(Modifier.fillMaxSize().imePadding()) {
            Row(
                Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) { Icon(Icons.Default.ArrowBack, "Back", tint = ink) }
                Column(Modifier.weight(1f)) {
                    Text(title, color = ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Search an address or pin the exact point", color = muted, fontSize = 11.sp)
                }
                Surface(color = Color(0xFFF0ECF7), shape = CircleShape) {
                    Text("MAP", color = purple, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = {
                        query = it; message = null; searchResults = emptyList()
                        if (it.isNotBlank()) { hasSelection = false; label = "" }
                    },
                    modifier = Modifier.weight(1f), singleLine = true,
                    placeholder = { Text("Search area, building or landmark", color = muted) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = purple) },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ink, unfocusedTextColor = ink,
                        focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                        focusedBorderColor = purple, unfocusedBorderColor = Color(0xFFE3DDEC),
                        cursorColor = purple
                    )
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    enabled = query.isNotBlank() && !searching,
                    onClick = {
                        searching = true; message = null; searchResults = emptyList()
                        scope.launch {
                            val found = withContext(Dispatchers.IO) {
                                runCatching {
                                    @Suppress("DEPRECATION")
                                    Geocoder(context, Locale.getDefault()).getFromLocationName(query, 6)?.toList().orEmpty()
                                }.getOrDefault(emptyList())
                            }
                            searching = false
                            if (found.isNotEmpty()) searchResults = found
                            else message = "No matching place found. Try a nearby landmark."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = purple),
                    shape = RoundedCornerShape(15.dp), contentPadding = PaddingValues(horizontal = 17.dp, vertical = 16.dp)
                ) { if (searching) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Text("Search", color = Color.White, fontWeight = FontWeight.Bold) }
            }
            if (searchResults.isNotEmpty()) {
                LazyColumn(
                    Modifier.fillMaxWidth().heightIn(max = 190.dp).padding(horizontal = 14.dp)
                        .clip(RoundedCornerShape(16.dp)).background(Color.White),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(searchResults) { result ->
                        val resultAddress = result.getAddressLine(0).orEmpty()
                        Column(
                            Modifier.fillMaxWidth().clickable {
                                selectedLatLng = LatLng(result.latitude, result.longitude)
                                label = resultAddress.ifBlank { result.featureName.orEmpty().ifBlank { query } }
                                hasSelection = true; searchResults = emptyList()
                            }.padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text(result.featureName?.takeIf { it.isNotBlank() } ?: resultAddress.substringBefore(','), color = ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(resultAddress, color = muted, fontSize = 11.sp, maxLines = 2)
                        }
                        HorizontalDivider(color = Color(0xFFF0ECF7))
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp).clip(RoundedCornerShape(22.dp))) {
                MobilityMap(
                    modifier = Modifier.fillMaxSize(), pin = selectedLatLng.takeIf { hasSelection },
                    onMapTap = { point ->
                        selectedLatLng = point; hasSelection = true; searchResults = emptyList()
                        reverseGeocode(point)
                    }
                )
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
                    color = Color.White.copy(alpha = .96f), shape = RoundedCornerShape(30.dp), shadowElevation = 5.dp
                ) {
                    Text("Move map and tap to set the pin", color = ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp))
                }
                FilledTonalIconButton(
                    onClick = { chooseCurrentLocation() },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp),
                ) {
                    if (locating) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.MyLocation, "Use current location")
                }
            }
            Surface(
                modifier = Modifier.fillMaxWidth(), color = Color.White,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), shadowElevation = 12.dp
            ) {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("SELECT YOUR LOCATION", color = purple, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp)
                            Text(label.ifBlank { "Choose a search result or tap anywhere on the map" }, color = ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 2)
                        }
                        TextButton(onClick = { query = ""; searchResults = emptyList(); hasSelection = false; label = "" }) { Text("Change", color = purple) }
                    }
                    if (!message.isNullOrBlank()) Text(message.orEmpty(), color = Color(0xFFB43E64), fontSize = 11.sp)
                    Button(
                        onClick = {
                            onConfirm(MobilityPoint(
                                label = title,
                                address = label.ifBlank { "Pinned location" },
                                latitude = selectedLatLng.latitude,
                                longitude = selectedLatLng.longitude
                            ))
                        },
                        enabled = hasSelection,
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = purple, disabledContainerColor = Color(0xFFD8D2E2))
                    ) {
                        Icon(Icons.Default.Check, null)
                        Spacer(Modifier.width(8.dp))
                        Text(confirmLabel, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
