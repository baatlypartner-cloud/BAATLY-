# BAATLY User App v54 — Food, Cabs, Panda Artwork & R2 Update

## App changes

- Bumped Android app version to **54 / 1.0.54**.
- Mobility is a full-screen destination: the main BAATLY bottom navigation is hidden while Food & Cabs is open. The screen has its own back action, and Android back navigation returns through the full-screen map, cart, restaurant menu, and Food/Cabs tab.
- Pickup, drop and food-delivery address selection use the full-screen map/search page rather than a dialog. Search results, current-location permission, tap-to-pin, reverse geocoding and confirmation remain available.
- Added a premium light plum/purple and pink mobility surface with the existing 3D vehicle artwork and a new food hero image made from the supplied food artwork.
- Replaced the old static panda runner resource with 12 supplied 3D panda animation frames. The sequence loops through running, scanning/searching with the magnifier, and running again. It is displayed only while a ride is still searching and is removed when the ride changes to an assigned/active or terminal state.
- Food discovery includes restaurant/dish/cuisine search, cuisine shortcuts and restaurant filters. The restaurant menu now has its own dish search, Veg/Non-Veg/Egg filters and category chips. Cart quantities are editable, and returning from a menu no longer clears the cart.
- Added explicit cancellation-in-progress states for ride and food-order cancellation so duplicate taps are disabled while the server request is pending. Existing API-backed cancellation actions and terminal status handling remain in place.

## Cloudflare R2 media

- Signup, verified-phone profile completion and profile-photo updates now upload avatars to Cloudflare R2 with a short-lived signed upload URL.
- Chat image and voice-note uploads now use Cloudflare R2. Chat playback requests resolve through the private R2 endpoint and are checked against the message participants.
- Profile avatar resolution uses the signed private R2 endpoint and migrates an existing legacy Supabase Storage avatar to R2 on first authenticated access.
- Social feed/story delivery remains R2-backed. The deployed R2 function was updated to copy legacy social objects to R2 when the database already contains a canonical `social/posts/...` or `social/stories/...` key but that R2 object is missing.
- Restaurant/menu image loading continues through the mobility image URL service already present in the app.

## Live backend state

- Supabase project `qewhxsbrnlgunygghpez`: **`baatly-r2-media` v26, ACTIVE** (deployed in this update).
- `baatly-mobility-api` v7 was already active and exposes the customer ride-cancel and food-order-cancel actions used by the app; no new mobility API version was deployed in this update.

## Validation and limits

- Confirmed the source contains the 12 panda frames and new food hero asset, and no mobility `Dialog` / `AlertDialog` / `ModalBottomSheet` usage remains in the Food & Cabs module.
- Ran a Kotlin parser scan over the modified Kotlin files; no parser/syntax diagnostics were emitted. The command cannot perform a meaningful Android compile on its own because Android/Compose dependencies are not on the standalone compiler classpath.
- A full Gradle build/APK could not be completed in this environment: the wrapper requires Gradle 9.3.1 from `services.gradle.org`, but the distribution host was not reachable (DNS/network failure). Therefore this ZIP is an updated **source project**, not a verified APK.
- Live ride/order cancellation was not exercised against a real active booking. The UI is wired to the existing cancellation endpoints, but an actual customer booking is required for an end-to-end production test.
