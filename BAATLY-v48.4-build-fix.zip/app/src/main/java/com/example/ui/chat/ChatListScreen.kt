package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ConversationSummary
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(viewModel: BaatlyViewModel) {
    val conversations by viewModel.conversations.collectAsState()
    val isConversationsLoading by viewModel.isConversationsLoading.collectAsState()
    val conversationsError by viewModel.conversationsError.collectAsState()
    var selectedFilter by remember { mutableStateOf("Messages") }
    var selectedReadFilter by remember { mutableStateOf("All") }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        viewModel.refreshConversations()
        while (true) {
            kotlinx.coroutines.delay(15000)
            viewModel.refreshConversations()
        }
    }

    val typedConversations = remember(conversations, selectedFilter, selectedReadFilter, searchQuery) {
        val isLoveNote = selectedFilter == "Love Note"
        conversations.filter { conversation ->
            val belongs = if (isLoveNote) conversation.isApprovedHost else !conversation.isApprovedHost
            val matchesSearch = searchQuery.isBlank() || conversation.partnerName.contains(searchQuery, ignoreCase = true) || conversation.lastMessageText.contains(searchQuery, ignoreCase = true)
            val matchesReadState = selectedReadFilter == "All" || conversation.unreadCount > 0
            belongs && matchesSearch && matchesReadState
        }
    }

    Column(Modifier.fillMaxSize().background(DarkBackground)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text("Messages", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp)
                Text("Your conversations, all in one place", color = TextSecondary, fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = VibrantPink.copy(alpha = 0.9f), modifier = Modifier.size(28.dp))
                IconButton(onClick = { showSearch = !showSearch }, modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(DarkSurface).testTag("btn_messages_search")) {
                    Icon(Icons.Filled.Search, contentDescription = "Search messages", tint = VibrantPink, modifier = Modifier.size(25.dp))
                }
            }
        }

        Surface(shape = RoundedCornerShape(28.dp), color = DarkSurfaceVariant, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
            Row(Modifier.padding(4.dp)) {
                listOf("Messages", "Love Note").forEach { filter ->
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = if (selectedFilter == filter) VibrantPink else Color.Transparent,
                        modifier = Modifier.weight(1f).clickable { selectedFilter = filter }.testTag("tab_messages_${filter.lowercase().replace(' ', '_')}")
                    ) {
                        Box(Modifier.background(if (selectedFilter == filter) Brush.horizontalGradient(listOf(VibrantPink, PrimaryLavender)) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))).padding(vertical = 13.dp), contentAlignment = Alignment.Center) {
                            Text(filter, color = if (selectedFilter == filter) Color.White else TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf("All", "Unread").forEach { readFilter ->
                FilterChip(
                    selected = selectedReadFilter == readFilter,
                    onClick = { selectedReadFilter = readFilter },
                    label = { Text(readFilter, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VibrantPink,
                        selectedLabelColor = Color.White,
                        containerColor = DarkSurfaceVariant,
                        labelColor = TextPrimary
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedReadFilter == readFilter) VibrantPink else DarkCardBorder)
                )
            }
            if (selectedFilter == "Messages") {
                val unread = conversations.filter { !it.isApprovedHost && it.unreadCount > 0 }.sumOf { it.unreadCount }
                Text("$unread unread", color = TextSecondary, fontSize = 10.sp)
            } else {
                val unread = conversations.filter { it.isApprovedHost && it.unreadCount > 0 }.sumOf { it.unreadCount }
                Text("$unread unread", color = TextSecondary, fontSize = 10.sp)
            }
        }

        if (showSearch) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                singleLine = true,
                placeholder = { Text("Search chats") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(18.dp)
            )
        }

        PullToRefreshBox(
            isRefreshing = isConversationsLoading && conversations.isNotEmpty(),
            onRefresh = { viewModel.refreshConversations() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (selectedFilter == "Messages") {
                    item(key = "system_baatly_chat") {
                        BaatlySystemConversationItem(onClick = { viewModel.setScreen(Screen.BAATLY_SYSTEM_CHAT) })
                    }
                }
                if (isConversationsLoading && conversations.isEmpty()) {
                    item(key = "loading") {
                        Box(Modifier.fillMaxWidth().height(230.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = VibrantPink) }
                    }
                } else if (!conversationsError.isNullOrBlank() && conversations.isEmpty()) {
                    item(key = "error") {
                        Box(Modifier.fillMaxWidth().height(230.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(conversationsError ?: "Couldn't load conversations", color = DangerRed)
                                OutlinedButton(onClick = { viewModel.refreshConversations() }, shape = RoundedCornerShape(18.dp)) { Text("Try again", color = VibrantPink) }
                            }
                        }
                    }
                } else if (typedConversations.isEmpty()) {
                    item(key = "empty") {
                        Box(Modifier.fillMaxWidth().height(270.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                Icon(if (selectedFilter == "Love Note") Icons.Filled.Email else Icons.AutoMirrored.Filled.Chat, contentDescription = null, tint = Color(0xFF8F7AB5), modifier = Modifier.size(48.dp))
                                Text(if (selectedFilter == "Love Note") "No Love Note chats yet" else "No regular chats yet", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text(if (selectedFilter == "Love Note") "Conversations with approved hosts will appear here." else "Messages from other BAATLY members will appear here.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                } else {
                    items(typedConversations, key = { it.id }) { conversation ->
                        ConversationItem(
                            conversation = conversation,
                            currentUserId = viewModel.sessionManager.userId.value ?: viewModel.currentUser.value?.id.orEmpty(),
                            dataService = viewModel.dataService,
                            onClick = { viewModel.openConversation(conversation) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ConversationItem(
    conversation: ConversationSummary,
    currentUserId: String = "",
    dataService: com.example.data.network.SupabaseDataService? = null,
    onClick: () -> Unit
) {
    val partner = conversation.partner
    val partnerDisplayName = partner?.displayName?.takeIf { it.isNotBlank() && it != "Host" && it != "Baatly Host" && it != "Partner" }
        ?: partner?.displayName?.takeIf { it.isNotBlank() }
        ?: "Host"

    val resolvedAvatarUrl by com.example.ui.components.rememberResolvedProfileImageUrl(partner?.avatarUrl, dataService)
    val isResolvingAvatar = !partner?.avatarUrl.isNullOrBlank() && partner?.avatarUrl != "null" && resolvedAvatarUrl == null && dataService != null

    val previewText = when {
        conversation.lastMessageId.isNullOrBlank() -> "No messages"
        !conversation.lastMessageText.isNullOrBlank() -> conversation.lastMessageText
        conversation.lastMessageType == "voice" -> "🎙️ Voice message"
        conversation.lastMessageType == "gift" -> "🎁 Gift"
        conversation.lastMessageType == "image" -> "📷 Photo"
        else -> "Message"
    }

    val formattedTime = if (conversation.lastMessageId.isNullOrBlank()) "" else formatMessageTime(conversation.lastMessageAt)
    val unreadCount = if (conversation.lastMessageId.isNullOrBlank()) 0 else conversation.unreadCount

    val isOutgoingLastMessage = !conversation.lastMessageId.isNullOrBlank() &&
        !conversation.lastMessageSenderId.isNullOrBlank() &&
        currentUserId.isNotBlank() &&
        conversation.lastMessageSenderId == currentUserId

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF080F2D)),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (unreadCount > 0) PrimaryLavender.copy(alpha = 0.6f) else DarkCardBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Partner Avatar with online status
            Box {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(HostAvatarGradient)
                        .border(2.dp, if (unreadCount > 0) VibrantPink else if (partner?.isOnline == true) OnlineGreen else DarkBorderSubtle, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (!resolvedAvatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = resolvedAvatarUrl,
                            contentDescription = partnerDisplayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (isResolvingAvatar) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = PrimaryLavender,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = (partnerDisplayName.take(1)).uppercase(),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 20.sp
                            )
                        )
                    }
                }
                if (partner?.isOnline == true) {
                    Box(
                        modifier = Modifier
                            .size(13.dp)
                            .clip(CircleShape)
                            .background(OnlineGreen)
                            .border(2.dp, DarkSurface, CircleShape)
                            .align(Alignment.BottomEnd)
                    )
                }
            }

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = partnerDisplayName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = if (unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                            color = TextPrimary
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (formattedTime.isNotBlank()) {
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (unreadCount > 0) PrimaryLavender else TextTertiary,
                                fontWeight = if (unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isOutgoingLastMessage) {
                            val state = com.example.data.model.getMessageDeliveryState(
                                conversation.lastMessageDeliveredAt,
                                conversation.lastMessageSeenAt
                            )
                            val tickText = when (state) {
                                com.example.data.model.MessageDeliveryState.SEEN -> "✓✓"
                                com.example.data.model.MessageDeliveryState.DELIVERED -> "✓✓"
                                com.example.data.model.MessageDeliveryState.SENT -> "✓"
                            }
                            val tickColor = if (state == com.example.data.model.MessageDeliveryState.SEEN) WhatsAppTickBlue else WhatsAppTickGrey
                            Text(
                                text = tickText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = tickColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    letterSpacing = (-1).sp
                                )
                            )
                        }

                        Text(
                            text = previewText,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (unreadCount > 0) TextPrimary else TextSecondary,
                                fontWeight = if (unreadCount > 0) FontWeight.Medium else FontWeight.Normal
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (unreadCount > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(PrimaryLavender)
                                .padding(horizontal = 7.dp, vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (unreadCount > 99) "99+" else unreadCount.toString(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

fun formatMessageTime(rawTimestamp: String?): String {
    if (rawTimestamp.isNullOrBlank() || rawTimestamp.equals("null", ignoreCase = true)) return ""
    return try {
        if (!rawTimestamp.contains("T") && !rawTimestamp.contains("-")) {
            return rawTimestamp
        }
        val clean = rawTimestamp.replace("Z", "+00:00")
        val zdt = java.time.ZonedDateTime.parse(clean).withZoneSameInstant(java.time.ZoneId.systemDefault())
        val now = java.time.ZonedDateTime.now(java.time.ZoneId.systemDefault())
        val today = now.toLocalDate()
        val msgDate = zdt.toLocalDate()

        when {
            msgDate.isEqual(today) -> zdt.format(java.time.format.DateTimeFormatter.ofPattern("h:mm a"))
            msgDate.isEqual(today.minusDays(1)) -> "Yesterday"
            msgDate.year == today.year -> zdt.format(java.time.format.DateTimeFormatter.ofPattern("MMM d"))
            else -> zdt.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yy"))
        }
    } catch (_: Exception) {
        try {
            val datePart = rawTimestamp.substringBefore("T")
            val timePart = rawTimestamp.substringAfter("T").substringBefore(".").substringBefore("+").substringBefore("Z")
            if (timePart.isNotBlank() && timePart != rawTimestamp) {
                val parts = timePart.split(":")
                if (parts.size >= 2) {
                    val hour = parts[0].toIntOrNull() ?: 0
                    val minute = parts[1].toIntOrNull() ?: 0
                    val amPm = if (hour >= 12) "PM" else "AM"
                    val displayHour = if (hour % 12 == 0) 12 else hour % 12
                    val displayMin = if (minute < 10) "0$minute" else "$minute"
                    "$displayHour:$displayMin $amPm"
                } else {
                    datePart
                }
            } else {
                datePart
            }
        } catch (_: Exception) {
            ""
        }
    }
}

@Composable
fun BaatlySystemConversationItem(
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = DarkSurface
        ),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryLavender.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("baatly_system_chat_item")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // System Avatar / Shield
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(PrimaryLavender.copy(alpha = 0.15f))
                    .border(1.5.dp, PrimaryLavender, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Baatly Official",
                    tint = PrimaryLavender,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Baatly",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Official Verified",
                            tint = PrimaryLavender,
                            modifier = Modifier.size(16.dp)
                        )
                        Surface(
                            color = PrimaryLavender.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "SYSTEM",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = PrimaryLavender,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Text(
                        text = "Always Active",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = OnlineGreen,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Welcome to Baatly • Official support & safety rules",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = PrimaryLavender.copy(alpha = 0.9f),
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

