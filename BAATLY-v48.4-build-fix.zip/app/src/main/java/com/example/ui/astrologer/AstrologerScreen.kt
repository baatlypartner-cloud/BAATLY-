package com.example.ui.astrologer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Work
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ai.AiAstrologer
import com.example.data.ai.AiAstrologerMessage
import com.example.data.ai.AiAstrologerService
import com.example.data.ai.KundliReport
import com.example.data.ai.AiKundliSavedReport
import com.example.data.ai.AiAstrologerConversationPreview
import com.example.ui.BaatlyViewModel
import kotlinx.coroutines.launch
import java.util.UUID

private val AstroInk = Color(0xFF03091F)
private val AstroSurface = Color(0xFF0D1434)
private val AstroSurfaceAlt = Color(0xFF151B43)
private val AstroLilac = Color(0xFF6E3BFF)
private val AstroRose = Color(0xFFFF19B8)
private val AstroGold = Color(0xFFFFD45E)
private val AstroText = Color(0xFFF8F6FF)
private val AstroMuted = Color(0xFFB9C0E2)
private val AstroLine = Color(0xFF5839A3)
private val AstroOnline = Color(0xFF00E89A)

private enum class AstroMode { HOME, CHAT, KUNDLI_FORM, KUNDLI_REPORT, REPORTS, HISTORY }

@Composable
fun AstrologerScreen(viewModel: BaatlyViewModel) {
    val service = remember { AiAstrologerService(viewModel.sessionManager) }
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(AstroMode.HOME) }
    var astrologers by remember { mutableStateOf<List<AiAstrologer>>(emptyList()) }
    var selectedAstrologer by remember { mutableStateOf<AiAstrologer?>(null) }
    var conversationId by remember { mutableStateOf<String?>(null) }
    var messages by remember { mutableStateOf<List<AiAstrologerMessage>>(emptyList()) }
    var messageDraft by remember { mutableStateOf("") }
    var isLoadingAstrologers by remember { mutableStateOf(false) }
    var isLoadingHistory by remember { mutableStateOf(false) }
    var isSending by remember { mutableStateOf(false) }
    var homeError by remember { mutableStateOf<String?>(null) }
    var chatError by remember { mutableStateOf<String?>(null) }
    var isGeneratingKundli by remember { mutableStateOf(false) }
    var kundliError by remember { mutableStateOf<String?>(null) }
    var kundliReport by remember { mutableStateOf<KundliReport?>(null) }
    var savedReports by remember { mutableStateOf<List<AiKundliSavedReport>>(emptyList()) }
    var conversationHistory by remember { mutableStateOf<List<AiAstrologerConversationPreview>>(emptyList()) }
    var isLoadingReports by remember { mutableStateOf(false) }
    var isLoadingConversationHistory by remember { mutableStateOf(false) }
    var reportsError by remember { mutableStateOf<String?>(null) }
    var historyError by remember { mutableStateOf<String?>(null) }
    var fullName by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var birthTime by remember { mutableStateOf("") }
    var birthPlace by remember { mutableStateOf("") }

    fun refreshAstrologers() {
        if (isLoadingAstrologers) return
        isLoadingAstrologers = true
        homeError = null
        scope.launch {
            try {
                astrologers = service.listOnlineAstrologers()
            } catch (e: Exception) {
                homeError = e.message ?: "Online astrologers load nahi ho paaye."
            } finally {
                isLoadingAstrologers = false
            }
        }
    }

    fun openChat(astrologer: AiAstrologer, savedConversationId: String? = null) {
        selectedAstrologer = astrologer
        conversationId = null
        messages = emptyList()
        messageDraft = ""
        chatError = null
        mode = AstroMode.CHAT
        isLoadingHistory = true
        scope.launch {
            try {
                val history = if (savedConversationId.isNullOrBlank()) {
                    service.loadHistory(astrologer.id)
                } else {
                    service.loadConversationDetails(savedConversationId)
                }
                conversationId = history.conversationId
                messages = history.messages
            } catch (e: Exception) {
                chatError = e.message ?: "Chat history load nahi hui. Aap naya message bhej sakte hain."
            } finally {
                isLoadingHistory = false
            }
        }
    }

    fun sendChatMessage() {
        val astrologer = selectedAstrologer ?: return
        if (!astrologer.isOnline) {
            chatError = "Ye AI astrologer abhi offline hai. History padh sakte hain, naya message online hone par bhejein."
            return
        }
        val text = messageDraft.trim()
        if (text.isEmpty() || isSending) return
        messageDraft = ""
        chatError = null
        messages = messages + AiAstrologerMessage(UUID.randomUUID().toString(), "user", text)
        isSending = true
        scope.launch {
            try {
                val reply = service.sendMessage(astrologer.id, conversationId, text)
                conversationId = reply.conversationId
                messages = messages + AiAstrologerMessage(UUID.randomUUID().toString(), "astrologer", reply.reply)
            } catch (e: Exception) {
                chatError = e.message ?: "Message send nahi ho paaya. Dobara try karein."
            } finally {
                isSending = false
            }
        }
    }

    fun generateKundli() {
        if (isGeneratingKundli) return
        if (fullName.isBlank() || birthDate.isBlank() || birthTime.isBlank() || birthPlace.isBlank()) {
            kundliError = "Naam, janam ki date, time aur place sab bharein."
            return
        }
        isGeneratingKundli = true
        kundliError = null
        scope.launch {
            try {
                kundliReport = service.generateKundli(fullName, birthDate, birthTime, birthPlace)
                mode = AstroMode.KUNDLI_REPORT
            } catch (e: Exception) {
                kundliError = e.message ?: "Kundli generate nahi ho paayi. Dobara try karein."
            } finally {
                isGeneratingKundli = false
            }
        }
    }

    fun openReports() {
        mode = AstroMode.REPORTS
        isLoadingReports = true
        reportsError = null
        scope.launch {
            try { savedReports = service.loadMyReports() }
            catch (e: Exception) { reportsError = e.message ?: "Reports load nahi ho paaye." }
            finally { isLoadingReports = false }
        }
    }

    fun openHistory() {
        mode = AstroMode.HISTORY
        isLoadingConversationHistory = true
        historyError = null
        scope.launch {
            try { conversationHistory = service.loadConversationHistory() }
            catch (e: Exception) { historyError = e.message ?: "History load nahi hui." }
            finally { isLoadingConversationHistory = false }
        }
    }

    fun openSavedReport(item: AiKundliSavedReport) {
        kundliReport = KundliReport(
            reportId = item.reportId,
            fullName = item.fullName,
            birthDate = item.birthDate,
            birthTime = item.birthTime,
            birthPlace = item.birthPlace,
            interpretation = item.interpretation,
            chartData = item.chartData
        )
        mode = AstroMode.KUNDLI_REPORT
    }

    fun openHistoryConversation(item: AiAstrologerConversationPreview) {
        val known = astrologers.firstOrNull { it.id == item.astrologerId }
        openChat(known ?: AiAstrologer(
            id = item.astrologerId,
            slug = item.astrologerId,
            displayName = item.astrologerName,
            avatarUrl = null,
            intro = "Saved conversation history",
            language = "hi-Hinglish",
            isOnline = false
        ), item.conversationId)
    }

    LaunchedEffect(Unit) { refreshAstrologers() }
    BackHandler(enabled = mode != AstroMode.HOME) {
        mode = when (mode) {
            AstroMode.HOME -> AstroMode.HOME
            AstroMode.KUNDLI_REPORT -> AstroMode.HOME
            else -> AstroMode.HOME
        }
        chatError = null
    }

    when (mode) {
        AstroMode.HOME -> AstrologerHome(
            astrologers = astrologers,
            isLoading = isLoadingAstrologers,
            error = homeError,
            onRefresh = { refreshAstrologers() },
            onReports = { openReports() },
            onHistory = { openHistory() },
            onKundli = {
                kundliError = null
                mode = AstroMode.KUNDLI_FORM
            },
            onChatNow = { openChat(it) },
            onTopicSelected = { topic ->
                val astrologer = astrologers.firstOrNull()
                if (astrologer == null) {
                    homeError = "Abhi koi AI astrologer online nahi hai. Refresh karke dobara dekhein."
                } else {
                    openChat(astrologer)
                    messageDraft = "Mujhe $topic ke baare mein simple aur practical guidance dijiye."
                }
            }
        )
        AstroMode.CHAT -> AstrologerChat(
            astrologer = selectedAstrologer,
            messages = messages,
            draft = messageDraft,
            onDraftChange = { messageDraft = it.take(3000) },
            isLoadingHistory = isLoadingHistory,
            isSending = isSending,
            error = chatError,
            onBack = { mode = AstroMode.HOME; chatError = null },
            onSend = { sendChatMessage() }
        )
        AstroMode.KUNDLI_FORM -> KundliForm(
            fullName = fullName, onFullNameChange = { fullName = it.take(100) },
            birthDate = birthDate, onBirthDateChange = { birthDate = it.take(10) },
            birthTime = birthTime, onBirthTimeChange = { birthTime = it.take(5) },
            birthPlace = birthPlace, onBirthPlaceChange = { birthPlace = it.take(160) },
            isLoading = isGeneratingKundli, error = kundliError,
            onBack = { mode = AstroMode.HOME }, onGenerate = { generateKundli() }
        )
        AstroMode.KUNDLI_REPORT -> KundliReportScreen(
            report = kundliReport,
            onBack = { mode = AstroMode.HOME },
            onHome = { mode = AstroMode.HOME }
        )
        AstroMode.REPORTS -> AstroReportsScreen(
            reports = savedReports,
            isLoading = isLoadingReports,
            error = reportsError,
            onBack = { mode = AstroMode.HOME },
            onRetry = { openReports() },
            onOpenReport = { openSavedReport(it) }
        )
        AstroMode.HISTORY -> AstroHistoryScreen(
            history = conversationHistory,
            isLoading = isLoadingConversationHistory,
            error = historyError,
            onBack = { mode = AstroMode.HOME },
            onRetry = { openHistory() },
            onOpenConversation = { openHistoryConversation(it) }
        )
    }
}

@Composable
private fun AstrologerHome(
    astrologers: List<AiAstrologer>,
    isLoading: Boolean,
    error: String?,
    onRefresh: () -> Unit,
    onReports: () -> Unit,
    onHistory: () -> Unit,
    onKundli: () -> Unit,
    onChatNow: (AiAstrologer) -> Unit,
    onTopicSelected: (String) -> Unit
) {
    val topics = listOf(
        "☀" to "Daily Horoscope", "♡" to "Love & Relationship", "↗" to "Career & Finance",
        "♧" to "Health & Wellness", "♾" to "Marriage Matching", "◇" to "Gemstone Advice", "♜" to "Puja & Remedies"
    )
    val tools = listOf(
        Triple("♡", "Kundli Matching", "Check compatibility"),
        Triple("▧", "Tarot Reading", "Guidance for questions"),
        Triple("123", "Numerology", "Explore lucky numbers"),
        Triple("▦", "Panchang", "Tithi and muhurat")
    )
    val articles = listOf(
        Triple("☼", "Daily Rashifal", "Aaj ka din kaisa rahega?"),
        Triple("♡", "Love Horoscope", "Rishte aur compatibility"),
        Triple("₹", "Career Forecast", "Career aur kaam par guidance"),
        Triple("◇", "Gemstone Guide", "Ratnon ki paramparik jankari")
    )
    Column(
        modifier = Modifier.fillMaxSize().background(AstroInk).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(AstroRose, AstroLilac))), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("Astrology", color = AstroText, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text("Kundli aur AI Pandit se margdarshan", color = AstroMuted, fontSize = 11.sp)
            }
            AstroHeaderAction("My Reports", Icons.Outlined.Description, onReports)
            AstroHeaderAction("History", Icons.Outlined.History, onHistory)
        }

        Surface(Modifier.fillMaxWidth().height(258.dp), shape = RoundedCornerShape(22.dp), color = AstroSurface, border = BorderStroke(1.dp, AstroRose)) {
            Box {
                Image(
                    painter = painterResource(id = com.example.R.drawable.astrology_hero_ref),
                    contentDescription = "Vedic astrology kundli illustration",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xF0060A25), Color(0xD9060A25), Color(0x22060925)))))
                Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.68f).padding(start = 18.dp, top = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("JANAM KUNDLI", color = AstroGold, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Apni kundli banayein", color = AstroText, fontSize = 25.sp, lineHeight = 29.sp, fontWeight = FontWeight.Black)
                    Text("Janam ki details daalein aur apni kundli report dekhein.", color = AstroMuted, fontSize = 12.sp, lineHeight = 17.sp)
                    Button(onClick = onKundli, shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = AstroRose), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)) {
                        Icon(Icons.Outlined.MenuBook, contentDescription = null, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(7.dp)); Text("Kundli Banaye", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.width(4.dp)); Icon(Icons.Outlined.ChevronRight, contentDescription = null)
                    }
                }
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 1.dp)) {
            items(topics.size) { index ->
                val (glyph, title) = topics[index]
                AstroTopicCard(glyph, title, Modifier.width(106.dp).height(112.dp)) { onTopicSelected(title) }
            }
        }

        Surface(Modifier.fillMaxWidth().clickable { onTopicSelected("general life guidance") }, shape = RoundedCornerShape(22.dp), color = AstroSurface, border = BorderStroke(1.dp, Color(0xFF4D41D3))) {
            Row(Modifier.background(Brush.horizontalGradient(listOf(Color(0xFF11113C), Color(0xFF17124E), Color(0xFF0C214A)))).padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Image(
                    painter = painterResource(id = com.example.R.drawable.astrology_ai_robot_ref),
                    contentDescription = "BAATLY AI astrologer assistant",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.width(74.dp).height(82.dp).clip(RoundedCornerShape(16.dp))
                )
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Chat with AI Astrologer", color = AstroText, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Surface(color = Color(0xFF68430F), shape = RoundedCornerShape(7.dp), border = BorderStroke(1.dp, AstroGold)) {
                            Text("♛ PRO", color = AstroGold, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                        }
                    }
                    Text("Get instant answers to your life questions with AI based on Vedic astrology.", color = AstroMuted, fontSize = 10.sp, lineHeight = 14.sp)
                }
                Button(onClick = { onTopicSelected("general life guidance") }, shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = AstroRose), contentPadding = PaddingValues(horizontal = 13.dp, vertical = 10.dp)) {
                    Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Start Chat", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Online AI Astrologers", color = AstroText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Available now", color = AstroMuted, fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(AstroOnline))
                Text("${astrologers.size} available now", color = AstroOnline, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("›", color = AstroText, fontSize = 25.sp, modifier = Modifier.clickable(onClick = onRefresh).padding(start = 4.dp))
            }
        }
        if (isLoading && astrologers.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(vertical = 26.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AstroRose) }
        } else if (error != null && astrologers.isEmpty()) {
            StateMessage("Astrologers load nahi hue", error, "Dobara try karein", onRefresh)
        } else if (astrologers.isEmpty()) {
            StateMessage("Abhi koi AI astrologer online nahi hai", "Online hone par astrologers yahan dikh jayenge.", "Refresh", onRefresh)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 2.dp)) {
                items(astrologers, key = { it.id }) { astrologer -> Box(Modifier.width(250.dp)) { AstrologerCard(astrologer = astrologer, onChatNow = { onChatNow(astrologer) }) } }
            }
        }

        AstroSectionHeader("Your Astrology Tools", "See all", onClick = { onTopicSelected("astrology tools") })
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tools.size) { index ->
                val item = tools[index]
                AstroSmallFeatureCard(item.first, item.second, item.third, Modifier.width(205.dp)) { onTopicSelected(item.second) }
            }
        }
        AstroSectionHeader("Astrology Articles & Insights", "See all", onClick = { onTopicSelected("astrology articles and insights") })
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(articles.size) { index ->
                val item = articles[index]
                AstroArticleCard(item.first, item.second, item.third) { onTopicSelected(item.second) }
            }
        }
        Text("Astrology paramparik vishwas par aadharit hai; ise pakki ya scientific prediction na samjhein.", color = AstroMuted.copy(alpha = 0.82f), fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 2.dp, bottom = 18.dp))
    }
}

@Composable
private fun AstroHeaderAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(Modifier.height(42.dp).clickable(onClick = onClick), shape = RoundedCornerShape(15.dp), color = AstroSurface, border = BorderStroke(1.dp, AstroLine)) {
        Row(Modifier.padding(horizontal = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(icon, contentDescription = title, tint = AstroRose, modifier = Modifier.size(18.dp))
            Text(title, color = AstroText, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun AstroSectionHeader(title: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = AstroText, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(action, color = AstroMuted, fontSize = 10.sp, modifier = Modifier.clickable(onClick = onClick))
        Text("  ›", color = AstroRose, fontSize = 20.sp)
    }
}

@Composable
private fun AstroSmallFeatureCard(glyph: String, title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.height(88.dp).clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), color = AstroSurface, border = BorderStroke(1.dp, AstroLine)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(AstroRose.copy(alpha = 0.35f), AstroLilac.copy(alpha = 0.35f)))), contentAlignment = Alignment.Center) {
                Text(glyph, color = AstroRose, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = AstroText, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, color = AstroMuted, fontSize = 9.sp, maxLines = 2, lineHeight = 12.sp)
            }
            Icon(Icons.Outlined.ChevronRight, contentDescription = null, tint = AstroRose, modifier = Modifier.size(17.dp))
        }
    }
}

@Composable
private fun AstroArticleCard(glyph: String, title: String, subtitle: String, onClick: () -> Unit) {
    val artwork = when (title) {
        "Daily Rashifal" -> com.example.R.drawable.astrology_article_daily_ref
        "Love Horoscope" -> com.example.R.drawable.astrology_article_love_ref
        "Career Forecast" -> com.example.R.drawable.astrology_article_career_ref
        else -> com.example.R.drawable.astrology_article_gemstone_ref
    }
    Column(Modifier.width(184.dp).clip(RoundedCornerShape(15.dp)).background(AstroSurface).border(1.dp, AstroLine, RoundedCornerShape(15.dp)).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().height(76.dp).background(Brush.linearGradient(listOf(Color(0xFF35126D), Color(0xFF0D2A65), Color(0xFF69145B))))) {
            Image(painter = painterResource(artwork), contentDescription = title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x9903091F)))))
            if (title.isBlank()) Text(glyph, color = AstroGold, fontSize = 36.sp, fontWeight = FontWeight.Black)
        }
        Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = AstroText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = AstroMuted, fontSize = 9.sp, maxLines = 2)
        }
    }
}

@Composable
private fun AstroReportsScreen(
    reports: List<AiKundliSavedReport>, isLoading: Boolean, error: String?,
    onBack: () -> Unit, onRetry: () -> Unit, onOpenReport: (AiKundliSavedReport) -> Unit
) {
    Column(Modifier.fillMaxSize().background(AstroInk).statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = AstroText) }
            Text("My Reports", color = AstroText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        when {
            isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AstroRose) }
            !error.isNullOrBlank() -> StateMessage("Reports load nahi hue", error, "Retry", onRetry)
            reports.isEmpty() -> StateMessage("Abhi koi report save nahi hai", "Kundli generate karne ke baad aapki reports yahan dikhenge.", "Kundli banayein", onBack)
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                items(reports, key = { it.reportId }) { item ->
                    Surface(Modifier.fillMaxWidth().clickable { onOpenReport(item) }, color = AstroSurface, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, AstroLine)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(Icons.Outlined.Description, contentDescription = null, tint = AstroRose, modifier = Modifier.size(32.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(item.fullName, color = AstroText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("${item.birthDate} · ${item.birthTime} · ${item.birthPlace}", color = AstroMuted, fontSize = 10.sp, maxLines = 2)
                                Text(item.createdAt.take(10), color = AstroGold, fontSize = 10.sp)
                            }
                            Icon(Icons.Outlined.ChevronRight, contentDescription = "Open report", tint = AstroRose)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AstroHistoryScreen(
    history: List<AiAstrologerConversationPreview>, isLoading: Boolean, error: String?,
    onBack: () -> Unit, onRetry: () -> Unit, onOpenConversation: (AiAstrologerConversationPreview) -> Unit
) {
    Column(Modifier.fillMaxSize().background(AstroInk).statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = AstroText) }
            Text("Astrology History", color = AstroText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        when {
            isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AstroRose) }
            !error.isNullOrBlank() -> StateMessage("History load nahi hui", error, "Retry", onRetry)
            history.isEmpty() -> StateMessage("Abhi koi chat history nahi hai", "AI Astrologer se chat karne par conversations yahan save hongi.", "Back to Astrology", onBack)
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                items(history, key = { it.conversationId }) { item ->
                    Surface(Modifier.fillMaxWidth().clickable { onOpenConversation(item) }, color = AstroSurface, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, AstroLine)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(46.dp).clip(CircleShape).background(Brush.linearGradient(listOf(AstroRose, AstroLilac))), contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null, tint = Color.White)
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(item.astrologerName, color = AstroText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(item.lastMessage.ifBlank { "Conversation started" }, color = AstroMuted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(item.updatedAt.take(16).replace('T', ' '), color = AstroGold, fontSize = 9.sp)
                            }
                            Icon(Icons.Outlined.ChevronRight, contentDescription = "Open history", tint = AstroRose)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AstroTopicCard(glyph: String, title: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Color(0xFF11183C), Color(0xFF0B1230)))).border(1.dp, Brush.horizontalGradient(listOf(AstroRose, AstroLilac)), RoundedCornerShape(15.dp)).clickable(onClick = onClick).padding(horizontal = 5.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF111A54), Color(0xFF291154)))), contentAlignment = Alignment.Center) {
            Text(glyph, color = when (title) { "Daily Horoscope", "Puja & Remedies" -> AstroGold; "Love & Relationship" -> AstroRose; else -> Color(0xFFBDA0FF) }, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        Text(title, color = AstroText, fontSize = 8.sp, fontWeight = FontWeight.SemiBold, lineHeight = 10.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun AstrologerCard(astrologer: AiAstrologer, onChatNow: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = AstroSurface,
        border = BorderStroke(1.dp, AstroLine)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(62.dp)) {
                    if (!astrologer.avatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = astrologer.avatarUrl,
                            contentDescription = astrologer.displayName,
                            modifier = Modifier.fillMaxSize().clip(CircleShape)
                        )
                    } else {
                        Box(Modifier.fillMaxSize().clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF6A4C93), Color(0xFFBD8AD7)))), contentAlignment = Alignment.Center) {
                            Text("ॐ", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Box(
                        Modifier.align(Alignment.BottomEnd).size(14.dp).clip(CircleShape)
                            .background(if (astrologer.isOnline) AstroOnline else AstroMuted)
                            .padding(2.dp).clip(CircleShape).background(AstroSurface)
                    )
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(astrologer.displayName, color = AstroText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(AstroOnline))
                        Text("Online now", color = AstroOnline, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text("· AI Astrologer", color = AstroMuted, fontSize = 11.sp)
                    }
                    Text(astrologer.intro, color = AstroMuted, fontSize = 12.sp, lineHeight = 17.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
            Button(
                onClick = onChatNow,
                modifier = Modifier.fillMaxWidth().height(47.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AstroLilac, contentColor = AstroInk)
            ) {
                Text("Chat Now", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Outlined.ChevronRight, contentDescription = null)
            }
        }
    }
}

@Composable
private fun AstrologerChat(
    astrologer: AiAstrologer?,
    messages: List<AiAstrologerMessage>,
    draft: String,
    onDraftChange: (String) -> Unit,
    isLoadingHistory: Boolean,
    isSending: Boolean,
    error: String?,
    onBack: () -> Unit,
    onSend: () -> Unit
) {
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, isSending) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }
    Column(Modifier.fillMaxSize().background(AstroInk).statusBarsPadding().imePadding()) {
        Row(
            Modifier.fillMaxWidth().background(AstroSurface).padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = AstroText) }
            Box(Modifier.size(43.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF6A4C93), Color(0xFFBD8AD7)))), contentAlignment = Alignment.Center) {
                Text("ॐ", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f)) {
                Text(astrologer?.displayName ?: "AI Astrologer", color = AstroText, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("AI Astrologer · Online", color = AstroOnline, fontSize = 11.sp)
            }
        }
        Surface(color = AstroSurfaceAlt, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 15.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = AstroGold, modifier = Modifier.size(16.dp))
                Text("Chat ka charge ₹2 per message hai.", color = AstroMuted, fontSize = 11.sp)
            }
        }
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
            state = listState,
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            if (messages.isEmpty() && !isLoadingHistory) {
                item {
                    ChatBubble(
                        message = AiAstrologerMessage("welcome", "astrologer", "Namaste! Main Pandit Ji, BAATLY ka AI astrologer hoon. Aap apna sawal pooch sakte hain. Kundli se juda sawal hai to janam ki date, time aur jagah batayein."),
                        isUser = false
                    )
                }
            }
            items(messages, key = { it.id }) { message ->
                ChatBubble(message = message, isUser = message.senderType == "user")
            }
            if (isLoadingHistory) item { SmallStatus("Purani chat load ho rahi hai…") }
            if (isSending) item { SmallStatus("Pandit Ji jawab taiyar kar rahe hain…") }
            if (error != null) item { Text(error, color = Color(0xFFFFA6B4), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp)) }
        }
        Row(
            Modifier.fillMaxWidth().background(AstroSurface).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = onDraftChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Pandit Ji se poochhein…", color = AstroMuted) },
                maxLines = 4,
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = AstroText, unfocusedTextColor = AstroText,
                    focusedBorderColor = AstroLilac, unfocusedBorderColor = AstroLine,
                    cursorColor = AstroLilac, focusedContainerColor = AstroInk, unfocusedContainerColor = AstroInk
                )
            )
            IconButton(
                onClick = onSend,
                enabled = draft.isNotBlank() && !isSending,
                modifier = Modifier.size(50.dp).clip(CircleShape).background(if (draft.isNotBlank() && !isSending) AstroLilac else AstroLine)
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = AstroInk) }
        }
    }
}

@Composable
private fun ChatBubble(message: AiAstrologerMessage, isUser: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Surface(
            modifier = Modifier.widthIn(max = 320.dp),
            shape = RoundedCornerShape(topStart = 19.dp, topEnd = 19.dp, bottomStart = if (isUser) 19.dp else 5.dp, bottomEnd = if (isUser) 5.dp else 19.dp),
            color = if (isUser) Color(0xFF7760C8) else AstroSurface,
            border = if (isUser) null else BorderStroke(1.dp, AstroLine)
        ) {
            Text(message.content, color = AstroText, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp))
        }
    }
}

@Composable
private fun SmallStatus(text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(14.dp), color = AstroLilac, strokeWidth = 2.dp)
        Spacer(Modifier.width(8.dp))
        Text(text, color = AstroMuted, fontSize = 11.sp)
    }
}

@Composable
private fun KundliForm(
    fullName: String, onFullNameChange: (String) -> Unit,
    birthDate: String, onBirthDateChange: (String) -> Unit,
    birthTime: String, onBirthTimeChange: (String) -> Unit,
    birthPlace: String, onBirthPlaceChange: (String) -> Unit,
    isLoading: Boolean, error: String?, onBack: () -> Unit, onGenerate: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().background(AstroInk).statusBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = AstroText) }
            Column {
                Text("Janam Kundli", color = AstroText, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("Apni birth details bharein", color = AstroMuted, fontSize = 12.sp)
            }
        }
        Surface(shape = RoundedCornerShape(22.dp), color = AstroSurface, border = BorderStroke(1.dp, AstroLine)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = AstroGold, modifier = Modifier.size(25.dp))
                Text("Aapki kundli, aapke janam ke details se", color = AstroText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Sahi date, local birth time aur birth place dena zaroori hai.", color = AstroMuted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
        AstroInput(value = fullName, onValueChange = onFullNameChange, label = "Poora naam", placeholder = "Apna naam", leading = { Icon(Icons.Outlined.PersonOutline, null, tint = AstroMuted) })
        AstroInput(value = birthDate, onValueChange = onBirthDateChange, label = "Janam ki tareekh", placeholder = "YYYY-MM-DD · 2000-01-31", leading = { Icon(Icons.Outlined.CalendarMonth, null, tint = AstroMuted) }, keyboardType = KeyboardType.Ascii)
        AstroInput(value = birthTime, onValueChange = onBirthTimeChange, label = "Janam ka samay (24-hour)", placeholder = "HH:MM · 07:35", leading = { Icon(Icons.Outlined.AccessTime, null, tint = AstroMuted) }, keyboardType = KeyboardType.Ascii)
        AstroInput(value = birthPlace, onValueChange = onBirthPlaceChange, label = "Janam ki jagah", placeholder = "Gaon / shehar, zila, rajya", leading = { Icon(Icons.Outlined.LocationOn, null, tint = AstroMuted) })
        Text(
            "Privacy: Kundli banane par aapki birth details chart-calculation service ko bheji jayengi aur report aapke BAATLY account mein save hogi.",
            color = AstroMuted, fontSize = 10.sp, lineHeight = 15.sp
        )
        error?.let { Text(it, color = Color(0xFFFFA6B4), fontSize = 12.sp) }
        Button(
            onClick = onGenerate, enabled = !isLoading,
            modifier = Modifier.fillMaxWidth().height(53.dp), shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AstroGold, contentColor = AstroInk)
        ) {
            if (isLoading) CircularProgressIndicator(Modifier.size(19.dp), color = AstroInk, strokeWidth = 2.dp)
            else Icon(Icons.Outlined.MenuBook, contentDescription = null)
            Spacer(Modifier.width(9.dp))
            Text(if (isLoading) "Kundli ban rahi hai…" else "Generate Kundli", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun AstroInput(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    leading: @Composable () -> Unit,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, modifier = Modifier.fillMaxWidth(),
        label = { Text(label) }, placeholder = { Text(placeholder, color = AstroMuted.copy(alpha = 0.75f)) },
        leadingIcon = leading, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = AstroText, unfocusedTextColor = AstroText,
            focusedBorderColor = AstroLilac, unfocusedBorderColor = AstroLine,
            focusedLabelColor = AstroLilac, unfocusedLabelColor = AstroMuted,
            cursorColor = AstroLilac, focusedContainerColor = AstroSurface, unfocusedContainerColor = AstroSurface
        )
    )
}

@Composable
private fun KundliReportScreen(report: KundliReport?, onBack: () -> Unit, onHome: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(AstroInk).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = AstroText) }
            Column {
                Text("Aapki Janam Kundli", color = AstroText, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text("Pandit Ji · AI interpretation", color = AstroMuted, fontSize = 12.sp)
            }
        }
        if (report == null) {
            StateMessage("Report nahi mili", "Kundli dobara generate karein.", "Wapas jaayein", onBack)
        } else {
            Surface(shape = RoundedCornerShape(22.dp), color = AstroSurface, border = BorderStroke(1.dp, AstroLine)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = AstroOnline)
                        Text("Kundli report tayyar hai", color = AstroOnline, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text(report.fullName, color = AstroText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("${report.birthDate} · ${report.birthTime} · ${report.birthPlace}", color = AstroMuted, fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
            Surface(shape = RoundedCornerShape(22.dp), color = AstroSurface, border = BorderStroke(1.dp, AstroLine)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Janam Kundli Reading", color = AstroGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(report.interpretation, color = AstroText, fontSize = 14.sp, lineHeight = 22.sp)
                }
            }
            Text("Astrology paramparik vishwas par aadharit hai; ise pakki ya scientific prediction na samjhein.", color = AstroMuted, fontSize = 10.sp, lineHeight = 15.sp)
            Button(onClick = onHome, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = AstroLilac, contentColor = AstroInk)) {
                Text("Astrology Home", fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun StateMessage(title: String, message: String, buttonText: String, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = AstroSurface, border = BorderStroke(1.dp, AstroLine), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = AstroLilac, modifier = Modifier.size(27.dp))
            Text(title, color = AstroText, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(message, color = AstroMuted, fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 18.sp)
            OutlinedButton(onClick = onClick, border = BorderStroke(1.dp, AstroLilac), colors = ButtonDefaults.outlinedButtonColors(contentColor = AstroText)) {
                Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(buttonText)
            }
        }
    }
}
