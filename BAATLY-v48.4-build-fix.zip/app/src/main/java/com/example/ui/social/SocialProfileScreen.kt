package com.example.ui.social

import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.SocialPost
import com.example.data.model.SocialHighlight
import com.example.ui.BaatlyViewModel
import com.example.ui.media.BaatlyVideoPlayer
import com.example.ui.components.rememberResolvedProfileImageUrl
import com.example.ui.Screen
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val Plum = Color(0xFFF7F2FF)
private val Cream = Color(0xFF070817)
private val SocialSoftPink = Color(0xFF242044)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialProfileScreen(viewModel: BaatlyViewModel) {
    val targetUserId by viewModel.socialProfileTargetUserId.collectAsState()
    val ownProfile by viewModel.mySocialProfile.collectAsState()
    val ownPosts by viewModel.mySocialPosts.collectAsState()
    val viewedProfile by viewModel.viewedSocialProfile.collectAsState()
    val viewedPosts by viewModel.viewedSocialPosts.collectAsState()
    val stories by viewModel.socialStories.collectAsState()
    val authUserId by viewModel.sessionManager.userId.collectAsState()
    val isOwn = targetUserId.isNullOrBlank()
    val profile = if (isOwn) ownProfile else viewedProfile
    val posts = if (isOwn) ownPosts else viewedPosts
    val resolvedProfileAvatar by rememberResolvedProfileImageUrl(profile?.avatarUrl, viewModel.dataService)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf("Posts") }
    var showCreateHighlightDialog by remember { mutableStateOf(false) }
    var highlightTitle by remember { mutableStateOf("") }
    var selectedStoryId by remember { mutableStateOf<String?>(null) }
    var isSavingHighlight by remember { mutableStateOf(false) }
    var highlights by remember { mutableStateOf<List<SocialHighlight>>(emptyList()) }
    var relationshipKind by remember { mutableStateOf<String?>(null) }
    var relationshipPeople by remember { mutableStateOf(emptyList<com.example.data.model.SocialProfile>()) }
    var relationshipLoading by remember { mutableStateOf(false) }
    var showFollowRequests by remember { mutableStateOf(false) }
    var showInsights by remember { mutableStateOf(false) }
    var followRequests by remember { mutableStateOf(emptyList<com.example.data.model.SocialFollowRequest>()) }
    var gridPost by remember { mutableStateOf<SocialPost?>(null) }
    var profileCommentTarget by remember { mutableStateOf<SocialPost?>(null) }

    val shareProfile: () -> Unit = {
        val display = profile?.displayName?.takeIf { it.isNotBlank() } ?: "BAATLY member"
        val handle = profile?.username?.takeIf { it.isNotBlank() }?.let { "\nUsername: @$it" }.orEmpty()
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Find me on BAATLY: $display$handle\nBAATLY profile ID: ${profile?.userId.orEmpty()}")
        }
        runCatching { context.startActivity(Intent.createChooser(shareIntent, "Share BAATLY profile")) }
            .onFailure { viewModel.showUserMessage("Could not open the share menu") }
    }
    val copyProfileId: () -> Unit = {
        val id = profile?.userId.orEmpty()
        if (id.isNotBlank()) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            clipboard?.setPrimaryClip(ClipData.newPlainText("BAATLY profile ID", id))
            viewModel.showUserMessage("Profile ID copied")
        } else viewModel.showUserMessage("Profile ID is not available")
    }

    val saveHighlightFromPickedMedia: (Uri) -> Unit = { uri ->
        val title = highlightTitle.trim().take(40)
        if (title.isBlank()) {
            viewModel.showUserMessage("Enter a Highlight name first")
        } else if (!isSavingHighlight) {
            isSavingHighlight = true
            scope.launch {
                viewModel.dataService.createSocialHighlightFromMedia(context, uri, title).onSuccess {
                    viewModel.dataService.getSocialHighlights(targetUserId).onSuccess { highlights = it }
                    showCreateHighlightDialog = false
                    viewModel.showUserMessage("Highlight saved")
                }.onFailure { error ->
                    viewModel.showUserMessage("Couldn't save Highlight: ${error.message ?: "please retry"}")
                }
                isSavingHighlight = false
            }
        }
    }
    val highlightPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveHighlightFromPickedMedia(uri)
    }
    val highlightVideoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveHighlightFromPickedMedia(uri)
    }

    LaunchedEffect(targetUserId) {
        if (targetUserId.isNullOrBlank()) {
            viewModel.loadMySocialProfile()
            viewModel.refreshSocialStories()
        }
        viewModel.dataService.getSocialHighlights(targetUserId).onSuccess { highlights = it }
            .onFailure { viewModel.showUserMessage("Couldn't load Highlights: ${it.message ?: "please retry"}") }
    }

    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = { viewModel.setScreen(Screen.SOCIAL) }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Plum) }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                Text("BAATLY", color = Plum, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("S O C I A L  M E D I A", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 7.sp, letterSpacing = 1.1.sp)
            }
            if (isOwn) {
                IconButton(onClick = shareProfile) { Icon(Icons.Filled.Share, contentDescription = "Share profile", tint = Plum) }
                IconButton(onClick = copyProfileId) { Icon(Icons.Filled.GridOn, contentDescription = "Copy profile ID", tint = Plum) }
            }
            IconButton(onClick = { if (isOwn) viewModel.setScreen(Screen.PROFILE) else viewModel.showUserMessage("More profile actions will appear here") }) {
                Icon(if (isOwn) Icons.Filled.Settings else Icons.Filled.MoreHoriz, contentDescription = "Profile options", tint = Plum)
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Box(Modifier.size(116.dp)) {
                    Box(Modifier.fillMaxSize().clip(CircleShape).background(Brush.sweepGradient(listOf(VibrantPink, Color(0xFF6A42FF), Color(0xFFFFB703), VibrantPink))).padding(4.dp)) {
                        AsyncImage(model = resolvedProfileAvatar, contentDescription = "Profile photo", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape).background(SocialSoftPink))
                    }
                    if (isOwn) Surface(Modifier.align(Alignment.BottomEnd).size(34.dp).clickable { viewModel.setScreen(Screen.PROFILE) }, color = VibrantPink, shape = CircleShape, border = androidx.compose.foundation.BorderStroke(2.dp, DarkBackground)) {
                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.CameraAlt, contentDescription = "Change profile photo", tint = Color.White, modifier = Modifier.size(17.dp)) }
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(profile?.username?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: profile?.displayName?.ifBlank { "BAATLY member" } ?: "BAATLY member", color = Plum, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (profile?.isHost == true) Text("✦", color = Color(0xFFFFD45E), fontSize = 15.sp)
                    }
                    Text(profile?.displayName?.takeIf { it.isNotBlank() } ?: "BAATLY member", color = Plum, fontSize = 13.sp)
                    if (profile?.isHost == true) {
                        Surface(color = Color(0xFF33220D), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFC857))) {
                            Text("♛ BAATLY Creator", color = Color(0xFFFFD45E), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                    }
                    profile?.bio?.takeIf { it.isNotBlank() }?.let { bio ->
                        Text(bio, color = TextSecondary, fontSize = 11.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ProfileStat(profile?.postsCount ?: posts.size, "Posts", modifier = Modifier.weight(1f))
                ProfileStat(profile?.followersCount ?: 0, "Followers", modifier = Modifier.weight(1f)) {
                    if (!isOwn && profile?.isPrivate == true && profile?.isFollowing != true) {
                        viewModel.showUserMessage("Follow this private account to view its followers")
                    } else {
                        relationshipKind = "followers"
                        relationshipPeople = emptyList()
                        relationshipLoading = true
                        scope.launch { viewModel.dataService.getSocialRelationshipList(profile?.userId ?: authUserId.orEmpty(), "followers").onSuccess { relationshipPeople = it }.onFailure { viewModel.showUserMessage("Could not load followers: ${it.message}") }; relationshipLoading = false }
                    }
                }
                ProfileStat(profile?.followingCount ?: 0, "Following", modifier = Modifier.weight(1f)) {
                    if (!isOwn && profile?.isPrivate == true && profile?.isFollowing != true) {
                        viewModel.showUserMessage("Follow this private account to view its following list")
                    } else {
                        relationshipKind = "following"
                        relationshipPeople = emptyList()
                        relationshipLoading = true
                        scope.launch { viewModel.dataService.getSocialRelationshipList(profile?.userId ?: authUserId.orEmpty(), "following").onSuccess { relationshipPeople = it }.onFailure { viewModel.showUserMessage("Could not load following: ${it.message}") }; relationshipLoading = false }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isOwn) {
                    Button(onClick = { viewModel.setScreen(Screen.PROFILE) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(16.dp)) { Text("Edit profile", fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = shareProfile, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)) { Icon(Icons.Filled.Share, contentDescription = null, tint = Plum, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Share profile", color = Plum) }
                } else {
                    Button(onClick = { viewModel.toggleSocialFollow(profile?.userId.orEmpty()) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = VibrantPink), shape = RoundedCornerShape(16.dp)) { Text(when { profile?.isFollowing == true -> "Following"; profile?.isFollowRequested == true -> "Requested"; else -> "Follow" }, fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = { profile?.let(viewModel::openSocialMessage) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)) {
                        Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp), tint = Plum); Spacer(Modifier.width(5.dp)); Text("Message", color = Plum)
                    }
                }
            }

            if (isOwn) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(14.dp)).background(DarkSurface).padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Private account", color = Plum, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Only approved followers can see your posts and Stories", color = TextSecondary, fontSize = 10.sp)
                    }
                    Switch(checked = profile?.isPrivate == true, onCheckedChange = { private -> viewModel.setSocialAccountPrivacy(private) })
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        modifier = Modifier.weight(1f).clickable {
                            scope.launch {
                                viewModel.dataService.getSocialFollowRequests().onSuccess { followRequests = it }
                                    .onFailure { viewModel.showUserMessage("Could not load follow requests: ${it.message}") }
                                showFollowRequests = true
                            }
                        },
                        color = DarkSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                    ) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = VibrantPink)
                            Column(Modifier.weight(1f)) {
                                Text("Follow requests", color = Plum, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text(if (profile?.isPrivate == true) "Review pending requests" else "No private requests expected", color = TextSecondary, fontSize = 9.sp)
                            }
                            Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = VibrantPink, modifier = Modifier.size(16.dp).graphicsLayer(rotationZ = 180f))
                        }
                    }
                    Surface(
                        modifier = Modifier.weight(1f).clickable { showInsights = true },
                        color = DarkSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                    ) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.GridOn, contentDescription = null, tint = PrimaryLavender)
                            Column(Modifier.weight(1f)) {
                                Text("Profile insights", color = Plum, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("See your post performance", color = TextSecondary, fontSize = 9.sp)
                            }
                            Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = PrimaryLavender, modifier = Modifier.size(16.dp).graphicsLayer(rotationZ = 180f))
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(start = 17.dp, end = 17.dp, top = 8.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Highlights", color = Plum, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                if (isOwn) Text("＋ Manage", color = VibrantPink, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.clickable {
                    highlightTitle = ""
                    selectedStoryId = stories.firstOrNull { it.userId == authUserId }?.id
                    showCreateHighlightDialog = true
                })
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (isOwn) {
                    HighlightBubble("+", "New", isAdd = true, onClick = {
                        highlightTitle = ""
                        selectedStoryId = stories.firstOrNull { it.userId == authUserId }?.id
                        showCreateHighlightDialog = true
                    })
                }
                highlights.take(7).forEach { highlight ->
                    HighlightBubble(
                        title = "",
                        label = highlight.title,
                        imageUrl = highlight.coverUrl,
                        mediaType = highlight.firstMediaType,
                        onClick = {
                            // Signed R2 URLs expire. Refresh the Highlight list on open so the
                            // viewer receives a current URL rather than a stale saved thumbnail URL.
                            scope.launch {
                                viewModel.dataService.getSocialHighlights(targetUserId).onSuccess { refreshed ->
                                    highlights = refreshed
                                    val latest = refreshed.firstOrNull { it.id == highlight.id } ?: highlight
                                    val media = latest.firstMediaUrl ?: latest.coverUrl
                                    if (!media.isNullOrBlank()) viewModel.openFullScreenMedia(media, latest.firstMediaType)
                                    else viewModel.showUserMessage("This Highlight has no available media")
                                }.onFailure { viewModel.showUserMessage("Could not open Highlight: ${it.message ?: "please retry"}") }
                            }
                        }
                    )
                }
            }
            if (highlights.isEmpty() && !isOwn && !(profile?.isPrivate == true && profile?.isFollowing != true)) {
                Text("No Highlights yet", color = TextTertiary, fontSize = 11.sp, modifier = Modifier.padding(start = 17.dp, top = 4.dp))
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().border(width = 1.dp, color = DarkCardBorder).background(DarkSurface), horizontalArrangement = Arrangement.SpaceEvenly) {
                ProfileTab("Posts", selectedTab == "Posts", Icons.Filled.GridOn, Modifier.weight(1f)) { selectedTab = "Posts" }
                ProfileTab("Reels", selectedTab == "Reels", Icons.Filled.PlayCircleOutline, Modifier.weight(1f)) { selectedTab = "Reels" }
                ProfileTab("Tagged", selectedTab == "Tagged", Icons.Filled.Tag, Modifier.weight(1f)) { selectedTab = "Tagged" }
            }
            val privateLocked = !isOwn && profile?.isPrivate == true && profile?.isFollowing != true
            val visiblePosts = when (selectedTab) {
                "Reels" -> posts.filter { it.mediaType.equals("video", true) }
                "Tagged" -> emptyList()
                else -> posts
            }
            if (privateLocked) {
                Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Settings, contentDescription = null, tint = Color(0xFFBBAABF), modifier = Modifier.size(32.dp))
                        Text("This account is private", color = Plum, fontWeight = FontWeight.Bold)
                        Text("Follow this account to see their photos, Reels and Highlights.", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            } else if (visiblePosts.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Icon(if (selectedTab == "Reels") Icons.Filled.PlayCircleOutline else Icons.Filled.GridOn, contentDescription = null, tint = Color(0xFFBBAABF), modifier = Modifier.size(36.dp))
                        Text(if (selectedTab == "Reels") "No reels yet" else if (selectedTab == "Tagged") "No tagged posts yet" else "No posts yet", color = Plum, fontWeight = FontWeight.SemiBold)
                        if (isOwn && selectedTab == "Posts") Text("Your photos and videos will appear here.", color = TextTertiary, fontSize = 11.sp)
                    }
                }
            } else {
                visiblePosts.chunked(3).forEach { rowPosts ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        rowPosts.forEach { post ->
                            ProfileGridTile(post = post, viewModel = viewModel, modifier = Modifier.weight(1f), onClick = { gridPost = post })
                        }
                        repeat((3 - rowPosts.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
        }
    }

    if (showInsights) {
        val insightPosts = if (isOwn) ownPosts else viewedPosts
        val totalViews = insightPosts.sumOf { it.viewsCount.coerceAtLeast(0) }
        val totalLikes = insightPosts.sumOf { it.likesCount.coerceAtLeast(0) }
        val totalLoveNotes = insightPosts.sumOf { it.loveNotesCount.coerceAtLeast(0) }
        AlertDialog(
            onDismissRequest = { showInsights = false },
            containerColor = DarkSurface,
            title = { Text("Profile insights", color = Plum, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Live totals from the posts currently loaded for this profile.", color = TextSecondary, fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InsightMetric("Posts", insightPosts.size.toString(), Modifier.weight(1f))
                        InsightMetric("Views", totalViews.toString(), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InsightMetric("Likes", totalLikes.toString(), Modifier.weight(1f))
                        InsightMetric("Love Notes", totalLoveNotes.toString(), Modifier.weight(1f))
                    }
                    Text("Counts reflect the posts returned by BAATLY right now; they are not lifetime analytics unless all posts are loaded.", color = TextTertiary, fontSize = 9.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showInsights = false }) { Text("Close", color = VibrantPink) } }
        )
    }

    relationshipKind?.let { kind ->
        ModalBottomSheet(onDismissRequest = { relationshipKind = null }, containerColor = DarkSurface) {
            Column(Modifier.fillMaxWidth().heightIn(min = 260.dp, max = 620.dp).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (kind == "followers") "Followers" else "Following", color = Plum, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                when {
                    relationshipLoading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = VibrantPink) }
                    relationshipPeople.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text("No ${kind} yet", color = TextSecondary) }
                    else -> LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(relationshipPeople, key = { it.userId }) { person ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { relationshipKind = null; viewModel.openSocialProfile(person.userId) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                AsyncImage(model = person.avatarUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(42.dp).clip(CircleShape).background(SocialSoftPink))
                                Column(Modifier.weight(1f)) {
                                    Text(person.displayName.ifBlank { person.username }, color = Plum, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(person.username.takeIf { it.isNotBlank() }?.let { "@$it" } ?: "BAATLY member", color = TextSecondary, fontSize = 11.sp)
                                }
                                if (person.userId != authUserId) TextButton(onClick = { viewModel.toggleSocialFollow(person.userId) }) {
                                    Text(when { person.isFollowing -> "Following"; person.isFollowRequested -> "Requested"; else -> "Follow" }, color = VibrantPink, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFollowRequests) {
        ModalBottomSheet(onDismissRequest = { showFollowRequests = false }, containerColor = DarkSurface) {
            Column(Modifier.fillMaxWidth().heightIn(min = 240.dp, max = 600.dp).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Follow requests", color = Plum, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (followRequests.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) { Text("No pending requests", color = TextSecondary) }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().heightIn(max = 480.dp)) {
                        items(followRequests, key = { it.requestId }) { request ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                AsyncImage(model = request.avatarUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(40.dp).clip(CircleShape).background(SocialSoftPink))
                                Column(Modifier.weight(1f)) {
                                    Text(request.displayName, color = Plum, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text(request.username.takeIf { it.isNotBlank() }?.let { "@$it" } ?: "BAATLY member", color = TextSecondary, fontSize = 10.sp)
                                }
                                TextButton(onClick = {
                                    scope.launch {
                                        viewModel.dataService.respondSocialFollowRequest(request.requestId, true).onSuccess {
                                            viewModel.dataService.getSocialFollowRequests().onSuccess { followRequests = it }
                                            viewModel.loadMySocialProfile()
                                        }.onFailure { viewModel.showUserMessage("Could not approve request: ${it.message}") }
                                    }
                                }) { Text("Accept", color = VibrantPink) }
                                TextButton(onClick = {
                                    scope.launch {
                                        viewModel.dataService.respondSocialFollowRequest(request.requestId, false).onSuccess {
                                            viewModel.dataService.getSocialFollowRequests().onSuccess { followRequests = it }
                                        }.onFailure { viewModel.showUserMessage("Could not reject request: ${it.message}") }
                                    }
                                }) { Text("Delete", color = TextSecondary) }
                            }
                        }
                    }
                }
            }
        }
    }

    gridPost?.let { post ->
        SocialGridPostDialog(post = post, viewModel = viewModel, onDismiss = { gridPost = null }, onComment = {
            gridPost = null
            profileCommentTarget = post
        })
    }
    profileCommentTarget?.let { post ->
        SocialCommentsSheet(viewModel, "post", post.id, post.creatorName) { profileCommentTarget = null }
    }

    if (showCreateHighlightDialog) {
        val ownStories = stories.filter { it.userId == authUserId }
        AlertDialog(
            onDismissRequest = { if (!isSavingHighlight) showCreateHighlightDialog = false },
            containerColor = DarkSurface,
            title = { Text("Create Story Highlight", color = Plum, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Name your Highlight, then save an active Story or upload a photo/video. Highlights stay on your profile after ordinary Stories expire.", color = TextSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = highlightTitle,
                        onValueChange = { highlightTitle = it.take(40) },
                        singleLine = true,
                        label = { Text("Highlight name") },
                        placeholder = { Text("e.g. Moments") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (ownStories.isEmpty()) {
                        Text("No active Stories right now. You can upload a photo or video directly below.", color = TextSecondary, fontSize = 12.sp)
                    } else {
                        ownStories.take(12).forEach { story ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(DarkSurface)
                                    .clickable { selectedStoryId = story.id }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                RadioButton(selected = selectedStoryId == story.id, onClick = { selectedStoryId = story.id }, colors = RadioButtonDefaults.colors(selectedColor = VibrantPink))
                                Column(Modifier.weight(1f)) {
                                    Text(story.caption.ifBlank { "Story media" }, color = Plum, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(if (story.mediaPath.orEmpty().substringAfterLast('.', "").lowercase() in setOf("mp4", "mov", "m4v", "webm")) "Video story" else "Photo story", color = TextSecondary, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { highlightPhotoPicker.launch("image/*") },
                            enabled = !isSavingHighlight,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Upload photo", color = VibrantPink, maxLines = 1) }
                        OutlinedButton(
                            onClick = { highlightVideoPicker.launch("video/*") },
                            enabled = !isSavingHighlight,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Upload video", color = VibrantPink, maxLines = 1) }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = selectedStoryId != null && ownStories.any { it.id == selectedStoryId } && !isSavingHighlight,
                    onClick = {
                        val storyId = selectedStoryId ?: return@TextButton
                        isSavingHighlight = true
                        scope.launch {
                            viewModel.dataService.addSocialHighlightFromStory(storyId, highlightTitle).onSuccess {
                                viewModel.dataService.getSocialHighlights().onSuccess { highlights = it }
                                showCreateHighlightDialog = false
                                viewModel.showUserMessage("Story saved to Highlights")
                            }.onFailure { error -> viewModel.showUserMessage("Couldn't save Highlight: ${error.message ?: "please retry"}") }
                            isSavingHighlight = false
                        }
                    }
                ) {
                    if (isSavingHighlight) CircularProgressIndicator(modifier = Modifier.size(16.dp), color = VibrantPink, strokeWidth = 2.dp)
                    else Text("Save selected Story", color = VibrantPink)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateHighlightDialog = false }, enabled = !isSavingHighlight) { Text("Cancel", color = TextSecondary) }
            }
        )
    }

}

@Composable
private fun InsightMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = DarkSurfaceVariant, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(value, color = Plum, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(label, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ProfileStat(value: Int, label: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    Surface(
        modifier = modifier.then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        color = DarkSurface,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp)
        ) {
            Text(value.toString(), color = Plum, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Text(label, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
private fun HighlightBubble(
    title: String,
    label: String,
    isAdd: Boolean = false,
    imageUrl: String? = null,
    mediaType: String = "image",
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(62.dp).clickable(onClick = onClick)) {
        Box(
            Modifier.size(58.dp).clip(CircleShape)
                .background(if (isAdd) Color.White else Color(0xFFF3E8FA))
                .border(1.dp, if (isAdd) DarkCardBorder else Color(0xFFE7D7F0), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (!imageUrl.isNullOrBlank()) {
                if (mediaType.equals("video", true)) {
                    SocialVideoThumbnail(url = imageUrl, modifier = Modifier.fillMaxSize())
                } else {
                    AsyncImage(model = imageUrl, contentDescription = label, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            } else {
                Text(title.ifBlank { "✨" }, color = if (isAdd) Plum else VibrantPink, fontSize = if (isAdd) 26.sp else 22.sp, fontWeight = FontWeight.Bold)
            }
            if (isAdd) {
                Box(Modifier.align(Alignment.BottomEnd).size(19.dp).clip(CircleShape).background(VibrantPink), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Add, contentDescription = "Add Highlight", tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = Plum, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ProfileTab(title: String, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(icon, contentDescription = title, tint = if (selected) VibrantPink else TextSecondary, modifier = Modifier.size(20.dp))
        Text(title, color = if (selected) VibrantPink else TextSecondary, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
        Box(Modifier.fillMaxWidth().height(2.dp).background(if (selected) VibrantPink else Color.Transparent))
    }
}

@Composable
internal fun SocialVideoThumbnail(url: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var thumbnailFile by remember(url) { mutableStateOf<File?>(null) }
    LaunchedEffect(url) {
        thumbnailFile = withContext(Dispatchers.IO) {
            runCatching {
                val stableKey = url.substringBefore('?').hashCode()
                val cachedFile = File(context.cacheDir, "social_video_thumb_${stableKey}.jpg")
                if (cachedFile.isFile && cachedFile.length() > 0L) {
                    cachedFile
                } else {
                    val retriever = MediaMetadataRetriever()
                    val frame = try {
                        retriever.setDataSource(url, mapOf("User-Agent" to "BAATLY-Android"))
                        retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } finally {
                        runCatching { retriever.release() }
                    }
                    if (frame == null) {
                        null
                    } else {
                        try {
                            // Keep grid posters small so a profile containing many reels cannot
                            // load a stack of full-resolution video frames into memory.
                            val longestEdge = maxOf(frame.width, frame.height).coerceAtLeast(1)
                            val scale = minOf(1f, 480f / longestEdge.toFloat())
                            val poster = if (scale < 1f) {
                                Bitmap.createScaledBitmap(
                                    frame,
                                    (frame.width * scale).toInt().coerceAtLeast(1),
                                    (frame.height * scale).toInt().coerceAtLeast(1),
                                    true
                                )
                            } else frame
                            try {
                                FileOutputStream(cachedFile).use { output ->
                                    if (!poster.compress(Bitmap.CompressFormat.JPEG, 84, output)) {
                                        throw IllegalStateException("Could not cache reel poster")
                                    }
                                }
                                cachedFile.takeIf { it.isFile && it.length() > 0L }
                            } finally {
                                if (poster !== frame) poster.recycle()
                            }
                        } finally {
                            frame.recycle()
                        }
                    }
                }
            }.getOrNull()
        }
    }
    if (thumbnailFile != null) {
        AsyncImage(model = thumbnailFile, contentDescription = "Reel thumbnail", contentScale = ContentScale.Crop, modifier = modifier)
    } else {
        Box(modifier.background(Color(0xFF24152F)), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.PlayCircleOutline, contentDescription = "Reel preview", tint = Color.White.copy(alpha = 0.82f), modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
private fun ProfileGridTile(post: SocialPost, viewModel: BaatlyViewModel, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    var failed by remember(post.id) { mutableStateOf(false) }
    var refreshAttempted by remember(post.id) { mutableStateOf(false) }
    val mediaScope = rememberCoroutineScope()
    LaunchedEffect(post.mediaPath, post.mediaUrl, post.mediaBucket, post.id) {
        refreshAttempted = false
        // Use the URL freshly signed by the feed first; canonical key remains the retry path.
        val raw = post.mediaUrl?.takeIf { it.startsWith("https://", ignoreCase = true) || it.startsWith("http://", ignoreCase = true) }
            ?: post.mediaPath?.takeIf { it.isNotBlank() }
            ?: post.mediaUrl
        mediaUrl = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id)
            .takeIf { it.isNotBlank() }
        failed = mediaUrl.isNullOrBlank()
    }
    fun refreshCanonicalPostMedia() {
        if (refreshAttempted) return
        refreshAttempted = true
        mediaScope.launch {
            val key = post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
            val refreshed = viewModel.dataService.resolveSocialMediaUrl(key, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id, forceRefresh = true)
            if (refreshed.isNotBlank()) { mediaUrl = refreshed; failed = false } else failed = true
        }
    }
    Box(modifier.height(132.dp).background(Color(0xFFE9DFE4)).clickable(onClick = onClick)) {
        when {
            mediaUrl.isNullOrBlank() -> Box(Modifier.fillMaxSize().background(Color(0xFFECE4E9)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.PlayCircleOutline, contentDescription = "Open post", tint = Color(0xFF8A7484), modifier = Modifier.size(32.dp))
                if (failed) Text("Tap to retry", color = Plum, fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(4.dp))
            }
            post.mediaType.equals("video", true) -> SocialVideoThumbnail(url = mediaUrl!!, modifier = Modifier.fillMaxSize())
            else -> AsyncImage(
                model = mediaUrl,
                contentDescription = post.caption,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                onError = { refreshCanonicalPostMedia() }
            )
        }
        if (post.mediaType.equals("video", true)) {
            Icon(Icons.Filled.PlayCircleOutline, contentDescription = "Video", tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(24.dp).background(Color.Black.copy(alpha = 0.32f), CircleShape))
        }
    }
}

@Composable
private fun SocialGridPostDialog(
    post: SocialPost,
    viewModel: BaatlyViewModel,
    onDismiss: () -> Unit,
    onComment: () -> Unit
) {
    var mediaUrl by remember(post.id) { mutableStateOf<String?>(null) }
    var mediaFailed by remember(post.id) { mutableStateOf(false) }
    var retryToken by remember(post.id) { mutableIntStateOf(0) }
    LaunchedEffect(post.id, post.mediaPath, post.mediaUrl, retryToken) {
        mediaUrl = null
        mediaFailed = false
        val raw = if (retryToken > 0) {
            post.mediaPath?.takeIf { it.isNotBlank() } ?: post.mediaUrl
        } else {
            post.mediaUrl?.takeIf { it.startsWith("https://", ignoreCase = true) || it.startsWith("http://", ignoreCase = true) }
                ?: post.mediaPath?.takeIf { it.isNotBlank() }
                ?: post.mediaUrl
        }
        val resolved = viewModel.dataService.resolveSocialMediaUrl(raw, explicitBucket = post.mediaBucket, contentType = "post", contentId = post.id, forceRefresh = retryToken > 0)
        mediaUrl = resolved.takeIf { it.isNotBlank() }
        mediaFailed = mediaUrl.isNullOrBlank()
        if (mediaUrl != null) viewModel.dataService.recordSocialPostView(post.id)
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF130E16)).statusBarsPadding().padding(bottom = 12.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                AsyncImage(model = post.creatorAvatarUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(38.dp).clip(CircleShape))
                Column(Modifier.weight(1f)) {
                    Text(post.creatorName, color = DarkSurface, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(if (post.mediaType.equals("video", true)) "Reel" else "Post", color = Color.White.copy(alpha = .65f), fontSize = 10.sp)
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Close post", tint = Color.White) }
            }
            Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black), contentAlignment = Alignment.Center) {
                when {
                    mediaUrl.isNullOrBlank() && !mediaFailed -> CircularProgressIndicator(color = VibrantPink)
                    mediaUrl.isNullOrBlank() -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Couldn't load this post right now", color = DarkSurface, fontSize = 13.sp)
                        TextButton(onClick = { retryToken++ }) { Text("Retry", color = Color(0xFFFF75A7)) }
                    }
                    post.mediaType.equals("video", true) -> BaatlyVideoPlayer(mediaUrl!!, shouldPlay = true, modifier = Modifier.fillMaxSize(), soundEnabled = true)
                    else -> AsyncImage(model = mediaUrl, contentDescription = post.caption, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                }
            }
            if (post.caption.isNotBlank()) Text(post.caption, color = DarkSurface, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onClick = { viewModel.toggleSocialLike(post) }) {
                    Icon(Icons.Filled.FavoriteBorder, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(5.dp)); Text(if (post.isLiked) "Liked" else "Like", color = Color.White)
                }
                TextButton(onClick = onComment) {
                    Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(5.dp)); Text("Comment", color = Color.White)
                }
            }
        }
    }
}
