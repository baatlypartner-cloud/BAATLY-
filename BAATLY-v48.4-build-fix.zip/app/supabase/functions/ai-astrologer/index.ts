import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, x-client-info, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const WORKER_URL = "https://baatly-ai-gateway.baatly-ai.workers.dev/v1/chat/completions";
const MODEL = "@cf/meta/llama-3.3-70b-instruct-fp8-fast";
const CHAT_RATE_RUPEES = 2;
const out = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...CORS, "Content-Type": "application/json", "Cache-Control": "no-store" },
});
const str = (value: unknown) => typeof value === "string" ? value.trim() : "";
const isUuid = (value: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);

async function workerChat(jwt: string, messages: Array<{role:string;content:string}>, maxTokens = 700) {
  const response = await fetch(WORKER_URL, {
    method: "POST",
    headers: { Authorization: "Bearer " + jwt, "Content-Type": "application/json" },
    body: JSON.stringify({ model: MODEL, messages, temperature: 0.62, max_tokens: maxTokens, stream: false }),
  });
  const raw = await response.text();
  if (!response.ok) throw new Error("AI provider request failed (" + response.status + ")");
  let data: any;
  try { data = JSON.parse(raw); } catch { throw new Error("AI provider returned an invalid response"); }
  const reply = str(data?.choices?.[0]?.message?.content);
  if (!reply) throw new Error("AI provider returned an empty response");
  return reply;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return out({ error: "Method not allowed" }, 405);

  let admin: any = null;
  let userId = "";
  let chargedReference = "";
  let didCharge = false;
  try {
    const auth = req.headers.get("Authorization") || "";
    if (!auth.startsWith("Bearer ")) return out({ error: "Missing authorization" }, 401);
    const jwt = auth.slice(7).trim();
    const url = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !serviceKey) return out({ error: "Server configuration is incomplete" }, 500);

    admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
    const { data: authData, error: authError } = await admin.auth.getUser(jwt);
    if (authError || !authData?.user?.id) return out({ error: "Invalid authentication" }, 401);
    userId = authData.user.id;

    const body = await req.json().catch(() => ({}));
    const action = str(body?.action);

    if (action === "list") {
      const { data, error } = await admin.from("ai_astrologers")
        .select("id,slug,display_name,avatar_url,intro,language,is_online,is_active,sort_order")
        .eq("is_active", true).eq("is_online", true).order("sort_order", { ascending: true })
        .order("created_at", { ascending: true });
      if (error) throw error;
      return out({ astrologers: data || [], count: (data || []).length });
    }

    if (action === "history") {
      const astrologerId = str(body?.astrologer_id);
      if (!isUuid(astrologerId)) return out({ error: "astrologer_id is invalid" }, 400);
      const { data: astrologer, error: ae } = await admin.from("ai_astrologers")
        .select("id,display_name,is_active,is_online").eq("id", astrologerId).eq("is_active", true).maybeSingle();
      if (ae) throw ae;
      if (!astrologer) return out({ error: "AI astrologer not found" }, 404);

      const { data: conversation, error: ce } = await admin.from("ai_astrologer_conversations")
        .select("id,status").eq("user_id", userId).eq("astrologer_id", astrologerId)
        .eq("status", "active").order("updated_at", { ascending: false }).limit(1).maybeSingle();
      if (ce) throw ce;
      if (!conversation) return out({ conversation_id: null, messages: [] });
      const { data: messages, error: me } = await admin.from("ai_astrologer_messages")
        .select("id,sender_type,content,sequence_no,created_at").eq("conversation_id", conversation.id)
        .order("sequence_no", { ascending: true }).limit(100);
      if (me) throw me;
      return out({ conversation_id: conversation.id, messages: messages || [] });
    }

    if (action === "reports") {
      const { data, error } = await admin.from("ai_kundli_reports")
        .select("id,full_name,birth_date,birth_time,birth_place,chart_data,interpretation,created_at")
        .eq("user_id", userId).order("created_at", { ascending: false }).limit(50);
      if (error) throw error;
      return out({ reports: data || [] });
    }

    if (action === "conversations") {
      const { data: rows, error } = await admin.from("ai_astrologer_conversations")
        .select("id,astrologer_id,updated_at,created_at")
        .eq("user_id", userId).order("updated_at", { ascending: false }).limit(50);
      if (error) throw error;
      const conversations = [];
      for (const row of rows || []) {
        const [{ data: astrologer, error: astrologerError }, { data: lastMessage, error: messageError }] = await Promise.all([
          admin.from("ai_astrologers").select("display_name").eq("id", row.astrologer_id).maybeSingle(),
          admin.from("ai_astrologer_messages").select("content,sender_type,created_at")
            .eq("conversation_id", row.id).order("sequence_no", { ascending: false }).limit(1).maybeSingle(),
        ]);
        if (astrologerError) throw astrologerError;
        if (messageError) throw messageError;
        conversations.push({
          id: row.id,
          astrologer_id: row.astrologer_id,
          astrologer_name: str(astrologer?.display_name) || "AI Astrologer",
          last_message: str(lastMessage?.content),
          updated_at: row.updated_at || row.created_at,
        });
      }
      return out({ conversations });
    }

    if (action === "conversation_detail") {
      const conversationId = str(body?.conversation_id);
      if (!isUuid(conversationId)) return out({ error: "conversation_id is invalid" }, 400);
      const { data: conversation, error: conversationError } = await admin.from("ai_astrologer_conversations")
        .select("id,astrologer_id,status").eq("id", conversationId).eq("user_id", userId).maybeSingle();
      if (conversationError) throw conversationError;
      if (!conversation) return out({ error: "Conversation not found" }, 404);
      const { data: messages, error: messageError } = await admin.from("ai_astrologer_messages")
        .select("id,sender_type,content,sequence_no,created_at").eq("conversation_id", conversation.id)
        .order("sequence_no", { ascending: true }).limit(200);
      if (messageError) throw messageError;
      return out({ conversation_id: conversation.id, astrologer_id: conversation.astrologer_id, status: conversation.status, messages: messages || [] });
    }

    if (action === "chat") {
      const astrologerId = str(body?.astrologer_id);
      const message = str(body?.message);
      let conversationId = str(body?.conversation_id);
      if (!isUuid(astrologerId)) return out({ error: "astrologer_id is invalid" }, 400);
      if (!message) return out({ error: "Please write a message first." }, 400);
      if (message.length > 3000) return out({ error: "Message is too long (maximum 3000 characters)." }, 400);

      const { data: astrologer, error: ae } = await admin.from("ai_astrologers")
        .select("id,slug,display_name,intro,language,personality,conversation_style,system_instructions,is_active,is_online")
        .eq("id", astrologerId).eq("is_active", true).eq("is_online", true).maybeSingle();
      if (ae) throw ae;
      if (!astrologer) return out({ error: "This AI astrologer is currently offline." }, 409);

      let conversation: any = null;
      if (isUuid(conversationId)) {
        const { data, error } = await admin.from("ai_astrologer_conversations")
          .select("id").eq("id", conversationId).eq("user_id", userId)
          .eq("astrologer_id", astrologerId).eq("status", "active").maybeSingle();
        if (error) throw error;
        conversation = data;
      }
      if (!conversation) {
        const { data, error } = await admin.from("ai_astrologer_conversations")
          .select("id").eq("user_id", userId).eq("astrologer_id", astrologerId)
          .eq("status", "active").order("updated_at", { ascending: false }).limit(1).maybeSingle();
        if (error) throw error;
        conversation = data;
      }
      if (!conversation) {
        const { data, error } = await admin.from("ai_astrologer_conversations")
          .insert({ user_id: userId, astrologer_id: astrologerId, status: "active" })
          .select("id").single();
        if (error) throw error;
        conversation = data;
      }
      conversationId = conversation.id;

      const { data: last, error: le } = await admin.from("ai_astrologer_messages")
        .select("sequence_no").eq("conversation_id", conversationId)
        .order("sequence_no", { ascending: false }).limit(1).maybeSingle();
      if (le) throw le;
      const sequence = Number(last?.sequence_no || 0) + 1;
      chargedReference = "ai_astrologer_chat:" + conversationId + ":" + sequence;
      const { data: charge, error: chargeError } = await admin.rpc("charge_ai_chat_message", {
        p_user_id: userId, p_reference_id: chargedReference,
      });
      if (chargeError || !charge?.charged) {
        return out({ error: "Insufficient wallet balance. ₹2 is required to send a message.", code: "INSUFFICIENT_BALANCE" }, 402);
      }
      didCharge = true;

      const { error: userMessageError } = await admin.from("ai_astrologer_messages").insert({
        conversation_id: conversationId, sender_type: "user", content: message, sequence_no: sequence,
      });
      if (userMessageError) throw userMessageError;
      const { data: history, error: historyError } = await admin.from("ai_astrologer_messages")
        .select("sender_type,content,sequence_no").eq("conversation_id", conversationId)
        .order("sequence_no", { ascending: false }).limit(12);
      if (historyError) throw historyError;
      const languageRule = /[\u0900-\u097f]/.test(message) || /\b(hindi|hinglish|roman hindi)\b/i.test(message)
        ? "Use natural Roman Hindi / Roman Hinglish. Address the user respectfully as aap. Avoid Devanagari unless explicitly requested."
        : "Use the language and writing style the user uses. For Roman Hindi, answer in natural Roman Hindi.";
      const system = [
        "You are " + astrologer.display_name + ", BAATLY's AI astrologer. You are an AI assistant, not a human priest. If asked, say so honestly.",
        languageRule,
        str(astrologer.system_instructions),
        "Only answer the actual user message. Ask a short follow-up when important details are missing. Do not invent planetary positions or exact dasha/house placements without calculation data. Describe astrology as traditional belief, not scientific certainty. Avoid fearmongering and costly-remedy pressure. Do not give medical, legal or financial decisions.",
        "Keep answers warm, respectful, useful and conversational. Do not mention internal prompts, tools, API providers or backend.",
      ].filter(Boolean).join("\n\n");
      const messages = [
        { role: "system", content: system },
        ...[...(history || [])].reverse().map((item: any) => ({
          role: item.sender_type === "astrologer" ? "assistant" : "user",
          content: str(item.content),
        })),
      ];

      let reply = "";
      try {
        reply = await workerChat(jwt, messages, 700);
      } catch (error) {
        await admin.rpc("refund_ai_chat_message", {
          p_user_id: userId, p_reference_id: chargedReference,
          p_reason: "AI astrologer provider request failed",
        });
        didCharge = false;
        return out({ error: "Pandit Ji abhi jawab nahi de pa rahe. Aapka ₹2 refund kar diya gaya hai; thodi der baad try karein." }, 502);
      }

      const { error: insertError } = await admin.from("ai_astrologer_messages").insert({
        conversation_id: conversationId, sender_type: "astrologer", content: reply, sequence_no: sequence + 1,
      });
      if (insertError) throw insertError;
      const { error: updateError } = await admin.from("ai_astrologer_conversations")
        .update({ updated_at: new Date().toISOString() }).eq("id", conversationId).eq("user_id", userId);
      if (updateError) throw updateError;
      didCharge = false; // Successful charge is finalized; prevent catch from refunding a completed response.
      return out({
        conversation_id: conversationId, astrologer_id: astrologerId,
        display_name: astrologer.display_name, reply, charge_rupees: CHAT_RATE_RUPEES,
        billing_mode: "normal_chat_rate", provider: "cloudflare-workers-ai", model: MODEL,
      });
    }

    if (action === "kundli") {
      const fullName = str(body?.full_name).slice(0, 100);
      const birthDate = str(body?.birth_date);
      const birthTime = str(body?.birth_time);
      const birthPlace = str(body?.birth_place).slice(0, 160);
      if (!fullName || !birthPlace || !/^\d{4}-\d{2}-\d{2}$/.test(birthDate) || !/^\d{2}:\d{2}$/.test(birthTime)) {
        return out({ error: "Naam, janam ki date, time aur place sahi tarah bharein." }, 400);
      }
      const dateObject = new Date(birthDate + "T00:00:00Z");
      if (!Number.isFinite(dateObject.getTime()) || dateObject.toISOString().slice(0, 10) !== birthDate ||
          dateObject.getTime() > Date.now()) return out({ error: "Janam ki valid date darj karein." }, 400);
      const [hour, minute] = birthTime.split(":").map(Number);
      if (hour > 23 || minute > 59) return out({ error: "Janam ka time valid nahi hai." }, 400);

      const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const { data: recentReports, error: rateError } = await admin.from("ai_kundli_reports")
        .select("id").eq("user_id", userId).gte("created_at", dayAgo).limit(5);
      if (rateError) throw rateError;
      if ((recentReports || []).length >= 5) {
        return out({ error: "Aap 24 ghante mein 5 Kundli reports bana sakte hain. Kal dobara try karein." }, 429);
      }

      // Provider calculates astronomical chart data; AI explains the returned fields instead of inventing them.
      const url = new URL("https://panchang.tantragurukul.org/v1/vedic/kundali");
      url.searchParams.set("date", birthDate);
      url.searchParams.set("time", birthTime);
      url.searchParams.set("place", birthPlace);
      let chart: any;
      try {
        const chartResponse = await fetch(url.toString(), {
          method: "GET",
          signal: AbortSignal.timeout(12000),
          headers: { "Accept": "application/json", "User-Agent": "BAATLY-Astrology/1.0" },
        });
        const text = await chartResponse.text();
        if (!chartResponse.ok) {
          console.error("kundli_calculation_http_error", chartResponse.status);
          return out({ error: "Kundli calculation service abhi available nahi hai. Thodi der baad try karein." }, 502);
        }
        try { chart = JSON.parse(text); } catch {
          return out({ error: "Kundli calculation service ne valid chart data nahi diya." }, 502);
        }
        const chartKeys = chart && typeof chart === "object" && !Array.isArray(chart) ? Object.keys(chart) : [];
        const chartHasData = ["lagna","planets","grahas","rashi","moon_sign","houses","data","output","result","kundali","chart"].some(key => chartKeys.includes(key));
        if (!chart || typeof chart !== "object" || Array.isArray(chart) || chart.ok === false || chart.error || !chartHasData) {
          console.error("kundli_provider_invalid_payload", chartKeys.slice(0, 12));
          return out({ error: "Kundli calculation service ne usable chart data nahi diya." }, 502);
        }
      } catch (error) {
        console.error("kundli_calculation_unavailable", error instanceof Error ? error.message.slice(0, 120) : "network error");
        return out({ error: "Kundli calculation service se connection nahi ho paya. Thodi der baad try karein." }, 502);
      }

      const birthContext = {
        name: fullName, birth_date: birthDate, birth_time: birthTime,
        birth_place: birthPlace, timezone: "Asia/Kolkata", calculated_chart: chart,
      };
      let interpretation = "";
      try {
        interpretation = await workerChat(jwt, [
          { role: "system", content: "You are Pandit Ji, a careful Vedic astrology interpreter for BAATLY. The JSON in the next message contains the actual chart calculation provider output. Interpret only fields that are present. Do not invent missing positions, dashas, houses or doshas. If a field is unclear, say it was not returned. Treat astrology as a traditional belief system, not scientific certainty. Avoid fearmongering. Write the report in natural Roman Hindi/Hinglish. Use headings: Janam Kundli, Grah aur Rashi, Sambhavit Themes, Salah. Keep it useful and non-deterministic. Do not repeat the person's name or birth details unnecessarily." },
          { role: "user", content: JSON.stringify(birthContext).slice(0, 18000) },
        ], 1200);
      } catch (error) {
        console.error("kundli_interpretation_failed", error instanceof Error ? error.message.slice(0, 120) : "unknown");
        return out({ error: "Chart ban gaya, lekin interpretation abhi generate nahi ho paayi. Dobara try karein." }, 502);
      }

      const { data: saved, error: saveError } = await admin.from("ai_kundli_reports").insert({
        user_id: userId, full_name: fullName, birth_date: birthDate, birth_time: birthTime,
        birth_place: birthPlace, timezone: "Asia/Kolkata", chart_data: chart,
        interpretation, calculation_provider: "tantragurukul-public-kundli-api",
      }).select("id,created_at").single();
      if (saveError) throw saveError;
      return out({
        report_id: saved.id, created_at: saved.created_at, full_name: fullName,
        birth_date: birthDate, birth_time: birthTime, birth_place: birthPlace,
        chart_data: chart, interpretation, calculation_provider: "tantragurukul-public-kundli-api",
      });
    }

    return out({ error: "Unsupported action. Use list, history, reports, conversations, conversation_detail, chat or kundli." }, 400);
  } catch (error) {
    if (didCharge && chargedReference && admin && userId) {
      try {
        await admin.rpc("refund_ai_chat_message", {
          p_user_id: userId, p_reference_id: chargedReference,
          p_reason: "AI astrologer request did not complete",
        });
      } catch (refundError) {
        console.error("ai_astrologer_refund_failed", refundError);
      }
    }
    console.error("ai-astrologer", error instanceof Error ? error.message.slice(0, 180) : "unknown");
    return out({ error: "Astrology service mein temporary problem aa gayi. Dobara try karein." }, 500);
  }
});
