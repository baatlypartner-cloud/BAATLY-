# BAATLY v48.3 — Additional Reference-Screen Update

This ZIP builds on `BAATLY-v48.3-reference-ui.zip` and adds the six newly supplied screen references. The work is applied to the existing Jetpack Compose Android project and preserves its current Supabase, Cloudflare/R2, messaging, wallet and audio-call integrations. This is a source ZIP update, not a compiled APK.

## Six additional reference screens

1. **Astrology dashboard** — midnight navy background, neon pink/purple/gold accents, kundli hero artwork, category tiles, AI astrologer call-to-action, online astrologer cards, astrology tools and image-backed article cards. `My Reports` and `History` open the signed-in user's saved Supabase records. The History detail endpoint now fetches the selected conversation by conversation ID and checks ownership before returning messages, including completed conversations.
2. **Entertainment dashboard** — BAATLY Entertainment header and search, cinematic hero, category filters including Web Series, and catalogue sections. Content cards are populated only from published catalogue records resolved through the existing Cloudflare/R2 path. A BAATLY Originals section appears only when the real catalogue contains matching original-content records.
3. **Social Search** — light search surface matching the reference, People/Posts/Reels/Hashtags filters, voice-search launch, local recent-search history, trending hashtags from the existing social data service, and creator suggestions drawn from real feed owners.
4. **Social Profile** — dark neon profile header, real account photo and counters, Edit/Share actions, privacy switch, follow-request management, profile-insights totals, Highlights create/view flows, and Posts/Reels/Tagged tabs. Follow/following lists are loaded from the existing social service.
5. **Relationship home** — wallet/messages/notifications header, relationship hero, host search, Voice Call/Love Note/Roleplay actions and approved-host cards. Host names, photos, online status, ratings, bio, interests and call/message prices are taken from live app data.
6. **Messages list** — Messages/Love Note tabs, All/Unread filters, local search, real conversation previews, unread counts, delivery state, online indicators and profile avatars. The Relationship bottom-navigation item remains selected for this screen.

## Data integrity

- No screenshot sample names, follower counts, like counts, chat messages, ratings or sample feed records were inserted as live app data.
- Online AI astrologers come from the existing `ai_astrologers` registry. Kundli reports and AI conversation history are fetched for the authenticated user from Supabase.
- Search suggestions, hashtags, profiles, posts, Highlights, hosts, ratings and messages continue to use the existing BAATLY/Supabase data services.
- Entertainment titles and media are rendered from the actual published catalogue. Empty states are shown when there is no published content.
- Astrology topic/tool/article cards are navigation shortcuts into the existing AI astrologer chat; they are not represented as independent backend services.

## Deliberate limitations (not faked)

- The reference's **Continue Watching** carousel is not shown because the current project has no persisted playback-progress/history service for streaming titles.
- Video calling remains unavailable because BAATLY's established call implementation is audio-only. The reference's video controls show a clear unavailable/coming-soon message; they do not start a fake video call.
- The profile grid-style action copies the actual BAATLY profile ID. A scannable QR generator is not included in the current project dependencies.
- Tagged posts display the real available tab/empty state; no placeholder tagged media is manufactured.
- Saved social posts remain account-scoped on-device state, not server-synced bookmarks, because the current backend contract does not expose a bookmark-sync endpoint.

## Validation

- Parsed all 10 XML resource/config files successfully.
- Verified all six astrology drawable references resolve to packaged resources.
- Transpiled the edited Astrology Edge Function with TypeScript's syntax transpiler: 0 syntax diagnostics.
- Checked the edited live social/relationship screens for reference-only demo names and counters: none found.
- Confirmed the ZIP contains the Android source project and Supabase/Cloudflare source; no APK is included.
- Attempted `./gradlew assembleDebug --offline`. The wrapper tried to retrieve Gradle 9.3.1 from `services.gradle.org` and failed with `UnknownHostException`; no local Android SDK/Gradle distribution is configured in this environment. Therefore a successful Android compile/build is **not verified**.

## Files changed for the additional references

- `app/src/main/java/com/example/ui/astrologer/AstrologerScreen.kt`
- `app/src/main/java/com/example/data/ai/AiAstrologerService.kt`
- `app/supabase/functions/ai-astrologer/index.ts`
- `app/src/main/java/com/example/ui/entertainment/EntertainmentScreen.kt`
- `app/src/main/java/com/example/ui/social/SocialScreen.kt`
- `app/src/main/java/com/example/ui/social/SocialProfileScreen.kt`
- `app/src/main/java/com/example/ui/home/HomeScreen.kt`
- `app/src/main/java/com/example/ui/chat/ChatListScreen.kt`
- `app/src/main/java/com/example/ui/components/BaatlyComponents.kt`
- `app/src/main/res/drawable-nodpi/astrology_*_ref.webp`

The earlier nine-screen rework report remains in `BAATLY_V48_3_REFERENCE_SCREEN_REWORK_REPORT.md`.
