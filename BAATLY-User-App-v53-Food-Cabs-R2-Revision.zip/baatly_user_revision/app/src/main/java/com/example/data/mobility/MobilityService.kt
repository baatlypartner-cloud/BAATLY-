package com.example.data.mobility

import android.util.Log
import com.example.data.local.SessionManager
import com.example.data.network.SupabaseClient
import com.example.data.network.SupabaseConfig
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Authenticated customer-side adapter for the already deployed BAATLY mobility API.
 * This client never contains the service-role key; every operation uses the signed-in user's JWT.
 */
class MobilityService(
    private val client: SupabaseClient,
    private val sessionManager: SessionManager
) {
    companion object {
        const val TRACKING_BASE_URL = "https://baatly-realtime-gateway.baatly-ai.workers.dev"
        private const val TAG = "BaatlyMobility"
    }

    private suspend fun edge(action: String, payload: JSONObject = JSONObject()): JSONObject = withContext(Dispatchers.IO) {
        val body = JSONObject(payload.toString()).put("action", action)
        val response = JSONObject(client.callEdgeFunction("baatly-mobility-api", body.toString()))
        if (!response.optBoolean("success", false)) {
            throw IllegalStateException(response.optString("error").ifBlank { "Mobility request failed" })
        }
        response
    }

    private suspend fun restRows(table: String, query: String): JSONArray = withContext(Dispatchers.IO) {
        val url = "${SupabaseConfig.supabaseUrl}/rest/v1/$table?$query"
        JSONArray(client.get(url))
    }

    suspend fun loadFoodCatalog(): List<FoodRestaurant> = withContext(Dispatchers.IO) {
        val restaurants = restRows(
            "mobility_restaurants",
            "select=id,restaurant_name,cuisine_types,description,logo_object_key&onboarding_status=eq.approved&is_active=eq.true&order=restaurant_name.asc"
        )
        val branches = restRows(
            "mobility_restaurant_branches",
            "select=id,restaurant_id,branch_name,address,city,state,latitude,longitude,is_open,is_active,preparation_time_minutes&is_active=eq.true&order=branch_name.asc"
        )
        val menuItems = restRows(
            "mobility_menu_items",
            "select=id,restaurant_id,branch_id,category_id,item_name,description,price,image_object_key,food_type,preparation_time_minutes&is_active=eq.true&is_available=eq.true&order=display_order.asc"
        )
        val categories = restRows(
            "mobility_menu_categories",
            "select=id,restaurant_id,branch_id,name,display_order&is_active=eq.true&order=display_order.asc"
        )
        // Menu datasets are cached in memory only for this load; no private restaurant bank/KYC fields are requested.
        val itemCache = mutableMapOf<String, List<FoodMenuItem>>()
        val categoryCache = mutableMapOf<String, List<FoodMenuCategory>>()
        val out = mutableListOf<FoodRestaurant>()
        for (i in 0 until restaurants.length()) {
            val r = restaurants.optJSONObject(i) ?: continue
            val rid = r.optString("id")
            val restaurantBranches = (0 until branches.length()).mapNotNull { index ->
                val b = branches.optJSONObject(index) ?: return@mapNotNull null
                if (b.optString("restaurant_id") != rid) return@mapNotNull null
                FoodBranch(
                    id = b.optString("id"), restaurantId = rid,
                    name = b.optString("branch_name").ifBlank { r.optString("restaurant_name") },
                    address = b.optString("address"), city = b.optString("city"), state = b.optString("state"),
                    latitude = b.optDouble("latitude").takeIf { b.has("latitude") && !b.isNull("latitude") },
                    longitude = b.optDouble("longitude").takeIf { b.has("longitude") && !b.isNull("longitude") },
                    isOpen = b.optBoolean("is_open"), preparationMinutes = b.optInt("preparation_time_minutes", 20)
                )
            }
            if (restaurantBranches.isEmpty()) continue
            itemCache[rid] = (0 until menuItems.length()).mapNotNull { index ->
                val m = menuItems.optJSONObject(index) ?: return@mapNotNull null
                if (m.optString("restaurant_id") != rid) return@mapNotNull null
                FoodMenuItem(
                    id = m.optString("id"), restaurantId = rid, branchId = m.optNullableString("branch_id"),
                    categoryId = m.optNullableString("category_id"), name = m.optString("item_name"),
                    description = m.optString("description"), price = m.optDouble("price"),
                    imageObjectKey = m.optNullableString("image_object_key"),
                    foodType = m.optString("food_type", "any"), preparationMinutes = m.optInt("preparation_time_minutes", 15)
                )
            }
            categoryCache[rid] = (0 until categories.length()).mapNotNull { index ->
                val c = categories.optJSONObject(index) ?: return@mapNotNull null
                if (c.optString("restaurant_id") != rid) return@mapNotNull null
                FoodMenuCategory(c.optString("id"), rid, c.optNullableString("branch_id"), c.optString("name"), c.optInt("display_order"))
            }
            out += FoodRestaurant(
                id = rid,
                name = r.optString("restaurant_name").ifBlank { "BAATLY restaurant" },
                cuisines = r.optJSONArray("cuisine_types")?.let { arr -> (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() } } ?: emptyList(),
                description = r.optString("description"), logoObjectKey = r.optNullableString("logo_object_key"),
                branches = restaurantBranches,
                menuFoodTypes = itemCache[rid].orEmpty().map { it.foodType.lowercase() }.toSet(),
                menuItemNames = itemCache[rid].orEmpty().map { it.name }
            )
        }
        out
    }

    fun menuFor(restaurantId: String, branchId: String, restaurants: List<FoodRestaurant>, allItems: List<FoodMenuItem>): List<FoodMenuItem> =
        allItems.filter { it.restaurantId == restaurantId && (it.branchId == null || it.branchId == branchId) }

    suspend fun loadMenuItems(restaurantId: String, branchId: String): List<FoodMenuItem> = withContext(Dispatchers.IO) {
        val arr = restRows(
            "mobility_menu_items",
            "select=id,restaurant_id,branch_id,category_id,item_name,description,price,image_object_key,food_type,preparation_time_minutes&restaurant_id=eq.$restaurantId&is_active=eq.true&is_available=eq.true&order=display_order.asc"
        )
        (0 until arr.length()).mapNotNull { i ->
            val m = arr.optJSONObject(i) ?: return@mapNotNull null
            val branch = m.optNullableString("branch_id")
            if (branch != null && branch != branchId) return@mapNotNull null
            FoodMenuItem(
                id = m.optString("id"), restaurantId = restaurantId, branchId = branch,
                categoryId = m.optNullableString("category_id"), name = m.optString("item_name"),
                description = m.optString("description"), price = m.optDouble("price"),
                imageObjectKey = m.optNullableString("image_object_key"), foodType = m.optString("food_type", "any"),
                preparationMinutes = m.optInt("preparation_time_minutes", 15)
            )
        }
    }

    suspend fun loadCategories(restaurantId: String, branchId: String): List<FoodMenuCategory> = withContext(Dispatchers.IO) {
        val arr = restRows("mobility_menu_categories", "select=id,restaurant_id,branch_id,name,display_order&restaurant_id=eq.$restaurantId&is_active=eq.true&order=display_order.asc")
        (0 until arr.length()).mapNotNull { i ->
            val c = arr.optJSONObject(i) ?: return@mapNotNull null
            val branch = c.optNullableString("branch_id")
            if (branch != null && branch != branchId) return@mapNotNull null
            FoodMenuCategory(c.optString("id"), restaurantId, branch, c.optString("name"), c.optInt("display_order"))
        }
    }

    suspend fun signedMenuImageUrl(objectKey: String?): String = withContext(Dispatchers.IO) {
        val key = objectKey?.trim()?.takeIf { it.startsWith("mobility/restaurants/") && !it.contains("..") }
            ?: return@withContext ""
        runCatching {
            // Menu/object downloads are served by the dedicated media function,
            // not the booking API. Keep this call authenticated with the user's JWT.
            val response = JSONObject(client.callEdgeFunction(
                "baatly-mobility-media",
                JSONObject().put("action", "signed_download_url").put("object_key", key).toString()
            ))
            if (!response.optBoolean("success", false)) {
                throw IllegalStateException(response.optString("error").ifBlank { "Menu image URL unavailable" })
            }
            response.optString("download_url").takeUnless { it.isBlank() || it == "null" }.orEmpty()
        }.getOrElse { error ->
            Log.w(TAG, "Menu image could not be signed: ${error.message}")
            ""
        }
    }

    suspend fun quoteCab(
        pickup: MobilityPoint,
        drop: MobilityPoint,
        category: String,
        serviceType: String
    ): MobilityCabQuote = withContext(Dispatchers.IO) {
        val response = edge("route_quote", JSONObject().apply {
            put("city_code", "DEFAULT")
            put("service_type", serviceType)
            put("vehicle_category", category)
            put("travel_mode", if (serviceType == "bike_taxi") "two_wheeler" else "drive")
            put("origin", JSONObject().put("latitude", pickup.latitude).put("longitude", pickup.longitude))
            put("destination", JSONObject().put("latitude", drop.latitude).put("longitude", drop.longitude))
        })
        val route = response.optJSONObject("route") ?: JSONObject()
        val quote = response.optJSONObject("quote") ?: JSONObject()
        MobilityCabQuote(
            distanceKm = route.optDouble("distanceKm"), durationMinutes = route.optDouble("durationMinutes"),
            fare = quote.optDouble("quoted_fare"), baseFare = quote.optDouble("base_fare"),
            distanceFare = quote.optDouble("distance_fare"), timeFare = quote.optDouble("time_fare"),
            perKmRate = quote.optDouble("per_km_rate"), perMinuteRate = quote.optDouble("per_minute_rate"),
            encodedPolyline = route.optNullableString("encodedPolyline")
        )
    }

    suspend fun createCabBooking(
        pickup: MobilityPoint,
        drop: MobilityPoint,
        category: String,
        serviceType: String
    ): MobilityRide = withContext(Dispatchers.IO) {
        val response = edge("create_cab_booking", JSONObject().put("payload", JSONObject().apply {
            put("city_code", "DEFAULT")
            put("city", pickup.city)
            put("state", pickup.state)
            put("service_type", serviceType)
            put("vehicle_category", category)
            put("pickup_address", pickup.address)
            put("pickup_latitude", pickup.latitude)
            put("pickup_longitude", pickup.longitude)
            put("drop_address", drop.address)
            put("drop_latitude", drop.latitude)
            put("drop_longitude", drop.longitude)
        }))
        val booking = response.optJSONObject("booking") ?: throw IllegalStateException("Booking response was empty")
        val ride = rideFromJson(JSONObject().apply {
            put("id", booking.optString("ride_id"))
            put("status", booking.optString("status", "searching"))
            put("service_type", serviceType)
            put("vehicle_category", category)
            put("pickup_address", pickup.address)
            put("drop_address", drop.address)
            put("pickup_latitude", pickup.latitude); put("pickup_longitude", pickup.longitude)
            put("drop_latitude", drop.latitude); put("drop_longitude", drop.longitude)
            put("quoted_fare", booking.optDouble("quoted_fare"))
        })
        ride.copy(rideCode = booking.optNullableString("ride_code"))
    }

    suspend fun getCabRide(rideId: String): MobilityRide? = withContext(Dispatchers.IO) {
        val fields = "id,status,service_type,vehicle_category,pickup_address,drop_address,pickup_latitude,pickup_longitude,drop_latitude,drop_longitude,route_distance_km,estimated_minutes,quoted_fare,final_fare,assigned_partner_id,cancellation_fee_amount,waiting_fee_amount,created_at"
        val arr = restRows("mobility_cab_rides", "select=$fields&id=eq.$rideId&limit=1")
        arr.optJSONObject(0)?.let(::rideFromJson)
    }

    suspend fun loadActiveCabRide(): MobilityRide? = withContext(Dispatchers.IO) {
        val userId = sessionManager.userId.value.orEmpty()
        if (userId.isBlank()) return@withContext null
        val fields = "id,status,service_type,vehicle_category,pickup_address,drop_address,pickup_latitude,pickup_longitude,drop_latitude,drop_longitude,route_distance_km,estimated_minutes,quoted_fare,final_fare,assigned_partner_id,cancellation_fee_amount,waiting_fee_amount,created_at"
        val arr = restRows("mobility_cab_rides", "select=$fields&customer_id=eq.$userId&status=in.(searching,accepted,driver_arriving,arrived,in_progress)&order=created_at.desc&limit=1")
        arr.optJSONObject(0)?.let(::rideFromJson)
    }

    suspend fun cancelCabRide(rideId: String, reason: String): JSONObject = edge("cancel_cab_ride", JSONObject().put("ride_id", rideId).put("reason", reason))

    suspend fun createFoodOrder(
        restaurant: FoodRestaurant,
        branch: FoodBranch,
        destination: MobilityPoint,
        cart: List<FoodCartLine>
    ): FoodOrder = withContext(Dispatchers.IO) {
        val response = edge("create_food_order", JSONObject().apply {
            put("payload", JSONObject().apply {
                put("restaurant_id", restaurant.id)
                put("branch_id", branch.id)
                put("city_code", "DEFAULT")
                put("delivery_address", destination.address)
                put("delivery_latitude", destination.latitude)
                put("delivery_longitude", destination.longitude)
                put("city", destination.city)
                put("state", destination.state)
            })
            put("items", JSONArray().apply {
                cart.forEach { line ->
                    put(JSONObject().put("menu_item_id", line.item.id).put("quantity", line.quantity).put("customization", JSONObject()))
                }
            })
        })
        val order = response.optJSONObject("order") ?: JSONObject()
        FoodOrder(
            id = order.optString("order_id"), status = order.optString("status", "placed"),
            restaurantName = restaurant.name, deliveryAddress = destination.address,
            customerTotal = order.optDouble("customer_total"), foodSubtotal = order.optDouble("food_subtotal"),
            deliveryFee = order.optDouble("delivery_fee"), packingFee = order.optDouble("packing_fee"),
            platformFee = order.optDouble("platform_fee"), deliveryCode = order.optNullableString("delivery_code"),
            assignedPartnerId = null, createdAt = "",
            deliveryLatitude = destination.latitude, deliveryLongitude = destination.longitude
        )
    }

    suspend fun getFoodOrder(orderId: String): FoodOrder? = withContext(Dispatchers.IO) {
        val fields = "id,status,restaurant_id,delivery_address,delivery_latitude,delivery_longitude,customer_total,food_subtotal,customer_delivery_fee,packing_fee,platform_fee,assigned_partner_id,created_at"
        val arr = restRows("mobility_food_orders", "select=$fields&id=eq.$orderId&limit=1")
        arr.optJSONObject(0)?.let { foodOrderFromJson(it, "BAATLY Food") }
    }

    suspend fun loadActiveFoodOrder(): FoodOrder? = withContext(Dispatchers.IO) {
        val userId = sessionManager.userId.value.orEmpty()
        if (userId.isBlank()) return@withContext null
        val fields = "id,status,restaurant_id,delivery_address,delivery_latitude,delivery_longitude,customer_total,food_subtotal,customer_delivery_fee,packing_fee,platform_fee,assigned_partner_id,created_at"
        val arr = restRows("mobility_food_orders", "select=$fields&customer_id=eq.$userId&status=not.in.(delivered,cancelled,rejected)&order=created_at.desc&limit=1")
        arr.optJSONObject(0)?.let { foodOrderFromJson(it, "BAATLY Food") }
    }

    suspend fun cancelFoodOrder(orderId: String, reason: String): JSONObject = edge("cancel_food_order", JSONObject().put("order_id", orderId).put("reason", reason))

    suspend fun trackingSnapshot(jobType: String, jobId: String): MobilityTrackingLocation? = withContext(Dispatchers.IO) {
        val url = "$TRACKING_BASE_URL/v1/tracking/$jobType/$jobId/snapshot"
        val response = JSONObject(client.get(url))
        if (!response.optBoolean("success", false)) return@withContext null
        val loc = response.optJSONObject("location") ?: return@withContext null
        MobilityTrackingLocation(
            latitude = loc.optDouble("latitude"), longitude = loc.optDouble("longitude"),
            accuracyMeters = loc.optDouble("accuracy_meters").takeIf { loc.has("accuracy_meters") && !loc.isNull("accuracy_meters") },
            speedMetersPerSecond = loc.optDouble("speed_mps").takeIf { loc.has("speed_mps") && !loc.isNull("speed_mps") },
            headingDegrees = loc.optDouble("heading_degrees").takeIf { loc.has("heading_degrees") && !loc.isNull("heading_degrees") },
            recordedAt = loc.optLong("recorded_at"), stale = loc.optBoolean("stale"),
            distanceKm = response.optDouble("distance_km"), ended = response.optBoolean("ended")
        )
    }

    fun connectTracking(jobType: String, jobId: String, onLocation: (MobilityTrackingLocation) -> Unit, onSocketClosed: () -> Unit): WebSocket? {
        val token = sessionManager.accessToken.value ?: return null
        val url = TRACKING_BASE_URL.replaceFirst("https://", "wss://") + "/v1/tracking/$jobType/$jobId/ws"
        val request = Request.Builder().url(url).header("Authorization", "Bearer $token").build()
        return try {
            client.okHttpClient.newWebSocket(request, object : WebSocketListener() {
                override fun onMessage(webSocket: WebSocket, text: String) {
                    try {
                        val payload = JSONObject(text)
                        when (payload.optString("type")) {
                            "location" -> onLocation(
                                MobilityTrackingLocation(
                                    latitude = payload.optDouble("latitude"), longitude = payload.optDouble("longitude"),
                                    accuracyMeters = payload.optDouble("accuracy_meters").takeIf { payload.has("accuracy_meters") && !payload.isNull("accuracy_meters") },
                                    speedMetersPerSecond = payload.optDouble("speed_mps").takeIf { payload.has("speed_mps") && !payload.isNull("speed_mps") },
                                    headingDegrees = payload.optDouble("heading_degrees").takeIf { payload.has("heading_degrees") && !payload.isNull("heading_degrees") },
                                    recordedAt = payload.optLong("recorded_at"), stale = false,
                                    distanceKm = payload.optDouble("distance_km")
                                )
                            )
                            "location_stale", "tracking_ended" -> onSocketClosed()
                        }
                    } catch (e: Exception) { Log.w(TAG, "Ignoring malformed tracking message", e) }
                }
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    Log.w(TAG, "Tracking WebSocket closed; snapshot polling will continue", t)
                    onSocketClosed()
                }
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { onSocketClosed() }
            })
        } catch (e: Exception) {
            Log.w(TAG, "Could not open tracking WebSocket", e)
            null
        }
    }

    private fun rideFromJson(obj: JSONObject): MobilityRide = MobilityRide(
        id = obj.optString("id"), status = obj.optString("status", "searching"),
        serviceType = obj.optString("service_type", "cab"), vehicleCategory = obj.optString("vehicle_category", "auto"),
        pickupAddress = obj.optString("pickup_address"), dropAddress = obj.optString("drop_address"),
        pickupLatitude = obj.optDouble("pickup_latitude"), pickupLongitude = obj.optDouble("pickup_longitude"),
        dropLatitude = obj.optDouble("drop_latitude"), dropLongitude = obj.optDouble("drop_longitude"),
        routeDistanceKm = obj.optDouble("route_distance_km"), estimatedMinutes = obj.optDouble("estimated_minutes"),
        quotedFare = obj.optDouble("quoted_fare"), finalFare = obj.optDouble("final_fare"),
        assignedPartnerId = obj.optNullableString("assigned_partner_id"), rideCode = obj.optNullableString("ride_code"),
        cancellationFee = obj.optDouble("cancellation_fee_amount"), waitingFee = obj.optDouble("waiting_fee_amount"),
        createdAt = obj.optString("created_at")
    )

    private fun foodOrderFromJson(obj: JSONObject, restaurantName: String): FoodOrder = FoodOrder(
        id = obj.optString("id"), status = obj.optString("status"), restaurantName = restaurantName,
        deliveryAddress = obj.optString("delivery_address"), customerTotal = obj.optDouble("customer_total"),
        foodSubtotal = obj.optDouble("food_subtotal"), deliveryFee = obj.optDouble("customer_delivery_fee"),
        packingFee = obj.optDouble("packing_fee"), platformFee = obj.optDouble("platform_fee"),
        deliveryCode = null, assignedPartnerId = obj.optNullableString("assigned_partner_id"), createdAt = obj.optString("created_at"),
        deliveryLatitude = obj.optDouble("delivery_latitude").takeIf { obj.has("delivery_latitude") && !obj.isNull("delivery_latitude") },
        deliveryLongitude = obj.optDouble("delivery_longitude").takeIf { obj.has("delivery_longitude") && !obj.isNull("delivery_longitude") }
    )
}
