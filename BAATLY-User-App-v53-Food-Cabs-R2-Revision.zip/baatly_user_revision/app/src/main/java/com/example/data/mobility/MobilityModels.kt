package com.example.data.mobility

import org.json.JSONObject

data class MobilityPoint(
    val label: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val city: String = "",
    val state: String = ""
)

data class MobilityCabQuote(
    val distanceKm: Double,
    val durationMinutes: Double,
    val fare: Double,
    val baseFare: Double,
    val distanceFare: Double,
    val timeFare: Double,
    val perKmRate: Double,
    val perMinuteRate: Double,
    val encodedPolyline: String?
)

data class MobilityRide(
    val id: String,
    val status: String,
    val serviceType: String,
    val vehicleCategory: String,
    val pickupAddress: String,
    val dropAddress: String,
    val pickupLatitude: Double,
    val pickupLongitude: Double,
    val dropLatitude: Double,
    val dropLongitude: Double,
    val routeDistanceKm: Double,
    val estimatedMinutes: Double,
    val quotedFare: Double,
    val finalFare: Double,
    val assignedPartnerId: String?,
    val rideCode: String?,
    val cancellationFee: Double,
    val waitingFee: Double,
    val createdAt: String
)

data class MobilityTrackingLocation(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Double?,
    val speedMetersPerSecond: Double?,
    val headingDegrees: Double?,
    val recordedAt: Long,
    val stale: Boolean,
    val distanceKm: Double = 0.0,
    val ended: Boolean = false
)

data class FoodRestaurant(
    val id: String,
    val name: String,
    val cuisines: List<String>,
    val description: String,
    val logoObjectKey: String?,
    val branches: List<FoodBranch>,
    val menuFoodTypes: Set<String> = emptySet(),
    val menuItemNames: List<String> = emptyList()
)

data class FoodBranch(
    val id: String,
    val restaurantId: String,
    val name: String,
    val address: String,
    val city: String,
    val state: String,
    val latitude: Double?,
    val longitude: Double?,
    val isOpen: Boolean,
    val preparationMinutes: Int
)

data class FoodMenuCategory(
    val id: String,
    val restaurantId: String,
    val branchId: String?,
    val name: String,
    val displayOrder: Int
)

data class FoodMenuItem(
    val id: String,
    val restaurantId: String,
    val branchId: String?,
    val categoryId: String?,
    val name: String,
    val description: String,
    val price: Double,
    val imageObjectKey: String?,
    val foodType: String,
    val preparationMinutes: Int,
    val imageUrl: String? = null
)

data class FoodCartLine(val item: FoodMenuItem, val quantity: Int)

data class FoodOrder(
    val id: String,
    val status: String,
    val restaurantName: String,
    val deliveryAddress: String,
    val customerTotal: Double,
    val foodSubtotal: Double,
    val deliveryFee: Double,
    val packingFee: Double,
    val platformFee: Double,
    val deliveryCode: String?,
    val assignedPartnerId: String?,
    val createdAt: String,
    val deliveryLatitude: Double? = null,
    val deliveryLongitude: Double? = null
)

internal fun JSONObject.optNullableString(key: String): String? =
    optString(key).takeIf { it.isNotBlank() && it != "null" }
