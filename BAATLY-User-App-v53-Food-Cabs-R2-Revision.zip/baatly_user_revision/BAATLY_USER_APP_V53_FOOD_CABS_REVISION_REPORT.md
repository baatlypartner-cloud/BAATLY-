# BAATLY User App v53 — Food & Cabs revision

## UI / navigation
- Changed the mobility palette to a premium light surface with plum/purple and pink accents.
- Replaced the old drawn stick-figure panda with a 3D panda artwork asset. The search animation alternates between a running cycle and a short scanning pause while the booking status is `searching`.
- Cab booking has a dedicated vehicle artwork hero and a full route preview after both addresses are chosen.
- Pickup, drop and food delivery address selection now use a full-screen map page, not a dialog. It supports address search results, tap-to-pin, reverse geocoding, current-location permission, confirm bar and Android back navigation. The default map camera does not count as a selected location.
- Food cart/checkout uses a full-screen page. Back navigation returns through cart, restaurant menu and location selection.
- Food discovery now includes restaurant/dish search, cuisine shortcuts, veg/non-veg/open filters and R2-backed restaurant logo and menu image URLs.
- Version set to 53 / 1.0.53.

## Booking and media fixes
- Cab create-booking now receives its first dispatch round and returns the ride ID immediately rather than waiting synchronously through all 15-second dispatch windows. The existing dispatch scheduler continues later rounds, so the User App can expose Cancel Ride as soon as the booking ID exists.
- Customer cancellation feedback now reads the server's `total_due` field. No-partner-found rides display a retry action.
- Social post/story playback is R2-only in the app resolver. Legacy `social-media/...` objects are migrated once to `baatly-media` on feed/playback access; the database media path is changed to the R2 key and future playback signs from R2.

## Backend deployments made
- `baatly-r2-media` Edge Function: version 22, ACTIVE; added one-time legacy social media to R2 migration and removed Supabase Storage signed-URL fallback for social playback.
- `baatly-mobility-api` Edge Function: version 7, ACTIVE; cab booking returns after first dispatch offer batch to keep cancellation responsive.

## Known limits / validation
- 0 approved active restaurants currently exist in the production mobility catalog, so Food will show a truthful empty state until a restaurant is approved, activated, and has an open branch/menu.
- Server route quotes still depend on `GOOGLE_MAPS_API_KEY` being configured as a Supabase Edge Function secret. This was not verifiable with the available controls; the Android Maps SDK key is present in the app resources but does not prove the server secret exists.
- The Gradle wrapper distribution could not be downloaded (`services.gradle.org` DNS failure). Kotlin source was scanned for parser-level syntax errors and none were reported, but a full Gradle compile and APK build could not be run in this environment.
- Existing old feed media is copied to R2 on a user's authenticated feed/playback request. Profile-avatar storage was not changed because it was outside the feed-photo path and the avatar pipeline was already working.
