# BAATLY User App — v53 Food & Cabs revision

Native Android application built with Kotlin and Jetpack Compose.

## v53 highlights

- Reworked Food & Cabs with a premium light/purple theme, vehicle artwork, full-screen map address selection, route preview, restaurant discovery/search, filters, R2-backed food images and full-screen cart.
- Added a 3D panda runner/search artwork animation that alternates between running and scanning until partner assignment or cancellation.
- Cab creation now returns the ride ID after the first dispatch batch so the user can cancel without waiting for all dispatch rounds.
- Cab cancel status, no-partner retry, live tracking, ride code and food order status are connected to the mobility API.
- Social post/story media playback is R2-only in the app. Legacy feed media is copied to R2 on first authenticated feed/playback access.
- AI Astrology remains removed from the user navigation.

## Build

1. Open this project root in Android Studio.
2. Use JDK 17 for the Gradle build.
3. Configure the existing Supabase, Google Maps and CI signing secrets using your own secure values.
4. Run `./gradlew :app:assembleRelease`.

`versionCode = 53`; `versionName = 1.0.53`.

Validation note: ZIP integrity and XML parsing passed. Kotlin parser scan reported no syntax errors, but the full Gradle build could not run here because the Gradle 9.3.1 distribution download failed with a `services.gradle.org` DNS error. This archive is source code, not an APK. See `BAATLY_USER_APP_V53_FOOD_CABS_REVISION_REPORT.md` for backend deployment status and remaining requirements.
