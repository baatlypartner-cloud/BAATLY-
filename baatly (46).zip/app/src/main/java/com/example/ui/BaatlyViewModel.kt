package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AgoraCallManager
import com.example.data.audio.AudioPlayerManager
import com.example.data.audio.AudioRecorderManager
import com.example.data.local.SessionManager
import com.example.data.model.*
import com.example.data.network.SupabaseAuthService
import com.example.data.network.SupabaseClient
import com.example.data.network.SupabaseDataService
import com.example.domain.BillingEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class BaatlyViewModel(application: Application) : AndroidViewModel(application) {

    val sessionManager = SessionManager(application)
    private val supabaseClient = SupabaseClient(sessionManager)
    val authService = SupabaseAuthService(supabaseClient, sessionManager)
    val dataService = SupabaseDataService(supabaseClient, sessionManager)

    val agoraCallManager = AgoraCallManager(application)
    val audioRecorderManager = AudioRecorderManager(application)
    val audioPlayerManager = AudioPlayerManager(application)
    val realtimeManager = com.example.data.network.SupabaseRealtimeManager(supabaseClient.okHttpClient, sessionManager)

    // User & Auth State
    val isLoggedIn = sessionManager.accessToken
    val currentUser = sessionManager.currentUser
    val wallet = sessionManager.wallet

    private val _isRestoringSession = MutableStateFlow(sessionManager.isLoggedIn)
    val isRestoringSession: StateFlow<Boolean> = _isRestoringSession.asStateFlow()

    private val _startupError = MutableStateFlow<String?>(null)
    val startupError: StateFlow<String?> = _startupError.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _userIdAvailable = MutableStateFlow<Boolean?>(null)
    val userIdAvailable: StateFlow<Boolean?> = _userIdAvailable.asStateFlow()

    // Navigation & Screen State
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _homeMode = MutableStateFlow(HomeMode.CALL) // CALL or CHAT
    val homeMode: StateFlow<HomeMode> = _homeMode.asStateFlow()

    // Hosts State
    private val _availablePartners = MutableStateFlow<List<PartnerProfile>>(emptyList())
    val availablePartners: StateFlow<List<PartnerProfile>> = _availablePartners.asStateFlow()

    private val _isLoadingPartners = MutableStateFlow(false)
    val isLoadingPartners: StateFlow<Boolean> = _isLoadingPartners.asStateFlow()

    private val _selectedPartner = MutableStateFlow<PartnerProfile?>(null)
    val selectedPartner: StateFlow<PartnerProfile?> = _selectedPartner.asStateFlow()

    // Call State
    private val _activeCall = MutableStateFlow<CallRecord?>(null)
    val activeCall: StateFlow<CallRecord?> = _activeCall.asStateFlow()

    private val _activeCallPartner = MutableStateFlow<PartnerProfile?>(null)
    val activeCallPartner: StateFlow<PartnerProfile?> = _activeCallPartner.asStateFlow()

    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _callRemainingSeconds = MutableStateFlow(0)
    val callRemainingSeconds: StateFlow<Int> = _callRemainingSeconds.asStateFlow()

    private val _callElapsedSeconds = MutableStateFlow(0)
    val callElapsedSeconds: StateFlow<Int> = _callElapsedSeconds.asStateFlow()

    private var callTimerJob: Job? = null

    // Chat State
    private val _conversations = MutableStateFlow<List<ConversationSummary>>(emptyList())
    val conversations: StateFlow<List<ConversationSummary>> = _conversations.asStateFlow()

    private val _activeConversation = MutableStateFlow<ConversationSummary?>(null)
    val activeConversation: StateFlow<ConversationSummary?> = _activeConversation.asStateFlow()

    private val _chatPartner = MutableStateFlow<PartnerProfile?>(null)
    val chatPartner: StateFlow<PartnerProfile?> = _chatPartner.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    private val conversationMessagesCache = java.util.concurrent.ConcurrentHashMap<String, List<ChatMessage>>()

    private val _isChatBlocked = MutableStateFlow(false)
    val isChatBlocked: StateFlow<Boolean> = _isChatBlocked.asStateFlow()

    // Gifts State
    private val _gifts = MutableStateFlow<List<GiftItem>>(emptyList())
    val gifts: StateFlow<List<GiftItem>> = _gifts.asStateFlow()

    private val _showGiftSheet = MutableStateFlow(false)
    val showGiftSheet: StateFlow<Boolean> = _showGiftSheet.asStateFlow()

    private val _recentGiftAnimation = MutableStateFlow<GiftItem?>(null)
    val recentGiftAnimation: StateFlow<GiftItem?> = _recentGiftAnimation.asStateFlow()

    // Wallet & Packages State
    private val _coinPackages = MutableStateFlow<List<CoinPackage>>(emptyList())
    val coinPackages: StateFlow<List<CoinPackage>> = _coinPackages.asStateFlow()

    // Recent Calls State
    private val _recentCalls = MutableStateFlow<List<CallRecord>>(emptyList())
    val recentCalls: StateFlow<List<CallRecord>> = _recentCalls.asStateFlow()

    // Notifications State
    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    // Social Media State
    private val _socialPosts = MutableStateFlow<List<SocialPost>>(emptyList())
    val socialPosts: StateFlow<List<SocialPost>> = _socialPosts.asStateFlow()

    private val _socialStories = MutableStateFlow<List<SocialStory>>(emptyList())
    val socialStories: StateFlow<List<SocialStory>> = _socialStories.asStateFlow()

    private val _isLoadingSocial = MutableStateFlow(false)
    val isLoadingSocial: StateFlow<Boolean> = _isLoadingSocial.asStateFlow()

    private val _isRefreshingSocial = MutableStateFlow(false)
    val isRefreshingSocial: StateFlow<Boolean> = _isRefreshingSocial.asStateFlow()

    private val _mySocialProfile = MutableStateFlow<SocialProfile?>(null)
    val mySocialProfile: StateFlow<SocialProfile?> = _mySocialProfile.asStateFlow()

    private val _viewedSocialProfile = MutableStateFlow<SocialProfile?>(null)
    val viewedSocialProfile: StateFlow<SocialProfile?> = _viewedSocialProfile.asStateFlow()

    private val _isLoadingSocialProfile = MutableStateFlow(false)
    val isLoadingSocialProfile: StateFlow<Boolean> = _isLoadingSocialProfile.asStateFlow()

    private val _activeStoryViewer = MutableStateFlow<SocialStory?>(null)
    val activeStoryViewer: StateFlow<SocialStory?> = _activeStoryViewer.asStateFlow()

    private val _activeCommentsPost = MutableStateFlow<SocialPost?>(null)
    val activeCommentsPost: StateFlow<SocialPost?> = _activeCommentsPost.asStateFlow()

    private val _activeCommentsStory = MutableStateFlow<SocialStory?>(null)
    val activeCommentsStory: StateFlow<SocialStory?> = _activeCommentsStory.asStateFlow()

    private val _socialComments = MutableStateFlow<List<SocialComment>>(emptyList())
    val socialComments: StateFlow<List<SocialComment>> = _socialComments.asStateFlow()

    private val _isLoadingComments = MutableStateFlow(false)
    val isLoadingComments: StateFlow<Boolean> = _isLoadingComments.asStateFlow()

    private val _socialSearchResult = MutableStateFlow<SocialSearchResult?>(null)
    val socialSearchResult: StateFlow<SocialSearchResult?> = _socialSearchResult.asStateFlow()

    private val _isSearchingSocial = MutableStateFlow(false)
    val isSearchingSocial: StateFlow<Boolean> = _isSearchingSocial.asStateFlow()

    private val _socialSearchError = MutableStateFlow<String?>(null)
    val socialSearchError: StateFlow<String?> = _socialSearchError.asStateFlow()

    // General Toast / SnackBar State
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        if (sessionManager.isLoggedIn) {
            loadInitialData()
        }
    }

    fun setScreen(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setHomeMode(mode: HomeMode) {
        _homeMode.value = mode
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    fun toggleGiftSheet(show: Boolean) {
        _showGiftSheet.value = show
    }

    // AUTH FLOWS
    fun checkUserIdAvailability(userId: String) {
        if (userId.length < 3) {
            _userIdAvailable.value = null
            return
        }
        viewModelScope.launch {
            val isAvail = authService.checkUserIdAvailable(userId)
            _userIdAvailable.value = isAvail
        }
    }

    fun signIn(userId: String, password: String) {
        if (userId.isBlank() || password.isBlank()) {
            _authError.value = "Please enter both User ID and Password."
            return
        }
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            val result = authService.signIn(userId, password)
            _isAuthLoading.value = false
            result.onSuccess {
                loadInitialData()
                _currentScreen.value = Screen.HOME
            }.onFailure { error ->
                _authError.value = error.message ?: "Authentication failed."
            }
        }
    }

    fun signUp(
        displayName: String,
        userId: String,
        password: String,
        mobileNumber: String,
        avatarFile: File? = null,
        referralCode: String? = null
    ) {
        val normalizedUserId = userId.trim().lowercase()

        // Validation 1: User ID
        val userIdRegex = Regex("""^[a-z0-9._-]{3,30}$""")
        if (!userIdRegex.matches(normalizedUserId)) {
            _authError.value = "User ID must be 3-30 characters (letters, numbers, '.', '_', '-')."
            return
        }

        // Validation 2: Display Name
        if (displayName.trim().isBlank()) {
            _authError.value = "Display Name is required."
            return
        }

        // Validation 3: Password
        if (password.length < 6) {
            _authError.value = "Password must be at least 6 characters."
            return
        }

        // Validation 4: Mobile Number (10 digits)
        val cleanPhone = mobileNumber.trim().replace("+91", "").replace(" ", "").replace("-", "").filter { it.isDigit() }
        val mobileRegex = Regex("""^[0-9]{10}$""")
        if (!mobileRegex.matches(cleanPhone)) {
            _authError.value = "Please enter a valid 10-digit mobile number."
            return
        }

        _isAuthLoading.value = true
        _authError.value = null

        viewModelScope.launch {
            val result = authService.signUp(
                userId = normalizedUserId,
                password = password,
                displayName = displayName.trim(),
                mobileNumber = cleanPhone,
                avatarFile = avatarFile,
                referralCode = referralCode?.trim().takeIf { !it.isNullOrBlank() }
            )
            _isAuthLoading.value = false
            result.onSuccess {
                loadInitialData()
                _currentScreen.value = Screen.HOME
            }.onFailure { error ->
                _authError.value = error.message ?: "Sign up failed."
            }
        }
    }

    fun clearAuthError() {
        _authError.value = null
        _userIdAvailable.value = null
    }

    fun updateUserProfile(
        displayName: String,
        bio: String?,
        avatarFile: File? = null,
        onComplete: ((Boolean, String?) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val res = authService.updateProfile(displayName, bio, avatarFile)
            res.onSuccess { updated ->
                _userMessage.value = "Profile updated successfully!"
                onComplete?.invoke(true, null)
            }.onFailure { err ->
                val errorMsg = err.message ?: "Failed to update profile."
                _userMessage.value = errorMsg
                onComplete?.invoke(false, errorMsg)
            }
        }
    }

    fun signOut() {
        authService.signOut()
        _currentScreen.value = Screen.AUTH
    }

    fun retryStartup() {
        _startupError.value = null
        if (sessionManager.isLoggedIn) {
            loadInitialData()
        }
    }

    fun loadInitialData() {
        _isRestoringSession.value = true
        _startupError.value = null
        viewModelScope.launch {
            try {
                authService.fetchCurrentUserProfile()
                dataService.fetchWallet()
                refreshPartners()
                refreshGifts()
                refreshCoinPackages()
                refreshConversations()
                refreshRecentCalls()
                refreshNotifications()
                refreshSocialFeed()
                loadMySocialProfile()
            } catch (e: Exception) {
                // If we have cached profile/session, do not block the app
                if (sessionManager.currentUser.value == null) {
                    _startupError.value = e.message ?: "Failed to load session data"
                }
            } finally {
                _isRestoringSession.value = false
            }
        }
    }

    fun refreshPartners() {
        _isLoadingPartners.value = true
        viewModelScope.launch {
            dataService.getAvailablePartners().onSuccess {
                _availablePartners.value = it
            }
            _isLoadingPartners.value = false
        }
    }

    fun refreshGifts() {
        viewModelScope.launch {
            dataService.fetchGifts().onSuccess {
                _gifts.value = it
            }
        }
    }

    fun refreshCoinPackages() {
        viewModelScope.launch {
            dataService.fetchCoinPackages().onSuccess {
                _coinPackages.value = it
            }
        }
    }

    fun refreshConversations() {
        viewModelScope.launch {
            dataService.fetchConversations().onSuccess {
                _conversations.value = it
            }
        }
    }

    fun refreshRecentCalls() {
        viewModelScope.launch {
            dataService.fetchRecentCalls().onSuccess {
                _recentCalls.value = it
            }
        }
    }

    fun refreshNotifications() {
        viewModelScope.launch {
            dataService.fetchNotifications().onSuccess {
                _notifications.value = it
            }
        }
    }

    fun refreshWallet() {
        viewModelScope.launch {
            dataService.fetchWallet()
        }
    }

    // HOST ACTIONS
    fun openHostProfile(partner: PartnerProfile) {
        _selectedPartner.value = partner
        _currentScreen.value = Screen.HOST_PROFILE
    }

    fun toggleFollowHost(partner: PartnerProfile) {
        viewModelScope.launch {
            val isNowFollowing = !partner.isFollowing
            if (isNowFollowing) {
                dataService.followHost(partner.id)
            } else {
                dataService.unfollowHost(partner.id)
            }
            // Update local state
            _selectedPartner.value = _selectedPartner.value?.copy(
                isFollowing = isNowFollowing,
                followersCount = if (isNowFollowing) partner.followersCount + 1 else maxOf(0, partner.followersCount - 1)
            )
            _availablePartners.value = _availablePartners.value.map {
                if (it.id == partner.id) it.copy(isFollowing = isNowFollowing) else it
            }
        }
    }

    // CALL FLOW
    private var callPollerJob: Job? = null

    fun requestCall(partner: PartnerProfile) {
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < BillingEngine.USER_COINS_PER_MINUTE) {
            _userMessage.value = "You don't have enough coins. Please top up your wallet."
            _currentScreen.value = Screen.WALLET
            return
        }

        val estimatedMaxSeconds = BillingEngine.calculateMaxCallDurationSeconds(currentBalance)
        _activeCallPartner.value = partner
        _callState.value = CallState.REQUESTING
        _callRemainingSeconds.value = estimatedMaxSeconds
        _callElapsedSeconds.value = 0
        _currentScreen.value = Screen.ACTIVE_CALL

        viewModelScope.launch {
            val result = dataService.requestCall(partner.id)
            result.onSuccess { callRecord ->
                _activeCall.value = callRecord
                _callState.value = CallState.RINGING
                startCallStatePoller(callRecord, partner)
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Could not connect call."
                endCall()
            }
        }
    }

    private fun startCallStatePoller(initialCall: CallRecord, partner: PartnerProfile) {
        callPollerJob?.cancel()
        callPollerJob = viewModelScope.launch {
            var currentCall = initialCall
            var joinedAgora = false

            while (_callState.value != CallState.ENDED && _callState.value != CallState.IDLE) {
                delay(1500)
                val statusResult = dataService.getCallRecord(currentCall.id)
                if (statusResult.isSuccess) {
                    val updated = statusResult.getOrThrow()
                    currentCall = updated
                    _activeCall.value = updated

                    when (updated.status.lowercase()) {
                        "ringing" -> {
                            if (_callState.value != CallState.RINGING) {
                                _callState.value = CallState.RINGING
                            }
                        }
                        "accepted", "connected" -> {
                            val channelName = updated.agoraChannelId
                            if (!joinedAgora && !channelName.isNullOrBlank()) {
                                joinedAgora = true
                                android.util.Log.i("BaatlyViewModel", "Using authoritative calls.agora_channel_id: $channelName")
                                dataService.getAgoraToken(channelName).onSuccess { tokenResp ->
                                    android.util.Log.i("BaatlyViewModel", "Joining Agora with exact channel: $channelName, token channel: ${tokenResp.channelName}")
                                    agoraCallManager.joinChannel(tokenResp, channelName)
                                }.onFailure { err ->
                                    android.util.Log.e("BaatlyViewModel", "Failed to get Agora token for channel '$channelName': ${err.message}", err)
                                }

                                if (updated.status.lowercase() == "accepted") {
                                    dataService.updateCallState(updated.id, "connected")
                                }
                                _callState.value = CallState.CONNECTED

                                val maxSec = updated.maxDurationSeconds
                                    ?.takeIf { it > 0 }
                                    ?: BillingEngine.calculateMaxCallDurationSeconds(wallet.value?.balance ?: 0)
                                startCallCountdown(maxSec)
                            }
                        }
                        "completed", "ended", "cancelled", "rejected", "missed" -> {
                            val statusLower = updated.status.lowercase()
                            val msg = when (statusLower) {
                                "rejected" -> "Host declined the call."
                                "missed" -> "No answer. Call was missed."
                                else -> "Call ended."
                            }
                            _userMessage.value = msg
                            handleCallTerminated(statusLower)
                            break
                        }
                    }
                }
            }
        }
    }

    private fun handleCallTerminated(status: String) {
        callPollerJob?.cancel()
        callTimerJob?.cancel()
        agoraCallManager.leaveChannel()

        val call = _activeCall.value
        if (call != null && status != "missed" && status != "rejected" && status != "cancelled") {
            viewModelScope.launch {
                dataService.updateCallState(call.id, "completed")
                dataService.settleCall(call.id)
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        } else {
            viewModelScope.launch {
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        }

        _callState.value = CallState.ENDED
        _activeCall.value = null
        if (_currentScreen.value == Screen.ACTIVE_CALL) {
            _currentScreen.value = Screen.HOME
        }
    }

    private fun startCallCountdown(maxDurationSec: Int) {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            var remaining = maxDurationSec
            var elapsed = 0
            _callRemainingSeconds.value = remaining
            _callElapsedSeconds.value = elapsed

            while (remaining > 0 && _callState.value == CallState.CONNECTED) {
                delay(1000)
                remaining--
                elapsed++
                _callRemainingSeconds.value = remaining
                _callElapsedSeconds.value = elapsed
            }
            if (remaining <= 0 && _callState.value == CallState.CONNECTED) {
                _userMessage.value = "Call ended: Maximum duration reached based on your coin balance."
                endCall()
            }
        }
    }

    fun endCall() {
        callPollerJob?.cancel()
        callTimerJob?.cancel()
        agoraCallManager.leaveChannel()

        val call = _activeCall.value
        if (call != null) {
            viewModelScope.launch {
                dataService.updateCallState(call.id, "completed")
                dataService.settleCall(call.id)
                refreshRecentCalls()
                dataService.fetchWallet()
            }
        }

        _callState.value = CallState.ENDED
        _activeCall.value = null
        if (_currentScreen.value == Screen.ACTIVE_CALL) {
            _currentScreen.value = Screen.HOME
        }
    }

    // CHAT FLOW
    fun openChatWithHost(partner: PartnerProfile) {
        _chatPartner.value = partner
        _isChatBlocked.value = false
        _currentScreen.value = Screen.DIRECT_CHAT

        // Check if we already have an active conversation with this partner
        val existingConv = _conversations.value.find {
            it.partnerId == partner.id || it.partner?.id == partner.id || it.partner?.userId == partner.userId
        }
        if (existingConv != null) {
            _activeConversation.value = existingConv
            val cached = conversationMessagesCache[existingConv.id]
            if (!cached.isNullOrEmpty()) {
                _messages.value = cached
            }
            loadMessages(existingConv.id)
            subscribeToChatRealtime(existingConv.id)
        }

        viewModelScope.launch {
            // Fetch authoritative host profile via get_host_profile RPC
            dataService.getHostProfile(partner.id).onSuccess { hostProfile ->
                _chatPartner.value = hostProfile
                _activeConversation.value?.let { conv ->
                    _activeConversation.value = conv.copy(partner = hostProfile)
                }
            }

            dataService.startChatWithHost(partner.id).onSuccess { convId ->
                val currentP = _chatPartner.value ?: partner
                val currentConv = _activeConversation.value
                if (currentConv == null || currentConv.id != convId) {
                    _activeConversation.value = ConversationSummary(
                        id = convId,
                        partnerId = partner.id,
                        partner = currentP
                    )
                }
                loadMessages(convId)
                subscribeToChatRealtime(convId)
            }
        }
    }

    fun openConversation(conversation: ConversationSummary) {
        _activeConversation.value = conversation
        _chatPartner.value = conversation.partner
        _isChatBlocked.value = false
        _currentScreen.value = Screen.DIRECT_CHAT

        // Immediately restore cached messages
        val cached = conversationMessagesCache[conversation.id]
        if (!cached.isNullOrEmpty()) {
            _messages.value = cached
        }

        val partnerId = conversation.partnerId
        if (!partnerId.isNullOrBlank()) {
            viewModelScope.launch {
                dataService.getHostProfile(partnerId).onSuccess { hostProfile ->
                    _chatPartner.value = hostProfile
                    _activeConversation.value = _activeConversation.value?.copy(partner = hostProfile)
                }
            }
        }

        loadMessages(conversation.id)
        subscribeToChatRealtime(conversation.id)
    }

    fun ensureChatLoaded() {
        val currentConv = _activeConversation.value
        val currentPartner = _chatPartner.value
        val partnerId = currentPartner?.id ?: currentConv?.partnerId

        if (!partnerId.isNullOrBlank()) {
            viewModelScope.launch {
                dataService.getHostProfile(partnerId).onSuccess { hostProfile ->
                    _chatPartner.value = hostProfile
                    _activeConversation.value?.let { conv ->
                        _activeConversation.value = conv.copy(partner = hostProfile)
                    }
                }
            }
        }

        if (currentConv != null && currentConv.id.isNotBlank()) {
            val cached = conversationMessagesCache[currentConv.id]
            if (!cached.isNullOrEmpty() && _messages.value.isEmpty()) {
                _messages.value = cached
            }
            loadMessages(currentConv.id)
            subscribeToChatRealtime(currentConv.id)
        } else if (!partnerId.isNullOrBlank()) {
            viewModelScope.launch {
                dataService.startChatWithHost(partnerId).onSuccess { convId ->
                    val currentP = _chatPartner.value ?: currentPartner
                    _activeConversation.value = ConversationSummary(
                        id = convId,
                        partnerId = partnerId,
                        partner = currentP
                    )
                    loadMessages(convId)
                    subscribeToChatRealtime(convId)
                }
            }
        }
    }

    private fun subscribeToChatRealtime(conversationId: String) {
        realtimeManager.subscribeToConversation(
            conversationId = conversationId,
            onNewMessage = { newMsg -> onRealtimeMessageReceived(newMsg) },
            onResync = { loadMessages(conversationId) }
        )
    }

    private fun onRealtimeMessageReceived(newMsg: ChatMessage) {
        val currentList = _messages.value
        if (currentList.none { it.id == newMsg.id }) {
            val updated = currentList + newMsg
            _messages.value = updated
            val convId = newMsg.conversationId.ifBlank { _activeConversation.value?.id ?: "" }
            if (convId.isNotBlank()) {
                conversationMessagesCache[convId] = updated
            }
        }
        refreshConversations()
    }

    fun refreshCurrentChat() {
        val convId = _activeConversation.value?.id
        val partnerId = _chatPartner.value?.id ?: _activeConversation.value?.partnerId
        viewModelScope.launch {
            if (!partnerId.isNullOrBlank()) {
                dataService.getHostProfile(partnerId).onSuccess { hostProfile ->
                    _chatPartner.value = hostProfile
                    _activeConversation.value?.let { conv ->
                        _activeConversation.value = conv.copy(partner = hostProfile)
                    }
                }
            }
            if (!convId.isNullOrBlank()) {
                loadMessages(convId)
                subscribeToChatRealtime(convId)
            }
        }
    }

    fun closeChatScreen() {
        val convId = _activeConversation.value?.id
        if (!convId.isNullOrBlank() && _messages.value.isNotEmpty()) {
            conversationMessagesCache[convId] = _messages.value
        }
        realtimeManager.unsubscribe()
        audioPlayerManager.stop()
        _activeConversation.value = null
        _chatPartner.value = null
        _currentScreen.value = Screen.CHAT_LIST
        refreshConversations()
    }

    fun loadMessages(conversationId: String) {
        if (conversationId.isBlank()) return
        val cached = conversationMessagesCache[conversationId]
        if (!cached.isNullOrEmpty() && _messages.value.isEmpty()) {
            _messages.value = cached
        }

        viewModelScope.launch {
            dataService.fetchMessages(conversationId).onSuccess { fetchedList ->
                if (fetchedList.isNotEmpty()) {
                    val currentList = _messages.value
                    val existingIds = currentList.map { it.id }.toSet()
                    val newOnes = fetchedList.filter { it.id !in existingIds }
                    val merged = if (currentList.isEmpty()) fetchedList else (currentList + newOnes)
                    val sorted = merged.distinctBy { it.id }
                    _messages.value = sorted
                    conversationMessagesCache[conversationId] = sorted
                } else if (_messages.value.isNotEmpty()) {
                    conversationMessagesCache[conversationId] = _messages.value
                }
            }.onFailure { err ->
                android.util.Log.e("BaatlyViewModel", "loadMessages error: ${err.message}", err)
            }

            dataService.markMessagesAsRead(conversationId)
        }
    }

    fun playVoiceMessage(mediaUrl: String) {
        viewModelScope.launch {
            val playableUrl = dataService.getSignedMediaUrl(mediaUrl, com.example.data.network.SupabaseConfig.BUCKET_CHAT_MEDIA)
            audioPlayerManager.play(playableUrl)
        }
    }

    fun sendTextMessage(content: String, onResult: ((Boolean) -> Unit)? = null) {
        val trimmed = content.trim()
        if (trimmed.isBlank()) return

        // Contact Number Moderation check
        if (BillingEngine.containsForbiddenNumberContent(trimmed)) {
            _userMessage.value = "Number or contact-sharing content is not allowed."
            onResult?.invoke(false)
            return
        }

        val partner = _chatPartner.value
        if (partner == null) {
            _userMessage.value = "Host not found. Please re-open the chat."
            onResult?.invoke(false)
            return
        }

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < BillingEngine.CHAT_COINS_PER_MESSAGE) {
            _userMessage.value = "You don't have enough coins. Messaging costs 3 coins."
            onResult?.invoke(false)
            return
        }

        viewModelScope.launch {
            // Resolve or initialize conversation ID if missing
            var convId = _activeConversation.value?.id
            if (convId.isNullOrBlank()) {
                val startRes = dataService.startChatWithHost(partner.id)
                if (startRes.isSuccess) {
                    convId = startRes.getOrNull()
                    if (!convId.isNullOrBlank()) {
                        _activeConversation.value = ConversationSummary(
                            id = convId,
                            partnerId = partner.id,
                            partner = partner
                        )
                        subscribeToChatRealtime(convId)
                    }
                } else {
                    val err = startRes.exceptionOrNull()?.message ?: "Could not start chat conversation."
                    _userMessage.value = err
                    onResult?.invoke(false)
                    return@launch
                }
            }

            if (convId.isNullOrBlank()) {
                _userMessage.value = "Failed to open conversation."
                onResult?.invoke(false)
                return@launch
            }

            val sendResult = dataService.sendMessage(
                conversationId = convId,
                receiverId = partner.id,
                messageType = "text",
                content = trimmed
            )

            sendResult.onSuccess { newMsg ->
                val currentList = _messages.value
                if (currentList.none { it.id == newMsg.id }) {
                    val updated = currentList + newMsg
                    _messages.value = updated
                    conversationMessagesCache[convId] = updated
                }
                dataService.fetchWallet()
                refreshConversations()
                onResult?.invoke(true)
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to send message."
                onResult?.invoke(false)
            }
        }
    }

    fun sendImageMessage(file: File) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < BillingEngine.CHAT_COINS_PER_MESSAGE) {
            _userMessage.value = "You don't have enough coins. Messaging costs 3 coins."
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = false).onSuccess { mediaUrl ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "image",
                    mediaUrl = mediaUrl
                ).onSuccess { newMsg ->
                    if (_messages.value.none { it.id == newMsg.id }) {
                        val updated = _messages.value + newMsg
                        _messages.value = updated
                        conversationMessagesCache[conv.id] = updated
                    }
                    dataService.fetchWallet()
                    refreshConversations()
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to upload image."
            }
        }
    }

    fun sendVoiceMessage(file: File, durationSec: Int) {
        val conv = _activeConversation.value ?: return
        val partner = _chatPartner.value ?: return

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < BillingEngine.CHAT_COINS_PER_MESSAGE) {
            _userMessage.value = "You don't have enough coins. Messaging costs 3 coins."
            return
        }

        viewModelScope.launch {
            dataService.uploadChatMedia(file, isVoice = true).onSuccess { mediaUrl ->
                dataService.sendMessage(
                    conversationId = conv.id,
                    receiverId = partner.id,
                    messageType = "voice",
                    mediaUrl = mediaUrl,
                    mediaDurationSeconds = durationSec
                ).onSuccess { newMsg ->
                    if (_messages.value.none { it.id == newMsg.id }) {
                        val updated = _messages.value + newMsg
                        _messages.value = updated
                        conversationMessagesCache[conv.id] = updated
                    }
                    dataService.fetchWallet()
                    refreshConversations()
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to upload voice note."
            }
        }
    }

    fun sendGift(gift: GiftItem, targetPartnerId: String? = null, conversationId: String? = null, callId: String? = null) {
        val partnerId = targetPartnerId
            ?: _chatPartner.value?.id
            ?: _activeCallPartner.value?.id
            ?: _selectedPartner.value?.id
            ?: return

        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < gift.coinPrice) {
            _userMessage.value = "You don't have enough coins to send ${gift.name}."
            return
        }

        viewModelScope.launch {
            val convId = conversationId ?: _activeConversation.value?.id
            dataService.sendGift(
                giftId = gift.id,
                receiverId = partnerId,
                conversationId = convId,
                callId = callId ?: _activeCall.value?.id
            ).onSuccess {
                _userMessage.value = "Sent ${gift.name} successfully!"
                _recentGiftAnimation.value = gift
                _showGiftSheet.value = false
                dataService.fetchWallet()
                // If in active chat, append gift message
                if (_activeConversation.value != null) {
                    val giftMsg = ChatMessage(
                        id = java.util.UUID.randomUUID().toString(),
                        conversationId = _activeConversation.value!!.id,
                        senderId = currentUser.value?.id ?: "",
                        receiverId = partnerId,
                        messageType = "gift",
                        giftId = gift.id,
                        gift = gift,
                        createdAt = "Just now"
                    )
                    if (_messages.value.none { it.id == giftMsg.id }) {
                        val updated = _messages.value + giftMsg
                        _messages.value = updated
                        convId?.let { cid -> conversationMessagesCache[cid] = updated }
                    }
                }
                refreshConversations()
                delay(3000)
                _recentGiftAnimation.value = null
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to send gift."
            }
        }
    }

    fun clearCurrentConversation() {
        val conv = _activeConversation.value ?: return
        viewModelScope.launch {
            dataService.clearMyConversation(conv.id).onSuccess {
                _messages.value = emptyList()
                conversationMessagesCache.remove(conv.id)
                _userMessage.value = "Chat cleared."
                refreshConversations()
            }
        }
    }

    fun blockCurrentHost(reason: String = "User requested block") {
        val partner = _chatPartner.value ?: return
        viewModelScope.launch {
            dataService.blockUser(partner.id, reason).onSuccess {
                _isChatBlocked.value = true
                _userMessage.value = "Host blocked. You can no longer send messages."
            }
        }
    }

    // TOP UP (Server-authoritative flow prepared)
    fun purchaseCoinPackage(pkg: CoinPackage) {
        _userMessage.value = "Payment checkout for ${pkg.coins} Coins (₹${pkg.priceInr.toInt()}) prepared."
    }

    // ====================================================
    // SOCIAL MEDIA MODULE ACTIONS
    // ====================================================

    fun refreshSocialFeed(isRefresh: Boolean = false) {
        if (isRefresh) {
            _isRefreshingSocial.value = true
        } else {
            _isLoadingSocial.value = true
        }

        viewModelScope.launch {
            try {
                dataService.ensureSocialProfile()

                val storiesResult = dataService.getSocialStories()
                storiesResult.onSuccess { stories ->
                    _socialStories.value = stories
                }

                val feedResult = dataService.getSocialFeed(page = 0, limit = 30)
                feedResult.onSuccess { posts ->
                    _socialPosts.value = posts
                }
            } catch (_: Exception) {
            } finally {
                _isLoadingSocial.value = false
                _isRefreshingSocial.value = false
            }
        }
    }

    fun loadMySocialProfile() {
        val currentUserId = sessionManager.userId.value ?: return
        viewModelScope.launch {
            dataService.ensureSocialProfile()
            dataService.getSocialProfile(currentUserId).onSuccess { profile ->
                val postsRes = dataService.getUserSocialPosts(currentUserId).getOrDefault(emptyList())
                val storiesRes = dataService.getUserSocialStories(currentUserId).getOrDefault(emptyList())
                _mySocialProfile.value = profile.copy(
                    posts = postsRes,
                    stories = storiesRes
                )
            }
        }
    }

    fun openSocialProfile(userId: String) {
        val currentUserId = sessionManager.userId.value ?: ""
        val targetId = if (userId.isBlank()) currentUserId else userId
        _isLoadingSocialProfile.value = true
        _currentScreen.value = Screen.SOCIAL_PROFILE

        viewModelScope.launch {
            dataService.getSocialProfile(targetId).onSuccess { profile ->
                val postsRes = dataService.getUserSocialPosts(targetId).getOrDefault(emptyList())
                val storiesRes = dataService.getUserSocialStories(targetId).getOrDefault(emptyList())
                val completeProfile = profile.copy(
                    posts = postsRes,
                    stories = storiesRes
                )
                _viewedSocialProfile.value = completeProfile
                if (targetId == currentUserId) {
                    _mySocialProfile.value = completeProfile
                }
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Could not load social profile."
            }
            _isLoadingSocialProfile.value = false
        }
    }

    fun closeSocialProfile() {
        _viewedSocialProfile.value = null
        _currentScreen.value = Screen.SOCIAL
    }

    fun updateMySocialProfile(
        bio: String,
        hobbies: String,
        avatarFile: File?,
        onComplete: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = dataService.updateSocialProfile(bio, hobbies, avatarFile)
            result.onSuccess {
                loadMySocialProfile()
                _userMessage.value = "Social Profile updated successfully!"
                onComplete(true, null)
            }.onFailure { err ->
                val msg = err.message ?: "Failed to update social profile"
                _userMessage.value = msg
                onComplete(false, msg)
            }
        }
    }

    fun searchSocialUser(query: String) {
        val clean = query.trim()
        if (clean.isBlank()) {
            _socialSearchError.value = "Please enter a User ID"
            return
        }
        _isSearchingSocial.value = true
        _socialSearchError.value = null
        _socialSearchResult.value = null

        viewModelScope.launch {
            val res = dataService.searchSocialProfile(clean)
            res.onSuccess { result ->
                _socialSearchResult.value = result
            }.onFailure { err ->
                _socialSearchError.value = err.message ?: "No host found with this User ID."
            }
            _isSearchingSocial.value = false
        }
    }

    fun clearSocialSearch() {
        _socialSearchResult.value = null
        _socialSearchError.value = null
        _isSearchingSocial.value = false
    }

    fun openStoryViewer(story: SocialStory) {
        _activeStoryViewer.value = story
        // Track view
        viewModelScope.launch {
            dataService.viewSocialContent("story", story.id)
            dataService.fetchWallet() // Authoritative balance update
            // Mark story as viewed locally
            _socialStories.value = _socialStories.value.map {
                if (it.id == story.id) it.copy(isViewed = true, viewsCount = it.viewsCount + 1) else it
            }
        }
    }

    fun closeStoryViewer() {
        _activeStoryViewer.value = null
    }

    fun createStory(
        mediaFile: File,
        caption: String,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < 10) {
            _userMessage.value = "You need 10 coins to post a Story. Please top up."
            _currentScreen.value = Screen.WALLET
            onComplete(false, "Insufficient balance (10 coins required)")
            return
        }

        viewModelScope.launch {
            val res = dataService.createSocialContent("story", mediaFile, caption)
            res.onSuccess {
                dataService.fetchWallet()
                refreshSocialFeed()
                loadMySocialProfile()
                _userMessage.value = "Story posted successfully! (10 Coins)"
                onComplete(true, null)
            }.onFailure { err ->
                val msg = err.message ?: "Failed to create story"
                _userMessage.value = msg
                onComplete(false, msg)
            }
        }
    }

    fun createPost(
        mediaFile: File,
        caption: String,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < 20) {
            _userMessage.value = "You need 20 coins to create a Post. Please top up."
            _currentScreen.value = Screen.WALLET
            onComplete(false, "Insufficient balance (20 coins required)")
            return
        }

        viewModelScope.launch {
            val res = dataService.createSocialContent("post", mediaFile, caption)
            res.onSuccess {
                dataService.fetchWallet()
                refreshSocialFeed()
                loadMySocialProfile()
                _userMessage.value = "Post created successfully! (20 Coins)"
                onComplete(true, null)
            }.onFailure { err ->
                val msg = err.message ?: "Failed to create post"
                _userMessage.value = msg
                onComplete(false, msg)
            }
        }
    }

    fun toggleLikePost(post: SocialPost) {
        val currentlyLiked = post.isLiked
        val newLiked = !currentlyLiked
        val delta = if (newLiked) 1 else -1

        // Optimistic UI update
        _socialPosts.value = _socialPosts.value.map {
            if (it.id == post.id) it.copy(isLiked = newLiked, likesCount = maxOf(0, it.likesCount + delta)) else it
        }

        viewModelScope.launch {
            val res = dataService.toggleSocialLike("post", post.id)
            if (res.isSuccess) {
                dataService.fetchWallet()
            }
        }
    }

    fun toggleLikeStory(story: SocialStory) {
        val currentlyLiked = story.isLiked
        val newLiked = !currentlyLiked
        val delta = if (newLiked) 1 else -1

        // Optimistic UI update
        val updatedStory = story.copy(isLiked = newLiked, likesCount = maxOf(0, story.likesCount + delta))
        _activeStoryViewer.value = updatedStory
        _socialStories.value = _socialStories.value.map {
            if (it.id == story.id) updatedStory else it
        }

        viewModelScope.launch {
            val res = dataService.toggleSocialLike("story", story.id)
            if (res.isSuccess) {
                dataService.fetchWallet()
            }
        }
    }

    fun unlockPost(post: SocialPost) {
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < 3) {
            _userMessage.value = "You need 3 coins to unlock this post. Please top up."
            _currentScreen.value = Screen.WALLET
            return
        }

        viewModelScope.launch {
            val res = dataService.unlockSocialPost(post.id)
            res.onSuccess {
                dataService.fetchWallet()
                _socialPosts.value = _socialPosts.value.map {
                    if (it.id == post.id) it.copy(isUnlocked = true) else it
                }
                _userMessage.value = "Post unlocked! (3 Coins)"
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to unlock post."
            }
        }
    }

    fun openCommentsForPost(post: SocialPost) {
        _activeCommentsPost.value = post
        _activeCommentsStory.value = null
        _socialComments.value = emptyList()
        _isLoadingComments.value = true

        viewModelScope.launch {
            dataService.getSocialComments("post", post.id).onSuccess { list ->
                _socialComments.value = list
            }
            _isLoadingComments.value = false
        }
    }

    fun openCommentsForStory(story: SocialStory) {
        _activeCommentsStory.value = story
        _activeCommentsPost.value = null
        _socialComments.value = emptyList()
        _isLoadingComments.value = true

        viewModelScope.launch {
            dataService.getSocialComments("story", story.id).onSuccess { list ->
                _socialComments.value = list
            }
            _isLoadingComments.value = false
        }
    }

    fun closeComments() {
        _activeCommentsPost.value = null
        _activeCommentsStory.value = null
        _socialComments.value = emptyList()
    }

    fun addCommentToActivePost(commentText: String) {
        val post = _activeCommentsPost.value ?: return
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < 3) {
            _userMessage.value = "You need 3 coins to comment. Please top up."
            _currentScreen.value = Screen.WALLET
            return
        }

        viewModelScope.launch {
            val res = dataService.addSocialComment("post", post.id, commentText)
            res.onSuccess { newComment ->
                dataService.fetchWallet()
                _socialComments.value = _socialComments.value + newComment
                _socialPosts.value = _socialPosts.value.map {
                    if (it.id == post.id) it.copy(commentsCount = it.commentsCount + 1) else it
                }
                _userMessage.value = "Comment posted! (3 Coins)"
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to post comment."
            }
        }
    }

    fun addCommentToActiveStory(commentText: String) {
        val story = _activeCommentsStory.value ?: _activeStoryViewer.value ?: return
        val currentBalance = wallet.value?.balance ?: 0
        if (currentBalance < 3) {
            _userMessage.value = "You need 3 coins to reply to a story. Please top up."
            _currentScreen.value = Screen.WALLET
            return
        }

        viewModelScope.launch {
            val res = dataService.addSocialComment("story", story.id, commentText)
            res.onSuccess { newComment ->
                dataService.fetchWallet()
                _socialComments.value = _socialComments.value + newComment
                _userMessage.value = "Reply sent! (3 Coins)"
            }.onFailure { err ->
                _userMessage.value = err.message ?: "Failed to send reply."
            }
        }
    }

    fun toggleSocialFollow(targetUserId: String) {
        viewModelScope.launch {
            val res = dataService.toggleSocialFollow(targetUserId)
            res.onSuccess { isFollowing ->
                // Update viewed social profile if matching
                _viewedSocialProfile.value?.let { currentProfile ->
                    if (currentProfile.userId == targetUserId) {
                        _viewedSocialProfile.value = currentProfile.copy(
                            isFollowing = isFollowing,
                            followersCount = if (isFollowing) currentProfile.followersCount + 1 else maxOf(0, currentProfile.followersCount - 1)
                        )
                    }
                }
                // Update partners list if matching
                _availablePartners.value = _availablePartners.value.map {
                    if (it.id == targetUserId || it.userId == targetUserId) {
                        it.copy(
                            isFollowing = isFollowing,
                            followersCount = if (isFollowing) it.followersCount + 1 else maxOf(0, it.followersCount - 1)
                        )
                    } else it
                }
            }
        }
    }

    fun startCallFromSocial(partner: PartnerProfile) {
        requestCall(partner)
    }

    override fun onCleared() {
        super.onCleared()
        callTimerJob?.cancel()
        realtimeManager.destroy()
        agoraCallManager.destroy()
        audioPlayerManager.stop()
        audioRecorderManager.release()
    }
}

enum class Screen {
    AUTH,
    HOME,
    HOST_PROFILE,
    ACTIVE_CALL,
    DIRECT_CHAT,
    BAATLY_SYSTEM_CHAT,
    CHAT_LIST,
    WALLET,
    RECENT_CALLS,
    PROFILE,
    NOTIFICATIONS,
    SOCIAL,
    SOCIAL_PROFILE
}

enum class HomeMode {
    CALL,
    CHAT
}

enum class CallState {
    IDLE,
    REQUESTING,
    RINGING,
    CONNECTED,
    ENDED
}

