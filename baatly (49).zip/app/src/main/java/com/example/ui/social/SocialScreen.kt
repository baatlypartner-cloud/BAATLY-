package com.example.ui.social

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.PartnerProfile
import com.example.data.model.SocialPost
import com.example.data.model.SocialSearchResult
import com.example.data.model.SocialStory
import com.example.ui.BaatlyViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(
    viewModel: BaatlyViewModel
) {
    val posts by viewModel.socialPosts.collectAsState()
    val stories by viewModel.socialStories.collectAsState()
    val isLoadingFeed by viewModel.isLoadingSocial.collectAsState()
    val isRefreshing by viewModel.isRefreshingSocial.collectAsState()
    val wallet by viewModel.wallet.collectAsState()
    val myProfile by viewModel.mySocialProfile.collectAsState()
    val activeStoryViewer by viewModel.activeStoryViewer.collectAsState()
    val activePostViewer by viewModel.activePostViewer.collectAsState()
    val activeCommentsPost by viewModel.activeCommentsPost.collectAsState()
    val socialComments by viewModel.socialComments.collectAsState()
    val isLoadingComments by viewModel.isLoadingComments.collectAsState()
    val searchResult by viewModel.socialSearchResult.collectAsState()
    val isSearching by viewModel.isSearchingSocial.collectAsState()
    val searchError by viewModel.socialSearchError.collectAsState()

    var showCreateSheet by remember { mutableStateOf(false) }
    var isSearchExpanded by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val userCoins = wallet?.balance ?: 0

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Social Top Bar
            SocialHeaderBar(
                coinBalance = userCoins,
                myAvatarUrl = myProfile?.socialAvatarUrl,
                isRefreshing = isRefreshing,
                onRefreshClick = { viewModel.refreshSocialFeed(isRefresh = true) },
                onCoinClick = { viewModel.setScreen(Screen.WALLET) },
                onSearchToggle = {
                    isSearchExpanded = !isSearchExpanded
                    if (!isSearchExpanded) {
                        viewModel.clearSocialSearch()
                        searchQuery = ""
                    }
                },
                onCreateClick = { showCreateSheet = true },
                onProfileClick = {
                    val myId = viewModel.sessionManager.userId.value ?: ""
                    viewModel.openSocialProfile(myId)
                }
            )

            // Search Bar & Results Accordion
            AnimatedVisibility(
                visible = isSearchExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                SocialSearchSection(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    onSearch = { viewModel.searchSocialUser(searchQuery) },
                    onClear = {
                        searchQuery = ""
                        viewModel.clearSocialSearch()
                    },
                    isSearching = isSearching,
                    searchResult = searchResult,
                    searchError = searchError,
                    onViewProfile = { result ->
                        viewModel.openSocialProfile(result.userId)
                    },
                    onCallHost = { partner ->
                        viewModel.startCallFromSocial(partner)
                    }
                )
            }

            // Main Feed with Stories & Posts
            PullToRefreshBox(
                isRefreshing = isRefreshing,
                onRefresh = { viewModel.refreshSocialFeed(isRefresh = true) },
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    // Stories Horizontal Carousel
                    item {
                        StoriesSection(
                            stories = stories,
                            myProfile = myProfile,
                            onAddStory = { showCreateSheet = true },
                            onStoryClick = { story ->
                                viewModel.openStoryViewer(story)
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // Feed State
                    if (isLoadingFeed && posts.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(280.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = VibrantPink)
                            }
                        }
                    } else if (posts.isEmpty()) {
                        item {
                            EmptyFeedCard(onCreatePost = { showCreateSheet = true })
                        }
                    } else {
                        items(posts, key = { it.id }) { post ->
                            SocialPostCard(
                                post = post,
                                onLike = { viewModel.toggleLikePost(post) },
                                onComment = { viewModel.openCommentsForPost(post) },
                                onUnlock = { viewModel.unlockPost(post) },
                                onMediaClick = {
                                    if (post.isUnlocked || !post.isOwnerHost) {
                                        viewModel.openPostViewer(post)
                                    } else {
                                        viewModel.unlockPost(post)
                                    }
                                },
                                onAuthorClick = {
                                    viewModel.openSocialProfile(post.ownerId)
                                },
                                onCallHost = { partner ->
                                    viewModel.startCallFromSocial(partner)
                                }
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                        }
                    }
                }
            }
        }

        // Create Story / Post Sheet
        if (showCreateSheet) {
            CreateSocialContentSheet(
                userCoinBalance = userCoins,
                onDismiss = { showCreateSheet = false },
                onSubmitStory = { file, caption ->
                    viewModel.createStory(file, caption) { success, _ ->
                        if (success) showCreateSheet = false
                    }
                },
                onSubmitPost = { file, caption ->
                    viewModel.createPost(file, caption) { success, _ ->
                        if (success) showCreateSheet = false
                    }
                }
            )
        }

        // Active Comments Sheet
        if (activeCommentsPost != null) {
            SocialCommentsSheet(
                title = "Comments (${activeCommentsPost?.commentsCount ?: 0})",
                comments = socialComments,
                isLoading = isLoadingComments,
                userCoinBalance = userCoins,
                onDismiss = { viewModel.closeComments() },
                onSendComment = { text -> viewModel.addCommentToActivePost(text) }
            )
        }

        // Full Screen Story Viewer
        if (activeStoryViewer != null) {
            StoryViewerModal(
                story = activeStoryViewer!!,
                onClose = { viewModel.closeStoryViewer() },
                onLikeStory = { viewModel.toggleLikeStory(activeStoryViewer!!) },
                onReplyStory = { text -> viewModel.addCommentToActiveStory(text) },
                onCallHost = { partner -> viewModel.startCallFromSocial(partner) }
            )
        }

        // Full Screen Post Viewer
        if (activePostViewer != null) {
            PostImageViewerModal(
                post = activePostViewer!!,
                onClose = { viewModel.closePostViewer() },
                onLikePost = { viewModel.toggleLikePost(activePostViewer!!) },
                onOpenComments = {
                    val currentPost = activePostViewer!!
                    viewModel.openCommentsForPost(currentPost)
                },
                onAuthorClick = {
                    val currentPost = activePostViewer
                    if (currentPost != null) {
                        viewModel.closePostViewer()
                        viewModel.openSocialProfile(currentPost.ownerId)
                    }
                },
                onCallHost = { partner -> viewModel.startCallFromSocial(partner) }
            )
        }
    }
}

@Composable
private fun SocialHeaderBar(
    coinBalance: Int,
    myAvatarUrl: String?,
    isRefreshing: Boolean,
    onRefreshClick: () -> Unit,
    onCoinClick: () -> Unit,
    onSearchToggle: () -> Unit,
    onCreateClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    Surface(
        color = DarkBackground,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App / Social Title
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Baatly",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        fontSize = 22.sp
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                    color = VibrantPink,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "SOCIAL",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Actions Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Coin Pill
                Surface(
                    color = DarkSurfaceVariant,
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                    modifier = Modifier
                        .clickable { onCoinClick() }
                        .testTag("btn_social_coins")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MonetizationOn,
                            contentDescription = "Coins",
                            tint = CoinGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$coinBalance",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }

                // Refresh Button
                IconButton(
                    onClick = onRefreshClick,
                    enabled = !isRefreshing,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .testTag("btn_refresh_social")
                ) {
                    if (isRefreshing) {
                        CircularProgressIndicator(
                            color = VibrantPink,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh Social Feed",
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Search Toggle Button
                IconButton(
                    onClick = onSearchToggle,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .testTag("btn_toggle_social_search")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search Host",
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Create Post/Story Button (+)
                IconButton(
                    onClick = onCreateClick,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(VibrantPink, DarkPink)))
                        .testTag("btn_create_social_content")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Create",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Top-right Profile Avatar Icon (Opens USER'S SOCIAL PROFILE)
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, VibrantPink, CircleShape)
                        .clickable { onProfileClick() }
                        .testTag("btn_open_my_social_profile")
                ) {
                    if (!myAvatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = myAvatarUrl,
                            contentDescription = "My Social Profile",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(DarkSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = "My Social Profile",
                                tint = VibrantPink,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialSearchSection(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    onClear: () -> Unit,
    isSearching: Boolean,
    searchResult: SocialSearchResult?,
    searchError: String?,
    onViewProfile: (SocialSearchResult) -> Unit,
    onCallHost: (PartnerProfile) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkNavBackground)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Search Input Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkSurfaceVariant)
                .border(1.dp, DarkCardBorder, RoundedCornerShape(20.dp))
                .padding(horizontal = 12.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Search",
                tint = TextTertiary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            TextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = {
                    Text("Search Host by User ID (e.g. host123)...", color = TextTertiary, fontSize = 13.sp)
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_search_host_id"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = VibrantPink
                ),
                singleLine = true
            )

            if (query.isNotBlank()) {
                IconButton(onClick = onClear, modifier = Modifier.size(28.dp)) {
                    Icon(imageVector = Icons.Filled.Close, contentDescription = "Clear", tint = TextTertiary, modifier = Modifier.size(16.dp))
                }
            }

            Button(
                onClick = onSearch,
                colors = ButtonDefaults.buttonColors(containerColor = VibrantPink),
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(32.dp)
                    .testTag("btn_submit_search_host")
            ) {
                if (isSearching) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(14.dp), strokeWidth = 1.5.dp)
                } else {
                    Text("Find", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Role Search Notice
        Text(
            text = "Notice: Users can only search and view Host profiles.",
            fontSize = 11.sp,
            color = TextTertiary,
            modifier = Modifier.padding(top = 4.dp, start = 4.dp)
        )

        // Error message if any
        if (searchError != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = ErrorRed.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = searchError,
                    color = ErrorRed,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }

        // Found Host Card
        if (searchResult != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCardBackground),
                border = androidx.compose.foundation.BorderStroke(1.dp, VibrantPink.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        // Avatar
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceVariant)
                        ) {
                            if (!searchResult.avatarUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = searchResult.avatarUrl,
                                    contentDescription = searchResult.displayName,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = (searchResult.displayName ?: "H").take(1).uppercase(),
                                        color = VibrantPink,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                }
                            }
                        }

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = searchResult.displayName ?: "Host",
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = VibrantPink,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "HOST",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            val handle = searchResult.publicHandle
                            if (handle.isNotBlank()) {
                                Text(
                                    text = "@$handle",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                            Text(
                                text = "${searchResult.followersCount} followers",
                                color = TextTertiary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Action buttons: View & Call
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { onViewProfile(searchResult) },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("Profile", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        val partnerToCall = searchResult.partner ?: com.example.data.model.PartnerProfile(
                            id = searchResult.userId,
                            userId = searchResult.signupUserId ?: searchResult.userId,
                            displayName = searchResult.displayName ?: "Host",
                            avatarUrl = searchResult.avatarUrl,
                            bio = searchResult.bio,
                            isOnline = true
                        )
                        Button(
                            onClick = { onCallHost(partnerToCall) },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(imageVector = Icons.Filled.Call, contentDescription = "Call", tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StoriesSection(
    stories: List<SocialStory>,
    myProfile: com.example.data.model.SocialProfile?,
    onAddStory: () -> Unit,
    onStoryClick: (SocialStory) -> Unit
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) {
        // "Your Story" item
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(68.dp)
                    .clickable { onAddStory() }
                    .testTag("btn_add_your_story")
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    if (!myProfile?.socialAvatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = myProfile?.socialAvatarUrl,
                            contentDescription = "Your profile",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = "Your profile",
                            tint = TextSecondary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Plus Badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(VibrantPink)
                            .border(1.5.dp, DarkBackground, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "Add Story",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your Story",
                    fontSize = 11.sp,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Active Stories Bubbles
        items(stories, key = { it.id }) { story ->
            StoryBubble(
                story = story,
                onClick = { onStoryClick(story) }
            )
        }
    }
}

@Composable
private fun StoryBubble(
    story: SocialStory,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(68.dp)
            .clickable { onClick() }
    ) {
        // Gradient Ring: Vibrant pink gradient if unviewed, subtle border if viewed
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(
                    if (!story.isViewed) Brush.sweepGradient(listOf(VibrantPink, DarkPink, VibrantPink))
                    else Brush.linearGradient(listOf(DarkCardBorder, DarkCardBorder))
                )
                .padding(2.5.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant)
            ) {
                if (!story.ownerAvatarUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = story.ownerAvatarUrl,
                        contentDescription = story.ownerDisplayName,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = (story.ownerDisplayName ?: "H").take(1).uppercase(),
                            color = VibrantPink,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = story.ownerDisplayName ?: "Host",
            fontSize = 11.sp,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun SocialPostCard(
    post: SocialPost,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onUnlock: () -> Unit,
    onMediaClick: () -> Unit,
    onAuthorClick: () -> Unit,
    onCallHost: (PartnerProfile) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCardBackground),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Post Author Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .clickable { onAuthorClick() }
                        .weight(1f)
                ) {
                    // Author Avatar
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceVariant)
                    ) {
                        if (!post.ownerAvatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = post.ownerAvatarUrl,
                                contentDescription = post.ownerDisplayName,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (post.ownerDisplayName ?: "U").take(1).uppercase(),
                                    color = VibrantPink,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = post.ownerDisplayName ?: "Host",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                            if (post.isOwnerHost) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = VibrantPink,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "HOST",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        val handle = post.publicHandle
                        if (handle.isNotBlank()) {
                            Text(
                                text = "@$handle",
                                color = TextTertiary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // If Author is a Host: Quick "Call Now" button!
                if (post.isOwnerHost && post.ownerPartner != null) {
                    Button(
                        onClick = { onCallHost(post.ownerPartner) },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(30.dp)
                            .testTag("btn_call_host_${post.id}")
                    ) {
                        Icon(imageVector = Icons.Filled.Call, contentDescription = "Call Host", tint = Color.White, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call Now", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Post Media Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 220.dp, max = 360.dp)
                    .background(DarkSurfaceVariant)
                    .clickable { onMediaClick() },
                contentAlignment = Alignment.Center
            ) {
                if (!post.resolvedMediaUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = post.resolvedMediaUrl,
                        contentDescription = "Post image",
                        modifier = Modifier.fillMaxWidth(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .background(DarkSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.BrokenImage,
                                contentDescription = "Media unavailable",
                                tint = TextSecondary,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Media unavailable",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Locked Host Post Overlay
                if (!post.isUnlocked && post.isOwnerHost) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.82f))
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = "Locked content",
                                tint = VibrantPink,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Exclusive Host Post",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Unlock this post to see full content",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 12.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = onUnlock,
                                colors = ButtonDefaults.buttonColors(containerColor = VibrantPink),
                                shape = RoundedCornerShape(14.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                modifier = Modifier.testTag("btn_unlock_post_${post.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LockOpen,
                                    contentDescription = "Unlock",
                                    tint = CoinGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Unlock for 3 Coins",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            // Post Interaction Bar (Likes & Comments)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Like Action
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { onLike() }
                            .testTag("btn_like_post_${post.id}")
                    ) {
                        Icon(
                            imageVector = if (post.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (post.isLiked) VibrantPink else TextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${post.likesCount}",
                            color = if (post.isLiked) VibrantPink else TextSecondary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }

                    // Comment Action
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { onComment() }
                            .testTag("btn_comment_post_${post.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = "Comment",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${post.commentsCount}",
                            color = TextSecondary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }

                // Unlock Status Tag
                if (post.isUnlocked && post.isOwnerHost) {
                    Surface(
                        color = SuccessGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = "Unlocked",
                            color = SuccessGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Post Caption
            if (!post.caption.isNullOrBlank()) {
                Text(
                    text = post.caption,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
private fun EmptyFeedCard(onCreatePost: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkCardBackground),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Filled.Explore,
                contentDescription = "Explore",
                tint = VibrantPink,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Welcome to Baatly Social",
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Follow Hosts and share your daily moments with the community!",
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onCreatePost,
                colors = ButtonDefaults.buttonColors(containerColor = VibrantPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = "Create", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Create First Post", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}
